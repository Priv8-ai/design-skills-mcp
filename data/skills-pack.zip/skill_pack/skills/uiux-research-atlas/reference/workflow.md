# Workflows

Four procedures. Pick the one matching the request; each ends with a deliverable
shape, not a vibe.

Set `S` once per session:

```bash
S=".claude/skills/uiux-research-atlas"   # or ~/.claude/skills/uiux-research-atlas
```

---

## 1. Direction brief — "design a landing page / app for X"

**Input:** a product, audience, or surface. **Output:** one committed direction
with cited evidence and named risks.

1. **Product truth, no visual language.** Write audience, primary job, primary
   action, hard constraints (regulatory, device, locale, data), and the one
   differentiator. If the user did not supply these, state your assumptions
   explicitly rather than asking for all five.
2. **Select the archetype.** Read the pattern-selection matrix in
   `patterns.md` (§ Pattern-selection matrix) and the matching archetype row in
   § Web archetypes or § Mobile archetypes. Record its anatomy, signature
   opportunity, and guardrail verbatim — the guardrail becomes an acceptance
   criterion later.
3. **Pull evidence from at least three different creators**, ideally across
   surfaces (a web navigation spine + a mobile precision layer + a motion study):

   ```bash
   python3 $S/scripts/atlas.py search <domain terms> --kind web --limit 6
   python3 $S/scripts/atlas.py search <interaction terms> --kind mobile --limit 6
   python3 $S/scripts/atlas.py search <motif> --kind motion --limit 4
   python3 $S/scripts/atlas.py show <id> --analysis     # for the 3 you keep
   ```

4. **Specify the system**, not adjectives:
   - Palette family from `patterns.md` § Palette families + a measured anchor
     (`atlas.py palette --max-luminance 0.2` / `--min-luminance 0.7`). Emit
     semantic tokens — surface, text, action, success, warning, danger, focus —
     before any theme mockup. Dark mode is authored, never inverted.
   - Type: one display voice + one utility voice, at most six roles, tabular
     figures wherever numbers are compared.
   - Layout model from § Layout models, with its responsive transformation.
   - Navigation grammar from § Navigation patterns, with the required fallback.
   - One signature motion motif with its job, duration band from § Motion jobs
     and token ladder, and its reduced-motion substitution.
5. **Apply the originality protocol** (`patterns.md` § Originality protocol):
   change metaphor, content model, grid proportions, type pairing, palette, icon
   family, silhouette, and choreography relative to every source.
6. **Design the unglamorous states**: empty, loading, error, offline, permission,
   keyboard, destructive confirmation, receipt, reduced motion, no-WebGL,
   return visit. A direction without these is not a direction.
7. **Deliver** as: direction statement → archetype + guardrails → cited
   references (`ID (title) — what it demonstrates`) → token/type/layout/motion
   spec → state inventory → validation still owed.

---

## 2. Reference pull — "find references for X"

**Output:** a ranked short list, each with a lesson and a guardrail. Not a link dump.

```bash
python3 $S/scripts/atlas.py search <terms> --kind <web|mobile|motion> --limit 8
python3 $S/scripts/atlas.py similar <id>          # widen from a good hit
python3 $S/scripts/atlas.py show <id> --analysis  # depth on the keepers
```

For each kept reference report: ID + title, source URL, what it demonstrates,
the adaptation lesson, the risk/accessibility caveat from the record, and the
preview status (14 records have no local preview — never invent imagery).

Prefer 4–6 references from different creators over 15 from one platform. If every
hit comes from one platform, say so — it is a sampling artifact of the corpus,
not a signal about the pattern.

---

## 3. Palette / type / motion spec — "give me tokens for X"

1. Choose the palette family from `patterns.md` § Palette families by product
   context, not by taste.
2. Anchor it in measured data:

   ```bash
   python3 $S/scripts/atlas.py palette --kind mobile --max-luminance 0.2 --limit 10
   python3 $S/scripts/atlas.py palette --temperature warm --min-luminance 0.7
   ```

   Palette entries carry pixel shares — the top-share hex is the surface, not the
   accent. Aim near 60/30/10 base/support/accent, then tune to content.
3. Emit semantic tokens with light and dark values authored independently, plus
   contrast ratios for text and non-text UI. State which pairs you verified and
   which still need a checker.
4. Type: display + utility voice, ≤6 roles, tabular figures for money/medical/
   timer/analytics values, and a note on Dynamic Type, 200% zoom, long
   translations, and RTL.
5. Motion: for each animation name the job (confirm / explain local state /
   preserve continuity / hand off a chapter / ambient), its duration band from
   the token ladder, and its reduced-motion substitution. An animation without a
   named job gets cut.

---

## 4. Direction critique — "review this design / is this a good idea"

1. Identify the archetype the design is actually using, and whether it matches
   the product context in the pattern-selection matrix.
2. Run the anti-pattern list (`patterns.md` § Anti-patterns) as a checklist.
   Report hits by name — award-site soup, 3D without an answer, canvas monopoly,
   scroll capture, spatial amnesia, card soup, dashboard theatre, AI orb as
   product, high-stakes flourish, hover dependency, theme inversion, motion
   plagiarism, performance optimism, showcase-as-validation.
3. Run the two tests from § Originality protocol: **silhouette test** (blur color
   and imagery — is hierarchy still clear?) and **motion removal** (is the flow
   still complete?).
4. Check novelty budget: more than one signature spatial/motion system per
   viewport is the finding.
5. Check the high-stakes rule: expressiveness must decrease approaching auth,
   payment, consent, destructive actions, medical escalation, and error recovery.
6. Report findings most-severe first, each with the anti-pattern name, where it
   occurs, and the concrete replacement — not just the objection.

---

## Citation format

Use this shape whenever the corpus backs a claim:

> `web-032 (Huly)` — SaaS conversion narrative with product-state transitions;
> guardrail: the product screenshot must tell one specific, readable story.
> Evidence level: showcase cue — no data on conversion or task success.

Never cite a record without saying what it demonstrates, and never state a
guardrail-free recommendation.
