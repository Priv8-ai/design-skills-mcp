# Rights and Provenance

## Purpose

This atlas is a private design-research reference. Screenshots and previews remain third-party works associated with their original creators and platforms. Inclusion does not grant a production, resale, publication, trademark, or redistribution license.

## Provenance chain

- Every record retains its public source-page URL.
- Local preview paths map to the original research catalogs.
- Original catalogs, notes, and measurement reports are preserved unchanged under data/raw.
- data/asset_manifest.json records SHA-256 hashes, byte sizes, and source-relative paths.
- Records without a preview are labeled; no substitute imagery was fabricated.
- Automatically measured palettes and dimensions describe the retained preview only.

## Permitted research use

Study hierarchy, spacing, colour relationships, interaction pacing, responsive structure, component behavior, and motion grammar. Create a new implementation with original copy, brand assets, imagery, icons, code, and composition.

## Before public or commercial use

Confirm platform terms and creator licenses for any pixel asset you intend to reuse. Obtain permission where required. Do not remove credits, imply endorsement, clone distinctive artwork, reproduce protected branding, or redistribute this collection as a stock or template pack.

## Accuracy boundaries

The catalogs were assembled from publicly accessible source pages without bypassing login walls. Some entries describe showcase claims rather than verified live implementation. Accessibility, performance, technical stack, interaction quality, and licensing must be evaluated independently.

## Recommended practice

Transform principles rather than pixels. Combine multiple references, document the reasoning, and validate keyboard, screen-reader, touch, contrast, reduced-motion, responsive, loading, and low-power behavior in the new product.
