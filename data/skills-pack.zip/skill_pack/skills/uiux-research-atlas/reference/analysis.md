# UI/UX Design Analysis

This document covers every normalized record: 38 web, 39 mobile, and 24 motion exemplars. Observations come from the local catalogs; unavailable previews and undocumented properties are stated explicitly.

Measured image properties describe the downloaded preview, not necessarily the complete live product. All third-party imagery is for attributed research reference only.

# Web references (38)

## W01 · Lusion v3

| Field | Detail |
|---|---|
| ID | web-001 |
| Platform | Awwwards |
| Creator | Lusion |
| Reference date | Not documented in the source corpus. |
| Preview | Downloaded local preview |
| Source | [Lusion v3](https://www.awwwards.com/sites/lusion-v3) |

![Lusion v3](assets/web/images/01_awwwards_lusion_v3.jpg)

**Design focus.** agency portfolio, 3D, interactive, light shell

**Elements.** framed WebGL hero, minimal pill navigation, scroll cue, project gallery, reactive cursor

**Colour.** Catalogued dominant colours: #15171F, #EEEEF6, #1A2FFB. Catalog palette: #15171F, #EEEEF6, #1A2FFB Measured preview palette: #13161F, #F1F1FB, #2B347B, #131419, #8A8B95, #EFEFF9, #121533, #FBFBFE

**Image evidence.** assets/web/images/01_awwwards_lusion_v3.jpg — 1600×1200 JPEG; near-square; cool; low visual density.

**Typography.** Compact neo-grotesk labels and a restrained sentence-case headline keep the interface quiet beside the 3D art.

**Layout and hierarchy.** A pale editorial frame wraps a large dark interactive viewport; micro-navigation sits in the corners and generous margins act like a gallery mat.

**Navigation.** Navigation details are included in the layout and component notes where documented.

**Motion and interaction.** Map scroll to camera orbit and object separation, use pointer parallax for shallow depth, and transition project views by morphing the 3D cluster rather than cutting scenes.

**Why it works.** The heavy visual computation is contained inside a simple, legible shell, so spectacle never destroys orientation.

**Adaptation lesson.** Give one immersive object a disciplined stage; keep navigation, copy and controls visually calmer than the hero.

**Accessibility / risk check.** Not evaluated by the source corpus; validate keyboard access, focus, contrast, reduced motion, and a non-WebGL fallback.

**Provenance note.** Awwwards project page and first-party public preview; palette cross-checked against the page and local visual inspection.

## W02 · Bruno's Portfolio

| Field | Detail |
|---|---|
| ID | web-002 |
| Platform | Awwwards |
| Creator | Bruno Simon |
| Reference date | Not documented in the source corpus. |
| Preview | Downloaded local preview |
| Source | [Bruno's Portfolio](https://www.awwwards.com/sites/brunos-portfolio) |

![Bruno's Portfolio](assets/web/images/02_awwwards_bruno_simon.png)

**Design focus.** portfolio, playable 3D world, experimental navigation

**Elements.** driveable avatar, 3D environment, spatial project landmarks, contextual prompts, playful onboarding

**Colour.** Catalogued dominant colours: #F79252, #9A6B2D, #A7454B, #6AAE52. Catalog palette: #F79252, #9A6B2D, #A7454B, #6AAE52 Measured preview palette: #FB8C4E, #B4743E, #F79553, #6E5647, #6C2757, #EEAE95, #B6424F, #BA8743

**Image evidence.** assets/web/images/02_awwwards_bruno_simon.png — 1600×1200 PNG; near-square; warm; high visual density.

**Typography.** Friendly oversized 3D lettering and compact utility text reinforce the toy-world character.

**Layout and hierarchy.** The website is the world: a drivable isometric landscape replaces conventional sections, with destinations functioning as portfolio chapters.

**Navigation.** Navigation details are included in the layout and component notes where documented.

**Motion and interaction.** Use velocity-aware camera follow, springy collisions, environmental animation and cinematic camera handoffs when a landmark is entered.

**Why it works.** Navigation becomes an authored experience with a clear spatial metaphor and immediate emotional identity.

**Adaptation lesson.** Only use game-like navigation when the brand can support it; add shortcuts and accessible alternatives for task-focused visitors.

**Accessibility / risk check.** Not evaluated by the source corpus; validate keyboard access, focus, contrast, reduced motion, and a non-WebGL fallback.

**Provenance note.** Awwwards SOTD page and public submission preview.

## W03 · Joshua's World

| Field | Detail |
|---|---|
| ID | web-003 |
| Platform | Awwwards |
| Creator | Joshua von Hofen |
| Reference date | Not documented in the source corpus. |
| Preview | Downloaded local preview |
| Source | [Joshua's World](https://www.awwwards.com/sites/joshuas-world) |

![Joshua's World](assets/web/images/03_awwwards_joshuas_world.jpg)

**Design focus.** portfolio, 3D island, dark mode, story journey

**Elements.** intro gate, dark/light theme, 3D island map, discoverable facts, project hotspots

**Colour.** Catalogued dominant colours: #020202, #23008E, #757BFD, #FF6464. Catalog palette: #020202, #23008E, #757BFD, #FF6464 Measured preview palette: #000000, #020202, #6D6B76, #BCBCBD, #121212, #F8F8F8, #4528B0, #000002

**Image evidence.** assets/web/images/03_awwwards_joshuas_world.jpg — 1600×1200 JPEG; near-square; balanced; low visual density.

**Typography.** Bold white sans-serif display type with a purple pill CTA; short centered copy keeps the dark scene readable.

**Layout and hierarchy.** A conventional welcome panel acts as an entry portal to an explorable island, balancing onboarding clarity with unusual navigation.

**Navigation.** Navigation details are included in the layout and component notes where documented.

**Motion and interaction.** Animate a zoom-through transition from flat intro to spatial world; use guided camera rails with optional free exploration.

**Why it works.** It delays complexity until intent is established, reducing the confusion common to spatial portfolios.

**Adaptation lesson.** Provide a clear first action and visible progress before asking users to learn a novel navigation model.

**Accessibility / risk check.** Not evaluated by the source corpus; validate keyboard access, focus, contrast, reduced motion, and a non-WebGL fallback.

**Provenance note.** Awwwards SOTD page, documented three-color palette and public preview.

## W04 · CANALS

| Field | Detail |
|---|---|
| ID | web-004 |
| Platform | Awwwards |
| Creator | Marcus Brown and Aristide Benoist |
| Reference date | Not documented in the source corpus. |
| Preview | Downloaded local preview |
| Source | [CANALS](https://www.awwwards.com/sites/canals) |

![CANALS](assets/web/images/04_awwwards_canals.jpg)

**Design focus.** editorial, culture, horizontal layout, parallax

**Elements.** full-bleed historical imagery, side-menu transition, horizontal story rail, chapter index, circular control

**Colour.** Catalogued dominant colours: #6292B5, #D14836, #000000, #FFFFFF. Catalog palette: #6292B5, #D14836, #000000, #FFFFFF Measured preview palette: #5288B1, #9DB7C2, #342C23, #729EBA, #7FA7BF, #AE1411, #96AEB7, #718999

**Image evidence.** assets/web/images/04_awwwards_canals.jpg — 1290×700 JPEG; landscape; cool; low visual density.

**Typography.** Custom editorial display lettering pairs with narrow explanatory copy, evoking a cultural magazine rather than a brochure.

**Layout and hierarchy.** Fullscreen photography, oversized cropped headings and horizontal narrative panels create a chaptered visual essay.

**Navigation.** Navigation details are included in the layout and component notes where documented.

**Motion and interaction.** Translate vertical wheel input into horizontal travel, add restrained image depth and synchronize title masks to section progress.

**Why it works.** A strong red accent and typographic rhythm make a dense historical story feel navigable and memorable.

**Adaptation lesson.** For editorial experiences, let rhythm and chaptering drive motion; avoid adding 3D where typography and photography already carry depth.

**Accessibility / risk check.** Not evaluated by the source corpus; validate keyboard access, focus, contrast, reduced motion, and a non-WebGL fallback.

**Provenance note.** Awwwards SOTD page, documented palette and public preview.

## W05 · Above the Clouds - 111 W 57

| Field | Detail |
|---|---|
| ID | web-005 |
| Platform | Awwwards |
| Creator | Outpost, Jesper Landberg and Samuel Honigstein |
| Reference date | Not documented in the source corpus. |
| Preview | Downloaded local preview |
| Source | [Above the Clouds - 111 W 57](https://www.awwwards.com/sites/above-the-clouds-111-w-57) |

![Above the Clouds - 111 W 57](assets/web/images/05_awwwards_above_clouds.png)

**Design focus.** luxury real estate, architecture, 3D, 360 tour

**Elements.** cloud fly-through intro, 3D tower reveal, room explorer, click-and-hold interaction, chapter scrubber

**Colour.** Catalogued dominant colours: #E1E3E4, #B3C6D6, #9CB4CA, #7C7262. Catalog palette: #E1E3E4, #B3C6D6, #9CB4CA, #7C7262 Measured preview palette: #AEC2D5, #EBEAE9, #F3F2F0, #E3E4E3, #D5DCE1, #C5CFD6, #7996B7, #9EB5C9

**Image evidence.** assets/web/images/05_awwwards_above_clouds.png — 1600×1200 PNG; near-square; cool; low visual density.

**Typography.** Fine high-contrast serif and tiny spaced labels communicate exclusivity without competing with the skyline.

**Layout and hierarchy.** A misty cinematic canvas holds a distant tower, sparse floating copy, a lower-right chapter controller and near-invisible navigation.

**Navigation.** Navigation details are included in the layout and component notes where documented.

**Motion and interaction.** Tie scroll to altitude, atmospheric density and architectural scale; use slow easing and long focal transitions to preserve the luxury tone.

**Why it works.** The page sells an emotional viewpoint before presenting floor plans or facts.

**Adaptation lesson.** Luxury motion should feel deliberate and low-frequency; build suspense through scale and atmosphere, not constant animation.

**Accessibility / risk check.** Not evaluated by the source corpus; validate keyboard access, focus, contrast, reduced motion, and a non-WebGL fallback.

**Provenance note.** Awwwards SOTD page, documented neutral palette and public preview.

## W06 · WONDERLAND

| Field | Detail |
|---|---|
| ID | web-006 |
| Platform | Awwwards |
| Creator | WONDERLAND |
| Reference date | Not documented in the source corpus. |
| Preview | Downloaded local preview |
| Source | [WONDERLAND](https://www.awwwards.com/sites/wonderlandams) |

![WONDERLAND](assets/web/images/06_awwwards_wonderland.jpg)

**Design focus.** agency, dark, motion sculpture, portfolio

**Elements.** animated 3D ribbon, minimal top navigation, portfolio hover states, experimental 404, dark canvas

**Colour.** Catalogued dominant colours: #261115, #4F2E2C, #654951, #B45BE0. Catalog palette: #261115, #4F2E2C, #654951, #B45BE0 Measured preview palette: #1B0E10, #250D0E, #321724, #1C0A0A, #261216, #300F1C, #704D60, #27131B

**Image evidence.** assets/web/images/06_awwwards_wonderland.jpg — 1290×700 JPEG; landscape; warm; low visual density.

**Typography.** Elegant serif headline over a tiny all-caps sans navigation creates a contemporary art-direction contrast.

**Layout and hierarchy.** A near-black full-screen hero centers a ribbon-like 3D form while navigation and metadata hug the outer frame.

**Navigation.** Navigation details are included in the layout and component notes where documented.

**Motion and interaction.** Let pointer movement bend the ribbon and reveal color; use the same geometry as a page-transition mask for continuity.

**Why it works.** One distinctive motion asset creates brand recall while the rest of the interface stays restrained.

**Adaptation lesson.** Build a reusable motion motif that can appear in hero, transitions, cursor and loading states instead of unrelated effects.

**Accessibility / risk check.** Not evaluated by the source corpus; validate keyboard access, focus, contrast, reduced motion, and a non-WebGL fallback.

**Provenance note.** Awwwards SOTD page and first-party preview.

## W07 · iyO

| Field | Detail |
|---|---|
| ID | web-007 |
| Platform | Awwwards |
| Creator | Matteo Donini, Federico and Enrico Deiana |
| Reference date | Not documented in the source corpus. |
| Preview | Downloaded local preview |
| Source | [iyO](https://www.awwwards.com/sites/iyo) |

![iyO](assets/web/images/07_awwwards_iyo.png)

**Design focus.** technology ecommerce, 3D product configurator, WebGL

**Elements.** exploded product view, adaptive menu and cart, dynamic color slider, procedural shader footer, sound controls

**Colour.** Catalogued dominant colours: #EBEBEB, #DEB0BC, #F9CEAC, #101010. Catalog palette: #EBEBEB, #DEB0BC, #F9CEAC, #101010 Measured preview palette: #E9E9E9, #EFEFEF, #EDEDED, #EEEEEE, #9C8A89, #F1F1F2, #EFEFEE, #EEEFEF

**Image evidence.** assets/web/images/07_awwwards_iyo.png — 1600×1200 PNG; near-square; balanced; low visual density.

**Typography.** Large geometric sans headlines use short line lengths; a tiny wordmark and utility labels keep the product dominant.

**Layout and hierarchy.** A bright tactile stage isolates two product objects with large negative space and minimal commerce controls.

**Navigation.** Navigation details are included in the layout and component notes where documented.

**Motion and interaction.** Use scroll to assemble and disassemble components, preserve chosen product state across scenes, and allow drag rotation only after a clear affordance.

**Why it works.** The 3D model explains construction and desirability at once, making motion functional rather than ornamental.

**Adaptation lesson.** For hardware, anchor every 3D transition to a feature, material or configuration decision the user needs to understand.

**Accessibility / risk check.** Not evaluated by the source corpus; validate keyboard access, focus, contrast, reduced motion, and a non-WebGL fallback.

**Provenance note.** Awwwards SOTD page, documented dark base color and public preview.

## W08 · TRIONN

| Field | Detail |
|---|---|
| ID | web-008 |
| Platform | Awwwards |
| Creator | Trionn and Sunny Rathod |
| Reference date | Not documented in the source corpus. |
| Preview | Downloaded local preview |
| Source | [TRIONN](https://www.awwwards.com/sites/trionn-2) |

![TRIONN](assets/web/images/08_awwwards_trionn.png)

**Design focus.** agency, 3D, sound interaction, experimental

**Elements.** explosive text scroll, interactive lion, floating gallery, draggable team, sound-reactive footer, 3D typography 404

**Colour.** Catalogued dominant colours: #141517, #353B43, #52575D, #FFFFFF. Catalog palette: #141517, #353B43, #52575D, #FFFFFF Measured preview palette: #0C0C0C, #191A1F, #41464C, #0D0C0E, #0C0C0F, #080808, #0C0C0B, #0B0C0E

**Image evidence.** assets/web/images/08_awwwards_trionn.png — 1600×1200 PNG; near-square; balanced; low visual density.

**Typography.** Bold geometric display text and tiny mono-like metadata support an industrial, high-tech identity.

**Layout and hierarchy.** A black immersive frame stages a central particle-lit 3D emblem, with sparse corner utilities and modular project galleries below.

**Navigation.** Navigation details are included in the layout and component notes where documented.

**Motion and interaction.** Unify drag, hold and hover gestures around consistent physics; add sound only as opt-in feedback and respect reduced-motion settings.

**Why it works.** A rich interaction vocabulary still feels coherent because it shares one monochrome material language.

**Adaptation lesson.** When using many effects, standardize easing, depth, lighting and input semantics so the experience feels authored rather than noisy.

**Accessibility / risk check.** Not evaluated by the source corpus; validate keyboard access, focus, contrast, reduced motion, and a non-WebGL fallback.

**Provenance note.** Awwwards SOTD page, documented black/white palette and public preview.

## W09 · Balmain.com - Artisanal Desktop Element

| Field | Detail |
|---|---|
| ID | web-009 |
| Platform | Awwwards |
| Creator | Mazarine for Balmain |
| Reference date | Not documented in the source corpus. |
| Preview | Downloaded local preview |
| Source | [Balmain.com - Artisanal Desktop Element](https://www.awwwards.com/inspiration/desktop-balmain-com) |

![Balmain.com - Artisanal Desktop Element](assets/web/images/09_awwwards_balmain_artisanal.jpg)

**Design focus.** luxury fashion, surreal product story, 3D editorial

**Elements.** 3D desert scene, floating craft objects, editorial story card, side rail, mode switcher

**Colour.** Catalogued dominant colours: #AC7946, #E4BA69, #E5CFA1, #1B1712. Catalog palette: #AC7946, #E4BA69, #E5CFA1, #1B1712 Measured preview palette: #A77340, #B5834F, #AE7D4A, #E5CD9A, #E4D7B9, #E6C37A, #DFB366, #3A2C1E

**Image evidence.** assets/web/images/09_awwwards_balmain_artisanal.jpg — 1600×1200 JPEG; near-square; warm; medium visual density.

**Typography.** High-contrast serif captions and ultra-small uppercase chrome keep the mood editorial and couture-led.

**Layout and hierarchy.** A surreal desert stage places floating scissors, garments and a rounded editorial card across a wide cinematic composition.

**Navigation.** Navigation details are included in the layout and component notes where documented.

**Motion and interaction.** Use horizontal camera drift, floating-object parallax and hover-focused depth of field; avoid fast spins that cheapen material realism.

**Why it works.** The interface turns an abstract brand value—craft—into a concrete visual world.

**Adaptation lesson.** Translate one brand truth into a spatial metaphor, then derive objects, copy and transitions from that metaphor.

**Accessibility / risk check.** Not evaluated by the source corpus; validate keyboard access, focus, contrast, reduced motion, and a non-WebGL fallback.

**Provenance note.** Awwwards inspiration element and first-party public still.

## W10 · LVMH Openlands - Infinite Scroll

| Field | Detail |
|---|---|
| ID | web-010 |
| Platform | Awwwards |
| Creator | LVMH Openlands project team |
| Reference date | Not documented in the source corpus. |
| Preview | Downloaded local preview |
| Source | [LVMH Openlands - Infinite Scroll](https://www.awwwards.com/inspiration/infinite-scroll-lvmh-openlands) |

![LVMH Openlands - Infinite Scroll](assets/web/images/10_awwwards_lvmh_openlands.jpg)

**Design focus.** immersive campaign, 3D landscape, infinite scroll

**Elements.** infinite environmental scroll, central chapter prompt, sound/info controls, journey navigation, WebGL landscape

**Colour.** Catalogued dominant colours: #7743A6, #1A0665, #643597, #FFFFFF. Catalog palette: #7743A6, #1A0665, #643597, #FFFFFF Measured preview palette: #7642A6, #240870, #100358, #723EA1, #633691, #431D82, #080149, #8150AD

**Image evidence.** assets/web/images/10_awwwards_lvmh_openlands.jpg — 1600×1200 JPEG; near-square; cool; low visual density.

**Typography.** Large elegant serif title over restrained sans utilities produces a premium exhibition feel.

**Layout and hierarchy.** A full-viewport purple 3D landscape frames a centered chapter title, with minimal corner controls and a visible journey cue.

**Navigation.** Navigation details are included in the layout and component notes where documented.

**Motion and interaction.** Loop distant geometry seamlessly, vary fog and color across chapters, and pin text while the environment advances in depth.

**Why it works.** The page makes abstract innovation content feel like travel through connected worlds.

**Adaptation lesson.** Infinite scroll needs explicit chapter state and an escape route; visual continuity is not a substitute for orientation.

**Accessibility / risk check.** Not evaluated by the source corpus; validate keyboard access, focus, contrast, reduced motion, and a non-WebGL fallback.

**Provenance note.** Awwwards inspiration page and public element still.

## W11 · dirt

| Field | Detail |
|---|---|
| ID | web-011 |
| Platform | Recent (formerly Godly) |
| Creator | Dirt |
| Reference date | Not documented in the source corpus. |
| Preview | Downloaded local preview |
| Source | [dirt](https://recent.design/i/1of4fz4-dirt) |

![dirt](assets/web/images/11_recent_dirt.jpg)

**Design focus.** agency, 3D, editorial, minimal

**Elements.** circular work rail, animated 3D thumbnails, minimal capsule nav, contact pill, editorial project pages

**Colour.** Catalogued dominant colours: #FEFEFE, #BFA8AF, #C9FF00, #111111. Catalog palette: #FEFEFE, #BFA8AF, #C9FF00, #111111 Measured preview palette: #FFFFFF, #B38181, #3C1F39, #FDFFFF, #536453, #D1C2B0, #F3F3D9, #FEFFF9

**Image evidence.** assets/web/images/11_recent_dirt.jpg — 2876×1796 JPEG; landscape; balanced; low visual density.

**Typography.** Tiny functional sans-serif copy contrasts with a bold centered wordmark and image-led storytelling.

**Layout and hierarchy.** A white gallery canvas uses a horizontal procession of circular 3D artworks as the primary navigation and visual rhythm.

**Navigation.** Navigation details are included in the layout and component notes where documented.

**Motion and interaction.** Apply magnetic horizontal drag, varied object spin and cursor-weighted lighting while keeping the document scroll conventional.

**Why it works.** The interface feels playful without losing the clean authority of a studio portfolio.

**Adaptation lesson.** Place experimental media inside a familiar information scaffold so users always know where they are.

**Accessibility / risk check.** Not evaluated by the source corpus; validate keyboard access, focus, contrast, reduced motion, and a non-WebGL fallback.

**Provenance note.** Recent.design listing, public recording poster and live source URL. Godly currently redirects to Recent.

## W12 · Pacôme Pertant

| Field | Detail |
|---|---|
| ID | web-012 |
| Platform | Recent (formerly Godly) |
| Creator | Pacôme Pertant |
| Reference date | Not documented in the source corpus. |
| Preview | Downloaded local preview |
| Source | [Pacôme Pertant](https://recent.design/i/pw6bwd5-pacome-pertant) |

![Pacôme Pertant](assets/web/images/12_recent_pacome_pertant.jpg)

**Design focus.** motion portfolio, dark, 3D showreel, sound

**Elements.** 3D showreel orb, enter-with-sound gate, custom cursor, project viewer, scroll transitions

**Colour.** Catalogued dominant colours: #0A0A0A, #515351, #959595, #59D850. Catalog palette: #0A0A0A, #515351, #959595, #59D850 Measured preview palette: #0A0A0A, #B4C8B7, #222523, #0B0A0B, #040404, #0A0A09, #050A08, #0A0A0B

**Image evidence.** assets/web/images/12_recent_pacome_pertant.jpg — 2876×1796 JPEG; landscape; balanced; low visual density.

**Typography.** Minimal lowercase sans copy and a single white capsule CTA create an intimate, almost cinematic entry screen.

**Layout and hierarchy.** A black full-screen void centers one small glowing 3D orb, short descriptor and a sound-enabled entrance.

**Navigation.** Navigation details are included in the layout and component notes where documented.

**Motion and interaction.** Let audio amplitude and pointer distance modulate the orb subtly; reveal work by expanding the orb into full-bleed media.

**Why it works.** Extreme restraint turns one small animated object into a strong focal point and invitation.

**Adaptation lesson.** Dark immersive entries need immediate identity, a plain-language CTA and a silent path; mystery should not become friction.

**Accessibility / risk check.** Not evaluated by the source corpus; validate keyboard access, focus, contrast, reduced motion, and a non-WebGL fallback.

**Provenance note.** Recent.design listing, public poster and live source.

## W13 · Icebug

| Field | Detail |
|---|---|
| ID | web-013 |
| Platform | Recent (formerly Godly) |
| Creator | Icebug product team |
| Reference date | Not documented in the source corpus. |
| Preview | Downloaded local preview |
| Source | [Icebug](https://recent.design/i/xa3v96i-icebug) |

![Icebug](assets/web/images/13_recent_icebug.jpg)

**Design focus.** ecommerce, outdoor, editorial, big image

**Elements.** editorial hero, dual CTA, category navigation, large product imagery, simple commerce chrome

**Colour.** Catalogued dominant colours: #8E9597, #5C5E5C, #3F3F40, #F5F5F1. Catalog palette: #8E9597, #5C5E5C, #3F3F40, #F5F5F1 Measured preview palette: #889194, #373837, #585753, #808687, #43484A, #242525, #6F7373, #A4A9AB

**Image evidence.** assets/web/images/13_recent_icebug.jpg — 2876×1796 JPEG; landscape; balanced; medium visual density.

**Typography.** Oversized condensed white headline overlays the lifestyle photograph; the rest of the navigation is extremely small and utilitarian.

**Layout and hierarchy.** A full-bleed product-in-context hero prioritizes one seasonal story, with two compact CTAs and a thin top navigation.

**Navigation.** Navigation details are included in the layout and component notes where documented.

**Motion and interaction.** Use subtle image depth, typographic mask reveals and product-card lift; heavy 3D would conflict with the authentic outdoor photography.

**Why it works.** The benefit is understood from image and headline in seconds, while shopping paths remain visible.

**Adaptation lesson.** For commerce, spectacle should strengthen product context and purchase intent, not delay category access.

**Accessibility / risk check.** Not evaluated by the source corpus; validate keyboard access, focus, contrast, reduced motion, and a non-WebGL fallback.

**Provenance note.** Recent.design listing and public recording poster.

## W14 · Offline Website Footer

| Field | Detail |
|---|---|
| ID | web-014 |
| Platform | Recent (formerly Godly) |
| Creator | Alim Joldaspayev |
| Reference date | Not documented in the source corpus. |
| Preview | Downloaded local preview |
| Source | [Offline Website Footer](https://recent.design/i/dr1cn19-offline-website-footer) |

![Offline Website Footer](assets/web/images/14_recent_offline_footer.jpg)

**Design focus.** footer concept, 3D, day-to-night, playful

**Elements.** 3D retro Mac, day/night environment, screen power state, minimal footer links, ambient transition

**Colour.** Catalogued dominant colours: #6193C9, #356AB6, #33371A, #A9D157. Catalog palette: #6193C9, #356AB6, #33371A, #A9D157 Measured preview palette: #356AB6, #497DC0, #6C97C2, #1E2514, #85A9C7, #6588AE, #366195, #4573AB

**Image evidence.** assets/web/images/14_recent_offline_footer.jpg — 1199×681 JPEG; landscape; cool; low visual density.

**Typography.** Soft, low-contrast lowercase wordmark and tiny links deliberately recede behind the nostalgic object.

**Layout and hierarchy.** A classic Macintosh sits alone on a grassy hill beneath a wide sky; footer links float faintly at the top edge.

**Navigation.** Navigation details are included in the layout and component notes where documented.

**Motion and interaction.** Map page-end progress to sunset, wind and screen power-down, then hold the final state without looping distraction.

**Why it works.** It rewards completion of the page with a memorable scene rather than treating the footer as leftover space.

**Adaptation lesson.** Use the footer as an emotional epilogue, while preserving legible legal, contact and navigation links.

**Accessibility / risk check.** Not evaluated by the source corpus; validate keyboard access, focus, contrast, reduced motion, and a non-WebGL fallback.

**Provenance note.** Recent.design public concept listing and poster.

## W15 · James Walsh Studio

| Field | Detail |
|---|---|
| ID | web-015 |
| Platform | Siteinspire |
| Creator | James Walsh Studio |
| Reference date | Not documented in the source corpus. |
| Preview | Downloaded local preview |
| Source | [James Walsh Studio](https://www.siteinspire.com/website/13478-james-walsh-studio) |

![James Walsh Studio](assets/web/images/15_siteinspire_james_walsh.webp)

**Design focus.** product design portfolio, minimal, unusual layout

**Elements.** asymmetric split hero, single product image, sparse navigation, project index, language switch

**Colour.** Catalogued dominant colours: #EFF0EE, #AEABA7, #6F4A35, #111111. Catalog palette: #EFF0EE, #AEABA7, #6F4A35, #111111 Measured preview palette: #F1F0EC, #CEC2B5, #745441, #F2F8FB, #ECF0F8, #F1F0EE, #F2F0EA, #F2F0EC

**Image evidence.** assets/web/images/15_siteinspire_james_walsh.webp — 1920×1200 JPEG; landscape; warm; low visual density.

**Typography.** Tiny black sans-serif navigation and labels give the furniture photography gallery-like authority.

**Layout and hierarchy.** A split canvas places one large product photograph on the left and a nearly empty information field on the right.

**Navigation.** Navigation details are included in the layout and component notes where documented.

**Motion and interaction.** Use slow image pan, material-detail zoom and seamless product swaps; preserve the quiet, museum-like pace.

**Why it works.** Large negative space turns a single object into the entire argument for craft and quality.

**Adaptation lesson.** When imagery is excellent, reduce UI density and let asymmetry create tension instead of adding decoration.

**Accessibility / risk check.** Not evaluated by the source corpus; validate keyboard access, focus, contrast, reduced motion, and a non-WebGL fallback.

**Provenance note.** Siteinspire project page and public 1920×1200 screengrab.

## W16 · Studio Tijmen Smeulders

| Field | Detail |
|---|---|
| ID | web-016 |
| Platform | Siteinspire |
| Creator | Studio Tijmen Smeulders |
| Reference date | Not documented in the source corpus. |
| Preview | Downloaded local preview |
| Source | [Studio Tijmen Smeulders](https://www.siteinspire.com/website/12267-studio-tijmen-smeulders) |

![Studio Tijmen Smeulders](assets/web/images/16_siteinspire_tijmen_smeulders.webp)

**Design focus.** product design portfolio, grid, light

**Elements.** two-column project grid, product renders, process photography, compact header, project metadata

**Colour.** Catalogued dominant colours: #E1E1E1, #BBBCBA, #261E0E, #F6F6F4. Catalog palette: #E1E1E1, #BBBCBA, #261E0E, #F6F6F4 Measured preview palette: #EFEFEF, #C9C9C9, #5B5345, #E6E7E7, #F4F4F5, #EFEFEE, #EFEFF0, #EAEFF4

**Image evidence.** assets/web/images/16_siteinspire_tijmen_smeulders.webp — 1920×1200 PNG; landscape; balanced; low visual density.

**Typography.** Neutral small sans-serif labels and metadata support an industrial-design catalog tone.

**Layout and hierarchy.** A strict header line introduces a two-column gallery with differently scaled product and process images.

**Navigation.** Navigation details are included in the layout and component notes where documented.

**Motion and interaction.** Stagger image reveals by column, use hover-to-detail crop and preserve grid position during project transitions.

**Why it works.** The grid is systematic enough for scanning but varied enough to feel editorial.

**Adaptation lesson.** Create hierarchy through image scale and crop before reaching for borders, cards or colored containers.

**Accessibility / risk check.** Not evaluated by the source corpus; validate keyboard access, focus, contrast, reduced motion, and a non-WebGL fallback.

**Provenance note.** Siteinspire page and public screengrab.

## W17 · Apossible

| Field | Detail |
|---|---|
| ID | web-017 |
| Platform | Siteinspire |
| Creator | Apossible; Siteinspire credit not listed |
| Reference date | Not documented in the source corpus. |
| Preview | Downloaded local preview |
| Source | [Apossible](https://www.siteinspire.com/website/12079-apossible) |

![Apossible](assets/web/images/17_siteinspire_apossible.webp)

**Design focus.** product design, unusual navigation, collage, light

**Elements.** overlapping windows, terminal panel, floating portrait card, utility strip, collage navigation

**Colour.** Catalogued dominant colours: #F4F3EE, #222122, #B4C5D0, #E6A833. Catalog palette: #F4F3EE, #222122, #B4C5D0, #E6A833 Measured preview palette: #F8F7F1, #2E2A2A, #D0C9B6, #F8F7EF, #FDFDFB, #F7F7F2, #F9F7F1, #F8F7F2

**Image evidence.** assets/web/images/17_siteinspire_apossible.webp — 1920×1200 PNG; landscape; balanced; medium visual density.

**Typography.** Mono terminal text and oversized quoted fragments create a speculative, research-lab voice.

**Layout and hierarchy.** Layered windows, notes, images and floating cards overlap on a warm off-white desktop-like canvas.

**Navigation.** Navigation details are included in the layout and component notes where documented.

**Motion and interaction.** Use draggable windows with z-index physics, slight perspective tilt and snap-back boundaries; maintain keyboard focus order independently of visual stacking.

**Why it works.** The collage communicates possibility and experimentation while distinct window styles preserve local structure.

**Adaptation lesson.** Freeform layouts still need invisible rules: alignment anchors, bounded overlap, predictable focus and responsive collapse behavior.

**Accessibility / risk check.** Not evaluated by the source corpus; validate keyboard access, focus, contrast, reduced motion, and a non-WebGL fallback.

**Provenance note.** Siteinspire page and public screengrab.

## W18 · Other Matter

| Field | Detail |
|---|---|
| ID | web-018 |
| Platform | Siteinspire |
| Creator | Other Matter |
| Reference date | Not documented in the source corpus. |
| Preview | Downloaded local preview |
| Source | [Other Matter](https://www.siteinspire.com/website/10649-other-matter) |

![Other Matter](assets/web/images/18_siteinspire_other_matter.webp)

**Design focus.** experimental studio, editorial, grid, green accent

**Elements.** fixed side navigation, large project image, brand glyph, rule-based menu, text continuation below fold

**Colour.** Catalogued dominant colours: #EFF7F2, #606466, #9B9EA3, #00E95B. Catalog palette: #EFF7F2, #606466, #9B9EA3, #00E95B Measured preview palette: #F7FEF9, #616565, #989897, #728082, #3C3D38, #A9D9B7, #FCFFFE, #F9FAF2

**Image evidence.** assets/web/images/18_siteinspire_other_matter.webp — 1920×1200 PNG; landscape; balanced; medium visual density.

**Typography.** Plain uppercase sans-serif and rule-separated menu lines evoke a functional art-catalog system.

**Layout and hierarchy.** A narrow fixed navigation rail sits beside a large image viewport; a fluorescent green flower mark anchors the lower-left corner.

**Navigation.** Navigation details are included in the layout and component notes where documented.

**Motion and interaction.** Keep the rail fixed while images crossfade or slide; use the flower glyph as a cursor or loading morph with minimal depth.

**Why it works.** A single vivid accent and rigid information rail make changing experimental work feel like one coherent collection.

**Adaptation lesson.** Use a stable navigation spine to contain visually diverse content and reserve bright color for orientation.

**Accessibility / risk check.** Not evaluated by the source corpus; validate keyboard access, focus, contrast, reduced motion, and a non-WebGL fallback.

**Provenance note.** Siteinspire page and public screengrab.

## W19 · DatAI — Web3 Website Design

| Field | Detail |
|---|---|
| ID | web-019 |
| Platform | Behance |
| Creator | Sigma Software Design; UI/UX Iryna Kryvorotko; 3D Ilya Kostin and Maksym Rud |
| Reference date | Not documented in the source corpus. |
| Preview | Downloaded local preview |
| Source | [DatAI — Web3 Website Design](https://www.behance.net/gallery/219267803/DatAI-Web3-Website-Design) |

![DatAI — Web3 Website Design](assets/web/images/19_behance_datai.webp)

**Design focus.** Web3, AI, dark, 3D data visualization

**Elements.** 3D data core, network-line backdrop, dark navigation, feature cards, content-dense product sections

**Colour.** Catalogued dominant colours: #111011, #3F1740, #601B61, #F400E9. Catalog palette: #111011, #3F1740, #601B61, #F400E9 Measured preview palette: #111111, #050505, #0E0E0E, #4E394F, #171417, #1D121D, #1D0F1D, #0E110F

**Image evidence.** assets/web/images/19_behance_datai.webp — 1400×1059 WEBP; near-square; balanced; low visual density.

**Typography.** Wide futuristic display text combines with technical sans labels and bright magenta emphasis.

**Layout and hierarchy.** A tilted dark website plane floats above a circuit-like background, centered on a luminous 3D data object and split CTA.

**Navigation.** Navigation details are included in the layout and component notes where documented.

**Motion and interaction.** Animate data nodes along curves, let the core respond to scroll depth and keep text panels on stable 2D planes for readability.

**Why it works.** Abstract infrastructure is given a visible system metaphor without abandoning conversion-oriented hierarchy.

**Adaptation lesson.** Use 3D to explain invisible systems, then pair it with plain-language claims and measurable proof.

**Accessibility / risk check.** Not evaluated by the source corpus; validate keyboard access, focus, contrast, reduced motion, and a non-WebGL fallback.

**Provenance note.** Behance project page, published credits and public project-module image.

## W20 · Interactive 3D Tech Product Website | Webflow

| Field | Detail |
|---|---|
| ID | web-020 |
| Platform | Behance |
| Creator | ELKAM Studio |
| Reference date | Not documented in the source corpus. |
| Preview | Downloaded local preview |
| Source | [Interactive 3D Tech Product Website \| Webflow](https://www.behance.net/gallery/232890727/Corporate-Website-with-3D-Product-UIUX-Webflow) |

![Interactive 3D Tech Product Website | Webflow](assets/web/images/20_behance_brax.webp)

**Design focus.** hardware launch, 3D product, conversion, clean

**Elements.** animated phone model, feature callouts, specification sections, pre-order CTA, custom preloader

**Colour.** Catalogued dominant colours: #E4E3E3, #FDFDFD, #A2A1A2, #F14A21. Catalog palette: #E4E3E3, #FDFDFD, #A2A1A2, #F14A21 Measured preview palette: #FFFFFF, #CECDCE, #DFDFDF, #8D8381, #D9D8D8, #EDEDEC, #FCFCFC, #FFFEFE

**Image evidence.** assets/web/images/20_behance_brax.webp — 1400×792 WEBP; landscape; balanced; medium visual density.

**Typography.** Technical grotesk headlines and compact specs use an orange accent to signal actions and innovation.

**Layout and hierarchy.** A clean desktop mockup centers a large angled smartphone render between short copy blocks and clear purchase CTAs.

**Navigation.** Navigation details are included in the layout and component notes where documented.

**Motion and interaction.** Rotate the phone to reveal each physical feature as its copy enters; keep camera angles reproducible for comparison.

**Why it works.** The product remains the hero and every effect supports understanding or pre-order confidence.

**Adaptation lesson.** For launch pages, sequence story beats as exterior, differentiator, internals, software, trust and purchase.

**Accessibility / risk check.** Not evaluated by the source corpus; validate keyboard access, focus, contrast, reduced motion, and a non-WebGL fallback.

**Provenance note.** Behance project page and public 1400px module.

## W21 · New Codes — Website for Digital Fashion Summit

| Field | Detail |
|---|---|
| ID | web-021 |
| Platform | Behance |
| Creator | LEAGUE Design Agency |
| Reference date | Not documented in the source corpus. |
| Preview | Downloaded local preview |
| Source | [New Codes — Website for Digital Fashion Summit](https://www.behance.net/gallery/191144391/New-Codes-Website-for-Digital-Fashion-Summit) |

![New Codes — Website for Digital Fashion Summit](assets/web/images/21_behance_new_codes.webp)

**Design focus.** event, digital fashion, 3D oracle, editorial

**Elements.** animated oracle eyes, fabric simulation, five-column grid, speaker/program modules, ticket CTA

**Colour.** Catalogued dominant colours: #151515, #E8E3EB, #3F3F40, #F3C4ED. Catalog palette: #151515, #E8E3EB, #3F3F40, #F3C4ED Measured preview palette: #EAF0F4, #131313, #0D0D0D, #323233, #1B1B1B, #0B0B0B, #060606, #A49EA9

**Image evidence.** assets/web/images/21_behance_new_codes.webp — 1400×933 WEBP; landscape; balanced; medium visual density.

**Typography.** Krylon display type pairs with IBM Plex Sans and IBM Plex Mono, combining fashion editorial drama with technical metadata.

**Layout and hierarchy.** A chrome-gray five-column grid balances a large 3D oracle figure, asymmetric text and ticket actions.

**Navigation.** Navigation details are included in the layout and component notes where documented.

**Motion and interaction.** Use the oracle gaze as a screen-transition cue; pin the grid while fabric and face shift across narrative states.

**Why it works.** A memorable symbol turns a conference agenda into a branded cultural event.

**Adaptation lesson.** Complex 3D needs an underlying grid and a recurring symbolic role; otherwise it becomes disconnected decoration.

**Accessibility / risk check.** Not evaluated by the source corpus; validate keyboard access, focus, contrast, reduced motion, and a non-WebGL fallback.

**Provenance note.** Behance case study, explicit grid/type/palette notes and public module images.

## W22 · Simple Perfection — Luxury Diamond E-commerce UX/UI

| Field | Detail |
|---|---|
| ID | web-022 |
| Platform | Behance |
| Creator | Alisa Zhuravleva |
| Reference date | Not documented in the source corpus. |
| Preview | Downloaded local preview |
| Source | [Simple Perfection — Luxury Diamond E-commerce UX/UI](https://www.behance.net/gallery/250598145/Simple-Perfection-Luxury-Diamond-E-commerce-UXUI) |

![Simple Perfection — Luxury Diamond E-commerce UX/UI](assets/web/images/22_behance_simple_perfection.webp)

**Design focus.** luxury ecommerce, jewelry, monochrome, editorial

**Elements.** spotlit product hero, science story block, jewelry grid, stone configurator, editorial mosaic, dense footer

**Colour.** Catalogued dominant colours: #090909, #F1F1F1, #5B5B5B. Catalog palette: #090909, #F1F1F1, #5B5B5B Measured preview palette: #080808, #FDFDFD, #0F0F0F, #696969, #040404, #080908, #080807, #080505

**Image evidence.** assets/web/images/22_behance_simple_perfection.webp — 1400×4370 WEBP; portrait; balanced; medium visual density.

**Typography.** A distinctive rounded geometric display face is paired with tiny catalog copy and understated links.

**Layout and hierarchy.** Black cinematic product chapters alternate with white catalog grids, asymmetric editorial photography and large typographic statements.

**Navigation.** Navigation details are included in the layout and component notes where documented.

**Motion and interaction.** Use light sweeps, controlled product rotation and black-to-white scroll transitions; keep interactions precise and almost mechanical.

**Why it works.** The absence of accent color amplifies material, reflection and geometry—the real selling points of diamonds.

**Adaptation lesson.** Luxury minimalism requires exceptional imagery, spacing and type; removing elements raises the quality bar for what remains.

**Accessibility / risk check.** Not evaluated by the source corpus; validate keyboard access, focus, contrast, reduced motion, and a non-WebGL fallback.

**Provenance note.** Behance project narrative and public module image.

## W23 · Luxury Ecommerce Site

| Field | Detail |
|---|---|
| ID | web-023 |
| Platform | Behance |
| Creator | Matthew Lippl |
| Reference date | Not documented in the source corpus. |
| Preview | Downloaded local preview |
| Source | [Luxury Ecommerce Site](https://www.behance.net/gallery/55321325/Luxury-Ecommerce-site) |

![Luxury Ecommerce Site](assets/web/images/23_behance_luxury_ecommerce.webp)

**Design focus.** fashion ecommerce, light, conversion, category grid

**Elements.** campaign mosaic, newsletter capture, style stories, category cutouts, utility footer

**Colour.** Catalogued dominant colours: #FDFDFD, #282828, #D9D4C4, #A89A72. Catalog palette: #FDFDFD, #282828, #D9D4C4, #A89A72 Measured preview palette: #FFFFFF, #1E1E1E, #EEF0F0, #363332, #A5A4A2, #FDFEFE, #FFFFFC, #FFFEFF

**Image evidence.** assets/web/images/23_behance_luxury_ecommerce.webp — 1400×2256 WEBP; portrait; balanced; medium visual density.

**Typography.** Straightforward bold sans-serif hierarchy prioritizes offer, category and action clarity.

**Layout and hierarchy.** A wide campaign tile plus two smaller product tiles leads into email capture, paired collection stories, category cutouts and a dark utility footer.

**Navigation.** Navigation details are included in the layout and component notes where documented.

**Motion and interaction.** Modernize with image-mask reveals, hover zoom and lightweight product tilt while preserving the proven conversion sequence.

**Why it works.** The homepage balances merchandising, inspiration and category access in a predictable scan path.

**Adaptation lesson.** A strong commerce layout can be visually refreshed without disrupting information architecture that supports shopping intent.

**Accessibility / risk check.** Not evaluated by the source corpus; validate keyboard access, focus, contrast, reduced motion, and a non-WebGL fallback.

**Provenance note.** Behance project page and public full-page module.

## W24 · SaaS Landing Page Design UI/UX

| Field | Detail |
|---|---|
| ID | web-024 |
| Platform | Behance |
| Creator | Mykola Tanasiichuk |
| Reference date | Not documented in the source corpus. |
| Preview | Downloaded local preview |
| Source | [SaaS Landing Page Design UI/UX](https://www.behance.net/gallery/206151643/Saas-Landing-page-design-ui-ux) |

![SaaS Landing Page Design UI/UX](assets/web/images/24_behance_saas_landing.webp)

**Design focus.** SaaS, marketing, gradient, dashboard preview

**Elements.** benefit headline, layered product UI, proof logos, feature sections, pricing, footer CTA

**Colour.** Catalogued dominant colours: #F3F2F8, #BC27ED, #645BE8, #0B0B20. Catalog palette: #F3F2F8, #BC27ED, #645BE8, #0B0B20 Measured preview palette: #FFFFFF, #C70EEC, #E3E5F0, #7E89D2, #311499, #6D48C4, #FEFAFE, #FFFFFE

**Image evidence.** assets/web/images/24_behance_saas_landing.webp — 1400×914 WEBP; landscape; cool; medium visual density.

**Typography.** Large bold sans-serif headline, short supporting copy and high-contrast buttons create a familiar SaaS conversion hierarchy.

**Layout and hierarchy.** A saturated violet/pink hero contains product cards, social proof and layered dashboard imagery, followed by modular benefit and pricing bands.

**Navigation.** Navigation details are included in the layout and component notes where documented.

**Motion and interaction.** Float UI cards in shallow z-space, use scroll-linked card convergence and animate charts only when visible.

**Why it works.** The product is demonstrated early and the gradient creates energy without changing the underlying conversion path.

**Adaptation lesson.** Use 3D card layering as a product explanation device, not as a substitute for a clear primary benefit.

**Accessibility / risk check.** Not evaluated by the source corpus; validate keyboard access, focus, contrast, reduced motion, and a non-WebGL fallback.

**Provenance note.** Behance project page and public module image.

## W25 · 3D & Interactive Web Design — Heydar Aliyev Center

| Field | Detail |
|---|---|
| ID | web-025 |
| Platform | Behance |
| Creator | Tech Arts |
| Reference date | Not documented in the source corpus. |
| Preview | Downloaded local preview |
| Source | [3D & Interactive Web Design — Heydar Aliyev Center](https://www.behance.net/gallery/114077773/3D-Interactive-Web-Design-Page-1) |

![3D & Interactive Web Design — Heydar Aliyev Center](assets/web/images/25_behance_zaha_3d.webp)

**Design focus.** architecture, 3D, cultural, experimental editorial

**Elements.** interactive architecture model, editorial collage, layered title, project narrative, Three.js scene

**Colour.** Catalogued dominant colours: #EBECED, #B4C7D8, #A2A5AA, #C8AE8A. Catalog palette: #EBECED, #B4C7D8, #A2A5AA, #C8AE8A Measured preview palette: #FFFFFF, #E6E4E2, #BFCDDA, #929DA7, #DADCDF, #E8E9EA, #FFFFFE, #FEFFFF

**Image evidence.** assets/web/images/25_behance_zaha_3d.webp — 806×632 WEBP; near-square; balanced; low visual density.

**Typography.** Oversized elegant serif names overlap architectural fragments, borrowing the building's flowing geometry.

**Layout and hierarchy.** A pale collage combines a 3D building render, masked photography and layered titles that cross conventional column boundaries.

**Navigation.** Navigation details are included in the layout and component notes where documented.

**Motion and interaction.** Let scroll trace the building silhouette, use camera paths that echo its curves and mask text through architectural apertures.

**Why it works.** The interface derives its composition from the subject's architecture rather than applying a generic gallery template.

**Adaptation lesson.** Extract layout geometry and motion behavior from the product or place itself for stronger conceptual unity.

**Accessibility / risk check.** Not evaluated by the source corpus; validate keyboard access, focus, contrast, reduced motion, and a non-WebGL fallback.

**Provenance note.** Behance project page and public project-module still.

## W26 · DataFlow Landing Page UI

| Field | Detail |
|---|---|
| ID | web-026 |
| Platform | Dribbble |
| Creator | UIUX STUDIO |
| Reference date | Not documented in the source corpus. |
| Preview | No downloaded preview |
| Source | [DataFlow Landing Page UI](https://dribbble.com/shots/26311201-DataFlow-Landing-Page-UI) |

> Preview unavailable in the downloaded corpus. Use the attributed source page for visual review.

**Design focus.** SaaS, analytics, dashboard, light

**Elements.** announcement badge, dual CTA, dashboard hero, metric cards, transaction list, logo proof

**Colour.** Catalogued dominant colours: #E9F2F4, #B0E0CE, #56A7A3, #242932, #1B51AC. Catalog palette: #E9F2F4, #B0E0CE, #56A7A3, #242932, #1B51AC Measured preview palette: Not available.

**Image evidence.** No local image metrics are available for this record.

**Typography.** Large modern grotesk headline with compact dashboard labels and friendly rounded buttons.

**Layout and hierarchy.** Centered copy and dual CTAs lead into an oversized dashboard preview; customer logos create a trust band at the fold.

**Navigation.** Navigation details are included in the layout and component notes where documented.

**Motion and interaction.** Tilt the dashboard plane slightly, stagger metric-card arrival and animate chart values from real data after the entrance completes.

**Why it works.** Visitors see both the product promise and a legible representation of the product in one viewport.

**Adaptation lesson.** For SaaS, make the hero screenshot tell a specific story rather than showing an unreadable decorative dashboard.

**Accessibility / risk check.** Not evaluated by the source corpus; validate keyboard access, focus, contrast, reduced motion, and a non-WebGL fallback.

**Provenance note.** Public Dribbble project page; palette is exposed by Dribbble. Original shot asset was not publicly retrievable without a challenge.

## W27 · SaaS Landing Page Design — Smart Analytics

| Field | Detail |
|---|---|
| ID | web-027 |
| Platform | Dribbble |
| Creator | Eva Reed for Orizon |
| Reference date | Not documented in the source corpus. |
| Preview | Downloaded local preview |
| Source | [SaaS Landing Page Design — Smart Analytics](https://dribbble.com/shots/26716924-SaaS-landing-page-design) |

![SaaS Landing Page Design — Smart Analytics](assets/web/images/29_dribbble_saas_analytics.png)

**Design focus.** SaaS, analytics, gradient, conversion

**Elements.** funding badge, benefit headline, dual CTA, logo row, dashboard preview, rounded navigation

**Colour.** Catalogued dominant colours: #EEE6EA, #D7BAC5, #DA929F, #6494AB, #121112. Catalog palette: #EEE6EA, #D7BAC5, #DA929F, #6494AB, #121112 Measured preview palette: #FFFFFF, #ECB6BA, #050505, #E2CFDA, #B9CCD9, #A7A9B8, #2E252D, #F8E6E3

**Image evidence.** assets/web/images/29_dribbble_saas_analytics.png — 752×564 PNG; near-square; balanced; low visual density.

**Typography.** A heavy centered sans-serif headline uses generous line spacing, with tiny navigation and compact social proof.

**Layout and hierarchy.** A soft rose-to-blue gradient frames a centered value proposition, announcement chip, dual CTA, trust logos and large product screenshot.

**Navigation.** Navigation details are included in the layout and component notes where documented.

**Motion and interaction.** Use slow gradient drift, shallow dashboard perspective and subtle depth separation between announcement, copy and product.

**Why it works.** The gradient feels distinctive but the hierarchy remains immediately familiar and conversion-oriented.

**Adaptation lesson.** Apply expressive color to the environment while keeping actions, proof and product UI structurally conventional.

**Accessibility / risk check.** Not evaluated by the source corpus; validate keyboard access, focus, contrast, reduced motion, and a non-WebGL fallback.

**Provenance note.** Public Dribbble page, exposed palette and public 752px preview.

## W28 · UX/UI Design for Financial Dashboard

| Field | Detail |
|---|---|
| ID | web-028 |
| Platform | Dribbble |
| Creator | VALMAX |
| Reference date | Not documented in the source corpus. |
| Preview | No downloaded preview |
| Source | [UX/UI Design for Financial Dashboard](https://dribbble.com/shots/26623741-UX-UI-design-for-Financial-Dashboard) |

> Preview unavailable in the downloaded corpus. Use the attributed source page for visual review.

**Design focus.** dashboard, fintech, data visualization, light

**Elements.** sidebar, KPI row, cash-flow chart, investment panel, transactions, filters

**Colour.** Catalogued dominant colours: #F6F6F7, #868686, #BDD1DC, #A598F9, #0E0E0F, #722E8E. Catalog palette: #F6F6F7, #868686, #BDD1DC, #A598F9, #0E0E0F, #722E8E Measured preview palette: Not available.

**Image evidence.** No local image metrics are available for this record.

**Typography.** Neutral product sans uses strong numeric emphasis and subdued labels to prioritize financial scanning.

**Layout and hierarchy.** A persistent side rail supports KPI cards, revenue/expense charts, investments and activity in a modular desktop grid.

**Navigation.** Navigation details are included in the layout and component notes where documented.

**Motion and interaction.** Keep dashboards mostly 2D; use restrained number rolls, chart morphs, row expansion and context-preserving view transitions.

**Why it works.** Information appears where finance users expect it and accent color is reserved for meaning.

**Adaptation lesson.** In operational UI, motion should preserve context and explain state changes rather than provide spectacle.

**Accessibility / risk check.** Not evaluated by the source corpus; validate keyboard access, focus, contrast, reduced motion, and a non-WebGL fallback.

**Provenance note.** Public Dribbble page with designer description and exposed palette.

## W29 · 3D Animated SaaS Landing Page

| Field | Detail |
|---|---|
| ID | web-029 |
| Platform | Dribbble |
| Creator | Swan Design Agency |
| Reference date | Not documented in the source corpus. |
| Preview | No downloaded preview |
| Source | [3D Animated SaaS Landing Page](https://dribbble.com/shots/27132565-3D-Animated-SaaS-Landing-Page-Interactive-Web-Design) |

> Preview unavailable in the downloaded corpus. Use the attributed source page for visual review.

**Design focus.** SaaS, 3D hero, interactive, pastel

**Elements.** 3D hero cluster, headline and CTA, navigation, feature proof, responsive composition

**Colour.** Catalogued dominant colours: #CBC5E0, #ACA3DE, #758CC9, #A070C1, #5B4ACF, #632F43. Catalog palette: #CBC5E0, #ACA3DE, #758CC9, #A070C1, #5B4ACF, #632F43 Measured preview palette: Not available.

**Image evidence.** No local image metrics are available for this record.

**Typography.** Contemporary bold sans typography is kept short so layered 3D forms can carry the first impression.

**Layout and hierarchy.** A conversion-oriented SaaS hero uses a clear copy column, primary CTA and a layered animated object field as the counterweight.

**Navigation.** Navigation details are included in the layout and component notes where documented.

**Motion and interaction.** Use layered depth and gentle camera movement to guide attention from claim to CTA; pause continuous loops after the first cycle.

**Why it works.** Depth communicates innovation while the message and action remain visually dominant.

**Adaptation lesson.** Treat 3D as storytelling with hierarchy: foreground action, midground product metaphor, background atmosphere.

**Accessibility / risk check.** Not evaluated by the source corpus; validate keyboard access, focus, contrast, reduced motion, and a non-WebGL fallback.

**Provenance note.** Public Dribbble project page, author rationale and exposed palette.

## W30 · ORVEN — Luxury Fashion E-commerce

| Field | Detail |
|---|---|
| ID | web-030 |
| Platform | Dribbble |
| Creator | Orbiq Studio |
| Reference date | Not documented in the source corpus. |
| Preview | No downloaded preview |
| Source | [ORVEN — Luxury Fashion E-commerce](https://dribbble.com/shots/27045919-Luxury-Fashion-E-commerce-Website-UI-UX-Animation) |

> Preview unavailable in the downloaded corpus. Use the attributed source page for visual review.

**Design focus.** luxury ecommerce, fashion, editorial, animation

**Elements.** editorial hero, collection stories, new arrivals, category exploration, social proof, commerce navigation

**Colour.** Catalogued dominant colours: #DEE1C4, #0D0805, #695C51, #9A5245, #A29F57. Catalog palette: #DEE1C4, #0D0805, #695C51, #9A5245, #A29F57 Measured preview palette: Not available.

**Image evidence.** No local image metrics are available for this record.

**Typography.** High-contrast editorial display type pairs with understated product metadata and compact commerce controls.

**Layout and hierarchy.** Large fashion photography and open neutral sections alternate with structured new-arrival, category and social-proof modules.

**Navigation.** Navigation details are included in the layout and component notes where documented.

**Motion and interaction.** Use image curtains, fabric-like page transitions and subtle product depth while keeping filters, cart and sizing interactions instant.

**Why it works.** It merges magazine storytelling with a recognizable shopping path.

**Adaptation lesson.** Luxury commerce should let storytelling lead discovery but never hide product, price, size or cart actions.

**Accessibility / risk check.** Not evaluated by the source corpus; validate keyboard access, focus, contrast, reduced motion, and a non-WebGL fallback.

**Provenance note.** Public Dribbble project page, written design rationale and exposed palette.

## W31 · Fintech Analytics Dashboard — Light & Dark Mode

| Field | Detail |
|---|---|
| ID | web-031 |
| Platform | Dribbble |
| Creator | Swan Design Agency |
| Reference date | Not documented in the source corpus. |
| Preview | No downloaded preview |
| Source | [Fintech Analytics Dashboard — Light & Dark Mode](https://dribbble.com/shots/26907912-Fintech-Analytics-Dashboard-UI-Light-Dark-Mode) |

> Preview unavailable in the downloaded corpus. Use the attributed source page for visual review.

**Design focus.** fintech, dashboard, light/dark themes, motion

**Elements.** theme switch, KPI cards, charts, tables, side navigation, persistent filters

**Colour.** Catalogued dominant colours: #020502, #FDFDFD, #3B5B2D, #B4AEBC, #76FC18, #8E5C90. Catalog palette: #020502, #FDFDFD, #3B5B2D, #B4AEBC, #76FC18, #8E5C90 Measured preview palette: Not available.

**Image evidence.** No local image metrics are available for this record.

**Typography.** High-legibility sans-serif with tabular figures and deliberate contrast across both themes.

**Layout and hierarchy.** Reusable KPI, chart, table and navigation modules retain the same hierarchy when the surface flips between black and white.

**Navigation.** Navigation details are included in the layout and component notes where documented.

**Motion and interaction.** Crossfade semantic color tokens, preserve chart geometry and animate only changed values so theme switching never destroys context.

**Why it works.** The themes feel like one system because component roles and data hierarchy remain stable.

**Adaptation lesson.** Design themes from semantic tokens and contrast rules, not independent color mockups.

**Accessibility / risk check.** Not evaluated by the source corpus; validate keyboard access, focus, contrast, reduced motion, and a non-WebGL fallback.

**Provenance note.** Public Dribbble project page, author description and exposed palette.

## W32 · Huly — SaaS Landing Page

| Field | Detail |
|---|---|
| ID | web-032 |
| Platform | Pinterest |
| Creator | Huly product team; pin curated by SaaS Landing Page |
| Reference date | Not documented in the source corpus. |
| Preview | Downloaded local preview |
| Source | [Huly — SaaS Landing Page](https://kr.pinterest.com/pin/116249234130533563/) |

![Huly — SaaS Landing Page](assets/web/images/26_pinterest_huly.jpg)

**Design focus.** SaaS, productivity, dark/light chapters, full page

**Elements.** cosmic product hero, feature card mosaic, video collaboration demo, GitHub integration, knowledge editor, dark closing CTA

**Colour.** Catalogued dominant colours: #151517, #EBECEE, #B7BECB, #5B6CFF, #FF7A38. Catalog palette: #151517, #EBECEE, #B7BECB, #5B6CFF, #FF7A38 Measured preview palette: #F7F7F7, #0F1011, #15161B, #E8EBEE, #38363E, #F4F5F6, #07080A, #A3A5AE

**Image evidence.** assets/web/images/26_pinterest_huly.jpg — 736×5009 JPEG; portrait; balanced; high visual density.

**Typography.** Large black/white grotesk headlines use short benefit statements, with dense but orderly product labels beneath.

**Layout and hierarchy.** A dark cosmic hero leads into alternating light and dark feature chapters, each pairing a large product view with a focused narrative.

**Navigation.** Navigation details are included in the layout and component notes where documented.

**Motion and interaction.** Use the luminous portal as a persistent transition motif, scroll-linked dashboard depth and restrained orbital particles around chapter boundaries.

**Why it works.** A long feature set remains coherent through repeated chapter rhythm and one recognizable light motif.

**Adaptation lesson.** For long SaaS pages, alternate density and background tone while reusing a stable content grammar.

**Accessibility / risk check.** Not evaluated by the source corpus; validate keyboard access, focus, contrast, reduced motion, and a non-WebGL fallback.

**Provenance note.** Public indexed Pinterest pin, public i.pinimg.com full-page preview and linked Huly source.

## W33 · Ecommerce Dashboard Web App

| Field | Detail |
|---|---|
| ID | web-033 |
| Platform | Pinterest |
| Creator | Ariunbold Ankhaa for Awesomed |
| Reference date | Not documented in the source corpus. |
| Preview | Downloaded local preview |
| Source | [Ecommerce Dashboard Web App](https://www.pinterest.com/pin/331577591321525696/) |

![Ecommerce Dashboard Web App](assets/web/images/27_pinterest_ecommerce_dashboard.jpg)

**Design focus.** ecommerce dashboard, desktop app, light, analytics

**Elements.** sidebar, revenue graph, orders card, team avatars, metric tiles, search and utilities

**Colour.** Catalogued dominant colours: #F1F4F8, #BBB1B5, #0A1B54, #FF6B31, #2F63E8. Catalog palette: #F1F4F8, #BBB1B5, #0A1B54, #FF6B31, #2F63E8 Measured preview palette: #F7F8FC, #FFFFFF, #EEF1F8, #E7ECF5, #83575C, #D9DEE7, #FCFCFC, #F2F8F8

**Image evidence.** assets/web/images/27_pinterest_ecommerce_dashboard.jpg — 736×552 JPEG; near-square; balanced; low visual density.

**Typography.** Compact dashboard sans-serif with bold monetary values and quiet navigation labels.

**Layout and hierarchy.** A spacious rounded desktop surface combines a sidebar, top utility bar, revenue chart, orders, team avatars and high-color metric cards.

**Navigation.** Navigation details are included in the layout and component notes where documented.

**Motion and interaction.** Use lightweight card elevation, drill-down expansion and chart interpolation; reserve 3D perspective for marketing mockups, not daily operation.

**Why it works.** Large whitespace and isolated color blocks make dense commercial metrics easy to scan.

**Adaptation lesson.** Let color identify metric families, but keep chart axes, totals and actions consistent across modules.

**Accessibility / risk check.** Not evaluated by the source corpus; validate keyboard access, focus, contrast, reduced motion, and a non-WebGL fallback.

**Provenance note.** Public indexed Pinterest pin and public i.pinimg.com preview; pin links to the originating Dribbble work.

## W34 · Dark SaaS Landing Page Mockup

| Field | Detail |
|---|---|
| ID | web-034 |
| Platform | Pinterest |
| Creator | Best Deal Services (Pinterest attribution) |
| Reference date | Not documented in the source corpus. |
| Preview | Downloaded local preview |
| Source | [Dark SaaS Landing Page Mockup](https://www.pinterest.com/pin/design-saas-landing-page-ui-ux-website-mockup-in-figma--951596596257228049/) |

![Dark SaaS Landing Page Mockup](assets/web/images/28_pinterest_saas_mockup.jpg)

**Design focus.** SaaS, dark, 3D device mockup, promotional

**Elements.** 3D laptop stack, dark product screens, large title, purple glow, contrasting CTA

**Colour.** Catalogued dominant colours: #0E0916, #423050, #5C575E, #8A2CFF, #FFFFFF. Catalog palette: #0E0916, #423050, #5C575E, #8A2CFF, #FFFFFF Measured preview palette: #211C27, #080014, #0C0412, #AFA295, #06040B, #0D001D, #09040F, #03000E

**Image evidence.** assets/web/images/28_pinterest_saas_mockup.jpg — 680×447 JPEG; landscape; balanced; low visual density.

**Typography.** Very large white sans-serif title uses compact purple labels and high-contrast yellow CTA treatment in the promotional composition.

**Layout and hierarchy.** Multiple dark interface screens are arranged in an angled 3D device stack beside an oversized title block.

**Navigation.** Navigation details are included in the layout and component notes where documented.

**Motion and interaction.** Animate devices unfolding into a usable product tour, then flatten the active screen for legibility.

**Why it works.** The angled stack communicates a multi-surface product quickly and creates strong depth in a compact frame.

**Adaptation lesson.** Use perspective for overview and excitement, but transition to flat readable UI when users need to inspect features.

**Accessibility / risk check.** Not evaluated by the source corpus; validate keyboard access, focus, contrast, reduced motion, and a non-WebGL fallback.

**Provenance note.** Public indexed Pinterest pin and public i.pinimg.com preview. This is a promotional reference with lower case-study depth than award-source entries.

## W35 · WERAVERSE

| Field | Detail |
|---|---|
| ID | web-035 |
| Platform | CSS Design Awards |
| Creator | Weronika Ostrowska with Krzysztof Wyrzykowski |
| Reference date | Not documented in the source corpus. |
| Preview | Downloaded local preview |
| Source | [WERAVERSE](https://www.cssdesignawards.com/sites/weraverse/43703/) |

![WERAVERSE](assets/web/images/30_cssda_weraverse.jpg)

**Design focus.** portfolio, 3D world, WebGL, game UI

**Elements.** 3D avatar stage, interactive props, dance action, cursor instruction, sound and about toggles

**Colour.** Catalogued dominant colours: #13105C, #030128, #2A2390, #9A62D8. Catalog palette: #13105C, #030128, #2A2390, #9A62D8 Measured preview palette: #33228A, #050551, #1B1B75, #403FA3, #030333, #6E7FC7, #020027, #140C5F

**Image evidence.** assets/web/images/30_cssda_weraverse.jpg — 1068×646 JPEG; landscape; cool; medium visual density.

**Typography.** Small game-like utility labels and a playful action button sit over a purple-lit 3D environment.

**Layout and hierarchy.** A full-screen virtual room contains an avatar, sculptural props and portfolio screens, with sound/about controls in the corners.

**Navigation.** Navigation details are included in the layout and component notes where documented.

**Motion and interaction.** Use direct manipulation and character reactions to reveal work; provide a conventional portfolio menu as a parallel route.

**Why it works.** The designer's game and UI expertise is demonstrated through the interaction model itself.

**Adaptation lesson.** Make the navigation mode prove a relevant capability; novelty alone is not enough.

**Accessibility / risk check.** Not evaluated by the source corpus; validate keyboard access, focus, contrast, reduced motion, and a non-WebGL fallback.

**Provenance note.** CSS Design Awards WOTD page and public first-party preview.

## W36 · Hungry Tiger

| Field | Detail |
|---|---|
| ID | web-036 |
| Platform | Behance |
| Creator | Artemii Lebedev, Svetlana Markova, Alex Gmyrak and Le:mma Studio |
| Reference date | Not documented in the source corpus. |
| Preview | No downloaded preview |
| Source | [Hungry Tiger](https://www.behance.net/gallery/229240991/Hungry-Tiger) |

> Preview unavailable in the downloaded corpus. Use the attributed source page for visual review.

**Design focus.** food ecommerce, 3D motion, interactive storytelling, playful

**Elements.** 3D sauce jar, ingredient world, interactive story, product proof, shop CTA, contact/game layer

**Colour.** Catalogued dominant colours: tikka orange, chili red, turmeric yellow, deep plum, cream. Catalog palette: tikka orange, chili red, turmeric yellow, deep plum, cream Measured preview palette: Not available.

**Image evidence.** No local image metrics are available for this record.

**Typography.** Expressive food-brand display lettering pairs with simple commerce copy and oversized product statements.

**Layout and hierarchy.** A product-first narrative alternates immersive 3D sauce imagery, bold brand chapters, playful interactions and purchase moments.

**Navigation.** Navigation details are included in the layout and component notes where documented.

**Motion and interaction.** Simulate viscous sauce, ingredient bursts and jar rotation while maintaining a fast direct path to ingredients, price and purchase.

**Why it works.** The sensory motion supports appetite and brand memory rather than presenting generic food photography.

**Adaptation lesson.** For physical products, derive motion physics from material behavior—pour, stretch, fizz, fold or snap.

**Accessibility / risk check.** Not evaluated by the source corpus; validate keyboard access, focus, contrast, reduced motion, and a non-WebGL fallback.

**Provenance note.** Behance case study, live URL and published team credits; imagery is embedded as video, so no still frame was extracted.

## W37 · 3D Animated Website for Luxury Events in Dubai

| Field | Detail |
|---|---|
| ID | web-037 |
| Platform | Behance |
| Creator | Anastasiia Hodubiak, Artycoders Team and Ivan Malysh |
| Reference date | Not documented in the source corpus. |
| Preview | No downloaded preview |
| Source | [3D Animated Website for Luxury Events in Dubai](https://www.behance.net/gallery/224741249/3D-Animated-Website-for-Luxury-Events-in-Dubai) |

> Preview unavailable in the downloaded corpus. Use the attributed source page for visual review.

**Design focus.** luxury events, Dubai, 3D florals, interactive

**Elements.** animated 3D flowers, art-object hero, event gallery, service narratives, inquiry CTA, responsive scenes

**Colour.** Catalogued dominant colours: ivory, champagne gold, soft rose, botanical green, charcoal. Catalog palette: ivory, champagne gold, soft rose, botanical green, charcoal Measured preview palette: Not available.

**Image evidence.** No local image metrics are available for this record.

**Typography.** Refined fashion-adjacent display type and sparse supporting copy reflect premium event craftsmanship.

**Layout and hierarchy.** Cinematic floral compositions alternate with airy service, gallery and inquiry sections in a high-end editorial rhythm.

**Navigation.** Navigation details are included in the layout and component notes where documented.

**Motion and interaction.** Use slow botanical growth, petal parallax and bouquet assembly keyed to scroll; cap particle counts on mobile.

**Why it works.** The digital material language mirrors the studio's real installations and emotional promise.

**Adaptation lesson.** Let motion demonstrate the maker's process and atmosphere, then provide clear evidence and inquiry paths.

**Accessibility / risk check.** Not evaluated by the source corpus; validate keyboard access, focus, contrast, reduced motion, and a non-WebGL fallback.

**Provenance note.** Behance project page and published description; presentation uses video embeds, so no static frame was extracted.

## W38 · ÉRRA ATELIER — Luxury Fashion E-commerce

| Field | Detail |
|---|---|
| ID | web-038 |
| Platform | Behance |
| Creator | Olga \| Shade |
| Reference date | Not documented in the source corpus. |
| Preview | No downloaded preview |
| Source | [ÉRRA ATELIER — Luxury Fashion E-commerce](https://www.behance.net/gallery/248801341/Luxury-Fashion-E-commerce-Branding-Website-Design) |

> Preview unavailable in the downloaded corpus. Use the attributed source page for visual review.

**Design focus.** luxury fashion, branding, Shopify, editorial ecommerce

**Elements.** brand story hero, campaign editorials, collection navigation, product grid, trust and shipping, Shopify conversion flow

**Colour.** Catalogued dominant colours: warm ivory, ink black, taupe, oxblood, muted gold. Catalog palette: warm ivory, ink black, taupe, oxblood, muted gold Measured preview palette: Not available.

**Image evidence.** No local image metrics are available for this record.

**Typography.** Elegant high-contrast fashion type is balanced by clean product information and restrained navigation.

**Layout and hierarchy.** Editorial brand storytelling, campaign imagery and structured product discovery flow into conversion-focused shop modules.

**Navigation.** Navigation details are included in the layout and component notes where documented.

**Motion and interaction.** Use fabric-like masks, cinematic image scale and subtle garment depth while keeping product variants and checkout immediate.

**Why it works.** Brand identity and commerce feel like one designed system rather than a campaign landing page bolted onto a store.

**Adaptation lesson.** Define shared typography, spacing and motion tokens across brand storytelling and transactional screens.

**Accessibility / risk check.** Not evaluated by the source corpus; validate keyboard access, focus, contrast, reduced motion, and a non-WebGL fallback.

**Provenance note.** Behance project page and published owner information; presentation uses embedded video, so no still frame was extracted.

# Mobile references (39)

## M01 · Travel Planner Mobile App with Trip Map & Weather Cards

| Field | Detail |
|---|---|
| ID | MOB-001 |
| Platform | Dribbble |
| Creator | Nixtio |
| Reference date | Not documented in the source corpus. |
| Preview | Downloaded local preview |
| Source | [Travel Planner Mobile App with Trip Map & Weather Cards](https://dribbble.com/shots/27455621-Travel-Planner-Mobile-App-with-Trip-Map-Weather-Cards) |

![Travel Planner Mobile App with Trip Map & Weather Cards](assets/mobile/images/dribbble-01-travel-planner.png)

**Design focus.** Travel discovery, itinerary overview, weather, and route map, Emotional editorial travel with photographic hero imagery and airy data cards

**Elements.** edge-to-edge hero, weather card, date chips, avatar group, route map, city stop cards

**Colour.** Catalogued dominant colours: sky blue, white, navy, steel blue, terracotta. Catalog palette: sky blue, white, navy, steel blue, terracotta Measured preview palette: #F2F5F3, #2990D1, #5DB4EB, #19415C, #8594A2, #68504E, #AFC8DD, #E6E2DE

**Image evidence.** assets/mobile/images/dribbble-01-travel-planner.png — 1200×900 PNG; near-square; cool; medium visual density.

**Typography.** Editorial destination headline paired with compact neutral sans-serif metadata

**Layout and hierarchy.** Destination hero first, then dates/weather/travelers, then map route and city stops

**Navigation.** Top utility actions, day chips, and contextual movement into the itinerary/map

**Motion and interaction.** Depth-shift the hero on drag, draw the route as the itinerary advances, and morph day chips into map stops.

**Why it works.** It sells the feeling of the trip before exposing planning complexity.

**Adaptation lesson.** Lead with one cinematic promise, then reveal structured planning data in quiet supporting surfaces.

**Accessibility / risk check.** Add a status-bar scrim over photography, keep text off busy image regions, and never encode route state by color alone.

**Provenance note.** Public source-page reference and local preview mapping documented by the mobile corpus methodology.

## M02 · Travel Mobile App Design | AI Assistant

| Field | Detail |
|---|---|
| ID | MOB-002 |
| Platform | Dribbble |
| Creator | Artspire |
| Reference date | Not documented in the source corpus. |
| Preview | Downloaded local preview |
| Source | [Travel Mobile App Design \| AI Assistant](https://dribbble.com/shots/26956915-Travel-Mobile-App-Design-AI-Assistant) |

![Travel Mobile App Design | AI Assistant](assets/mobile/images/dribbble-02-travel-ai-assistant.png)

**Design focus.** Hotel review analysis and conversational travel assistant, Airy white interface with pastel aurora gradients and cobalt actions

**Elements.** rating hero, metric chips, AI prompt suggestions, expandable insight list, chat composer

**Colour.** Catalogued dominant colours: white, ice blue, lavender, soft pink, cobalt, charcoal. Catalog palette: white, ice blue, lavender, soft pink, cobalt, charcoal Measured preview palette: #ECEEF1, #E6E8EF, #FAFBFC, #817F8B, #F2EEF8, #FDF4E0, #ECEEF4, #E1F2F8

**Image evidence.** assets/mobile/images/dribbble-02-travel-ai-assistant.png — 1200×900 PNG; near-square; balanced; medium visual density.

**Typography.** Large geometric sans-serif rating, restrained labels, and friendly conversational text

**Layout and hierarchy.** Overall score, category metrics, AI question prompt, then detailed review themes

**Navigation.** Focused single-task stack with expandable analysis and persistent ask field

**Motion and interaction.** Animate metric bars from the score, expand topics in-place, and use a soft listening pulse around the assistant action.

**Why it works.** It converts review overload into a readable answer path without hiding the underlying dimensions.

**Adaptation lesson.** Put the synthesized answer first, but keep inspectable evidence one tap away.

**Accessibility / risk check.** Pastel gradients need tested text contrast; AI answers need source/uncertainty treatment and keyboard-safe chat controls.

**Provenance note.** Public source-page reference and local preview mapping documented by the mobile corpus methodology.

## M03 · Flight Tickets Booking Mobile App

| Field | Detail |
|---|---|
| ID | MOB-003 |
| Platform | Dribbble |
| Creator | Conceptzilla |
| Reference date | Not documented in the source corpus. |
| Preview | Downloaded local preview |
| Source | [Flight Tickets Booking Mobile App](https://dribbble.com/shots/21665054-Flight-Tickets-Booking-Mobile-App) |

![Flight Tickets Booking Mobile App](assets/mobile/images/dribbble-03-flight-booking.png)

**Design focus.** Flight search, active flights, boarding pass, and trip management, High-energy airline red on crisp white with dense ticket geometry

**Elements.** route tabs, boarding pass, QR code, status badge, flight timeline, price summary

**Colour.** Catalogued dominant colours: signal red, white, black, pale gray, green success. Catalog palette: signal red, white, black, pale gray, green success Measured preview palette: #B72B24, #FFFFFF, #F4F5F6, #E2E4E4, #FEFEFE, #BD7876, #FEFFFF, #FEFFFE

**Image evidence.** assets/mobile/images/dribbble-03-flight-booking.png — 1200×900 PNG; near-square; warm; medium visual density.

**Typography.** Bold condensed numeric emphasis with utilitarian sans-serif labels

**Layout and hierarchy.** Route and status, departure/arrival time, passenger and seat data, QR boarding credential

**Navigation.** Segmented trip status, stacked ticket cards, and direct manage-flight actions

**Motion and interaction.** Let the ticket tear/fold into a detail view and animate the route line between origin and destination.

**Why it works.** The visual language borrows familiar physical-ticket cues while making the next travel action obvious.

**Adaptation lesson.** For stressful flows, let hierarchy and recognizable objects carry personality rather than decorative complexity.

**Accessibility / risk check.** QR and critical gate data need full brightness and zoom support; red must not be the only status signal.

**Provenance note.** Public source-page reference and local preview mapping documented by the mobile corpus methodology.

## M04 · Custom Travel Itinerary Mobile App

| Field | Detail |
|---|---|
| ID | MOB-004 |
| Platform | Dribbble |
| Creator | Ronas IT \| UI/UX Team |
| Reference date | Not documented in the source corpus. |
| Preview | Downloaded local preview |
| Source | [Custom Travel Itinerary Mobile App](https://dribbble.com/shots/27210613-Custom-Travel-Itinerary-Mobile-App) |

![Custom Travel Itinerary Mobile App](assets/mobile/images/dribbble-04-custom-itinerary.png)

**Design focus.** Destination browse, tour detail, booking, and day-by-day timeline, Premium travel editorial with neutral canvas, landscape photography, and serif titles

**Elements.** photo cards, continent chips, price CTA, route preview, vertical itinerary timeline

**Colour.** Catalogued dominant colours: warm white, ink black, slate, ocean blue, earth brown. Catalog palette: warm white, ink black, slate, ocean blue, earth brown Measured preview palette: #B5BBC5, #FFFFFF, #645D50, #1D2F36, #748694, #A49C98, #FAFAFA, #94B8DB

**Image evidence.** assets/mobile/images/dribbble-04-custom-itinerary.png — 1200×900 PNG; near-square; balanced; high visual density.

**Typography.** Elegant display serif for place names with clean sans-serif controls

**Layout and hierarchy.** Continent filter and destination, then tour story/price, then route and daily agenda

**Navigation.** Bottom tab bar, horizontal destination filters, and drill-down detail stack

**Motion and interaction.** Use shared-element photo transitions, a sticky booking CTA, and scroll-linked timeline progress.

**Why it works.** It blends aspirational editorial content with a very legible operational itinerary.

**Adaptation lesson.** Pair expressive imagery with a strict information rhythm: discover, understand, commit, manage.

**Accessibility / risk check.** Do not place essential copy only over photos; support larger type in chips and timeline rows.

**Provenance note.** Public source-page reference and local preview mapping documented by the mobile corpus methodology.

## M05 · Booking App for Rental Business - RentPlanner

| Field | Detail |
|---|---|
| ID | MOB-005 |
| Platform | Dribbble |
| Creator | Linkup ST |
| Reference date | Not documented in the source corpus. |
| Preview | Downloaded local preview |
| Source | [Booking App for Rental Business - RentPlanner](https://dribbble.com/shots/25826662-Booking-App-for-Rental-Business-RentPlanner) |

![Booking App for Rental Business - RentPlanner](assets/mobile/images/dribbble-05-rentplanner.png)

**Design focus.** Rental availability, booking operations, occupancy, and performance dashboard, Dark bento dashboard mixed with pastel analytics and photographic property cards

**Elements.** occupancy ring, property card, calendar, map, KPI tile, trend chart

**Colour.** Catalogued dominant colours: charcoal, mist blue, cobalt, pale pink, white, mint. Catalog palette: charcoal, mist blue, cobalt, pale pink, white, mint Measured preview palette: #4D4D57, #DEE7ED, #F9F0FB, #79747D, #93A9C6, #5D606D, #2B3037, #C7C7D5

**Image evidence.** assets/mobile/images/dribbble-05-rentplanner.png — 1200×900 PNG; near-square; cool; medium visual density.

**Typography.** Compact product sans-serif with large percentage KPIs

**Layout and hierarchy.** Availability KPI, property state, booking map/calendar, then trend and revenue evidence

**Navigation.** Dashboard hub with room/property drill-down and calendar/map modes

**Motion and interaction.** Reflow bento tiles on selection, sweep the occupancy ring, and crossfade calendar/map contexts.

**Why it works.** The dashboard feels operational yet approachable because each tile answers one question.

**Adaptation lesson.** Treat mobile dashboards as a ranked set of decisions, not a desktop dashboard squeezed smaller.

**Accessibility / risk check.** Charts need text summaries and non-color encodings; density should collapse to a prioritized single column on small phones.

**Provenance note.** Public source-page reference and local preview mapping documented by the mobile corpus methodology.

## M06 · AI-Powered Travel Mobile App - Smart Trip Planner

| Field | Detail |
|---|---|
| ID | MOB-006 |
| Platform | Dribbble |
| Creator | Orbix Studio LLC |
| Reference date | Not documented in the source corpus. |
| Preview | Downloaded local preview |
| Source | [AI-Powered Travel Mobile App - Smart Trip Planner](https://dribbble.com/shots/24692725-AI-Powered-Travel-Mobile-App-Smart-Trip-Planner) |

![AI-Powered Travel Mobile App - Smart Trip Planner](assets/mobile/images/dribbble-06-ai-trip-planner.png)

**Design focus.** AI package generation, destination, activity, budget, and preview map, Futuristic dark-purple travel poster with neon lime actions and 3D destination art

**Elements.** AI hero, package card, prompt/mode chips, 3D destination object, assistant orb

**Colour.** Catalogued dominant colours: black, deep violet, electric purple, acid lime, soft pink. Catalog palette: black, deep violet, electric purple, acid lime, soft pink Measured preview palette: #50579D, #212C4F, #8475B7, #3F3B6F, #101221, #7B5CAA, #BBABCA, #5E428D

**Image evidence.** assets/mobile/images/dribbble-06-ai-trip-planner.png — 1200×900 PNG; near-square; cool; medium visual density.

**Typography.** Oversized display sans-serif paired with compact pill labels

**Layout and hierarchy.** AI promise and featured package, then mode chips, generated content, and bottom navigation

**Navigation.** Mode tabs and persistent bottom bar centered on the assistant action

**Motion and interaction.** Use a restrained 3D tilt, orbiting assistant particles, and staged package generation with cancellable progress.

**Why it works.** A single visually dominant AI action gives a complex planner a memorable center of gravity.

**Adaptation lesson.** Use spectacle around the product's one magical moment, then return to calm controls.

**Accessibility / risk check.** Neon text must pass contrast on gradients; provide Reduce Motion and a static non-3D fallback.

**Provenance note.** Public source-page reference and local preview mapping documented by the mobile corpus methodology.

## M07 · Roamly - eSIM Provider Mobile App UI UX Design

| Field | Detail |
|---|---|
| ID | MOB-007 |
| Platform | Dribbble |
| Creator | CLOUD 2 VOICE |
| Reference date | Not documented in the source corpus. |
| Preview | Downloaded local preview |
| Source | [Roamly - eSIM Provider Mobile App UI UX Design](https://dribbble.com/shots/27618632-Roamly-eSIM-Provider-Mobile-App-UI-UX-Design) |

![Roamly - eSIM Provider Mobile App UI UX Design](assets/mobile/images/dribbble-07-roamly-esim.png)

**Design focus.** Country search, eSIM plan browse, purchase, and activation, Dark premium utility with mint glow, glassy cards, and compact travel illustrations

**Elements.** country search, plan card, allowance chips, activation progress, bottom tabs

**Colour.** Catalogued dominant colours: near black, mint, teal, pale aqua, warm gray. Catalog palette: near black, mint, teal, pale aqua, warm gray Measured preview palette: #060D1B, #010106, #1C1115, #AEE8E1, #05050D, #01030B, #02030B, #534142

**Image evidence.** assets/mobile/images/dribbble-07-roamly-esim.png — 1200×888 PNG; landscape; balanced; low visual density.

**Typography.** Confident sans-serif headlines with highly scannable plan metadata

**Layout and hierarchy.** Destination/search, recommended plan, allowance/duration/price, activation status

**Navigation.** Search-led home, category shortcuts, and bottom tab bar

**Motion and interaction.** Morph a selected country tile into the plan sheet and animate activation as a clear finite sequence.

**Why it works.** It gives a technical telecom purchase the visual simplicity of a travel accessory.

**Adaptation lesson.** For invisible services, anchor trust with concrete quantities, progress, and a clear installed state.

**Accessibility / risk check.** Prices and data limits need larger tap targets; avoid low-contrast glass surfaces and keep activation recoverable.

**Provenance note.** Public source-page reference and local preview mapping documented by the mobile corpus methodology.

## M08 · Beyond - Travel Mobile Apps

| Field | Detail |
|---|---|
| ID | MOB-008 |
| Platform | Dribbble |
| Creator | Arfi Maulana for Pickolab Studio |
| Reference date | Not documented in the source corpus. |
| Preview | Downloaded local preview |
| Source | [Beyond - Travel Mobile Apps](https://dribbble.com/shots/21024574-Beyond-Travel-Mobile-Apps) |

![Beyond - Travel Mobile Apps](assets/mobile/images/dribbble-08-beyond-travel.png)

**Design focus.** Travel onboarding, flight search, and destination discovery, Friendly minimal travel with charcoal surfaces, white canvas, and marigold illustrations

**Elements.** illustrated onboarding, flight search, airport fields, destination cards, bottom tabs

**Colour.** Catalogued dominant colours: white, charcoal, marigold, pale gray, sky blue. Catalog palette: white, charcoal, marigold, pale gray, sky blue Measured preview palette: #F4F4F4, #FFFFFF, #E5E6E7, #807F74, #F0EFEF, #F8F8F8, #FDFDFC, #F1F5F6

**Image evidence.** assets/mobile/images/dribbble-08-beyond-travel.png — 1200×900 PNG; near-square; balanced; medium visual density.

**Typography.** Rounded modern sans-serif with concise onboarding copy

**Layout and hierarchy.** Benefit illustration, primary start CTA, search form, then recent/popular destinations

**Navigation.** Three-step onboarding into a conventional bottom-tab travel home

**Motion and interaction.** Animate the illustrated character between steps and slide airport fields as a reversible swap gesture.

**Why it works.** It uses illustration to establish warmth, then switches to familiar booking patterns without visual whiplash.

**Adaptation lesson.** Onboarding style can be expressive if the first operational screen becomes immediately conventional.

**Accessibility / risk check.** Keep Skip and progress visible, use 44pt controls, and announce swapped origin/destination to assistive tech.

**Provenance note.** Public source-page reference and local preview mapping documented by the mobile corpus methodology.

## M09 · Food Tracking Mobile App UI with AI Scan

| Field | Detail |
|---|---|
| ID | MOB-009 |
| Platform | Dribbble |
| Creator | Nixtio |
| Reference date | Not documented in the source corpus. |
| Preview | Downloaded local preview |
| Source | [Food Tracking Mobile App UI with AI Scan](https://dribbble.com/shots/27377874-Food-Tracking-Mobile-App-UI-with-AI-Scan) |

![Food Tracking Mobile App UI with AI Scan](assets/mobile/images/dribbble-09-ai-food-tracking.png)

**Design focus.** Nutrition dashboard, AI meal scan, recipes, and macro tracking, Warm editorial wellness with cream surfaces, food photography, and orange/olive accents

**Elements.** macro arc, meal rows, camera scan CTA, food photo, recipe cards, nutrition badges

**Colour.** Catalogued dominant colours: cream, black, burnt orange, olive, sand, fresh green. Catalog palette: cream, black, burnt orange, olive, sand, fresh green Measured preview palette: #D0C5BE, #F9F7F3, #8D7C66, #C0C585, #EBE4D7, #CBC5C0, #D2C5C3, #CECCB5

**Image evidence.** assets/mobile/images/dribbble-09-ai-food-tracking.png — 1200×900 PNG; near-square; warm; medium visual density.

**Typography.** Bold friendly sans-serif for outcomes and small compact nutrition labels

**Layout and hierarchy.** Daily calorie arc, meal totals, AI scan, then recipes and nutrition details

**Navigation.** Bottom tabs with a visually elevated central scan action

**Motion and interaction.** Animate detected food labels onto the camera image and let the macro arc reconcile after confirmation.

**Why it works.** The product reduces logging friction while retaining a transparent daily summary.

**Adaptation lesson.** When AI automates input, design the confirmation and correction loop as carefully as the magic scan.

**Accessibility / risk check.** Camera overlays need spoken results and manual correction; macro colors need text labels and pattern alternatives.

**Provenance note.** Public source-page reference and local preview mapping documented by the mobile corpus methodology.

## M10 · Creative 3D Builder Mobile App UI

| Field | Detail |
|---|---|
| ID | MOB-010 |
| Platform | Dribbble |
| Creator | Nixtio |
| Reference date | Not documented in the source corpus. |
| Preview | Downloaded local preview |
| Source | [Creative 3D Builder Mobile App UI](https://dribbble.com/shots/26958138-Creative-3D-Builder-Mobile-App-UI) |

![Creative 3D Builder Mobile App UI](assets/mobile/images/dribbble-10-creative-3d-builder.png)

**Design focus.** Tutorials, recent 3D projects, mobile editor, and premium upgrade, Playful black interface over acid green/yellow geometry with friendly 3D characters

**Elements.** 3D canvas, object library, floating toolbar, tutorial cards, pricing comparison

**Colour.** Catalogued dominant colours: black, white, acid green, yellow, orange, forest green. Catalog palette: black, white, acid green, yellow, orange, forest green Measured preview palette: #F8CE0B, #131313, #F3EF85, #97D524, #5CA142, #060606, #3F4B31, #CCD624

**Image evidence.** assets/mobile/images/dribbble-10-creative-3d-builder.png — 1200×900 PNG; near-square; warm; medium visual density.

**Typography.** Chunky rounded display type plus compact tool labels

**Layout and hierarchy.** Recent work and tutorials, selected 3D object, edit controls, then plan benefits

**Navigation.** Project home into immersive editor with floating toolbars and modal upgrade

**Motion and interaction.** Direct-manipulation rotation, springy object placement, contextual toolbars, and an undoable action history are central.

**Why it works.** The editor looks fun without hiding a predictable tool model.

**Adaptation lesson.** Let the 3D artifact be the spectacle; keep controls flat, labeled, and spatially stable.

**Accessibility / risk check.** Offer non-gesture controls for every transform, large handles, Reduce Motion, and sufficient contrast on neon fields.

**Provenance note.** Public source-page reference and local preview mapping documented by the mobile corpus methodology.

## M11 · PowerPeak – Fitness Mobile App Design

| Field | Detail |
|---|---|
| ID | MOB-011 |
| Platform | Dribbble |
| Creator | Phenomenon Product for Phenomenon Studio |
| Reference date | Not documented in the source corpus. |
| Preview | Downloaded local preview |
| Source | [PowerPeak – Fitness Mobile App Design](https://dribbble.com/shots/26144127-PowerPeak-Fitness-Mobile-App-Design) |

![PowerPeak – Fitness Mobile App Design](assets/mobile/images/dribbble-11-powerpeak-fitness.png)

**Design focus.** Fitness onboarding, adaptive workouts, live session, summary, and challenges, Kinetic dark sports UI with orange light trails and oversized performance numbers

**Elements.** workout card, big stat, interval timer, rep counter, AI coach, leaderboard

**Colour.** Catalogued dominant colours: black, burnt orange, amber, cream, deep red. Catalog palette: black, burnt orange, amber, cream, deep red Measured preview palette: #321C19, #8D4124, #1D1A1D, #A06442, #54211A, #EAC495, #573727, #120B0A

**Image evidence.** assets/mobile/images/dribbble-11-powerpeak-fitness.png — 1200×900 PNG; near-square; warm; low visual density.

**Typography.** Very large condensed numeric display with terse coaching text

**Layout and hierarchy.** Current goal/performance, next workout, live rep/timer controls, then history/community

**Navigation.** Bottom tabs plus full-screen workout mode and watch companion

**Motion and interaction.** Use energy trails only for transitions; session motion should reinforce cadence, progress, and success haptics.

**Why it works.** The visual energy matches the domain while the live session remains singular and focused.

**Adaptation lesson.** Separate motivational spectacle from the safety-critical task surface.

**Accessibility / risk check.** Provide audio/haptic cues, pause controls, high-contrast text, and avoid flashing or motion during intense activity.

**Provenance note.** Public source-page reference and local preview mapping documented by the mobile corpus methodology.

## M12 · Hume – Mobile App Design for Smart Home

| Field | Detail |
|---|---|
| ID | MOB-012 |
| Platform | Dribbble |
| Creator | Phenomenon Product for Phenomenon Studio |
| Reference date | Not documented in the source corpus. |
| Preview | Downloaded local preview |
| Source | [Hume – Mobile App Design for Smart Home](https://dribbble.com/shots/26559633-Hume-Mobile-App-Design-for-Smart-Home) |

![Hume – Mobile App Design for Smart Home](assets/mobile/images/dribbble-12-hume-smart-home.png)

**Design focus.** Home overview, device control, scenes, surveillance, and energy use, Dark architectural dashboard with room imagery, graphite cards, and red-orange focus states

**Elements.** device cards, room carousel, scene builder, live camera, energy chart, state toggle

**Colour.** Catalogued dominant colours: near black, graphite, warm gray, red-orange, muted green. Catalog palette: near black, graphite, warm gray, red-orange, muted green Measured preview palette: #3E3F41, #212223, #5E5D5D, #534A47, #373334, #2A2A2C, #111010, #818180

**Image evidence.** assets/mobile/images/dribbble-12-hume-smart-home.png — 1200×900 PNG; near-square; balanced; medium visual density.

**Typography.** Low-noise sans-serif with compact state labels and clear section titles

**Layout and hierarchy.** Home mode and urgent status, room/device cards, scene controls, then analytics

**Navigation.** Room-based dashboard with bottom tabs and contextual device sheets

**Motion and interaction.** Mirror physical state changes with brief, reversible micro-animations and animate scene setup as a cause-and-effect chain.

**Why it works.** Real imagery provides spatial context while card hierarchy keeps many devices manageable.

**Adaptation lesson.** In control systems, beauty comes from trustworthy state, latency feedback, and spatial grouping.

**Accessibility / risk check.** Every device state needs text, pending/error feedback, and large controls; destructive security actions need confirmation.

**Provenance note.** Public source-page reference and local preview mapping documented by the mobile corpus methodology.

## M13 · Next - Crypto App Design

| Field | Detail |
|---|---|
| ID | MOB-013 |
| Platform | Dribbble |
| Creator | Outloud |
| Reference date | Not documented in the source corpus. |
| Preview | Downloaded local preview |
| Source | [Next - Crypto App Design](https://dribbble.com/shots/27241033-Next-Crypto-App-Design) |

![Next - Crypto App Design](assets/mobile/images/dribbble-13-next-crypto.webp)

**Design focus.** Crypto portfolio overview, transfer action, and market movement, Quiet pale-gray finance UI disrupted by soft organic 3D data forms and acid-green CTA

**Elements.** balance hero, 3D organic chart, transfer CTA, asset list, activity card

**Colour.** Catalogued dominant colours: pale gray, white, black, sage, acid green, blue gray. Catalog palette: pale gray, white, black, sage, acid green, blue gray Measured preview palette: #DEE5EB, #F7F9FB, #3C3C3A, #C7D4D8, #DFE5EC, #DEE5EC, #E7F4B2, #D6E9DA

**Image evidence.** assets/mobile/images/dribbble-13-next-crypto.webp — 1200×900 JPEG; near-square; balanced; medium visual density.

**Typography.** Editorially oversized balance with understated sans-serif transaction labels

**Layout and hierarchy.** Portfolio value and change, transfer action, organic chart, then recent activity

**Navigation.** Minimal home with focused primary action and direct asset drill-down

**Motion and interaction.** Make the 3D graph respond slowly to time-range changes; never animate live values so aggressively that comparison becomes difficult.

**Why it works.** A single unfamiliar 3D motif creates distinction while the financial controls stay orthodox.

**Adaptation lesson.** Use one signature data visualization, but keep numeric truth and task flows conventional.

**Accessibility / risk check.** Pair chart shape/color with exact values, disclose volatility, and protect transfer confirmation from accidental taps.

**Provenance note.** Public source-page reference and local preview mapping documented by the mobile corpus methodology.

## M14 · Sereno – AI Psychological Support Mobile App

| Field | Detail |
|---|---|
| ID | MOB-014 |
| Platform | Dribbble |
| Creator | Phenomenon Product for Phenomenon Studio |
| Reference date | Not documented in the source corpus. |
| Preview | Downloaded local preview |
| Source | [Sereno – AI Psychological Support Mobile App](https://dribbble.com/shots/25994023-Sereno-AI-Psychological-Support-Mobile-App) |

![Sereno – AI Psychological Support Mobile App](assets/mobile/images/dribbble-14-sereno-ai-mental-health.png)

**Design focus.** Mood-aware chat, mindfulness, breathing, voice/video, and emergency support, Calm deep-violet nightscape with soft gradients, low visual noise, and empathetic copy

**Elements.** mood line, chat, breathing timer, voice/video controls, emergency action, privacy cues

**Colour.** Catalogued dominant colours: midnight indigo, violet, lavender, white, muted blue. Catalog palette: midnight indigo, violet, lavender, white, muted blue Measured preview palette: #100326, #3C3EA1, #32318A, #36369B, #13052D, #201450, #797BBB, #06010E

**Image evidence.** assets/mobile/images/dribbble-14-sereno-ai-mental-health.png — 1200×900 PNG; near-square; cool; low visual density.

**Typography.** Warm large sans-serif statements with generous line spacing

**Layout and hierarchy.** Current emotional state, recommended support, conversation, then optional tools and escalation

**Navigation.** Assistant-centered home with context-sensitive recommendations and always-reachable help

**Motion and interaction.** Use slow ambient gradients and paced breathing animation, with complete Reduce Motion and immediate emergency interruption.

**Why it works.** The interface removes choice at emotionally difficult moments while maintaining several communication modes.

**Adaptation lesson.** In sensitive products, calm hierarchy, privacy, and escalation design matter more than visual novelty.

**Accessibility / risk check.** Avoid low-contrast purple text, support screen readers and captions, and never let AI obscure crisis escalation or clinical limitations.

**Provenance note.** Public source-page reference and local preview mapping documented by the mobile corpus methodology.

## M15 · Mobile App Design — ECG & Heart Rate Monitoring UI

| Field | Detail |
|---|---|
| ID | MOB-015 |
| Platform | Dribbble |
| Creator | Nixtio |
| Reference date | Not documented in the source corpus. |
| Preview | Downloaded local preview |
| Source | [Mobile App Design — ECG & Heart Rate Monitoring UI](https://dribbble.com/shots/26808268-Mobile-App-Design-ECG-Heart-Rate-Monitoring-UI) |

![Mobile App Design — ECG & Heart Rate Monitoring UI](assets/mobile/images/dribbble-15-ecg-heart-rate.png)

**Design focus.** ECG recording, current heart rate, weekly insights, and health metrics, Clinical light UI with soft gray blocks, high-contrast numbers, and vermilion data accents

**Elements.** BPM hero, ECG trace, recording timer, weekly bars, range badge, metric tabs

**Colour.** Catalogued dominant colours: white, light gray, charcoal, vermilion, peach. Catalog palette: white, light gray, charcoal, vermilion, peach Measured preview palette: #B3B3B3, #F3F4F4, #E6E7E8, #B2B3B3, #AC867C, #D0CECC, #B3B3B4, #E4B39A

**Image evidence.** assets/mobile/images/dribbble-15-ecg-heart-rate.png — 1200×900 PNG; near-square; balanced; medium visual density.

**Typography.** Large tabular numerals with precise medical labels

**Layout and hierarchy.** Current BPM, recording state, trace/chart, range and weekly interpretation

**Navigation.** Metric dashboard into focused recording mode and longitudinal insight views

**Motion and interaction.** Animate the live trace only while measuring; freeze and annotate results for review.

**Why it works.** Large numbers and restrained decoration make complex health data readable at a glance.

**Adaptation lesson.** Clinical clarity should dominate; animation is useful only when it communicates measurement state.

**Accessibility / risk check.** Never rely on red alone, expose exact values and units, support large type, and distinguish wellness guidance from diagnosis.

**Provenance note.** Public source-page reference and local preview mapping documented by the mobile corpus methodology.

## M16 · SaaS Mobile App Design for Upstream

| Field | Detail |
|---|---|
| ID | MOB-016 |
| Platform | Dribbble |
| Creator | Ramotion |
| Reference date | Not documented in the source corpus. |
| Preview | Downloaded local preview |
| Source | [SaaS Mobile App Design for Upstream](https://dribbble.com/shots/26656585-SaaS-Mobile-App-Design-for-Upstream) |

![SaaS Mobile App Design for Upstream](assets/mobile/images/dribbble-16-upstream-saas.png)

**Design focus.** Enterprise carbon visibility and facility KPI dashboard, Warm editorial ESG interface with cream cards, wood photography, and restrained charts

**Elements.** KPI card, facility list, donut/chart, goal status, filter chips, insight summary

**Colour.** Catalogued dominant colours: off-white, warm brown, amber, charcoal, sage, steel blue. Catalog palette: off-white, warm brown, amber, charcoal, sage, steel blue Measured preview palette: #F4F3F0, #7F4C2A, #FDFDFD, #CA9056, #956F50, #4B3322, #F8E4B7, #E3D8BF

**Image evidence.** assets/mobile/images/dribbble-16-upstream-saas.png — 1200×900 PNG; near-square; warm; medium visual density.

**Typography.** Professional humanist sans-serif with large KPI numerals

**Layout and hierarchy.** Headline emissions KPI, facility breakdown, trend/goal, then actions and details

**Navigation.** Executive overview with facility drill-down and filterable time ranges

**Motion and interaction.** Use subtle count-up only on first reveal and shared-axis chart transitions when filters change.

**Why it works.** Warm material cues make sustainability data feel grounded rather than abstract.

**Adaptation lesson.** Enterprise mobile should answer one executive question per screen and defer analytical depth.

**Accessibility / risk check.** Provide chart tables/summaries, stable tabular numbers, and avoid excessively small enterprise labels.

**Provenance note.** Public source-page reference and local preview mapping documented by the mobile corpus methodology.

## M17 · Online Language Learning Mobile App UX/UI

| Field | Detail |
|---|---|
| ID | MOB-017 |
| Platform | Dribbble |
| Creator | Nixtio |
| Reference date | Not documented in the source corpus. |
| Preview | Downloaded local preview |
| Source | [Online Language Learning Mobile App UX/UI](https://dribbble.com/shots/27176366-Online-Language-Learning-Mobile-App-UX-UI) |

![Online Language Learning Mobile App UX/UI](assets/mobile/images/dribbble-17-language-learning.png)

**Design focus.** Lesson selection, writing/listening practice, tutor call, and classroom chat, Soft blush learning environment with clean cards and friendly portrait/video focus

**Elements.** task checklist, practice chips, video call, chat thread, progress state

**Colour.** Catalogued dominant colours: blush, soft pink, white, black, rose, warm brown. Catalog palette: blush, soft pink, white, black, rose, warm brown Measured preview palette: #F3D1D1, #F0E5EE, #C8A29F, #F9EEF7, #E0C7D0, #F4D4E1, #4C3732, #E0DEE6

**Image evidence.** assets/mobile/images/dribbble-17-language-learning.png — 1200×900 PNG; near-square; warm; medium visual density.

**Typography.** Rounded accessible sans-serif with task-first labels

**Layout and hierarchy.** Next task, practice type, tutor context, then real-time conversation

**Navigation.** Task list home into full-screen lesson/call/chat contexts

**Motion and interaction.** Use completion ticks, pronunciation feedback waves, and smooth handoff between lesson and call.

**Why it works.** Each screen asks the learner to do one thing while preserving human connection.

**Adaptation lesson.** Learning interfaces benefit from calm task framing and immediate, multimodal feedback.

**Accessibility / risk check.** Caption all media, support text alternatives for audio, account for keyboard/IME height, and avoid pink-on-white low contrast.

**Provenance note.** Public source-page reference and local preview mapping documented by the mobile corpus methodology.

## M18 · AI Mobile App Onboarding Screens

| Field | Detail |
|---|---|
| ID | MOB-018 |
| Platform | Dribbble |
| Creator | Nixtio |
| Reference date | Not documented in the source corpus. |
| Preview | Downloaded local preview |
| Source | [AI Mobile App Onboarding Screens](https://dribbble.com/shots/26172693-AI-Mobile-App-Onboarding-Screens) |

![AI Mobile App Onboarding Screens](assets/mobile/images/dribbble-18-ai-onboarding.png)

**Design focus.** Strategy/risk personalization onboarding, Editorial pastel cards with bold black type and hand-drawn risk illustrations

**Elements.** choice cards, progress, illustration, primary CTA, plain-language consequence

**Colour.** Catalogued dominant colours: cream, salmon, pale yellow, black, muted brown. Catalog palette: cream, salmon, pale yellow, black, muted brown Measured preview palette: #F5F5F5, #F9E5D9, #F3FCDE, #9E928D, #FAFCE7, #FCFCFC, #F5F5F6, #F6F5F5

**Image evidence.** assets/mobile/images/dribbble-18-ai-onboarding.png — 1200×900 PNG; near-square; warm; medium visual density.

**Typography.** Oversized bold grotesk headlines with short explanatory copy

**Layout and hierarchy.** Distinct choice headline, one-sentence consequence, illustration, then explicit selection CTA

**Navigation.** Linear card sequence with one decision per screen

**Motion and interaction.** Cards can tilt subtly on drag and snap into a confirmed state; avoid delaying the decision with decorative animation.

**Why it works.** Abstract strategy choices become memorable because each is given a strong verbal and visual identity.

**Adaptation lesson.** For consequential onboarding, explain tradeoffs in plain language before collecting a preference.

**Accessibility / risk check.** Do not make risk meaning depend on color or illustration; preserve clear Back/Skip and minimum touch sizes.

**Provenance note.** Public source-page reference and local preview mapping documented by the mobile corpus methodology.

## M19 · Time Tracking & Productivity Mobile App UI

| Field | Detail |
|---|---|
| ID | MOB-019 |
| Platform | Dribbble |
| Creator | Nixtio |
| Reference date | Not documented in the source corpus. |
| Preview | Downloaded local preview |
| Source | [Time Tracking & Productivity Mobile App UI](https://dribbble.com/shots/27279963-Time-Tracking-Productivity-Mobile-App-UI) |

![Time Tracking & Productivity Mobile App UI](assets/mobile/images/dribbble-19-time-tracking.png)

**Design focus.** Calendar, session tracking, timer, and productivity performance, Dark gradient productivity with hot orange, cobalt, and circular timer emphasis

**Elements.** calendar heatmap, session card, circular timer, project selector, summary chart

**Colour.** Catalogued dominant colours: black, orange, red, cobalt, violet, white. Catalog palette: black, orange, red, cobalt, violet, white Measured preview palette: #BCBBD1, #EC741B, #E0D2DB, #7E1406, #49679D, #0A1024, #9AACD1, #E5AD86

**Image evidence.** assets/mobile/images/dribbble-19-time-tracking.png — 1200×900 PNG; near-square; warm; medium visual density.

**Typography.** Large timer numerals with compact schedule metadata

**Layout and hierarchy.** Today's schedule, active session, elapsed/remaining time, then historical insight

**Navigation.** Calendar and dashboard tabs leading to a distraction-free active timer

**Motion and interaction.** Animate time continuously only in active mode; use quiet state transitions elsewhere and support Live Activities.

**Why it works.** Three distinct contexts—plan, focus, review—share one visual system without competing on the same screen.

**Adaptation lesson.** Productivity tools should visually change mode when the user's cognitive job changes.

**Accessibility / risk check.** Timer controls need large targets, background-state persistence, voice control, and non-color status cues.

**Provenance note.** Public source-page reference and local preview mapping documented by the mobile corpus methodology.

## M20 · AI Learning Mobile App — Kids Education UI

| Field | Detail |
|---|---|
| ID | MOB-020 |
| Platform | Dribbble |
| Creator | Bogdan Nikitin for Nixtio |
| Reference date | Not documented in the source corpus. |
| Preview | Downloaded local preview |
| Source | [AI Learning Mobile App — Kids Education UI](https://dribbble.com/shots/27068193-AI-Learning-Mobile-App-Kids-Education-UI) |

![AI Learning Mobile App — Kids Education UI](assets/mobile/images/dribbble-20-kids-ai-learning.png)

**Design focus.** Gamified lesson, daily affirmation, AI chat, and rewards, Character-led playful UI with peach surfaces, comic typography, orange and lime stickers

**Elements.** 3D character, speech card, reward badge, lesson CTA, chat composer, progress

**Colour.** Catalogued dominant colours: peach, white, orange, lime, brown, black. Catalog palette: peach, white, orange, lime, brown, black Measured preview palette: #EABBA7, #EBEBEA, #AD6138, #CFEF6F, #BEC484, #ECBBA6, #EABBA6, #EEBFAB

**Image evidence.** assets/mobile/images/dribbble-20-kids-ai-learning.png — 1200×900 PNG; near-square; warm; medium visual density.

**Typography.** Bold playful display type backed by large, simple conversational text

**Layout and hierarchy.** Character/message, current lesson or reward, primary response, then supporting progress

**Navigation.** Assistant-led home with chat/lesson cards and a persistent voice/text composer

**Motion and interaction.** Use short character reactions and celebratory stickers tied to learning outcomes, with strict frequency caps.

**Why it works.** A consistent character makes the assistant feel coherent while the bold hierarchy stays easy for children.

**Adaptation lesson.** Character motion should acknowledge meaningful progress, not distract from the learning task.

**Accessibility / risk check.** Keep reading level age-appropriate, caption voice, protect child privacy, support Reduce Motion, and avoid manipulative reward loops.

**Provenance note.** Public source-page reference and local preview mapping documented by the mobile corpus methodology.

## M21 · Furniture E-commerce Mobile App

| Field | Detail |
|---|---|
| ID | MOB-021 |
| Platform | Dribbble |
| Creator | Nixtio |
| Reference date | Not documented in the source corpus. |
| Preview | Downloaded local preview |
| Source | [Furniture E-commerce Mobile App](https://dribbble.com/shots/27020833-Furniture-E-commerce-Mobile-App) |

![Furniture E-commerce Mobile App](assets/mobile/images/dribbble-21-furniture-commerce.png)

**Design focus.** Furniture browse, product detail, color/material choice, and add to cart, Premium forest-green product theatre with oversized cutout furniture and minimal UI chrome

**Elements.** product cutout, variant swatches, price, favorite, cart CTA, image progress

**Colour.** Catalogued dominant colours: forest green, black, white, sage, natural wood. Catalog palette: forest green, black, white, sage, natural wood Measured preview palette: #5E7646, #1C321F, #2B3D27, #465F39, #F7F9F6, #3B4C30, #7E9A63, #0B170E

**Image evidence.** assets/mobile/images/dribbble-21-furniture-commerce.png — 1200×900 PNG; near-square; balanced; medium visual density.

**Typography.** Elegant large sans-serif product title with sparse commercial metadata

**Layout and hierarchy.** Product image and name, price/discount, variant choice, then purchase action

**Navigation.** Visual product card into immersive detail with floating actions

**Motion and interaction.** Rotate the product with constrained 3D drag, morph listing image into detail, and keep the buy action spatially stable.

**Why it works.** The product occupies the visual stage while conversion controls remain minimal and obvious.

**Adaptation lesson.** In premium commerce, remove chrome before adding effects; one excellent product transition is enough.

**Accessibility / risk check.** Name color/material variants, keep product controls above the home indicator, and provide static photos for Reduce Motion.

**Provenance note.** Public source-page reference and local preview mapping documented by the mobile corpus methodology.

## M22 · Online E-commerce Shop Mobile App UI Design

| Field | Detail |
|---|---|
| ID | MOB-022 |
| Platform | Behance |
| Creator | Opedia Studio |
| Reference date | Not documented in the source corpus. |
| Preview | Downloaded local preview |
| Source | [Online E-commerce Shop Mobile App UI Design](https://www.behance.net/gallery/200234609/Online-E-commerce-Shop-Mobile-App-UI-Design) |

![Online E-commerce Shop Mobile App UI Design](assets/mobile/images/behance-01-online-ecommerce.jpg)

**Design focus.** Authentication and broader online store flow, Minimal monochrome forms staged on a deep green atmospheric background

**Elements.** text fields, password affordance, primary button, social login, account switch link

**Colour.** Catalogued dominant colours: white, black, deep green, soft gray. Catalog palette: white, black, deep green, soft gray Measured preview palette: #FFFFFF, #09160E, #070D0A, #0D2217, #071C11, #060807, #07110B, #B3B6B5

**Image evidence.** assets/mobile/images/behance-01-online-ecommerce.jpg — 1920×1440 JPEG; near-square; balanced; low visual density.

**Typography.** Neutral modern sans-serif with restrained form labels

**Layout and hierarchy.** Account purpose, essential fields, primary submit, then social/alternate access

**Navigation.** Linear sign-in/sign-up entry into the commerce experience

**Motion and interaction.** Use a shared layout between sign-in and sign-up with inline validation rather than page-flipping spectacle.

**Why it works.** Strong contrast and few choices keep the gateway calm.

**Adaptation lesson.** Save expressive branding for the surrounding frame; authentication itself should feel predictable.

**Accessibility / risk check.** Support password managers, autofill, visible labels, error summaries, and keyboard-safe forms.

**Provenance note.** Public source-page reference and local preview mapping documented by the mobile corpus methodology.

## M23 · Serena Medical — Healthcare App UX/UI Design

| Field | Detail |
|---|---|
| ID | MOB-023 |
| Platform | Behance |
| Creator | Sigma Software Design |
| Reference date | Not documented in the source corpus. |
| Preview | Downloaded local preview |
| Source | [Serena Medical — Healthcare App UX/UI Design](https://www.behance.net/gallery/226311719/Serena-Medical-Healthcare-App-UXUI-Design) |

![Serena Medical — Healthcare App UX/UI Design](assets/mobile/images/behance-02c-serena-medical.jpg)

Additional local frames: assets/mobile/images/behance-02-serena-medical.jpg, assets/mobile/images/behance-02b-serena-medical.jpg

**Design focus.** Doctor search, specialty browse, appointment booking, and healthcare service management, Research-led medical clarity with white space, electric blue, soft lavender cards, and black CTAs

**Elements.** search field, specialty tiles, doctor card, availability, favorite, booking CTA

**Colour.** Catalogued dominant colours: white, electric blue, lavender, black, soft yellow, gray. Catalog palette: white, electric blue, lavender, black, soft yellow, gray Measured preview palette: #FFFFFF, #4648E6, #F9F8FB, #D6D6DC, #171753, #8382B8, #FDFFFF, #FFFFFD

**Image evidence.** assets/mobile/images/behance-02c-serena-medical.jpg — 1920×1454 JPEG; near-square; balanced; medium visual density. assets/mobile/images/behance-02-serena-medical.jpg — 1920×937 JPEG; landscape; balanced; low visual density. assets/mobile/images/behance-02b-serena-medical.jpg — 1920×2399 JPEG; near-square; balanced; medium visual density.

**Typography.** Large assertive sans-serif headings with compact evidence and service labels

**Layout and hierarchy.** Search/specialty, doctor card, rating/availability, then book appointment

**Navigation.** Search-led discovery with specialty grid and list-based booking

**Motion and interaction.** Expand a specialty tile into filtered results and carry the selected doctor card into the booking calendar.

**Why it works.** The case study ties clear UX decisions to user research instead of decorating a generic doctor list.

**Adaptation lesson.** Build the visual system around the user's anxiety-reducing questions: who, when, cost, next step.

**Accessibility / risk check.** Medical specialties need text labels, booking must work at large type, and photos cannot substitute for provider identity/details.

**Provenance note.** Public source-page reference and local preview mapping documented by the mobile corpus methodology.

## M24 · AI eCommerce | Mobile app & Website UI UX | FocoTik

| Field | Detail |
|---|---|
| ID | MOB-024 |
| Platform | Behance |
| Creator | FocoTik UI/UX Design & Branding |
| Reference date | Not documented in the source corpus. |
| Preview | Downloaded local preview |
| Source | [AI eCommerce \| Mobile app & Website UI UX \| FocoTik](https://www.behance.net/gallery/220000795/AI-eCommerce-Mobile-app-Website-UI-UX-FocoTik) |

![AI eCommerce | Mobile app & Website UI UX | FocoTik](assets/mobile/images/behance-03-focotik-ai-commerce.jpg)

**Design focus.** AI fashion discovery, recommendations, checkout, and order confirmation, Glossy black commerce with cosmic magenta/orange gradients and vivid product cards

**Elements.** recommendation carousel, promo card, category chips, product card, success badge, order summary

**Colour.** Catalogued dominant colours: black, plum, magenta, coral, orange, white. Catalog palette: black, plum, magenta, coral, orange, white Measured preview palette: #0B0A0B, #140D19, #332331, #25161D, #171119, #100C11, #80626D, #060607

**Image evidence.** assets/mobile/images/behance-03-focotik-ai-commerce.jpg — 1920×2061 JPEG; near-square; balanced; low visual density.

**Typography.** Bold modern sans-serif mixed with expressive handwritten accent words

**Layout and hierarchy.** Recommended products and promotion, item/price, checkout success, then order details and tracking

**Navigation.** Bottom commerce tabs, recommendation feed, cart/checkout, then explicit success state

**Motion and interaction.** Use glossy card depth, assistant recommendation reveals, and a compact success celebration that resolves into track-order details.

**Why it works.** It gives AI shopping a distinct nightlife identity while keeping checkout conventional.

**Adaptation lesson.** Push visual personality in discovery and success, but reduce novelty during payment.

**Accessibility / risk check.** Gradient buttons and small product metadata need contrast checks; success confetti must respect Reduce Motion.

**Provenance note.** Public source-page reference and local preview mapping documented by the mobile corpus methodology.

## M25 · Swift - Digital Banking Mobile App UI UX design

| Field | Detail |
|---|---|
| ID | MOB-025 |
| Platform | Behance |
| Creator | Musemind |
| Reference date | Not documented in the source corpus. |
| Preview | Downloaded local preview |
| Source | [Swift - Digital Banking Mobile App UI UX design](https://www.behance.net/gallery/207942807/Swift-Digital-Banking-Mobile-App-UI-UX-design) |

![Swift - Digital Banking Mobile App UI UX design](assets/mobile/images/behance-04-swift-banking.png)

**Design focus.** Banking home, virtual cards, limits, transfers, scheduled payments, and AI advice, Gen-Z banking with deep teal, lime/orange pill typography, and bright modular surfaces

**Elements.** balance, quick actions, virtual card, limit control, scheduled payment, AI advice

**Colour.** Catalogued dominant colours: deep teal, lime, orange-red, white, black, pastel pink. Catalog palette: deep teal, lime, orange-red, white, black, pastel pink Measured preview palette: #004C5D, #88887C, #B5CAB3, #FDFCFC, #514A44, #003645, #004C5E, #005366

**Image evidence.** assets/mobile/images/behance-04-swift-banking.png — 1920×1085 PNG; landscape; cool; medium visual density.

**Typography.** Large sans-serif words inside mixed-shape labels with clear numeric UI text

**Layout and hierarchy.** Balance and quick actions, account/card control, transaction task, then advice

**Navigation.** One-bank hub with unified payment selection and conventional bottom tabs

**Motion and interaction.** Morph branded word pills into functional quick-action chips; keep transfer and limit transitions sober and explicit.

**Why it works.** The brand is energetic while task groupings remain understandable.

**Adaptation lesson.** Expressive finance can work when identity wraps the system rather than altering transaction semantics.

**Accessibility / risk check.** Colorful pills need strong contrast and logical reading order; all financial actions require review and confirmation.

**Provenance note.** Public source-page reference and local preview mapping documented by the mobile corpus methodology.

## M26 · ZocDoc Health Care - Mobile App & UX UI Design

| Field | Detail |
|---|---|
| ID | MOB-026 |
| Platform | Behance |
| Creator | Rondesignlab and collaborators |
| Reference date | Not documented in the source corpus. |
| Preview | Downloaded local preview |
| Source | [ZocDoc Health Care - Mobile App & UX UI Design](https://www.behance.net/gallery/179997039/ZocDoc-Health-Care-Mobile-App-UX-UI-Design) |

![ZocDoc Health Care - Mobile App & UX UI Design](assets/mobile/images/behance-05-zocdoc-health.jpg)

**Design focus.** Doctor discovery, reviews, insurance documents, and appointment scheduling, Human-centered medical branding with full-bleed portraits, warm glass panels, and huge editorial copy

**Elements.** provider portrait, trust statement, doctor profile, review, insurance card, schedule picker

**Colour.** Catalogued dominant colours: warm white, taupe, gray, skin tones, black. Catalog palette: warm white, taupe, gray, skin tones, black Measured preview palette: #747879, #E5E7E3, #9B9EA0, #745C4F, #F2F3F0, #8E847E, #C5C7C9, #463E3A

**Image evidence.** assets/mobile/images/behance-05-zocdoc-health.jpg — 1920×1523 JPEG; near-square; balanced; medium visual density.

**Typography.** Oversized neo-grotesk statements with sparse supporting labels

**Layout and hierarchy.** Trust promise and people first, then provider proof, availability, and booking details

**Navigation.** Search/browse journey supported by strong brand and trust moments

**Motion and interaction.** Reveal trust copy through portrait masks and use shared provider imagery into profile/booking; avoid decorative motion during medical selection.

**Why it works.** It makes confidentiality and human care the visual story instead of leading with generic medical icons.

**Adaptation lesson.** For trust-heavy products, use authentic human context and precise operational proof together.

**Accessibility / risk check.** Portrait text needs stable contrast, provider details must be text-accessible, and privacy/security cues should be explicit.

**Provenance note.** Public source-page reference and local preview mapping documented by the mobile corpus methodology.

## M27 · Personal finance, Expense, Budgeting app UI UX Design (Finany)

| Field | Detail |
|---|---|
| ID | MOB-027 |
| Platform | Behance |
| Creator | Musemind |
| Reference date | Not documented in the source corpus. |
| Preview | Downloaded local preview |
| Source | [Personal finance, Expense, Budgeting app UI UX Design (Finany)](https://www.behance.net/gallery/142046849/Personal-finance-Expense-Budgeting-app-UI-UX-Design) |

![Personal finance, Expense, Budgeting app UI UX Design (Finany)](assets/mobile/images/behance-06-finany-motion.gif)

Additional local frames: assets/mobile/images/behance-08-finany-finance.png

**Design focus.** Balance, budgeting, investment, expenses, and transaction insight, Bright cobalt brand frame around a very light finance dashboard with playful 3D wallet assets

**Elements.** balance card, quick actions, investment list, category transaction, 3D wallet

**Colour.** Catalogued dominant colours: cobalt blue, white, navy, orange, lavender, pale gray. Catalog palette: cobalt blue, white, navy, orange, lavender, pale gray Measured preview palette: #F4F6F9, #F5F6F9, #7987B6, #FCFDFE, #EFF7F4, #F4F6F8, #F6F6F8, #F4F6FB

**Image evidence.** assets/mobile/images/behance-06-finany-motion.gif — 1920×1540 GIF; near-square; cool; medium visual density. assets/mobile/images/behance-08-finany-finance.png — 1920×1646 PNG; near-square; cool; low visual density.

**Typography.** Oversized campaign headline plus crisp tabular financial text

**Layout and hierarchy.** Total balance/change, add/invest/more actions, investments, then categorized transactions

**Navigation.** Dashboard home with quick actions and account/transaction drill-down

**Motion and interaction.** Use the supplied motion vocabulary for value transitions and card entry, but keep live financial values stable long enough to compare.

**Why it works.** A bold marketing shell makes a conventional money dashboard feel specific without reducing legibility.

**Adaptation lesson.** Separate the expressive presentation layer from the precision layer that carries money.

**Accessibility / risk check.** Ensure animated GIF concepts translate to controllable native motion; numbers need tabular alignment and non-color deltas.

**Provenance note.** Public source-page reference and local preview mapping documented by the mobile corpus methodology.

## M28 · Fashion E-Commerce Mobile App UI Design (Stylista)

| Field | Detail |
|---|---|
| ID | MOB-028 |
| Platform | Behance |
| Creator | Opedia Studio and Md. Habibur Rahman |
| Reference date | Not documented in the source corpus. |
| Preview | Downloaded local preview |
| Source | [Fashion E-Commerce Mobile App UI Design (Stylista)](https://www.behance.net/gallery/210271483/Fashion-E-Commerce-Mobile-App-UI-Design) |

![Fashion E-Commerce Mobile App UI Design (Stylista)](assets/mobile/images/behance-07-fashion-commerce.jpg)

**Design focus.** Personalized fashion browse, virtual try-on, product details, cart, and order tracking, Dark boutique commerce with coral accents, soft product photography, and restrained gradients

**Elements.** style feed, try-on entry, product gallery, size selector, cart, tracking

**Colour.** Catalogued dominant colours: black, charcoal, coral, soft pink, white. Catalog palette: black, charcoal, coral, soft pink, white Measured preview palette: #FEFEFE, #111111, #2A2A2A, #1E1E1E, #171717, #4F4C4A, #0B0B0B, #E2D0C5

**Image evidence.** assets/mobile/images/behance-07-fashion-commerce.jpg — 1920×1867 JPEG; near-square; balanced; low visual density.

**Typography.** Fashion-forward sans-serif with large product emphasis

**Layout and hierarchy.** Personal recommendation, product visual, price/availability, then purchase/tracking

**Navigation.** Recommendation feed and category browse into product and cart stack

**Motion and interaction.** Use garment shared-element transitions and reversible try-on overlays; retain stable size and price controls.

**Why it works.** Personalization is visible at the discovery layer while conversion remains familiar.

**Adaptation lesson.** Make novel commerce features an enhancement to a complete conventional buying path.

**Accessibility / risk check.** Label colors/sizes, support image descriptions, and make try-on optional with privacy disclosure.

**Provenance note.** Public source-page reference and local preview mapping documented by the mobile corpus methodology.

## M29 · Nexora – A Modern Finance App UI/UX Case Study

| Field | Detail |
|---|---|
| ID | MOB-029 |
| Platform | Behance |
| Creator | Jobayer Mahbub, Kowser Ahmed Ridoy, MD. Azbin Islam, Mainul Islam Arafat |
| Reference date | Not documented in the source corpus. |
| Preview | Downloaded local preview |
| Source | [Nexora – A Modern Finance App UI/UX Case Study](https://www.behance.net/gallery/232889299/Nexora-A-Modern-Finance-App-UIUX-Case-Study) |

![Nexora – A Modern Finance App UI/UX Case Study](assets/mobile/images/behance-09-nexora-finance.jpg)

**Design focus.** Expense tracking, reports, budgeting, and financial control case study, Long-form systematic case study combining minimal finance UI, diagrams, and component documentation

**Elements.** dashboard, expense categories, budget goal, report chart, transaction list, design system

**Colour.** Catalogued dominant colours: white, black, cool gray, blue-violet accents, soft green. Catalog palette: white, black, cool gray, blue-violet accents, soft green Measured preview palette: #FEFDFE, #BDB5CE, #F0EBF8, #E6E4EF, #F7F3F9, #E5D3E3, #CBCBDB, #7C7495

**Image evidence.** assets/mobile/images/behance-09-nexora-finance.jpg — 1920×29033 JPEG; portrait; balanced; high visual density.

**Typography.** Structured design-system sans-serif with large section markers and compact UI labels

**Layout and hierarchy.** Problem/research, user journey, information architecture, visual system, then key task screens

**Navigation.** Bottom-tab personal finance app supported by documented end-to-end flows

**Motion and interaction.** Animate category drill-down and report range changes with shared axes; avoid chart morphs that distort comparison.

**Why it works.** It demonstrates that visual consistency is downstream of a documented product model.

**Adaptation lesson.** Generate the flow and component grammar before selecting the glossy presentation style.

**Accessibility / risk check.** Case-study polish must translate to dynamic type, text alternatives for charts, and complete empty/error states.

**Provenance note.** Public source-page reference and local preview mapping documented by the mobile corpus methodology.

## M30 · GLUME - Mobile App Design for Healthcare

| Field | Detail |
|---|---|
| ID | MOB-030 |
| Platform | Behance |
| Creator | Phenomenon Studio and collaborators |
| Reference date | Not documented in the source corpus. |
| Preview | Downloaded local preview |
| Source | [GLUME - Mobile App Design for Healthcare](https://www.behance.net/gallery/207838935/-GLUME-MOBILE-APP-DESIGN-FOR-HEALTHCARE) |

![GLUME - Mobile App Design for Healthcare](assets/mobile/images/behance-10-glume-health.png)

**Design focus.** Healthcare journey shaped by patient personas, telehealth, and ongoing care, Dark research presentation with rounded persona cards and vivid lime line accents

**Elements.** persona cards, care dashboard, appointment, telehealth, tracking, support

**Colour.** Catalogued dominant colours: near black, charcoal, lime, lavender, coral, white. Catalog palette: near black, charcoal, lime, lavender, coral, white Measured preview palette: #21232B, #17191F, #16181D, #525057, #23232D, #1F2129, #20232A, #21232A

**Image evidence.** assets/mobile/images/behance-10-glume-health.png — 1920×1366 PNG; landscape; balanced; low visual density.

**Typography.** Large modern sans-serif headings with structured persona and evidence text

**Layout and hierarchy.** User needs/goals and pain points first, then task flows and high-fidelity UI

**Navigation.** Patient-centered service hub with progressive care workflows

**Motion and interaction.** Use gentle continuity between care stages and calm state feedback; avoid motion that raises perceived urgency.

**Why it works.** Its visual direction is traceable to distinct patient needs rather than a generic wellness palette.

**Adaptation lesson.** Tie every high-style decision to a persona goal, constraint, or emotional state.

**Accessibility / risk check.** Healthcare UI must support large type, accessible charts, captioned calls, and explicit emergency boundaries.

**Provenance note.** Public source-page reference and local preview mapping documented by the mobile corpus methodology.

## M31 · ZenPay l Fintech Mobile App UI/UX Design

| Field | Detail |
|---|---|
| ID | MOB-031 |
| Platform | Behance |
| Creator | Wolf Pixel / Masuder Rahaman / Muhammad Jubayer |
| Reference date | Not documented in the source corpus. |
| Preview | Downloaded local preview |
| Source | [ZenPay l Fintech Mobile App UI/UX Design](https://www.behance.net/gallery/224523415/ZenPay-l-Fintech-Mobile-App-UIUX-Design) |

![ZenPay l Fintech Mobile App UI/UX Design](assets/mobile/images/behance-11-zenpay-fintech.jpg)

**Design focus.** Wallet, transfers, cards, banking history, and product case study, Light fintech presentation with blue-violet highlights, generous white space, and process timelines

**Elements.** wallet balance, send/request, card carousel, transaction list, transfer confirmation, timeline

**Colour.** Catalogued dominant colours: white, blue-violet, navy, pale gray, soft cyan. Catalog palette: white, blue-violet, navy, pale gray, soft cyan Measured preview palette: #FFFFFF, #FDFDFD, #FCFCFC, #FAFAFA, #F3F3F3, #B1B1B1, #FEFEFE, #FCFCFB

**Image evidence.** assets/mobile/images/behance-11-zenpay-fintech.jpg — 1920×1164 JPEG; landscape; balanced; low visual density.

**Typography.** Clean corporate sans-serif with strong numeric hierarchy

**Layout and hierarchy.** Project rationale and timeline, then balance/actions, transactions, cards, and transfer proof

**Navigation.** Bottom-tab wallet with focused transfer/card drill-down

**Motion and interaction.** Use card depth and restrained transfer progress; confirmation should settle into a receipt rather than disappear.

**Why it works.** A calm visual system reinforces financial trust and makes the underlying design process visible.

**Adaptation lesson.** Fintech sophistication is better expressed through disciplined spacing and state design than visual noise.

**Accessibility / risk check.** Maintain clear review screens, biometric alternatives, large numeric text, and readable receipt history.

**Provenance note.** Public source-page reference and local preview mapping documented by the mobile corpus methodology.

## M32 · Onboarding Screens for Mobile Banking

| Field | Detail |
|---|---|
| ID | MOB-032 |
| Platform | Pinterest |
| Creator | As Told By Des (pin attribution) |
| Reference date | Not documented in the source corpus. |
| Preview | Downloaded local preview |
| Source | [Onboarding Screens for Mobile Banking](https://www.pinterest.com/pin/onboarding-screens-for-mobile-banking--431290101834554087/) |

![Onboarding Screens for Mobile Banking](assets/mobile/images/pinterest-01-banking-onboarding.jpg)

**Design focus.** Three-step mobile banking onboarding, Light blue illustration-led onboarding with floating device/card metaphors

**Elements.** benefit illustration, progress dots, Skip, next button, get started

**Colour.** Catalogued dominant colours: white, royal blue, pale blue, navy, soft gray. Catalog palette: white, royal blue, pale blue, navy, soft gray Measured preview palette: #F3F6FB, #FFFFFF, #EDF0F5, #9BB3DD, #FEFEFE, #FFFFFD, #FAFCFC, #F1F7FC

**Image evidence.** assets/mobile/images/pinterest-01-banking-onboarding.jpg — 736×552 JPEG; near-square; balanced; low visual density.

**Typography.** Friendly bold sans-serif headline and very short explanatory copy

**Layout and hierarchy.** One benefit per screen, illustration, progress dots, then a single next/get-started action

**Navigation.** Linear carousel with Skip and progress

**Motion and interaction.** Carry the card/coin illustration across pages and spring the final CTA only after the copy is available.

**Why it works.** It communicates benefits rather than listing features.

**Adaptation lesson.** Each onboarding screen should earn its place by explaining one concrete outcome.

**Accessibility / risk check.** Skip must remain visible, illustrations need no embedded essential text, and controls must sit above the home indicator.

**Provenance note.** Public source-page reference and local preview mapping documented by the mobile corpus methodology.

## M33 · Nafa - Medical App Design

| Field | Detail |
|---|---|
| ID | MOB-033 |
| Platform | Pinterest |
| Creator | Avtar Singh / UI8 attribution |
| Reference date | Not documented in the source corpus. |
| Preview | Downloaded local preview |
| Source | [Nafa - Medical App Design](https://in.pinterest.com/pin/nafa-medical-app-design--8303580557319612/) |

![Nafa - Medical App Design](assets/mobile/images/pinterest-02-nafa-medical.jpg)

**Design focus.** Doctor discovery, appointment, chat, news, pharmacy, and schedule UI kit, Large light medical UI kit using bright blue, white cards, and full portrait/video contexts

**Elements.** doctor card, search, video call, chat, pharmacy, calendar, bottom tabs

**Colour.** Catalogued dominant colours: white, medical blue, navy, pale gray, orange accents. Catalog palette: white, medical blue, navy, pale gray, orange accents Measured preview palette: #CCD6DF, #FFFFFF, #3C5F7B, #F6F6F6, #D9E1E8, #B4C0C7, #CFD6DD, #C4D9E2

**Image evidence.** assets/mobile/images/pinterest-02-nafa-medical.jpg — 736×1560 JPEG; portrait; cool; high visual density.

**Typography.** Compact utilitarian sans-serif with clear medical category headings

**Layout and hierarchy.** Service shortcut/search, doctor identity and availability, then booking/chat/pharmacy tasks

**Navigation.** Bottom-tab healthcare super-app with several focused task stacks

**Motion and interaction.** Use shared provider identity between list, profile, booking, and call; keep every context switch explicit.

**Why it works.** A consistent component grammar holds many healthcare services together.

**Adaptation lesson.** A super-app needs domain-level navigation plus focused task stacks, not one endlessly scrolling home.

**Accessibility / risk check.** UI-kit density must be reduced per screen, calls need captions, and medical actions need text labels beyond icons.

**Provenance note.** Public source-page reference and local preview mapping documented by the mobile corpus methodology.

## M34 · AI Assistant Chatbot Mobile Apps UI Kit

| Field | Detail |
|---|---|
| ID | MOB-034 |
| Platform | Pinterest |
| Creator | UI8 attribution |
| Reference date | Not documented in the source corpus. |
| Preview | Downloaded local preview |
| Source | [AI Assistant Chatbot Mobile Apps UI Kit](https://mx.pinterest.com/pin/34621490880754639/) |

![AI Assistant Chatbot Mobile Apps UI Kit](assets/mobile/images/pinterest-03-ai-chatbot-dark.jpg)

**Design focus.** AI assistant welcome, capability shortcuts, and conversation, Dark navy chatbot with electric-blue orb, luminous outlines, and rounded capability cards

**Elements.** assistant orb, start CTA, capability cards, example prompts, chat composer, tool navigation

**Colour.** Catalogued dominant colours: near black, midnight blue, electric blue, white, slate. Catalog palette: near black, midnight blue, electric blue, white, slate Measured preview palette: #0A0D14, #11172D, #34438D, #0B0E16, #080B13, #090D15, #0B0D12, #0B0D14

**Image evidence.** assets/mobile/images/pinterest-03-ai-chatbot-dark.jpg — 736×556 JPEG; near-square; cool; low visual density.

**Typography.** Minimal sans-serif with centered welcome hierarchy and compact tool labels

**Layout and hierarchy.** Assistant identity, primary start action, capability examples, then chat composer

**Navigation.** Assistant home with bottom tabs and persistent conversation entry

**Motion and interaction.** Use the orb as a state indicator—idle, listening, working, complete—without constant decoration.

**Why it works.** The assistant has a clear visual identity and users are shown what to ask before facing an empty chat.

**Adaptation lesson.** AI empty states should teach capability through actionable examples, not marketing prose.

**Accessibility / risk check.** Blue-on-dark contrast needs testing; state must be announced in text and all generated output needs selectable accessible content.

**Provenance note.** Public source-page reference and local preview mapping documented by the mobile corpus methodology.

## M35 · Mobile App Dashboard — Dark Mode

| Field | Detail |
|---|---|
| ID | MOB-035 |
| Platform | Pinterest |
| Creator | Dmitri Litvinov |
| Reference date | Not documented in the source corpus. |
| Preview | Downloaded local preview |
| Source | [Mobile App Dashboard — Dark Mode](https://www.pinterest.com/pin/dashboard-dark-mode--62065301106037592/) |

![Mobile App Dashboard — Dark Mode](assets/mobile/images/pinterest-04-dashboard-dark.jpg)

**Design focus.** Personal services/finance dashboard in dark and light variants, Split dark/light cards with blue-violet gradients and compact colorful service tiles

**Elements.** profile header, theme toggle, service tiles, stats, cards, bottom tabs

**Colour.** Catalogued dominant colours: black, white, violet, electric blue, coral, green. Catalog palette: black, white, violet, electric blue, coral, green Measured preview palette: #F3F3F3, #262B2F, #7280F2, #FDFDFD, #DFE0E0, #D58AA5, #ECEDEE, #3D3C48

**Image evidence.** assets/mobile/images/pinterest-04-dashboard-dark.jpg — 736×552 JPEG; near-square; balanced; low visual density.

**Typography.** Compact dashboard sans-serif with a prominent account greeting

**Layout and hierarchy.** Profile/account total, service shortcut grid, then stats/cards and bottom navigation

**Navigation.** Bottom tabs plus a home service grid

**Motion and interaction.** Theme transitions can crossfade surfaces and preserve component position; service tiles can lift on press.

**Why it works.** Identical structure across modes demonstrates that theme is token-driven rather than a redesign.

**Adaptation lesson.** Design semantic color and elevation tokens first so light/dark modes preserve hierarchy.

**Accessibility / risk check.** Both themes require independent contrast validation and theme choice must follow system settings by default.

**Provenance note.** Public source-page reference and local preview mapping documented by the mobile corpus methodology.

## M36 · AI Assistant - Self Improvement

| Field | Detail |
|---|---|
| ID | MOB-036 |
| Platform | Pinterest |
| Creator | Arip for Enver Studio |
| Reference date | Not documented in the source corpus. |
| Preview | Downloaded local preview |
| Source | [AI Assistant - Self Improvement](https://www.pinterest.com/pin/design--780459810455381140/) |

![AI Assistant - Self Improvement](assets/mobile/images/pinterest-05-ai-self-improvement.jpg)

**Design focus.** Motivational assistant, goal/task suggestions, and AI conversation, Deep purple gradient assistant with soft waveforms, glass cards, and luminous voice orb

**Elements.** greeting, motivation card, task list, voice orb, chat composer, bottom navigation

**Colour.** Catalogued dominant colours: black, deep purple, violet, lavender, cream, white. Catalog palette: black, deep purple, violet, lavender, cream, white Measured preview palette: #140A1A, #311B50, #EDECEC, #EBE7E4, #D9D7D6, #231238, #6B607F, #11051F

**Image evidence.** assets/mobile/images/pinterest-05-ai-self-improvement.jpg — 736×552 JPEG; near-square; balanced; medium visual density.

**Typography.** Large welcoming sans-serif with compact motivational card copy

**Layout and hierarchy.** Assistant greeting, suggested goal, actionable task list, then text/voice composer

**Navigation.** Conversational home with embedded to-do actions and bottom assistant controls

**Motion and interaction.** Use waveform motion only while listening/speaking and animate task completion into the conversation history.

**Why it works.** Conversation and structured actions coexist, so the assistant feels productive rather than merely chatty.

**Adaptation lesson.** Pair generative conversation with durable task objects users can inspect and complete.

**Accessibility / risk check.** Voice requires transcript/control parity; motivational copy must not shame users and purple cards need adequate contrast.

**Provenance note.** Public source-page reference and local preview mapping documented by the mobile corpus methodology.

## M37 · Dark & Light Mode Settings

| Field | Detail |
|---|---|
| ID | MOB-037 |
| Platform | Pinterest |
| Creator | Bahuleyan Design Spot |
| Reference date | Not documented in the source corpus. |
| Preview | Downloaded local preview |
| Source | [Dark & Light Mode Settings](https://uk.pinterest.com/pin/dark-light-mode-settings--799389002642744136/) |

![Dark & Light Mode Settings](assets/mobile/images/pinterest-06-dark-light-settings.jpg)

**Design focus.** Settings and theme-system comparison, Native-looking iOS settings rendered in paired light and dark semantic palettes

**Elements.** grouped list, toggle, value row, chevron, section header, theme states

**Colour.** Catalogued dominant colours: system white, system black, gray, blue, multicolor icons. Catalog palette: system white, system black, gray, blue, multicolor icons Measured preview palette: #F7F7F7, #242424, #F7F7F6, #FAFAFA, #BDBDBD, #F7F7F9, #FBF7F8, #F4FBF8

**Image evidence.** assets/mobile/images/pinterest-06-dark-light-settings.jpg — 736×1104 JPEG; portrait; balanced; medium visual density.

**Typography.** Native system sans-serif with grouped section hierarchy

**Layout and hierarchy.** Account/context header, grouped settings rows, values/toggles, then destructive/support actions

**Navigation.** Hierarchical settings list with grouped sections and detail chevrons

**Motion and interaction.** Prefer native theme crossfade and standard row feedback; novelty would reduce platform familiarity.

**Why it works.** It preserves platform conventions and semantic hierarchy in both modes.

**Adaptation lesson.** Use native patterns where familiarity is itself a usability feature.

**Accessibility / risk check.** Honor system theme, contrast, Dynamic Type, VoiceOver row/value semantics, and larger accessibility controls.

**Provenance note.** Public source-page reference and local preview mapping documented by the mobile corpus methodology.

## M38 · Online Shopping App Aesthetic & Minimal UI Kit

| Field | Detail |
|---|---|
| ID | MOB-038 |
| Platform | Pinterest |
| Creator | Computer Star 300 pin attribution; original creator not verified |
| Reference date | Not documented in the source corpus. |
| Preview | Downloaded local preview |
| Source | [Online Shopping App Aesthetic & Minimal UI Kit](https://www.pinterest.com/pin/online-shopping-app-aesthetic-amp-minimal-ui-kit-for-ecommerce-mobile-app--361836151328357154/) |

![Online Shopping App Aesthetic & Minimal UI Kit](assets/mobile/images/pinterest-07-minimal-ecommerce.jpg)

**Design focus.** Large commerce UI kit spanning discovery, product, cart, checkout, account, and dark states, Editorial beige/black fashion commerce with dense but consistent full-flow screens

**Elements.** campaign hero, product grid, filters, product detail, cart, checkout, order history

**Colour.** Catalogued dominant colours: cream, white, black, warm gray, brown, muted orange. Catalog palette: cream, white, black, warm gray, brown, muted orange Measured preview palette: #FAF7F4, #655F5D, #2B2C31, #444042, #524D4D, #36353A, #1F1F22, #A49E9A

**Image evidence.** assets/mobile/images/pinterest-07-minimal-ecommerce.jpg — 736×1742 JPEG; portrait; balanced; high visual density.

**Typography.** Elegant editorial sans-serif with compact product metadata

**Layout and hierarchy.** Campaign/product visual, product information, selection, purchase, then account/order management

**Navigation.** Bottom commerce tabs plus vertical task stacks for browse, product, cart, and account

**Motion and interaction.** Use product shared-element transitions and bottom-sheet filters; avoid animating every catalog card.

**Why it works.** A consistent visual grammar survives across a genuinely broad commerce surface.

**Adaptation lesson.** Evaluate a style against every major flow and edge state before declaring the design system complete.

**Accessibility / risk check.** Tiny kit text must be enlarged in production, colors and sizes named, and filters fully keyboard/screen-reader accessible.

**Provenance note.** Public source-page reference and local preview mapping documented by the mobile corpus methodology.

## M39 · Digital Wallet Dashboard UI - Dark Theme

| Field | Detail |
|---|---|
| ID | MOB-039 |
| Platform | Pinterest |
| Creator | Mike Taylor for Dark UI |
| Reference date | Not documented in the source corpus. |
| Preview | Downloaded local preview |
| Source | [Digital Wallet Dashboard UI - Dark Theme](https://www.pinterest.com/pin/digital-wallet-dashboard-ui-dark-theme--429108670766570682/) |

![Digital Wallet Dashboard UI - Dark Theme](assets/mobile/images/pinterest-08-digital-wallet-dark.jpg)

**Design focus.** Wallet payments dashboard, payment types, transaction list, cards, and weekly analytics, Dense midnight dashboard with violet highlights, neon category icons, and cyan charts

**Elements.** balance, payment shortcuts, transaction list, credit card, bar chart, deposit CTA

**Colour.** Catalogued dominant colours: midnight navy, violet, cyan, coral, green, white. Catalog palette: midnight navy, violet, cyan, coral, green, white Measured preview palette: #26273B, #1A1C30, #DFE2E9, #565F72, #252343, #212135, #D3E1E8, #E5DFEA

**Image evidence.** assets/mobile/images/pinterest-08-digital-wallet-dark.jpg — 736×552 JPEG; near-square; cool; low visual density.

**Typography.** Compact dashboard sans-serif with strong monetary totals

**Layout and hierarchy.** Wallet total, payment shortcut row, latest transactions, active card, then weekly summary

**Navigation.** Sidebar-like mobile rail plus dashboard panels and category shortcuts

**Motion and interaction.** Animate payment selection into a focused sheet and use shared-axis chart range transitions.

**Why it works.** Color creates fast category scanning against a coherent dark foundation.

**Adaptation lesson.** When adapting dashboard inspiration, preserve decision priority and discard ornamental density.

**Accessibility / risk check.** This concept is desktop-dense; production mobile should stack panels, enlarge targets, and expose chart summaries.

**Provenance note.** Public source-page reference and local preview mapping documented by the mobile corpus methodology.

# Motion references (24)

## M01 · The Future in Mind

| Field | Detail |
|---|---|
| ID | motion-awwwards-the-future-in-mind |
| Platform | Awwwards |
| Creator | Not documented in the source corpus. |
| Reference date | 2021-12-27 |
| Preview | Downloaded local preview |
| Source | [The Future in Mind](https://www.awwwards.com/sites/the-future-in-mind) |

![The Future in Mind](assets/motion/images/01_awwwards_the_future_in_mind.png)

**Design focus.** 3D world navigation, WebGL storytelling, infinite scroll, unusual navigation

**Elements.** persistent progress/orientation cue, single coherent spatial metaphor, DOM navigation overlay

**Colour.** Colour is not documented in this motion-only source record. Catalog palette: Not documented. Measured preview palette: #FDECCD, #DCAD7B, #CC9666, #EFCA97, #E6B27A, #F5D9A6, #7A5F4A, #FCE8C5

**Image evidence.** assets/motion/images/01_awwwards_the_future_in_mind.png — 918×656 PNG; landscape; warm; medium visual density.

**Typography.** Typography is not documented in this motion-only source record.

**Layout and hierarchy.** The complete static layout is not documented; this record isolates: 3D world navigation, WebGL storytelling, infinite scroll, unusual navigation.

**Navigation.** Navigation behavior is asserted only where it appears in the documented patterns or source evidence.

**Motion and interaction.** Documented patterns: 3D world navigation, WebGL storytelling, infinite scroll, unusual navigation. Evidence: The showcase tags the project with animation, infinite scroll, unusual navigation, storytelling, 3D, WebGL, Three.js, and Vue.js.

**Why it works.** A spatial metaphor is strongest when navigation and narrative inhabit the same world, but users still need a visible map of where they are and how to leave.

**Adaptation lesson.** Borrow as principles: persistent progress/orientation cue, single coherent spatial metaphor, DOM navigation overlay.

**Accessibility / risk check.** Novel navigation becoming a memory test or scroll trap.

**Provenance note.** The showcase tags the project with animation, infinite scroll, unusual navigation, storytelling, 3D, WebGL, Three.js, and Vue.js.

## M02 · Otherlife

| Field | Detail |
|---|---|
| ID | motion-awwwards-otherlife |
| Platform | Awwwards |
| Creator | Not documented in the source corpus. |
| Reference date | 2024-11-12 |
| Preview | Downloaded local preview |
| Source | [Otherlife](https://www.awwwards.com/sites/otherlife) |

![Otherlife](assets/motion/images/02_awwwards_otherlife.png)

**Design focus.** ScrollTrigger reveals, contact overlay transition, homepage transition, limited palette

**Elements.** two-tone motion system, mode-specific transition, case-study chapter reveals

**Colour.** The entry highlights ScrollTrigger case-study animation, a contact-form opening animation, and a homepage transition; it records a two-color neon-green/deep-green palette. Catalog palette: Not documented. Measured preview palette: #979284, #C0BDA6, #373128, #4C4931, #A79E92, #22211B, #ACAE94, #857763

**Image evidence.** assets/motion/images/02_awwwards_otherlife.png — 1600×1200 PNG; near-square; warm; medium visual density.

**Typography.** Typography is not documented in this motion-only source record.

**Layout and hierarchy.** The complete static layout is not documented; this record isolates: ScrollTrigger reveals, contact overlay transition, homepage transition, limited palette.

**Navigation.** Navigation behavior is asserted only where it appears in the documented patterns or source evidence.

**Motion and interaction.** Documented patterns: ScrollTrigger reveals, contact overlay transition, homepage transition, limited palette. Evidence: The entry highlights ScrollTrigger case-study animation, a contact-form opening animation, and a homepage transition; it records a two-color neon-green/deep-green palette.

**Why it works.** A restrained palette gives motion room to distinguish modes without creating visual noise.

**Adaptation lesson.** Borrow as principles: two-tone motion system, mode-specific transition, case-study chapter reveals.

**Accessibility / risk check.** High-chroma accents reducing text contrast or overwhelming every state.

**Provenance note.** The entry highlights ScrollTrigger case-study animation, a contact-form opening animation, and a homepage transition; it records a two-color neon-green/deep-green palette.

## M03 · iyO

| Field | Detail |
|---|---|
| ID | motion-awwwards-iyo |
| Platform | Awwwards |
| Creator | Not documented in the source corpus. |
| Reference date | 2026-04-02 |
| Preview | Downloaded local preview |
| Source | [iyO](https://www.awwwards.com/sites/iyo) |

![iyO](assets/motion/images/03_awwwards_iyo.png)

**Design focus.** 3D product presentation, dynamic color slider, sound, infinite browsing

**Elements.** state-labelled product variants, color synchronized with selection, explicit sound control

**Colour.** The entry highlights a dynamic color-switch product slider and tags infinite scroll, unusual navigation, sound, 3D, interaction design, WebGL, Three.js, and Webflow. Catalog palette: Not documented. Measured preview palette: #E9E9E9, #EFEFEF, #EDEDED, #EEEEEE, #9C8A89, #F1F1F2, #EFEFEE, #EEEFEF

**Image evidence.** assets/motion/images/03_awwwards_iyo.png — 1600×1200 PNG; near-square; balanced; low visual density.

**Typography.** Typography is not documented in this motion-only source record.

**Layout and hierarchy.** The complete static layout is not documented; this record isolates: 3D product presentation, dynamic color slider, sound, infinite browsing.

**Navigation.** Navigation behavior is asserted only where it appears in the documented patterns or source evidence.

**Motion and interaction.** Documented patterns: 3D product presentation, dynamic color slider, sound, infinite browsing. Evidence: The entry highlights a dynamic color-switch product slider and tags infinite scroll, unusual navigation, sound, 3D, interaction design, WebGL, Three.js, and Webflow.

**Why it works.** Synchronize product pose, background color, copy, and sound at discrete states so the sensory layers change as one system.

**Adaptation lesson.** Borrow as principles: state-labelled product variants, color synchronized with selection, explicit sound control.

**Accessibility / risk check.** Autoplay sound, uncontrolled infinite browsing, or color transitions that hide focus and contrast.

**Provenance note.** The entry highlights a dynamic color-switch product slider and tags infinite scroll, unusual navigation, sound, 3D, interaction design, WebGL, Three.js, and Webflow.

## M04 · Noomo Labs

| Field | Detail |
|---|---|
| ID | motion-awwwards-noomo-labs |
| Platform | Awwwards |
| Creator | Not documented in the source corpus. |
| Reference date | 2024-06-19 |
| Preview | Downloaded local preview |
| Source | [Noomo Labs](https://www.awwwards.com/sites/noomo-labs) |

![Noomo Labs](assets/motion/images/04_awwwards_noomo_labs.jpg)

**Design focus.** 3D scroll signature, immersive studio portfolio, soft chromatic environment

**Elements.** recurring scene motif, calm copy layer, single 3D signature

**Colour.** The Awwwards page describes cutting-edge immersive experiences and explicitly highlights a 3D scroll animation with a pale lavender/blue palette. Catalog palette: Not documented. Measured preview palette: #EEECF3, #EEEBF3, #000000, #E8E6F2, #EBEAF3, #C6C5ED, #F1EFF6, #685075

**Image evidence.** assets/motion/images/04_awwwards_noomo_labs.jpg — 1600×1200 JPEG; near-square; balanced; medium visual density.

**Typography.** Typography is not documented in this motion-only source record.

**Layout and hierarchy.** The complete static layout is not documented; this record isolates: 3D scroll signature, immersive studio portfolio, soft chromatic environment.

**Navigation.** Navigation behavior is asserted only where it appears in the documented patterns or source evidence.

**Motion and interaction.** Documented patterns: 3D scroll signature, immersive studio portfolio, soft chromatic environment. Evidence: The Awwwards page describes cutting-edge immersive experiences and explicitly highlights a 3D scroll animation with a pale lavender/blue palette.

**Why it works.** A portfolio becomes memorable through one recurring spatial signature, not a different trick for every project tile.

**Adaptation lesson.** Borrow as principles: recurring scene motif, calm copy layer, single 3D signature.

**Accessibility / risk check.** Each section becoming an unrelated technical demo.

**Provenance note.** The Awwwards page describes cutting-edge immersive experiences and explicitly highlights a 3D scroll animation with a pale lavender/blue palette.

## M05 · Lightweight

| Field | Detail |
|---|---|
| ID | motion-awwwards-lightweight |
| Platform | Awwwards |
| Creator | Not documented in the source corpus. |
| Reference date | 2026-02-15 |
| Preview | Downloaded local preview |
| Source | [Lightweight](https://www.awwwards.com/sites/lightweight) |

![Lightweight](assets/motion/images/05_awwwards_lightweight.png)

**Design focus.** scroll-linked 3D, object continuity, immersive transition

**Elements.** one hero object across sections, authored camera holds, quiet typographic layer

**Colour.** Colour is not documented in this motion-only source record. Catalog palette: Not documented. Measured preview palette: #030303, #111111, #040404, #010101, #090909, #272727, #020302, #040304

**Image evidence.** assets/motion/images/05_awwwards_lightweight.png — 1600×1200 PNG; near-square; balanced; low visual density.

**Typography.** Typography is not documented in this motion-only source record.

**Layout and hierarchy.** The complete static layout is not documented; this record isolates: scroll-linked 3D, object continuity, immersive transition.

**Navigation.** Navigation behavior is asserted only where it appears in the documented patterns or source evidence.

**Motion and interaction.** Documented patterns: scroll-linked 3D, object continuity, immersive transition. Evidence: The entry separately highlights a 3D scroll interaction and 3D scroll animation.

**Why it works.** Keep the object continuous across chapters while typography remains stable enough to read; continuity provides spectacle without constant UI movement.

**Adaptation lesson.** Borrow as principles: one hero object across sections, authored camera holds, quiet typographic layer.

**Accessibility / risk check.** Continuous camera movement with no reading pauses.

**Provenance note.** The entry separately highlights a 3D scroll interaction and 3D scroll animation.

## M06 · The Power of Storytelling

| Field | Detail |
|---|---|
| ID | motion-awwwards-power-of-storytelling |
| Platform | Awwwards |
| Creator | Not documented in the source corpus. |
| Reference date | 2026-06-08 |
| Preview | Downloaded local preview |
| Source | [The Power of Storytelling](https://www.awwwards.com/sites/the-power-of-storytelling) |

![The Power of Storytelling](assets/motion/images/06_awwwards_power_of_storytelling.png)

**Design focus.** hero shader, symbolic 3D object, 3D scroll, pointer-reactive contact

**Elements.** symbol-led chapters, two-color art direction, pointer response limited to a destination section

**Colour.** The entry highlights a hero shader animation, 3D glass phoenix animation, 3D scroll, and contact-page mouse interaction; it records a pale-lilac/near-black palette. Catalog palette: Not documented. Measured preview palette: #E9D2ED, #D7CAF0, #E76E7B, #D9BCE9, #ED9DAE, #F0E5F4, #DFD5EF, #EDBCDD

**Image evidence.** assets/motion/images/06_awwwards_power_of_storytelling.png — 1600×1200 PNG; near-square; balanced; low visual density.

**Typography.** Typography is not documented in this motion-only source record.

**Layout and hierarchy.** The complete static layout is not documented; this record isolates: hero shader, symbolic 3D object, 3D scroll, pointer-reactive contact.

**Navigation.** Navigation behavior is asserted only where it appears in the documented patterns or source evidence.

**Motion and interaction.** Documented patterns: hero shader, symbolic 3D object, 3D scroll, pointer-reactive contact. Evidence: The entry highlights a hero shader animation, 3D glass phoenix animation, 3D scroll, and contact-page mouse interaction; it records a pale-lilac/near-black palette.

**Why it works.** A recurring symbolic object and disciplined color pair make several advanced effects feel like one story.

**Adaptation lesson.** Borrow as principles: symbol-led chapters, two-color art direction, pointer response limited to a destination section.

**Accessibility / risk check.** Shader, cursor, and object motion all competing at the same moment.

**Provenance note.** The entry highlights a hero shader animation, 3D glass phoenix animation, 3D scroll, and contact-page mouse interaction; it records a pale-lilac/near-black palette.

## M07 · Utsubo v2

| Field | Detail |
|---|---|
| ID | motion-awwwards-utsubo-v2 |
| Platform | Awwwards |
| Creator | Not documented in the source corpus. |
| Reference date | 2025-01-02 |
| Preview | Downloaded local preview |
| Source | [Utsubo v2](https://www.awwwards.com/sites/utsubo-v2) |

![Utsubo v2](assets/motion/images/07_awwwards_utsubo_v2.png)

**Design focus.** animated menu, scroll choreography, reactive cursor

**Elements.** shared motion tokens, menu state machine, fine-pointer-only cursor

**Colour.** Colour is not documented in this motion-only source record. Catalog palette: Not documented. Measured preview palette: #06192F, #060D17, #BAA186, #010811, #0F2032, #061424, #031122, #69524B

**Image evidence.** assets/motion/images/07_awwwards_utsubo_v2.png — 1600×1200 PNG; near-square; balanced; low visual density.

**Typography.** Typography is not documented in this motion-only source record.

**Layout and hierarchy.** The complete static layout is not documented; this record isolates: animated menu, scroll choreography, reactive cursor.

**Navigation.** Navigation behavior is asserted only where it appears in the documented patterns or source evidence.

**Motion and interaction.** Documented patterns: animated menu, scroll choreography, reactive cursor. Evidence: The showcase includes dedicated highlight videos for the menu, scroll animation, and cursor interaction.

**Why it works.** Give menu, cursor, and page motion the same easing and visual character so interaction feels authored rather than plugin-assembled.

**Adaptation lesson.** Borrow as principles: shared motion tokens, menu state machine, fine-pointer-only cursor.

**Accessibility / risk check.** A custom cursor replacing native affordances or a menu that cannot reverse cleanly.

**Provenance note.** The showcase includes dedicated highlight videos for the menu, scroll animation, and cursor interaction.

## M08 · Lusion v3

| Field | Detail |
|---|---|
| ID | motion-awwwards-lusion-v3 |
| Platform | Awwwards |
| Creator | Not documented in the source corpus. |
| Reference date | 2023-10-02 |
| Preview | Downloaded local preview |
| Source | [Lusion v3](https://www.awwwards.com/sites/lusion-v3) |

![Lusion v3](assets/motion/images/08_awwwards_lusion_v3.png)

**Design focus.** reactive cursor, 3D portfolio, scroll animation, clean UI

**Elements.** context-sensitive pointer states, clean DOM overlay, project-specific spatial response

**Colour.** Colour is not documented in this motion-only source record. Catalog palette: Not documented. Measured preview palette: #13151B, #F0F1FA, #141729, #353C68, #B4B5BB, #EFF0F9, #0A0F4D, #F7F8FE

**Image evidence.** assets/motion/images/08_awwwards_lusion_v3.png — 1600×1200 PNG; near-square; cool; low visual density.

**Typography.** Typography is not documented in this motion-only source record.

**Layout and hierarchy.** The complete static layout is not documented; this record isolates: reactive cursor, 3D portfolio, scroll animation, clean UI.

**Navigation.** Navigation behavior is asserted only where it appears in the documented patterns or source evidence.

**Motion and interaction.** Documented patterns: reactive cursor, 3D portfolio, scroll animation, clean UI. Evidence: The entry highlights reactive cursor interaction and scroll animation and tags the project as clean and 3D.

**Why it works.** Pointer response should react to nearby content and project surfaces, not decorate empty space indiscriminately.

**Adaptation lesson.** Borrow as principles: context-sensitive pointer states, clean DOM overlay, project-specific spatial response.

**Accessibility / risk check.** Follower lag, pointer obscuration, or touch hover emulation.

**Provenance note.** The entry highlights reactive cursor interaction and scroll animation and tags the project as clean and 3D.

## M09 · Saisei Architecture

| Field | Detail |
|---|---|
| ID | motion-awwwards-saisei-architecture |
| Platform | Awwwards |
| Creator | Not documented in the source corpus. |
| Reference date | 2024-11-10 |
| Preview | Downloaded local preview |
| Source | [Saisei Architecture](https://www.awwwards.com/sites/saisei-architecture) |

![Saisei Architecture](assets/motion/images/09_awwwards_saisei_architecture.png)

**Design focus.** page transition, menu animation, project slider, editorial scroll

**Elements.** shared image transition, cream/dark material palette, measured gallery motion

**Colour.** The entry highlights a sustainability scroll page, page transition, menu animation, and project slider with a dark-brown/cream palette. Catalog palette: Not documented. Measured preview palette: #1F150C, #735F46, #E7D6BC, #B6A185, #18100A, #130C06, #070403, #3F3022

**Image evidence.** assets/motion/images/09_awwwards_saisei_architecture.png — 1600×1200 PNG; near-square; warm; low visual density.

**Typography.** Typography is not documented in this motion-only source record.

**Layout and hierarchy.** The complete static layout is not documented; this record isolates: page transition, menu animation, project slider, editorial scroll.

**Navigation.** Navigation behavior is asserted only where it appears in the documented patterns or source evidence.

**Motion and interaction.** Documented patterns: page transition, menu animation, project slider, editorial scroll. Evidence: The entry highlights a sustainability scroll page, page transition, menu animation, and project slider with a dark-brown/cream palette.

**Why it works.** Architectural work benefits from quiet typography and material-toned colors while spatial transitions establish continuity between projects.

**Adaptation lesson.** Borrow as principles: shared image transition, cream/dark material palette, measured gallery motion.

**Accessibility / risk check.** Parallax making photography feel unstable or slowing project comparison.

**Provenance note.** The entry highlights a sustainability scroll page, page transition, menu animation, and project slider with a dark-brown/cream palette.

## M10 · PaulKram Photographer

| Field | Detail |
|---|---|
| ID | motion-awwwards-paulkram-photographer |
| Platform | Awwwards |
| Creator | Not documented in the source corpus. |
| Reference date | 2025-12-17 |
| Preview | Downloaded local preview |
| Source | [PaulKram Photographer](https://www.awwwards.com/sites/paulkram-photographer) |

![PaulKram Photographer](assets/motion/images/10_awwwards_paulkram_photographer.jpg)

**Design focus.** gallery parallax, menu/page transition, album slider, photographic portfolio

**Elements.** image-led shared transitions, album orientation cues, subtle depth

**Colour.** Colour is not documented in this motion-only source record. Catalog palette: Not documented. Measured preview palette: #908A7F, #0D0D0D, #B8B8A8, #3F4139, #0E0D0D, #060607, #0C0D0D, #0D0D0C

**Image evidence.** assets/motion/images/10_awwwards_paulkram_photographer.jpg — 1600×1200 JPEG; near-square; balanced; low visual density.

**Typography.** Typography is not documented in this motion-only source record.

**Layout and hierarchy.** The complete static layout is not documented; this record isolates: gallery parallax, menu/page transition, album slider, photographic portfolio.

**Navigation.** Navigation behavior is asserted only where it appears in the documented patterns or source evidence.

**Motion and interaction.** Documented patterns: gallery parallax, menu/page transition, album slider, photographic portfolio. Evidence: The entry highlights gallery parallax, menu animation with page transitions, an album-navigation slider, and slider animation.

**Why it works.** Motion should frame photographic scale and preserve image comparison rather than become the subject.

**Adaptation lesson.** Borrow as principles: image-led shared transitions, album orientation cues, subtle depth.

**Accessibility / risk check.** Aggressive image crop, blur, or parallax that impairs evaluation of the work.

**Provenance note.** The entry highlights gallery parallax, menu animation with page transitions, an album-navigation slider, and slider animation.

## M11 · Brontide

| Field | Detail |
|---|---|
| ID | motion-awwwards-brontide |
| Platform | Awwwards |
| Creator | Not documented in the source corpus. |
| Reference date | 2018-04-02 |
| Preview | Downloaded local preview |
| Source | [Brontide](https://www.awwwards.com/sites/brontide) |

![Brontide](assets/motion/images/11_awwwards_brontide.jpg)

**Design focus.** horizontal narrative, parallax navigation, WebGL, image scroll effect

**Elements.** progress rail, real DOM links, vertical-to-horizontal mapping

**Colour.** Colour is not documented in this motion-only source record. Catalog palette: Not documented. Measured preview palette: #FFFFFF, #E2D7CB, #F9F9F8, #EDE6DD, #A06F41, #FFFFFE, #F8EDDF, #FEFFFF

**Image evidence.** assets/motion/images/11_awwwards_brontide.jpg — 918×656 JPEG; landscape; warm; low visual density.

**Typography.** Typography is not documented in this motion-only source record.

**Layout and hierarchy.** The complete static layout is not documented; this record isolates: horizontal narrative, parallax navigation, WebGL, image scroll effect.

**Navigation.** Navigation behavior is asserted only where it appears in the documented patterns or source evidence.

**Motion and interaction.** Documented patterns: horizontal narrative, parallax navigation, WebGL, image scroll effect. Evidence: The entry highlights a scroll-interaction image effect and parallax horizontal-scroll navigation and tags horizontal layout, parallax, transitions, 3D, and WebGL.

**Why it works.** Horizontal storytelling requires unusually strong orientation, visible progress, and a conventional mobile alternative.

**Adaptation lesson.** Borrow as principles: progress rail, real DOM links, vertical-to-horizontal mapping.

**Accessibility / risk check.** Users missing off-screen content or losing wheel/keyboard control.

**Provenance note.** The entry highlights a scroll-interaction image effect and parallax horizontal-scroll navigation and tags horizontal layout, parallax, transitions, 3D, and WebGL.

## M12 · Annatwelve – Fragrances

| Field | Detail |
|---|---|
| ID | motion-awwwards-annatwelve |
| Platform | Awwwards |
| Creator | Not documented in the source corpus. |
| Reference date | 2020-08-02 |
| Preview | Downloaded local preview |
| Source | [Annatwelve – Fragrances](https://www.awwwards.com/sites/annatwelve-fragrances) |

![Annatwelve – Fragrances](assets/motion/images/12_awwwards_annatwelve.png)

**Design focus.** overlay menu, horizontal project page, luxury pacing, WebGL

**Elements.** layered overlay reveal, slow visual/fast control feedback, product-first composition

**Colour.** Colour is not documented in this motion-only source record. Catalog palette: Not documented. Measured preview palette: #293526, #040809, #101C12, #0B130E, #1A251A, #060D0A, #020508, #81867E

**Image evidence.** assets/motion/images/12_awwwards_annatwelve.png — 918×656 PNG; landscape; balanced; medium visual density.

**Typography.** Typography is not documented in this motion-only source record.

**Layout and hierarchy.** The complete static layout is not documented; this record isolates: overlay menu, horizontal project page, luxury pacing, WebGL.

**Navigation.** Navigation behavior is asserted only where it appears in the documented patterns or source evidence.

**Motion and interaction.** Documented patterns: overlay menu, horizontal project page, luxury pacing, WebGL. Evidence: The page highlights an overlay-menu animation and horizontal project page and identifies WebGL, GSAP, and Vue.js.

**Why it works.** Luxury motion comes from controlled pace, material transitions, and restraint rather than adding more simultaneous effects.

**Adaptation lesson.** Borrow as principles: layered overlay reveal, slow visual/fast control feedback, product-first composition.

**Accessibility / risk check.** Long luxurious transitions blocking navigation or reduced-motion users.

**Provenance note.** The page highlights an overlay-menu animation and horizontal project page and identifies WebGL, GSAP, and Vue.js.

## M13 · Prime Exits

| Field | Detail |
|---|---|
| ID | motion-awwwards-prime-exits |
| Platform | Awwwards |
| Creator | Not documented in the source corpus. |
| Reference date | Not documented in the source corpus. |
| Preview | Downloaded local preview |
| Source | [Prime Exits](https://www.awwwards.com/sites/prime-exits) |

![Prime Exits](assets/motion/images/13_awwwards_prime_exits.jpg)

**Design focus.** Lottie icons, menu animation, form microinteractions, animated quiz, horizontal layout

**Elements.** stateful icon library, quiz progress feedback, motion reused by function

**Colour.** Colour is not documented in this motion-only source record. Catalog palette: Not documented. Measured preview palette: #FAFAFA, #C34130, #F7F7F7, #B0756F, #66251F, #DCD7D6, #FEFEFE, #FDFAFA

**Image evidence.** assets/motion/images/13_awwwards_prime_exits.jpg — 1600×1200 JPEG; near-square; warm; low visual density.

**Typography.** Typography is not documented in this motion-only source record.

**Layout and hierarchy.** The complete static layout is not documented; this record isolates: Lottie icons, menu animation, form microinteractions, animated quiz, horizontal layout.

**Navigation.** Navigation behavior is asserted only where it appears in the documented patterns or source evidence.

**Motion and interaction.** Documented patterns: Lottie icons, menu animation, form microinteractions, animated quiz, horizontal layout. Evidence: The entry highlights Lottie icon scroll animation, slider animation, menu animation, animated icons, footer, quiz, and forms.

**Why it works.** A repeatable icon-motion language can connect navigation, forms, and content as long as state feedback stays immediate.

**Adaptation lesson.** Borrow as principles: stateful icon library, quiz progress feedback, motion reused by function.

**Accessibility / risk check.** Every icon looping or decorative Lottie increasing bundle and cognitive load.

**Provenance note.** The entry highlights Lottie icon scroll animation, slider animation, menu animation, animated icons, footer, quiz, and forms.

## M14 · House of Evil

| Field | Detail |
|---|---|
| ID | motion-awwwards-house-of-evil |
| Platform | Awwwards |
| Creator | Not documented in the source corpus. |
| Reference date | 2025-12-11 |
| Preview | Downloaded local preview |
| Source | [House of Evil](https://www.awwwards.com/sites/house-of-evil-1) |

![House of Evil](assets/motion/images/14_awwwards_house_of_evil.jpg)

**Design focus.** 3D commerce, experimental minimalism, loading transition, infinite scroll

**Elements.** 3D as product atmosphere, minimal purchase layer, poster-first loading

**Colour.** Colour is not documented in this motion-only source record. Catalog palette: Not documented. Measured preview palette: #121212, #020202, #393638, #070706, #8E928D, #0F0D0D, #1E1C1D, #000000

**Image evidence.** assets/motion/images/14_awwwards_house_of_evil.jpg — 1600×1200 JPEG; near-square; balanced; low visual density.

**Typography.** Typography is not documented in this motion-only source record.

**Layout and hierarchy.** The complete static layout is not documented; this record isolates: 3D commerce, experimental minimalism, loading transition, infinite scroll.

**Navigation.** Navigation behavior is asserted only where it appears in the documented patterns or source evidence.

**Motion and interaction.** Documented patterns: 3D commerce, experimental minimalism, loading transition, infinite scroll. Evidence: The entry highlights a loading animation and tags e-commerce, experimental, infinite scroll, minimal, 3D, WebGL, Shopify, and Next.js.

**Why it works.** Commerce can carry experimental 3D only if product identity, price, variant, and purchase actions remain plain DOM and immediately usable.

**Adaptation lesson.** Borrow as principles: 3D as product atmosphere, minimal purchase layer, poster-first loading.

**Accessibility / risk check.** Mandatory loader or experimental browsing delaying product and cart access.

**Provenance note.** The entry highlights a loading animation and tags e-commerce, experimental, infinite scroll, minimal, 3D, WebGL, Shopify, and Next.js.

## M15 · Der Baukasten

| Field | Detail |
|---|---|
| ID | motion-behance-der-baukasten |
| Platform | Behance |
| Creator | Not documented in the source corpus. |
| Reference date | 2026-01-21 |
| Preview | Downloaded local preview |
| Source | [Der Baukasten](https://www.behance.net/gallery/239747121/Der-Baukasten) |

![Der Baukasten](assets/motion/images/15_behance_der_baukasten.webp)

**Design focus.** modular object narrative, scroll-triggered 3D, custom UI, toy character design

**Elements.** assembly as progress, parts aligned with copy, tactile material cues

**Colour.** Colour is not documented in this motion-only source record. Catalog palette: Not documented. Measured preview palette: #029065, #000000, #B0CDAD, #493937, #029066, #029064, #029467, #019164

**Image evidence.** assets/motion/images/15_behance_der_baukasten.webp — 2352×1440 WEBP; landscape; cool; low visual density.

**Typography.** Typography is not documented in this motion-only source record.

**Layout and hierarchy.** The complete static layout is not documented; this record isolates: modular object narrative, scroll-triggered 3D, custom UI, toy character design.

**Navigation.** Navigation behavior is asserted only where it appears in the documented patterns or source evidence.

**Motion and interaction.** Documented patterns: modular object narrative, scroll-triggered 3D, custom UI, toy character design. Evidence: The case study describes an interactive scroll-based experience for modular 3D toys with detailed modelling, custom UI, and seamless scroll-triggered transitions.

**Why it works.** Use a product's real modular structure as the chapter logic: assemble, separate, compare, and recombine to explain relationships.

**Adaptation lesson.** Borrow as principles: assembly as progress, parts aligned with copy, tactile material cues.

**Accessibility / risk check.** Object manipulation that is playful but fails to explain the product.

**Provenance note.** The case study describes an interactive scroll-based experience for modular 3D toys with detailed modelling, custom UI, and seamless scroll-triggered transitions.

## M16 · Planetoño

| Field | Detail |
|---|---|
| ID | motion-behance-planetono |
| Platform | Behance |
| Creator | Not documented in the source corpus. |
| Reference date | 2026-03-18 |
| Preview | Downloaded local preview |
| Source | [Planetoño](https://www.behance.net/gallery/245955521/Planetono) |

![Planetoño](assets/motion/images/16_behance_planetono.webp)

**Design focus.** custom Three.js scroll, portal navigation, optimized shaders, Rive microinteractions

**Elements.** scene/UI ownership boundary, portal as transition motif, shader performance budget

**Colour.** Colour is not documented in this motion-only source record. Catalog palette: Not documented. Measured preview palette: #3E1513, #E72D1E, #D99C3A, #E82C1E, #E92D1E, #E92C1E, #E92A1D, #632D2A

**Image evidence.** assets/motion/images/16_behance_planetono.webp — 2800×2100 WEBP; near-square; warm; low visual density.

**Typography.** Typography is not documented in this motion-only source record.

**Layout and hierarchy.** The complete static layout is not documented; this record isolates: custom Three.js scroll, portal navigation, optimized shaders, Rive microinteractions.

**Navigation.** Navigation behavior is asserted only where it appears in the documented patterns or source evidence.

**Motion and interaction.** Documented patterns: custom Three.js scroll, portal navigation, optimized shaders, Rive microinteractions. Evidence: The case study describes narrative scroll motion, 3D environments, a custom Three.js scroll engine, portal-inspired navigation, optimized shaders, and Rive microinteractions.

**Why it works.** Separate large scene choreography from small interface acknowledgement; both can share art direction without sharing an implementation layer.

**Adaptation lesson.** Borrow as principles: scene/UI ownership boundary, portal as transition motif, shader performance budget.

**Accessibility / risk check.** Custom engine complexity without semantic fallback, instrumentation, and device tiers.

**Provenance note.** The case study describes narrative scroll motion, 3D environments, a custom Three.js scroll engine, portal-inspired navigation, optimized shaders, and Rive microinteractions.

## M17 · Alphane Labs

| Field | Detail |
|---|---|
| ID | motion-behance-alphane-labs |
| Platform | Behance |
| Creator | Not documented in the source corpus. |
| Reference date | 2026-03-05 |
| Preview | Downloaded local preview |
| Source | [Alphane Labs](https://www.behance.net/gallery/244697577/Alphane-Labs) |

![Alphane Labs](assets/motion/images/17_behance_alphane_labs.webp)

**Design focus.** orthographic 3D, wireframe shader, exploded product reveal, technical storytelling

**Elements.** orthographic camera, layer-labelled holds, wireframe-to-solid transition

**Colour.** Colour is not documented in this motion-only source record. Catalog palette: Not documented. Measured preview palette: #B3ADA2, #F4F7FD, #D0D0CA, #7D6D60, #CDC4B7, #DCD7CF, #FCFDFE, #F3F6FC

**Image evidence.** assets/motion/images/17_behance_alphane_labs.webp — 2800×1866 WEBP; landscape; balanced; low visual density.

**Typography.** Typography is not documented in this motion-only source record.

**Layout and hierarchy.** The complete static layout is not documented; this record isolates: orthographic 3D, wireframe shader, exploded product reveal, technical storytelling.

**Navigation.** Navigation behavior is asserted only where it appears in the documented patterns or source evidence.

**Motion and interaction.** Documented patterns: orthographic 3D, wireframe shader, exploded product reveal, technical storytelling. Evidence: The one-page concept is described as a scroll-driven 3D experience using orthographic projection, custom wireframe shaders, and layer-by-layer device storytelling.

**Why it works.** Camera and material language should express brand character; orthographic wireframe rendering makes precision and internal structure legible.

**Adaptation lesson.** Borrow as principles: orthographic camera, layer-labelled holds, wireframe-to-solid transition.

**Accessibility / risk check.** Thin wireframe contrast, excessive geometry, or continuously rotating technical copy.

**Provenance note.** The one-page concept is described as a scroll-driven 3D experience using orthographic projection, custom wireframe shaders, and layer-by-layer device storytelling.

## M18 · Centogene Solutions Website

| Field | Detail |
|---|---|
| ID | motion-behance-centogene-solutions |
| Platform | Behance |
| Creator | Not documented in the source corpus. |
| Reference date | 2020-10-08 |
| Preview | Downloaded local preview |
| Source | [Centogene Solutions Website](https://www.behance.net/gallery/105745513/Centogene-Solutions-Website) |

![Centogene Solutions Website](assets/motion/images/18_behance_centogene_solutions.webp)

**Design focus.** user-controlled 3D timeline, idle motion, section-specific animation, scientific storytelling

**Elements.** scroll-controlled explanation, distinct chapter timelines, pausable idle state

**Colour.** Colour is not documented in this motion-only source record. Catalog palette: Not documented. Measured preview palette: #E3DDE4, #D3C7CF, #E0DDE3, #ECEAF1, #E2DFE5, #E3DDE3, #E3DDE5, #E5DDE4

**Image evidence.** assets/motion/images/18_behance_centogene_solutions.webp — 1400×895 WEBP; landscape; balanced; low visual density.

**Typography.** Typography is not documented in this motion-only source record.

**Layout and hierarchy.** The complete static layout is not documented; this record isolates: user-controlled 3D timeline, idle motion, section-specific animation, scientific storytelling.

**Navigation.** Navigation behavior is asserted only where it appears in the documented patterns or source evidence.

**Motion and interaction.** Documented patterns: user-controlled 3D timeline, idle motion, section-specific animation, scientific storytelling. Evidence: The case study states that every 3D element has a timeline and idle motion, with timeline animations controlled by scrolling so users progress at their own pace.

**Why it works.** Give users control over explanatory motion; use low-amplitude idle animation only to keep a scene alive between interactions.

**Adaptation lesson.** Borrow as principles: scroll-controlled explanation, distinct chapter timelines, pausable idle state.

**Accessibility / risk check.** Idle loops consuming battery or distracting from scientific information.

**Provenance note.** The case study states that every 3D element has a timeline and idle motion, with timeline animations controlled by scrolling so users progress at their own pace.

## M19 · Millimetre – Scroll-Driven Website

| Field | Detail |
|---|---|
| ID | motion-behance-millimetre |
| Platform | Behance |
| Creator | Not documented in the source corpus. |
| Reference date | 2025-05-13 |
| Preview | Motion-only source reference; no downloaded preview |
| Source | [Millimetre – Scroll-Driven Website](https://www.behance.net/gallery/225780597/Millimetre-Scroll-Driven-Website) |

> Preview unavailable in the downloaded corpus. Use the attributed source page for visual review.

**Design focus.** process scrollytelling, industrial UI, technical chapter reveals, minimal layout

**Elements.** process milestones, chapter progress, specification panels paired with visuals

**Colour.** Colour is not documented in this motion-only source record. Catalog palette: Not documented. Measured preview palette: Not available.

**Image evidence.** No local image metrics are available for this record.

**Typography.** Typography is not documented in this motion-only source record.

**Layout and hierarchy.** The complete static layout is not documented; this record isolates: process scrollytelling, industrial UI, technical chapter reveals, minimal layout.

**Navigation.** Navigation behavior is asserted only where it appears in the documented patterns or source evidence.

**Motion and interaction.** Documented patterns: process scrollytelling, industrial UI, technical chapter reveals, minimal layout. Evidence: The case study describes a scroll-triggered journey that reveals phases of an industrial manufacturing process with a minimal technical UI.

**Why it works.** Scroll choreography is most intelligible when it mirrors a real process with a beginning, transformation, proof, and result.

**Adaptation lesson.** Borrow as principles: process milestones, chapter progress, specification panels paired with visuals.

**Accessibility / risk check.** Turning simple manufacturing facts into an unnecessarily long scroll.

**Provenance note.** The case study describes a scroll-triggered journey that reveals phases of an industrial manufacturing process with a minimal technical UI.

## M20 · RabenRifaie – Immersive 3D Studio Website

| Field | Detail |
|---|---|
| ID | motion-behance-rabenrifaie |
| Platform | Behance |
| Creator | Not documented in the source corpus. |
| Reference date | 2026-04-08 |
| Preview | Motion-only source reference; no downloaded preview |
| Source | [RabenRifaie – Immersive 3D Studio Website](https://www.behance.net/gallery/247171145/RabenRifaie-Immersive-3D-Studio-Website) |

> Preview unavailable in the downloaded corpus. Use the attributed source page for visual review.

**Design focus.** tactile 3D materials, calm studio portfolio, responsive 3D, organic motion

**Elements.** material-led worlds, calm motion amplitude, responsive composition variants

**Colour.** Colour is not documented in this motion-only source record. Catalog palette: Not documented. Measured preview palette: Not available.

**Image evidence.** No local image metrics are available for this record.

**Typography.** Typography is not documented in this motion-only source record.

**Layout and hierarchy.** The complete static layout is not documented; this record isolates: tactile 3D materials, calm studio portfolio, responsive 3D, organic motion.

**Navigation.** Navigation behavior is asserted only where it appears in the documented patterns or source evidence.

**Motion and interaction.** Documented patterns: tactile 3D materials, calm studio portfolio, responsive 3D, organic motion. Evidence: The case study describes Framer-based high-quality 3D, smooth natural animations, moss/wood/stone textures, calm immersion, and responsive treatment for smartphone and desktop.

**Why it works.** Material selection and low-frequency movement can create depth without aggressive camera motion; mobile should preserve art direction while simplifying rendering.

**Adaptation lesson.** Borrow as principles: material-led worlds, calm motion amplitude, responsive composition variants.

**Accessibility / risk check.** Large uncompressed textures or a desktop composition merely scaled down.

**Provenance note.** The case study describes Framer-based high-quality 3D, smooth natural animations, moss/wood/stone textures, calm immersion, and responsive treatment for smartphone and desktop.

## M21 · UX Motion Vol. 01

| Field | Detail |
|---|---|
| ID | motion-behance-ux-motion-vol-01 |
| Platform | Behance |
| Creator | Not documented in the source corpus. |
| Reference date | 2025-02-20 |
| Preview | Motion-only source reference; no downloaded preview |
| Source | [UX Motion Vol. 01](https://www.behance.net/gallery/205453429/UX-Motion-Vol-01) |

> Preview unavailable in the downloaded corpus. Use the attributed source page for visual review.

**Design focus.** motion specification, app navigation journey, section interaction, standardized motion grid

**Elements.** motion tokens, state diagrams, prototype-to-code handoff, interaction inventory

**Colour.** Colour is not documented in this motion-only source record. Catalog palette: Not documented. Measured preview palette: Not available.

**Image evidence.** No local image metrics are available for this record.

**Typography.** Typography is not documented in this motion-only source record.

**Layout and hierarchy.** The complete static layout is not documented; this record isolates: motion specification, app navigation journey, section interaction, standardized motion grid.

**Navigation.** Navigation behavior is asserted only where it appears in the documented patterns or source evidence.

**Motion and interaction.** Documented patterns: motion specification, app navigation journey, section interaction, standardized motion grid. Evidence: The collection groups landing-page interactions, animated app navigation journeys, section interactions, a standardized motion grid, and implemented website examples.

**Why it works.** Treat motion as a reusable delivery system with documented states and implementation intent, not as isolated After Effects clips.

**Adaptation lesson.** Borrow as principles: motion tokens, state diagrams, prototype-to-code handoff, interaction inventory.

**Accessibility / risk check.** Designer-only timing that cannot reverse, interrupt, or adapt in production.

**Provenance note.** The collection groups landing-page interactions, animated app navigation journeys, section interactions, a standardized motion grid, and implemented website examples.

## M22 · Micro Interactions – UI Design – Figma

| Field | Detail |
|---|---|
| ID | motion-behance-micro-interactions-figma |
| Platform | Behance |
| Creator | Not documented in the source corpus. |
| Reference date | 2023-04-20 |
| Preview | Motion-only source reference; no downloaded preview |
| Source | [Micro Interactions – UI Design – Figma](https://www.behance.net/gallery/168809995/Micro-Interactions-UI-Design-Figma) |

> Preview unavailable in the downloaded corpus. Use the attributed source page for visual review.

**Design focus.** transforming button, toggle feedback, expanding search, hover affordance, completion acknowledgement

**Elements.** label-preserving transforms, clear terminal state, hover plus focus, busy/success feedback

**Colour.** Colour is not documented in this motion-only source record. Catalog palette: Not documented. Measured preview palette: Not available.

**Image evidence.** No local image metrics are available for this record.

**Typography.** Typography is not documented in this motion-only source record.

**Layout and hierarchy.** The complete static layout is not documented; this record isolates: transforming button, toggle feedback, expanding search, hover affordance, completion acknowledgement.

**Navigation.** Navigation behavior is asserted only where it appears in the documented patterns or source evidence.

**Motion and interaction.** Documented patterns: transforming button, toggle feedback, expanding search, hover affordance, completion acknowledgement. Evidence: The project demonstrates animated countdown, airplane-mode toggle, subscribe-to-input-to-thank-you transformation, settings feedback, expanding search, carousel, read-more hover, and testimonial hover.

**Why it works.** The best microinteraction exposes the next step and confirms completion in the same footprint, reducing context switching.

**Adaptation lesson.** Borrow as principles: label-preserving transforms, clear terminal state, hover plus focus, busy/success feedback.

**Accessibility / risk check.** Morphing controls changing accessible names, hit areas, or focus unexpectedly.

**Provenance note.** The project demonstrates animated countdown, airplane-mode toggle, subscribe-to-input-to-thank-you transformation, settings feedback, expanding search, carousel, read-more hover, and testimonial hover.

## M23 · Interactive Homepage Design with 3D and Scroll Animations

| Field | Detail |
|---|---|
| ID | motion-dribbble-stenoa-homepage |
| Platform | Dribbble |
| Creator | Not documented in the source corpus. |
| Reference date | Not documented in the source corpus. |
| Preview | Motion-only source reference; no downloaded preview |
| Source | [Interactive Homepage Design with 3D and Scroll Animations](https://dribbble.com/shots/24138454-Interactive-Homepage-Design-with-3D-and-Scroll-Animations) |

> Preview unavailable in the downloaded corpus. Use the attributed source page for visual review.

**Design focus.** 3D hero, scroll reveals, agency landing page

**Elements.** hero focal object, quieter downstream sections, single CTA layer

**Colour.** Colour is not documented in this motion-only source record. Catalog palette: Not documented. Measured preview palette: Not available.

**Image evidence.** No local image metrics are available for this record.

**Typography.** Typography is not documented in this motion-only source record.

**Layout and hierarchy.** The complete static layout is not documented; this record isolates: 3D hero, scroll reveals, agency landing page.

**Navigation.** Navigation behavior is asserted only where it appears in the documented patterns or source evidence.

**Motion and interaction.** Documented patterns: 3D hero, scroll reveals, agency landing page. Evidence: The shot describes an interactive 3D hero and scroll animations created for Stenoa.

**Why it works.** Concentrate the richest spatial moment in the hero, then lower motion density so the rest of the page can explain and convert.

**Adaptation lesson.** Borrow as principles: hero focal object, quieter downstream sections, single CTA layer.

**Accessibility / risk check.** The hero consuming the performance and attention budget needed by the actual content.

**Provenance note.** The shot describes an interactive 3D hero and scroll animations created for Stenoa.

## M24 · Navigation on-hover UX animation

| Field | Detail |
|---|---|
| ID | motion-dribbble-navigation-on-hover |
| Platform | Dribbble |
| Creator | Not documented in the source corpus. |
| Reference date | Not documented in the source corpus. |
| Preview | Motion-only source reference; no downloaded preview |
| Source | [Navigation on-hover UX animation](https://dribbble.com/shots/4041918-Navigation-on-hover-UX-animation) |

> Preview unavailable in the downloaded corpus. Use the attributed source page for visual review.

**Design focus.** mega-menu reveal, active underline, child-link stagger, frame-to-navigation transition

**Elements.** visual-origin menu reveal, active-route persistence, short bounded stagger

**Colour.** Colour is not documented in this motion-only source record. Catalog palette: Not documented. Measured preview palette: Not available.

**Image evidence.** No local image metrics are available for this record.

**Typography.** Typography is not documented in this motion-only source record.

**Layout and hierarchy.** The complete static layout is not documented; this record isolates: mega-menu reveal, active underline, child-link stagger, frame-to-navigation transition.

**Navigation.** Navigation behavior is asserted only where it appears in the documented patterns or source evidence.

**Motion and interaction.** Documented patterns: mega-menu reveal, active underline, child-link stagger, frame-to-navigation transition. Evidence: The concept animates an outer canvas border into a mega-menu, underlines the active parent, and staggers child links.

**Why it works.** Animate hierarchy and group ordering: active parent first, children second, supporting content last.

**Adaptation lesson.** Borrow as principles: visual-origin menu reveal, active-route persistence, short bounded stagger.

**Accessibility / risk check.** Hover-only opening, excessive stagger latency, or menu content that cannot be dismissed with keyboard/touch.

**Provenance note.** The concept animates an outer canvas border into a mega-menu, underlines the active parent, and staggers child links.
