# Research-Grounded UI Patterns

Use this library to select and combine design systems from the web, mobile, and motion research corpora. Treat each linked showcase as evidence that an aesthetic or interaction can be compelling—not as proof that it is usable, accessible, performant, or commercially effective.

## Contents

- [Evidence model](#evidence-model)
- [Cross-corpus design grammar](#cross-corpus-design-grammar)
- [Web archetypes](#web-archetypes)
- [Mobile archetypes](#mobile-archetypes)
- [Palette, type, layout, and material patterns](#palette-type-layout-and-material-patterns)
- [Navigation patterns](#navigation-patterns)
- [Motion and 3D patterns](#motion-and-3d-patterns)
- [Pattern-selection matrix](#pattern-selection-matrix)
- [Originality protocol](#originality-protocol)
- [Anti-patterns](#anti-patterns)

## Evidence model

Use four evidence levels and never silently promote one into another:

| Level | What this corpus supplies | What it can support | What it cannot prove |
|---|---|---|---|
| Showcase cue | Awwwards, Behance, Dribbble, Pinterest, Recent, Siteinspire, CSSDA | Art direction, composition, interaction hypotheses, memorable metaphors | Task success, accessibility, performance, conversion, maintainability |
| Interaction case study | The 24 motion/3D exemplars | Choreography, continuity, feedback, state transitions, spatial storytelling | Cross-device reliability or measurable user outcomes |
| Production-pattern check | Mobbin, Screenlane, Pttrns, Refero, UIguana | Recurring real-product conventions and missing intermediate states | That a pattern is optimal for this audience or context |
| Validated product UX | Requirements, complete flows, prototype/usability testing, accessibility and performance verification | A defensible release decision | Not present merely because a design appears in an inspiration catalog |

Design from showcase cues, normalize with production-pattern checks, then validate in the actual product. For example, [Lusion v3](https://www.awwwards.com/sites/lusion-v3) demonstrates a calm shell around an immersive stage; it does not establish that a WebGL hero is appropriate for a banking transfer or a low-power device.

## Cross-corpus design grammar

### 1. Singular stage, stable spine

Give one object, proposition, metric, destination, or task visual ownership. Keep navigation, labels, and supporting controls at least one tier quieter. This relationship appears in the framed 3D scene of [Lusion v3](https://www.awwwards.com/sites/lusion-v3), the restrained product story of [iyO](https://www.awwwards.com/sites/iyo), and the mobile hero-to-itinerary hierarchy of [Travel Planner](https://dribbble.com/shots/27455621-Travel-Planner-Mobile-App-with-Trip-Map-Weather-Cards).

**Rule:** one focal stage + one primary action + one stable orientation system. Do not distribute equal emphasis across the viewport.

### 2. Expressive discovery, conventional commitment

Increase personality during orientation, discovery, storytelling, and success; reduce novelty during authentication, consent, payment, booking, health escalation, destructive actions, and error recovery. [FocoTik](https://www.behance.net/gallery/220000795/AI-eCommerce-Mobile-app-Website-UI-UX-FocoTik) and [House of Evil](https://www.awwwards.com/sites/house-of-evil-1) suggest how experimental commerce can coexist with legible product and purchase semantics.

**Rule:** the closer the user gets to irreversible or high-stakes action, the flatter, clearer, and more familiar the interaction should become.

### 3. Story rhythm, not effect accumulation

Long experiences feel authored when a small set of section archetypes alternates density, alignment, and scale. [CANALS](https://www.awwwards.com/sites/canals) and [New Codes](https://www.behance.net/gallery/191144391/New-Codes-Website-for-Digital-Fashion-Summit) build rhythm through chaptering; they do not require a novel effect in every section.

**Rule:** define three to five compositional beats and one motion motif, then reuse them with variation.

### 4. Object continuity preserves understanding

Keep the selected product, project, destination, or card visually continuous as context changes. [Lightweight](https://www.awwwards.com/sites/lightweight) uses continuity through scroll chapters, while mobile product and travel flows benefit from card-to-detail shared elements.

**Rule:** continuity is useful when it answers “is this still the same object?”; it is wasteful when it transitions unrelated decoration.

### 5. Cards are semantic answers

Each card should answer one user question: “what happens next?”, “what changed?”, “is this safe?”, or “which choice fits?” The ranked mobile dashboard in [RentPlanner](https://dribbble.com/shots/25826662-Booking-App-for-Rental-Business-RentPlanner) and the web operational hierarchy in [Financial Dashboard](https://dribbble.com/shots/26623741-UX-UI-design-for-Financial-Dashboard) work when cards carry distinct decision roles.

**Rule:** name a card's question before designing its container. Merge cards that answer the same question and remove cards without a decision role.

### 6. Motion explains causality

Prioritize motion that orients, explains, or confirms. Delight is the fourth job. [Micro Interactions](https://www.behance.net/gallery/168809995/Micro-Interactions-UI-Design-Figma) shows state feedback in a compact footprint; [Der Baukasten](https://www.behance.net/gallery/239747121/Der-Baukasten) derives scroll choreography from actual modular structure.

**Rule:** every animation must name its user-facing job and its reduced-motion equivalent.

### 7. Capability is a design input

Build enhanced, simplified-interactive, and static-resilient variants. The information architecture and actions remain constant while scene complexity, pointer effects, scroll choreography, and asset weight degrade. Do not equate a narrow viewport with low capability, or a wide viewport with high capability.

## Web archetypes

| Archetype | Anatomy | Signature opportunity | Guardrail | Source anchors |
|---|---|---|---|---|
| Framed immersive hero | Quiet shell, large scene, compact proposition, corner controls | Product orbit, material reveal, shallow pointer depth | DOM copy and CTA must remain complete without canvas | [Lusion v3](https://www.awwwards.com/sites/lusion-v3), [iyO](https://www.awwwards.com/sites/iyo) |
| Spatial portfolio/world | Coherent world, landmarks, current position, shortcuts | Camera travel as navigation | Provide a visible map, first-action cue, conventional index, and escape | [Bruno's Portfolio](https://www.awwwards.com/sites/brunos-portfolio), [The Future in Mind](https://www.awwwards.com/sites/the-future-in-mind) |
| Editorial chapters | Display type, full-bleed media, text pauses, asymmetric alternation | Masks, parallax, chapter handoffs | Preserve reading order and avoid horizontal-only mobile navigation | [CANALS](https://www.awwwards.com/sites/canals), [New Codes](https://www.behance.net/gallery/191144391/New-Codes-Website-for-Digital-Fashion-Summit) |
| SaaS conversion narrative | Promise, proof, product view, benefit, trust, CTA | Product-state transitions and layered UI explanation | Product screenshot must tell a specific, readable story | [DataFlow](https://dribbble.com/shots/26311201-DataFlow-Landing-Page-UI), [Huly](https://kr.pinterest.com/pin/116249234130533563/) |
| Operational dashboard | Persistent navigation, stable grid, semantic metric families, drill-down | Filter continuity, changed-data emphasis | Keep data planar; never animate values continuously | [Financial Dashboard](https://dribbble.com/shots/26623741-UX-UI-design-for-Financial-Dashboard) |
| Luxury/material commerce | Editorial opening, exceptional imagery, restrained product grid, explicit purchase path | Low-frequency material transition or product reveal | Never hide title, price, variants, availability, or cart | [Simple Perfection](https://www.behance.net/gallery/250598145/Simple-Perfection-Luxury-Diamond-E-commerce-UXUI), [Icebug](https://recent.design/i/xa3v96i-icebug) |
| Stable rail + diverse canvas | Fixed index/rail, modular content plane, strong type anchors | Project change with shared rail state | Responsive collapse must preserve index and DOM order | [Other Matter](https://www.siteinspire.com/website/10649-other-matter) |

## Mobile archetypes

| Archetype | First-screen hierarchy | Flow grammar | Motion opportunity | Trust requirement | Source anchors |
|---|---|---|---|---|---|
| Cinematic discovery | Hero promise → essential facts → next action | Discover → understand → commit → manage | Shared hero, route draw, day/step progression | Text-safe imagery, offline and error recovery | [Travel Planner](https://dribbble.com/shots/27455621-Travel-Planner-Mobile-App-with-Trip-Map-Weather-Cards) |
| Ranked decision dashboard | One focal metric → prioritized actions → supporting evidence | Overview → exception → drill-down → action | Local state transitions and changed-data emphasis | Exact values, stable axes, semantic status | [RentPlanner](https://dribbble.com/shots/25826662-Booking-App-for-Rental-Business-RentPlanner) |
| Assistant-to-object | Capability examples → conversation → structured result | Prompt → generate → inspect → correct → save/use | Listening/thinking states and message-to-object morph | Provenance, uncertainty, editability, manual route | [Travel AI Assistant](https://dribbble.com/shots/26956915-Travel-Mobile-App-Design-AI-Assistant), [AI Chatbot UI Kit](https://mx.pinterest.com/pin/34621490880754639/) |
| Clinical measurement | Current status → trend/context → action/escalation | Prepare → measure → interpret → follow up | Measurement progress only when truthful | Color-independent state, privacy, no implied diagnosis | [ECG & Heart Rate](https://dribbble.com/shots/26808268-Mobile-App-Design-ECG-Heart-Rate-Monitoring-UI), [Serena Medical](https://www.behance.net/gallery/226311719/Serena-Medical-Healthcare-App-UXUI-Design) |
| Product theatre | Product object → variants → evidence → sticky CTA | Browse → inspect → configure → cart → checkout | Object continuity and material/swatch response | Variant labels, total, stock, returns, conventional checkout | [Furniture E-commerce](https://dribbble.com/shots/27020833-Furniture-E-commerce-Mobile-App), [FocoTik](https://www.behance.net/gallery/220000795/AI-eCommerce-Mobile-app-Website-UI-UX-FocoTik) |
| Character-guided learning | One task → guidance → response → progress | Attempt → feedback → repair → mastery | Character reaction tied to meaningful progress | Avoid manipulative loops; provide transcripts and guardian-safe settings | [Kids AI Learning](https://dribbble.com/shots/27068193-AI-Learning-Mobile-App-Kids-Education-UI) |
| Device/control utility | System/room state → primary control → scenes/history | Inspect → command → pending → success/failure | Latency and state feedback, spatial grouping | Explicit pending/failed states and sensitive-action confirmation | [Hume Smart Home](https://dribbble.com/shots/26559633-Hume-Mobile-App-Design-for-Smart-Home) |
| Expressive finance shell | Balance/goal → conventional actions → transactions/proof | Inspect → review → confirm → receipt | Restrained shared cards and chart scrub | Tabular figures, privacy masking, review and receipt | [Swift Banking](https://www.behance.net/gallery/207942807/Swift-Digital-Banking-Mobile-App-UI-UX-design) |

## Palette, type, layout, and material patterns

### Palette families

| Family | Token behavior | Good fit | Constraint |
|---|---|---|---|
| Calm utility | Warm white/pale gray base, ink text, one saturated action | Health, planning, finance, SaaS | Strengthen contrast and brand character without raising noise |
| Premium dark | Near-black graphite, controlled elevation, one emissive accent | Crypto, smart home, fitness, media, AI | Avoid glow behind text and tune dark mode independently |
| Editorial material | Cream, stone, forest, wine, metal, or colors sampled from imagery | Travel, fashion, furniture, luxury | Let material color replace generic “luxury gold” |
| Technical emissive | Black/navy with violet, cyan, acid green, or cobalt at interaction points | Spatial tech, 3D tools, Web3 | Keep accents sparse; separate brand and semantic colors |
| Expressive youth | Pastel field, black type, one or two vivid sticker colors | Learning, onboarding, Gen-Z products | Preserve task hierarchy and avoid reward saturation |
| Clinical measurement | White/soft gray with vermilion, blue, or green data accents | Health, fitness, timing | Pair every color signal with label, icon, texture, or shape |

Start near a 60/30/10 base/support/accent balance, then tune by content. Build semantic tokens—surface, text, action, success, warning, danger, focus—before theme mockups. [Dark & Light Mode Settings](https://uk.pinterest.com/pin/dark-light-mode-settings--799389002642744136/) is a useful visual cue, but production themes still require independent contrast and elevation checks.

### Typography system

- Use one display voice for proposition or emotion and one neutral utility voice for reading, controls, and data; one variable family can cover both.
- Use tabular figures for balances, medical readings, timers, analytics, and comparisons.
- Create six roles at most: display, screen/page title, section title, body, label, metadata.
- Establish hierarchy with size, weight, spacing, and placement in agreement. Do not make all four compete.
- Keep labels stable during transforms; masks and line reveals are safer than continuous glyph distortion.
- Test Dynamic Type, browser zoom, long translations, and RTL before accepting an oversized-type composition.

### Layout models

| Model | Composition rule | Responsive transformation |
|---|---|---|
| Framed viewport | One scene inside a quiet page frame | Replace deep camera travel with poster or shallow object response |
| Split hero | Proposition/action and product/media with unequal visual weight | Stack message before media; retain immediate CTA |
| Chapter alternation | Reuse three to five sections with changing density and alignment | Collapse horizontal beats into ordered vertical chapters |
| Fixed rail + canvas | Stable navigation/index beside changing content | Convert rail into top bar, drawer, or section index |
| Mosaic/bento | Variable spans on a strict grid; every tile has a decision role | Rank into a vertical decision stack; do not preserve desktop density |
| Edge-to-edge mobile stage | Hero respects system insets; utility follows in quiet cards | Add status-bar scrim and keep sticky actions above home indicator |

### Material and depth ladder

Use three depth tiers only: atmosphere, focal object/content, and controls. Controls remain crisp and stable. Glass is an elevation cue, not a universal surface; provide an opaque fallback. Blur, glow, grain, translucency, and 3D lighting should derive from one material story and never reduce contrast or imply a false physical affordance.

Use exactly one dimensional focal system per surface. It should explain product construction, spatial relation, state, or transformation. If layered CSS/SVG communicates the same idea, do not add WebGL.

## Navigation patterns

| Context | Preferred grammar | Motion grammar | Required fallback/behavior |
|---|---|---|---|
| Web marketing | Persistent header or compact overlay menu | `closed → opening → open → closing`; links enter as one group | Real links, Escape/backdrop close, focus trap/return, current location |
| Web portfolio/archive | Stable rail/index + project canvas | Shared indicator and project/media continuity | Conventional index and keyboard-readable DOM order |
| Spatial world | Landmarks + visible map/progress + shortcut list | Recoverable camera travel | Direct navigation outside the 3D world |
| Long editorial | Chapter index/progress + native document scroll | Reversible scroll beats; optional pinning | Skip link, normal-flow reduced-motion/mobile variant |
| Mobile app | Labeled 3–5 item tab bar | Shared tab indicator; no page-scale flourish | Stable destinations and preserved state |
| Mobile contextual task | Top app bar + bottom sheet | Sheet from trigger context, interruptible dismissal | Clear close action, drag affordance, keyboard and safe-area handling |
| Mobile object flow | Card-to-detail drill-down | Shared product/image/title | Immediate transition fallback and restored focus/state |
| Sequential task | Timeline/stepper | State change and progress, not decorative travel | Text step state, editable review, back without data loss |

[Utsubo v2](https://www.awwwards.com/sites/utsubo-v2) and [Navigation on-hover](https://dribbble.com/shots/4041918-Navigation-on-hover-UX-animation) show authored navigation rhythm. Borrow group ordering and shared easing; do not copy hover dependence or allow animated layers to destabilize hit targets.

## Motion and 3D patterns

### Motion jobs and token ladder

| Job | Typical band | Examples |
|---|---:|---|
| Confirm | 80–160 ms | Press, toggle, selection, acknowledgement |
| Explain local state | 180–280 ms | Sheet, accordion, validation, tab indicator |
| Preserve continuity | 280–500 ms | Card-to-detail, route/state shared element |
| Hand off a chapter | 420–800 ms | Hero reveal, gallery change, scroll chapter |
| Ambient atmosphere | 4–18 s, low amplitude | Material drift or light movement; pause/reduce |

Use one signature motif—camera glide, layered peel, elastic mask, material shimmer, or route draw—and repeat it with variation. At any instant, one element owns attention, one supporting group may move coherently, and the rest stays quiet. [UX Motion Vol. 01](https://www.behance.net/gallery/205453429/UX-Motion-Vol-01) is a useful cue for documenting motion as a state system rather than a clip collection.

### Scroll-to-3D choreography

Use four authored states:

1. Orient in a readable, mostly flat composition.
2. Let the focal object acquire depth or separate into meaningful parts.
3. Hold while supporting facts pin, cross-fade, or change emphasis.
4. Resolve into the next stable screen or ordinary document flow.

Scroll remains the only progress source; one render clock damps and applies it. Keep copy and controls in semantic DOM. On mobile or reduced motion, use fewer states, a fixed camera, simplified assets, or static views. [Der Baukasten](https://www.behance.net/gallery/239747121/Der-Baukasten) grounds the chapters in modular product logic; [Lightweight](https://www.awwwards.com/sites/lightweight) demonstrates object continuity across scroll.

### Horizontal narrative

Use only when sequence and image scale justify it. Keep each item a real DOM link, show progress and controls, and provide a vertical or native-snap mobile variant. [Brontide](https://www.awwwards.com/sites/brontide) is an aesthetic hypothesis with a high orientation burden, not a default page pattern.

### Microinteraction contract

Every button/control needs rest, hover or focus, pressed, disabled, pending, success, and error behavior where applicable. Move an inner visual layer rather than the semantic hit area. Pending preserves label context and blocks duplicate submission without losing focus. State is conveyed with text/icon semantics, not animation or color alone.

### Reduced-motion substitution

Replace large translation/scale with a short cross-fade or immediate swap; parallax with fixed layers; camera travel with static authored views; orbit/exploded scenes with stills; smooth scroll with native scroll; long staggers with grouped appearance; cursor/magnetic effects with native pointer plus focus/hover color. Reduced motion preserves information and continuity—it does not simply set every duration to zero.

## Pattern-selection matrix

| Product/context | Primary archetype | Add at most one signature effect | Keep conventional | Validation burden | Research anchors |
|---|---|---|---|---|---|
| Hardware launch | Framed immersive hero + chapter story | Feature-linked orbit/exploded view | Nav, comparison, price, CTA | Asset weight, WebGL failure, reduced motion | [iyO](https://www.awwwards.com/sites/iyo), [Lightweight](https://www.awwwards.com/sites/lightweight) |
| Creative portfolio | Stable rail + expressive canvas | Shared project transition or coherent spatial world | Index, contact, project links | Orientation, keyboard path, mobile alternative | [Lusion v3](https://www.awwwards.com/sites/lusion-v3), [The Future in Mind](https://www.awwwards.com/sites/the-future-in-mind) |
| Editorial/cultural story | Chapter alternation | Masks/parallax or one symbolic object | Reading order, chapter access | Readability, scroll agency, media alternatives | [CANALS](https://www.awwwards.com/sites/canals), [New Codes](https://www.behance.net/gallery/191144391/New-Codes-Website-for-Digital-Fashion-Summit) |
| SaaS marketing | Conversion narrative | Product-state continuity | Proposition, proof, pricing, CTA | Screenshot legibility, performance, conversion path | [DataFlow](https://dribbble.com/shots/26311201-DataFlow-Landing-Page-UI), [Huly](https://kr.pinterest.com/pin/116249234130533563/) |
| Analytics/dashboard | Stable grid or ranked stack | Filter/drill-down continuity | Values, axes, navigation, export/action | Data accuracy, keyboard, dense responsive states | [Financial Dashboard](https://dribbble.com/shots/26623741-UX-UI-design-for-Financial-Dashboard), [RentPlanner](https://dribbble.com/shots/25826662-Booking-App-for-Rental-Business-RentPlanner) |
| Premium commerce | Material/editorial commerce | One product shared element or material reveal | Search, variants, price, cart, checkout | Product findability, checkout, asset performance | [Simple Perfection](https://www.behance.net/gallery/250598145/Simple-Perfection-Luxury-Diamond-E-commerce-UXUI), [Furniture E-commerce](https://dribbble.com/shots/27020833-Furniture-E-commerce-Mobile-App) |
| Health/clinical | Clinical measurement/task flow | Truthful measurement-state feedback | Labels, escalation, privacy, history | High-stakes accuracy, contrast, assistive tech | [ECG & Heart Rate](https://dribbble.com/shots/26808268-Mobile-App-Design-ECG-Heart-Rate-Monitoring-UI), [Serena Medical](https://www.behance.net/gallery/226311719/Serena-Medical-Healthcare-App-UXUI-Design) |
| Finance | Calm or expressive shell around precision layer | Shared card/chart scrub | Review, confirmation, receipt, exact values | Privacy, error prevention, localization, contrast | [Swift Banking](https://www.behance.net/gallery/207942807/Swift-Digital-Banking-Mobile-App-UI-UX-design) |
| AI assistant | Assistant-to-object | State orb/waveform plus message-to-object continuity | Examples, edit, regenerate, save, manual path | Uncertainty, provenance, latency/error states | [Travel AI Assistant](https://dribbble.com/shots/26956915-Travel-Mobile-App-Design-AI-Assistant), [AI Chatbot UI Kit](https://mx.pinterest.com/pin/34621490880754639/) |
| Smart home/control | Spatially grouped utility | Device-state and latency response | Controls, pending/error, security confirmation | Real-device latency, offline, safety | [Hume Smart Home](https://dribbble.com/shots/26559633-Hume-Mobile-App-Design-for-Smart-Home) |
| Kids/learning | Character-guided task | Meaningful progress reaction | Instruction, response, repair, progress | Attention, captions, guardian safety | [Kids AI Learning](https://dribbble.com/shots/27068193-AI-Learning-Mobile-App-Kids-Education-UI) |

## Originality protocol

1. **Write product truth first.** State audience, job, desired action, constraints, and differentiator without visual language.
2. **Extract design DNA.** For each candidate reference record purpose, emotional tone, first-viewport hierarchy, navigation model, component grammar, palette/type relation, and motion role.
3. **Mix unlike evidence.** Combine principles from at least three references across different creators and preferably different surfaces—for example, a Siteinspire navigation spine, an Awwwards focal stage, and a mobile finance precision layer.
4. **Change the fingerprint.** Replace the source metaphor, content model, grid proportions, type pairing, palette, icon family, object silhouette, and transition choreography. Never reproduce distinctive artwork, brand copy, exact composition, or proprietary assets.
5. **Budget novelty.** Permit one signature spatial/motion system per viewport and one supporting microinteraction family. Spend novelty where it expresses the product differentiator.
6. **Design the unglamorous states.** Complete empty, loading, error, offline, permission, keyboard, destructive, confirmation, receipt, reduced-motion, no-WebGL, and return-visit states before declaring the direction coherent.
7. **Run the silhouette test.** Blur color and imagery: the new hierarchy should remain clear. Remove motion: the flow should remain complete. Compare to each source: no single reference should dominate the recognizable result.
8. **Keep provenance.** Record source IDs and the abstract lessons used. Production assets must be original or properly licensed.

## Anti-patterns

- **Award-site soup:** WebGL, cursor follower, marquees, glass, noise, scroll smoothing, and chromatic gradients combined without one concept.
- **3D without an answer:** a floating object that explains no product feature, structure, state, or spatial relationship.
- **Canvas monopoly:** essential copy, navigation, forms, or status rendered only in canvas/video.
- **Scroll capture:** long locks, hidden scrollbars, broken anchors, or a narrative that cannot be skipped or reversed.
- **Spatial amnesia:** camera travel without current location, landmarks, progress, shortcut, or escape.
- **Card soup:** identical rounded containers with equal emphasis and no decision hierarchy.
- **Dashboard theatre:** continuous number animation, ornamental 3D charts, unstable axes, or color reused inconsistently.
- **AI orb as product:** decorative listening/thinking animation without capability examples, editable results, evidence, or recovery.
- **High-stakes flourish:** parallax, bounce, or delayed transitions during payment, consent, medical escalation, destructive confirmation, or emergency paths.
- **Hover dependency:** content or navigation available only to a fine pointer; magnetic effects that move the actual hit target.
- **Theme inversion:** deriving dark mode mechanically from light mode rather than semantic contrast/elevation tokens.
- **Motion plagiarism:** copying a source's exact reveal order, camera path, mascot/object, easing signature, and composition as one recognizable bundle.
- **Performance optimism:** designing only for a desktop GPU and treating low-power, touch, slow-network, or WebGL failure as post-launch cleanup.
- **Showcase-as-validation:** assuming an award, like count, or polished case-study board demonstrates task success or accessibility.

For the complete evidence index, load [SOURCE_CATALOG.json](SOURCE_CATALOG.json). For implementation and verification, use the dedicated motion, layout, visual-language, originality, recipe, and quality-gate references instead of expanding this file into framework documentation.
