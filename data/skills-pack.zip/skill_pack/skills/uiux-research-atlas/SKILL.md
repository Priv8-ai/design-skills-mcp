---
name: uiux-research-atlas
description: Use when a UI/UX decision should be grounded in a specific research reference instead of generic taste — choosing a layout archetype for a landing page, dashboard, commerce, fintech, health, AI-assistant or portfolio surface; picking a palette family, type system, navigation grammar, motion timing or 3D/scroll choreography; sanity-checking a direction against known anti-patterns; or looking up evidence from the 101-reference UI/UX Research Atlas (38 web, 39 mobile, 24 motion exemplars from Awwwards, Behance, Dribbble, Pinterest, Siteinspire, Recent, CSSDA). Also use for "find design references for X", "what does the atlas say about Y", "is this pattern supported by the research", or any work inside the uiux-research-atlas deliverable itself.
user-invocable: true
argument-hint: "[search <terms> | show <id> | palette | brief <product> | check <direction>]"
---

# UI/UX Research Atlas

A corpus of 101 normalized design references with measured palettes, per-record
analysis, and a synthesized pattern library. Use it to make design choices that
cite evidence, and to stay honest about what that evidence can and cannot prove.

## The one rule that governs everything

**A showcase reference is an aesthetic hypothesis, never a validation.** Awwwards,
Behance, Dribbble, and Pinterest entries prove that a direction can be compelling.
They prove nothing about task success, accessibility, performance, or conversion.
Never present a corpus reference as evidence that something *works* for users —
say what it demonstrates, then name the validation still owed.

The four evidence levels (showcase cue → interaction case study → production-pattern
check → validated product UX) are defined in `reference/patterns.md`. Do not silently
promote one level into another.

## Query the corpus

Run the script; do not read the 208 KB analysis file end to end.

```bash
S=".claude/skills/uiux-research-atlas"   # or ~/.claude/skills/uiux-research-atlas

python3 $S/scripts/atlas.py stats                                  # composition + resolved asset root
python3 $S/scripts/atlas.py search fintech dark --kind mobile      # ranked keyword search (AND)
python3 $S/scripts/atlas.py search scroll 3D --kind web --limit 5
python3 $S/scripts/atlas.py show web-001 --analysis                # full record + long-form section
python3 $S/scripts/atlas.py similar MOB-005                        # neighbours by tag + element overlap
python3 $S/scripts/atlas.py palette --max-luminance 0.2            # measured dark surfaces
python3 $S/scripts/atlas.py palette --min-luminance 0.7 --temperature warm
python3 $S/scripts/atlas.py list --kind motion                     # 24 motion exemplars
python3 $S/scripts/atlas.py tags --kind web                        # tag vocabulary
python3 $S/scripts/atlas.py assets web-001                         # absolute preview image paths
```

Every command accepts `--json`. Filters `--kind`, `--platform`, `--tag`,
`--with-preview` work on `search`, `list`, `tags`, and `palette`.

ID shapes differ by corpus: `web-001…web-038`, `MOB-001…MOB-039`,
`motion-<platform>-<slug>`. Tags differ too — Web and Motion records carry short
tags (`3D`, `editorial`, `SaaS`); Mobile records carry two descriptive sentences
(product purpose, then visual character). Free-text `search` spans all fields, so
prefer it over `--tag` when unsure.

## Files

| Path | Use it for |
|---|---|
| `reference/patterns.md` | **Read this first for any design decision.** Cross-corpus grammar, web/mobile archetype tables, palette families, layout models, navigation grammar, motion token ladder, pattern-selection matrix, originality protocol, anti-patterns. ~27 KB — read whole. |
| `reference/analysis.md` | Per-record long-form analysis (101 sections). Reach it through `show --analysis` or `Grep`; never read whole. |
| `reference/workflow.md` | Step-by-step procedures for the four common jobs (direction brief, reference pull, palette/motion spec, direction critique). |
| `reference/rights.md` | Rights, provenance, and reuse boundaries. Read before any suggestion that reuses a pixel asset. |
| `data/SOURCE_CATALOG.json` / `.csv` | Structured records if you need to compute over the corpus yourself. |

Preview images and the interactive `UI_UX_ATLAS.html` live in the source
deliverable, not in this skill. `atlas.py root` prints the resolved location;
`atlas.py root --set /path/to/uiux-research-atlas` records it if the deliverable
moved. Without it, everything except image paths still works.

## How to use it in practice

1. **State product truth before visual language.** Audience, job, primary action,
   constraints, differentiator. Skip this and the corpus becomes mood-boarding.
2. **Pick the archetype from `reference/patterns.md`**, then pull 3+ concrete
   references across *different creators and surfaces* with `atlas.py search`.
   One reference dominating the result is plagiarism, not synthesis.
3. **Budget novelty: one signature spatial/motion system per viewport**, one
   supporting microinteraction family. Everything else stays conventional —
   especially auth, payment, consent, destructive, and health-escalation paths.
4. **Cite the record ID and what it demonstrates** in your recommendation, plus
   the guardrail from the archetype table. Format:
   `MOB-005 (RentPlanner) — ranked decision stack; guardrail: exact values, stable axes.`
5. **Name the validation still owed.** Contrast, keyboard, screen reader, touch
   targets, reduced motion, low-power/no-WebGL fallback, offline and error states.

`reference/workflow.md` has the full procedures. Follow it when the request is a
brief, a spec, or a critique rather than a lookup.

## Hard constraints

- Never reproduce a source's distinctive artwork, brand copy, exact composition,
  icon family, or complete transition choreography. Transform principles, not pixels.
- Never claim a pattern is accessible, performant, or conversion-effective because
  it appears in the corpus.
- Never recommend a WebGL/3D hero without also specifying the static-resilient
  variant and reduced-motion substitution.
- Measured palettes and dimensions describe a downloaded preview image, not the
  live product. 14 records have no local preview and say so — don't fabricate one.
- Corpus assets are private research reference. Anything shipping to production
  must be original or properly licensed (`reference/rights.md`).
