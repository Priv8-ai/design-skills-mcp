#!/usr/bin/env python3
"""Query the UI/UX Research Atlas corpus (101 normalized references).

Data ships with the skill (data/SOURCE_CATALOG.json), so every command works
regardless of the current working directory. Image previews and the interactive
HTML atlas live in the source deliverable; that root is resolved from, in order:

  1. $UIUX_ATLAS_ROOT
  2. data/atlas-root.txt next to this skill
  3. a parent directory of the skill containing UI_UX_ATLAS.html
  4. the current working directory, if it contains UI_UX_ATLAS.html

Commands: search, show, list, tags, stats, palette, similar, assets, root
"""

from __future__ import annotations

import argparse
import json
import os
import re
import sys
from pathlib import Path

SKILL_DIR = Path(__file__).resolve().parent.parent
CATALOG = SKILL_DIR / "data" / "SOURCE_CATALOG.json"
ANALYSIS = SKILL_DIR / "reference" / "analysis.md"
ROOT_HINT = SKILL_DIR / "data" / "atlas-root.txt"

TEXT_FIELDS = [
    "title", "creator", "platform", "kind", "elements", "tags", "colour",
    "typography", "layout_hierarchy", "navigation", "motion", "why_it_works",
    "adaptation_lesson", "accessibility_or_risk", "provenance",
]

NARRATIVE_FIELDS = [
    ("elements", "Elements"),
    ("colour", "Colour"),
    ("typography", "Typography"),
    ("layout_hierarchy", "Layout and hierarchy"),
    ("navigation", "Navigation"),
    ("motion", "Motion and interaction"),
    ("why_it_works", "Why it works"),
    ("adaptation_lesson", "Adaptation lesson"),
    ("accessibility_or_risk", "Accessibility / risk"),
    ("provenance", "Provenance"),
]


# --------------------------------------------------------------------------- io


def load_items() -> list[dict]:
    if not CATALOG.exists():
        sys.exit(f"catalog not found: {CATALOG}")
    return json.loads(CATALOG.read_text())["items"]


def atlas_root() -> Path | None:
    env = os.environ.get("UIUX_ATLAS_ROOT")
    if env and (Path(env) / "UI_UX_ATLAS.html").exists():
        return Path(env)
    if ROOT_HINT.exists():
        hinted = Path(ROOT_HINT.read_text().strip()).expanduser()
        if (hinted / "UI_UX_ATLAS.html").exists():
            return hinted
    for parent in SKILL_DIR.parents:
        if (parent / "UI_UX_ATLAS.html").exists():
            return parent
    cwd = Path.cwd()
    if (cwd / "UI_UX_ATLAS.html").exists():
        return cwd
    return None


def analysis_sections() -> dict[str, str]:
    """Map record id -> its long-form section from reference/analysis.md."""
    if not ANALYSIS.exists():
        return {}
    sections: dict[str, str] = {}
    current: list[str] = []
    for line in ANALYSIS.read_text().splitlines():
        if line.startswith("## "):
            _flush(sections, current)
            current = [line]
        elif current:
            current.append(line)
    _flush(sections, current)
    return sections


def _flush(sections: dict[str, str], buf: list[str]) -> None:
    if not buf:
        return
    body = "\n".join(buf)
    match = re.search(r"^\|\s*ID\s*\|\s*([a-z0-9\-]+)\s*\|", body, re.M)
    if match:
        sections[match.group(1)] = body.strip()


# ---------------------------------------------------------------------- filters


def flat_text(item: dict) -> str:
    parts = []
    for field in TEXT_FIELDS:
        value = item.get(field)
        if isinstance(value, list):
            parts.append(" ".join(str(v) for v in value))
        elif value:
            parts.append(str(value))
    return " ".join(parts).lower()


def apply_filters(items: list[dict], args) -> list[dict]:
    out = items
    if getattr(args, "kind", None):
        wanted = {k.lower() for k in args.kind}
        out = [i for i in out if i["kind"].lower() in wanted]
    if getattr(args, "platform", None):
        needle = args.platform.lower()
        out = [i for i in out if needle in i["platform"].lower()]
    if getattr(args, "tag", None):
        wanted = [t.lower() for t in args.tag]
        out = [i for i in out
               if all(any(w in t.lower() for t in i["tags"]) for w in wanted)]
    if getattr(args, "with_preview", False):
        out = [i for i in out if i.get("local_images")]
    return out


def score(item: dict, terms: list[str]) -> int:
    haystack = flat_text(item)
    title = f"{item['title']} {' '.join(item['tags'])}".lower()
    total = 0
    for term in terms:
        hits = haystack.count(term)
        if not hits:
            return 0
        total += hits + (5 if term in title else 0)
    return total


# ----------------------------------------------------------------------- render


def brief(item: dict) -> str:
    tags = ", ".join(item["tags"]) or "—"
    palette = " ".join(item.get("measured_palette") or item.get("catalog_palette") or [])
    preview = item["local_images"][0] if item.get("local_images") else "no local preview"
    return (
        f"{item['id']}  [{item['kind']}/{item['platform']}]  {item['title']}\n"
        f"    tags     {tags}\n"
        f"    lesson   {item.get('adaptation_lesson', '—')}\n"
        f"    palette  {palette or '—'}\n"
        f"    source   {item['source_url']}\n"
        f"    preview  {preview}"
    )


def full(item: dict, section: str | None) -> str:
    lines = [
        f"# {item['id']} · {item['title']}",
        "",
        f"- Kind      : {item['kind']}",
        f"- Platform  : {item['platform']}",
        f"- Creator   : {item.get('creator') or '—'}",
        f"- Date      : {item.get('date') or '—'}",
        f"- Tags      : {', '.join(item['tags']) or '—'}",
        f"- Source    : {item['source_url']}",
        f"- Live      : {item.get('live_url') or '—'}",
        f"- Preview   : {item.get('preview_status') or '—'}",
    ]
    if item.get("local_images"):
        lines.append(f"- Images    : {', '.join(item['local_images'])}")
    if item.get("catalog_palette"):
        lines.append(f"- Catalog palette : {', '.join(item['catalog_palette'])}")
    if item.get("measured_palette"):
        lines.append(f"- Measured palette: {', '.join(item['measured_palette'])}")
    for metric in item.get("image_metrics") or []:
        lines.append(
            f"- Measured  : {metric['width']}x{metric['height']} {metric['format']}, "
            f"{metric['orientation']}, {metric['temperature']}, "
            f"{metric['visual_density']} density, luminance {metric['luminance_mean']}"
        )
    lines.append("")
    for key, label in NARRATIVE_FIELDS:
        value = item.get(key)
        if not value:
            continue
        if isinstance(value, list):
            value = ", ".join(value)
        lines.append(f"**{label}.** {value}")
        lines.append("")
    if section:
        lines += ["---", "", "Long-form analysis (reference/analysis.md):", "", section]
    return "\n".join(lines).rstrip()


def emit(payload, args, renderer) -> None:
    if getattr(args, "json", False):
        print(json.dumps(payload, indent=2, ensure_ascii=False))
    else:
        print(renderer(payload))


# --------------------------------------------------------------------- commands


def cmd_search(args) -> None:
    items = apply_filters(load_items(), args)
    terms = [t.lower() for t in args.query]
    if terms:
        ranked = [(score(i, terms), i) for i in items]
        items = [i for s, i in sorted(ranked, key=lambda p: -p[0]) if s > 0]
    items = items[: args.limit]
    if args.json:
        print(json.dumps(items, indent=2, ensure_ascii=False))
        return
    if not items:
        print("no matches; try fewer terms, or `atlas.py tags` to see the vocabulary")
        return
    print(f"{len(items)} match(es)\n")
    print("\n\n".join(brief(i) for i in items))


def cmd_show(args) -> None:
    items = load_items()
    needle = args.ref.lower()
    hits = [i for i in items if i["id"].lower() == needle]
    if not hits:
        hits = [i for i in items if needle in i["id"].lower() or needle in i["title"].lower()]
    if not hits:
        sys.exit(f"no record matching {args.ref!r}")
    if len(hits) > 1 and not args.json:
        print(f"{len(hits)} records match {args.ref!r}:\n")
        print("\n\n".join(brief(i) for i in hits[:10]))
        return
    if args.json:
        print(json.dumps(hits if len(hits) > 1 else hits[0], indent=2, ensure_ascii=False))
        return
    sections = analysis_sections() if args.analysis else {}
    print(full(hits[0], sections.get(hits[0]["id"])))


def cmd_list(args) -> None:
    items = apply_filters(load_items(), args)
    if args.json:
        print(json.dumps(items, indent=2, ensure_ascii=False))
        return
    for item in items:
        tags = ", ".join(item["tags"])
        print(f"{item['id']:<38} {item['kind']:<7} {item['title']}  [{tags}]")
    print(f"\n{len(items)} record(s)")


def cmd_tags(args) -> None:
    from collections import Counter
    items = apply_filters(load_items(), args)
    counts = Counter(t for i in items for t in i["tags"])
    if args.json:
        print(json.dumps(dict(counts.most_common()), indent=2, ensure_ascii=False))
        return
    for tag, n in counts.most_common():
        print(f"{n:>3}  {tag}")


def cmd_stats(args) -> None:
    from collections import Counter
    items = load_items()
    data = {
        "total": len(items),
        "by_kind": dict(Counter(i["kind"] for i in items)),
        "by_platform": dict(Counter(i["platform"] for i in items).most_common()),
        "with_local_preview": sum(1 for i in items if i.get("local_images")),
        "unique_tags": len({t for i in items for t in i["tags"]}),
        "atlas_root": str(atlas_root() or "not resolved"),
    }
    if args.json:
        print(json.dumps(data, indent=2, ensure_ascii=False))
        return
    print(f"records            {data['total']}")
    print(f"by kind            {data['by_kind']}")
    print(f"with local preview {data['with_local_preview']}")
    print(f"unique tags        {data['unique_tags']}")
    print("by platform")
    for platform, n in data["by_platform"].items():
        print(f"  {n:>3}  {platform}")
    print(f"atlas root         {data['atlas_root']}")


def cmd_palette(args) -> None:
    items = apply_filters(load_items(), args)
    rows = []
    for item in items:
        for metric in item.get("image_metrics") or []:
            if args.max_luminance is not None and metric["luminance_mean"] > args.max_luminance:
                continue
            if args.min_luminance is not None and metric["luminance_mean"] < args.min_luminance:
                continue
            if args.temperature and metric["temperature"] != args.temperature:
                continue
            rows.append({
                "id": item["id"],
                "title": item["title"],
                "kind": item["kind"],
                "luminance_mean": metric["luminance_mean"],
                "temperature": metric["temperature"],
                "visual_density": metric["visual_density"],
                "palette": [p["hex"] for p in metric["palette"]],
                "shares": [p["share"] for p in metric["palette"]],
            })
    rows.sort(key=lambda r: r["luminance_mean"])
    rows = rows[: args.limit]
    if args.json:
        print(json.dumps(rows, indent=2, ensure_ascii=False))
        return
    if not rows:
        print("no measured palettes match those filters")
        return
    for row in rows:
        swatches = "  ".join(
            f"{hexv}({share:.0%})" for hexv, share in zip(row["palette"], row["shares"])
        )
        print(f"{row['id']:<38} lum {row['luminance_mean']:.2f}  {row['temperature']:<5} "
              f"{row['visual_density']:<6}  {row['title']}")
        print(f"    {swatches}")


def cmd_similar(args) -> None:
    items = load_items()
    target = next((i for i in items if i["id"].lower() == args.ref.lower()), None)
    if target is None:
        target = next((i for i in items if args.ref.lower() in i["title"].lower()), None)
    if target is None:
        sys.exit(f"no record matching {args.ref!r}")
    # Web and Motion records carry short tags; Mobile records carry two long
    # descriptive tags, so element overlap is what makes them comparable.
    tags = {t.lower() for t in target["tags"]}
    elements = {e.lower() for e in target.get("elements") or []}
    scored = []
    for item in items:
        if item["id"] == target["id"]:
            continue
        overlap = len(tags & {t.lower() for t in item["tags"]})
        shared_elements = len(elements & {e.lower() for e in item.get("elements") or []})
        if not overlap and not shared_elements:
            continue
        bonus = 1 if item["kind"] == target["kind"] else 0
        scored.append((overlap * 3 + shared_elements * 2 + bonus, item))
    scored.sort(key=lambda p: -p[0])
    picked = [i for _, i in scored[: args.limit]]
    if args.json:
        print(json.dumps(picked, indent=2, ensure_ascii=False))
        return
    print(f"similar to {target['id']} · {target['title']}\n")
    print("\n\n".join(brief(i) for i in picked) if picked
          else "no tag or element overlap found")


def cmd_assets(args) -> None:
    root = atlas_root()
    items = load_items()
    needle = args.ref.lower() if args.ref else None
    picked = [i for i in items
              if not needle or needle in i["id"].lower() or needle in i["title"].lower()]
    missing_root = root is None
    for item in picked:
        for rel in item.get("local_images") or []:
            path = str(root / rel) if root else rel
            exists = "" if missing_root or (root / rel).exists() else "  [MISSING]"
            print(f"{item['id']:<38} {path}{exists}")
    if missing_root:
        print("\nAtlas root not resolved: paths above are relative to the deliverable.",
              file=sys.stderr)
        print("Set UIUX_ATLAS_ROOT=/path/to/uiux-research-atlas to resolve them.",
              file=sys.stderr)


def cmd_root(args) -> None:
    if args.set:
        target = Path(args.set).expanduser().resolve()
        if not (target / "UI_UX_ATLAS.html").exists():
            sys.exit(f"{target} does not look like the atlas deliverable "
                     "(no UI_UX_ATLAS.html)")
        ROOT_HINT.parent.mkdir(parents=True, exist_ok=True)
        ROOT_HINT.write_text(str(target) + "\n")
        print(f"atlas root recorded: {target}")
        return
    root = atlas_root()
    if root:
        print(root)
    else:
        sys.exit("atlas root not resolved; run `atlas.py root --set /path/to/uiux-research-atlas`")


# -------------------------------------------------------------------------- cli


def add_filters(p: argparse.ArgumentParser) -> None:
    p.add_argument("--kind", action="append", choices=["Web", "Mobile", "Motion",
                                                       "web", "mobile", "motion"],
                   help="restrict to one or more corpora (repeatable)")
    p.add_argument("--platform", help="substring match on source platform")
    p.add_argument("--tag", action="append", help="require a tag substring (repeatable, AND)")
    p.add_argument("--with-preview", action="store_true", help="only records with a local image")


def main() -> None:
    parser = argparse.ArgumentParser(
        prog="atlas.py", description=__doc__,
        formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--json", action="store_true", help="machine-readable output")
    sub = parser.add_subparsers(dest="cmd", required=True)

    p = sub.add_parser("search", help="rank records by keyword across every field")
    p.add_argument("query", nargs="*", help="terms; all must match (AND)")
    p.add_argument("--limit", type=int, default=8)
    add_filters(p)
    p.set_defaults(func=cmd_search)

    p = sub.add_parser("show", help="full record by id or title substring")
    p.add_argument("ref")
    p.add_argument("--analysis", action="store_true",
                   help="append the long-form section from reference/analysis.md")
    p.set_defaults(func=cmd_show)

    p = sub.add_parser("list", help="list records, optionally filtered")
    add_filters(p)
    p.set_defaults(func=cmd_list)

    p = sub.add_parser("tags", help="tag vocabulary with frequencies")
    add_filters(p)
    p.set_defaults(func=cmd_tags)

    p = sub.add_parser("stats", help="corpus composition and resolved atlas root")
    p.set_defaults(func=cmd_stats)

    p = sub.add_parser("palette", help="measured palettes, sorted light-to-dark")
    p.add_argument("--max-luminance", type=float, help="e.g. 0.25 for premium-dark surfaces")
    p.add_argument("--min-luminance", type=float, help="e.g. 0.7 for calm-utility surfaces")
    p.add_argument("--temperature", choices=["warm", "cool", "neutral"])
    p.add_argument("--limit", type=int, default=12)
    add_filters(p)
    p.set_defaults(func=cmd_palette)

    p = sub.add_parser("similar", help="records sharing tags with a reference")
    p.add_argument("ref")
    p.add_argument("--limit", type=int, default=6)
    p.set_defaults(func=cmd_similar)

    p = sub.add_parser("assets", help="resolve local preview paths against the atlas root")
    p.add_argument("ref", nargs="?", help="id or title substring; omit for all")
    p.set_defaults(func=cmd_assets)

    p = sub.add_parser("root", help="show or record the atlas deliverable root")
    p.add_argument("--set", metavar="PATH")
    p.set_defaults(func=cmd_root)

    args = parser.parse_args()
    args.func(args)


if __name__ == "__main__":
    main()
