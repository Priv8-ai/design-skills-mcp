#!/usr/bin/env bash
# Install (or refresh) the uiux-research-atlas skill for Claude Code.
#
#   ./install.sh            install to ~/.claude/skills/uiux-research-atlas
#   ./install.sh --dest DIR install somewhere else (e.g. another project's .claude/skills)
#
# The skill bundles its own text corpus (~740 KB) and is self-contained.
# The 71 MB of preview images stays in the deliverable; its path is recorded in
# data/atlas-root.txt so `atlas.py assets` can resolve absolute image paths.

set -euo pipefail

SRC="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
DEST="${HOME}/.claude/skills/uiux-research-atlas"

while [[ $# -gt 0 ]]; do
  case "$1" in
    --dest) DEST="$2"; shift 2 ;;
    -h|--help) sed -n '2,10p' "${BASH_SOURCE[0]}"; exit 0 ;;
    *) echo "unknown argument: $1" >&2; exit 2 ;;
  esac
done

# Locate the atlas deliverable by walking up from the skill directory.
ATLAS_ROOT=""
probe="$SRC"
while [[ "$probe" != "/" ]]; do
  if [[ -f "$probe/UI_UX_ATLAS.html" ]]; then ATLAS_ROOT="$probe"; break; fi
  probe="$(dirname "$probe")"
done

mkdir -p "$DEST"
rm -rf "$DEST"/{SKILL.md,reference,scripts,data,install.sh}
cp "$SRC/SKILL.md" "$SRC/install.sh" "$DEST/"
cp -R "$SRC/reference" "$SRC/scripts" "$SRC/data" "$DEST/"
chmod +x "$DEST/scripts/atlas.py" "$DEST/install.sh"

if [[ -n "$ATLAS_ROOT" ]]; then
  printf '%s\n' "$ATLAS_ROOT" > "$DEST/data/atlas-root.txt"
  echo "atlas root recorded: $ATLAS_ROOT"
  case "$ATLAS_ROOT" in
    /var/folders/*|/private/var/folders/*|/tmp/*)
      echo "WARNING: the deliverable sits in a macOS temp directory that the system" >&2
      echo "         may purge. Move it somewhere permanent, then run:" >&2
      echo "         python3 $DEST/scripts/atlas.py root --set /new/path" >&2 ;;
  esac
else
  echo "note: atlas deliverable not found from $SRC; preview image paths will be relative."
  echo "      run: python3 $DEST/scripts/atlas.py root --set /path/to/uiux-research-atlas"
fi

echo "installed: $DEST"
python3 "$DEST/scripts/atlas.py" stats
