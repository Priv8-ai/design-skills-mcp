# Entity Categorization Pattern — schema → API → client UI

Adding classification (categories/tags) to any entity in a multi-tenant SaaS
follows a consistent 4-layer pattern. Proven in Q.af for links (URL shortener
categorization with auto-tag, color-coded badges, filter dropdown, inline edit).

## Layer 1: Prisma schema

Add a simple optional string field:

```prisma
model Link {
  // ... existing fields
  category String?  // Arabic or English classification label
}
```

No separate model needed unless you need multi-tag or hierarchical categories.
Run `npx prisma generate` immediately after the edit — TypeScript types are
stale until you do.

## Layer 2: API handlers (POST + PATCH)

### POST create — accept `category` in the request body

```ts
// src/app/api/links/route.ts
const link = await prisma.link.create({
  data: {
    slug,
    destination: dest,
    title: body.title ? String(body.title) : null,
    category: body.category ? String(body.category) : null,
    // ... other fields
  },
  include: { domain: true },
});
```

### PATCH update — accept `category` in the update payload

```ts
// src/app/api/links/[id]/route.ts
const data: {
  destination?: string;
  title?: string | null;
  category?: string | null;
  active?: boolean;
  expiresAt?: Date | null;
  clickLimit?: number | null;
} = {};

if (body.category !== undefined)
  data.category = body.category ? String(body.category) : null;
```

## Layer 3: Server component → client prop

Map the field explicitly in the server page. Do NOT spread the raw Prisma object.

```tsx
// page.tsx
<LinksListClient
  links={links.map(l => ({
    id: l.id, slug: l.slug, destination: l.destination,
    domain: l.domain.hostname, clicks: l.clicks, active: l.active,
    title: l.title,
    category: l.category,
    createdAt: l.createdAt.toISOString(),
    variants: [],
    abMode: false,
  }))}
  domains={domains}
  shortBase={baseUrl}
/>
```

## Layer 4: Client UI (4 sub-patterns)

### 4a. Category constants + color map

Define a static list of known categories and their badge colors. When the
project is Arabic-first, use Arabic labels:

```tsx
const CATEGORIES = ["فيديو", "تسوق", "تواصل", "برمجة", "توثيق", "بحث",
                    "تدوين", "متجر", "دفع", "موسيقى", "اجتماع", "تصميم", "سحابة"];

const CATEGORY_COLORS: Record<string, string> = {
  "فيديو": "#ef4444", "تسوق": "#f59e0b", "تواصل": "#3b82f6",
  "برمجة": "#22c55e", "توثيق": "#6366f1", "بحث": "#14b8a6",
  "تدوين": "#ec4899", "متجر": "#a855f7", "دفع": "#06b6d4",
  "موسيقى": "#8b5cf6", "اجتماع": "#0ea5e9", "تصميم": "#d946ef",
  "سحابة": "#84cc16",
};
```

### 4b. Category badges in table

```tsx
<td>
  {l.category ? (
    <span className="dash-badge" style={{
      background: CATEGORY_COLORS[l.category] || "var(--purple)",
      color: "white", fontSize: ".72rem",
    }}>
      {l.category}
    </span>
  ) : (
    <span style={{ color: "var(--muted)", fontSize: ".78rem" }}>—</span>
  )}
</td>
```

### 4c. Category filter dropdown

Auto-populate from the links currently in view:

```tsx
const [filterCategory, setFilterCategory] = useState<string>("");
const availableCategories = [...new Set(links.map(l => l.category).filter(Boolean))] as string[];
availableCategories.sort();

// In JSX:
{availableCategories.length > 0 && (
  <select value={filterCategory} onChange={e => setFilterCategory(e.target.value)}>
    <option value="">كل التصنيفات</option>
    {availableCategories.map((c) => <option key={c} value={c}>{c}</option>)}
  </select>
)}
```

Then filter the table rows:

```tsx
const filtered = links.filter(l =>
  (!filterDomain || l.domain === filterDomain) &&
  (!filterCategory || l.category === filterCategory) &&
  (!q || l.slug.includes(q) || l.destination.includes(q))
);
```

### 4d. Auto-tag from URL (on create)

Map URL patterns to category labels using regex rules. Wire via
`onTagsUpdate` callback from LinksSmartFeatures:

```tsx
// SmartFeatures component calls onTagsUpdate?.(detectedTags)
<LinksSmartFeatures
  destination={destValue}
  onTagsUpdate={(tags) => {
    if (tags.length > 0 && !createCategory) {
      setCreateCategory(tags[0]);
    }
  }}
/>

// In create form, controlled input bound to createCategory state:
<input
  name="category"
  value={createCategory}
  onChange={(e) => setCreateCategory(e.target.value)}
  list="category-list"
/>
<datalist id="category-list">
  {CATEGORIES.map((c) => <option key={c} value={c} />)}
</datalist>
```

Use a `datalist` so users can pick from known categories or type a custom one.

### 4e. Inline edit modal

Clicking a table row opens a modal to edit title/category/destination without
navigating away:

```tsx
const [editLink, setEditLink] = useState<LinkRow | null>(null);
const [editTitle, setEditTitle] = useState("");
const [editCategory, setEditCategory] = useState("");
const [editDest, setEditDest] = useState("");
const [savingEdit, setSavingEdit] = useState(false);

function openEdit(l: LinkRow) {
  setEditTitle(l.title || "");
  setEditCategory(l.category || "");
  setEditDest(l.destination);
  setEditLink(l);
}

async function saveEdit() {
  if (!editLink) return;
  setSavingEdit(true);
  try {
    await fetch(`/api/links/${editLink.id}`, {
      method: "PATCH",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        title: editTitle || null,
        category: editCategory || null,
        destination: editDest || editLink.destination,
      }),
    });
    setEditLink(null);
    router.refresh();
  } finally {
    setSavingEdit(false);
  }
}

// Modal JSX pattern:
{editLink && (
  <div onClick={() => setEditLink(null)}
       style={{ position: "fixed", inset: 0, background: "rgba(7,17,47,.55)",
                backdropFilter: "blur(6px)", display: "flex", alignItems: "center",
                justifyContent: "center", zIndex: 1000 }}>
    <div onClick={(e) => e.stopPropagation()} className="dash-card"
         style={{ maxWidth: 480, width: "100%", padding: 24 }}>
      <h3>تعديل الرابط</h3>
      <label>العنوان <input className="dash-input" value={editTitle} onChange={e => setEditTitle(e.target.value)} /></label>
      <label>التصنيف <input className="dash-input" value={editCategory} onChange={e => setEditCategory(e.target.value)} list="edit-category-list" /></label>
      <label>الوجهة <input className="dash-input ltr" dir="ltr" value={editDest} onChange={e => setEditDest(e.target.value)} /></label>
      <button onClick={() => setEditLink(null)}>إلغاء</button>
      <button onClick={saveEdit} disabled={savingEdit}>حفظ</button>
    </div>
  </div>
)}
```

Key design points:
- The outer `<div>` click closes the modal (click-away dismiss)
- The inner `<div>` stops propagation so clicks inside don't close
- Modal is at `zIndex: 1000` with backdrop blur
- Form fields use `list` + `<datalist>` for autocomplete suggestions

## Verification checklist

After implementing categorization for any entity:

1. `npx tsc --noEmit` — zero errors
2. `npm run build` — route registers
3. Grep POST handler for `body.category` — accept
4. Grep PATCH handler for `body.category` — accept
5. Confirm category badges render in table cell
6. Confirm filter dropdown exists and filters correctly
7. Confirm auto-tag fires on URL paste → "تحليل الرابط"
8. Confirm inline edit modal saves (PATCH 200 + refresh reflects changes)
