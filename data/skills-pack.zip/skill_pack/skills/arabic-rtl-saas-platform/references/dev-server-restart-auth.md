# Dev server stale cache and authentication workflow

## Stale cache symptoms
- `npm run build` passes clean
- `curl http://localhost:4000/login` returns 500 with `Cannot find module './8.js'`
- Browser shows empty page or fallback error page
- Server process appears to be running but serving broken chunks

## Fix: Scoped restart
```bash
# Kill the specific server (not bare 'next dev' — kills other projects too)
pkill -f "next dev -p 4000"
sleep 2

# Clear the cache completely
rm -rf .next

# Restart in background
npx next dev -p 4000 > /tmp/hr-bridge-dev.log 2>&1 &

# Wait and verify
sleep 5
curl -s -o /dev/null -w "%{http_code}\n" http://localhost:4000/login
```

## Authentication workflow
Browser sessions and curl do NOT share cookies. The `iron-session` cookie is:
- `HttpOnly` (cannot be read by JavaScript)
- `sameSite: "lax"` (only sent on same-site requests)
- Encrypted with `iron-session` (not plain text)

### For API testing (curl)
```bash
# Login and save cookie jar
curl -s -X POST http://localhost:4000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"naif.sahw@gmail.com","password":"Qweewq123!"}' \
  -c /tmp/session.txt

# Use cookie jar for subsequent requests
curl -s -X POST http://localhost:4000/api/employees \
  -H "Content-Type: application/json" \
  -b /tmp/session.txt \
  -d '{...}'
```

### For browser testing
1. Navigate to `/login`
2. Type email and password in form fields
3. Click the submit button
4. Navigate to dashboard pages
5. If session expires, repeat steps 1-3

### Important: Do NOT try `document.cookie` injection
`document.cookie = "hrbridge_session=..."` does NOT work because:
- The cookie is `HttpOnly` (JavaScript cannot set it)
- Even if visible, `iron-session` requires the correct format and signature
- The browser automation tool's cookie jar is separate from curl's

## Verification checklist after restart
```bash
# 1. Check server is listening
lsof -i :4000 | grep node

# 2. Check login page returns 200
curl -s http://localhost:4000/login | head -1

# 3. Check API health
curl -s http://localhost:4000/api/health 2>/dev/null || echo "No health endpoint"

# 4. Check build output
npm run build 2>&1 | tail -5
```
