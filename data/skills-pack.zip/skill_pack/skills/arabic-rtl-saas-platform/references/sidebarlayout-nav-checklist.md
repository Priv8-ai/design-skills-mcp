# SidebarLayout Nav Item Addition Checklist

When adding a new nav item to `src/components/SidebarLayout.tsx`, all 4 steps must be done in order. Skipping any results in `tsc` errors or invisible nav items.

## The 4 required changes

### 1. Add the Icon SVG component (bottom of file)

```tsx
function IconHealth()  { return <svg {...stroke()}><path d="..."/></svg>; }
```

Place after the last existing icon. All icons use the `stroke()` helper for consistent sizing (18×18, stroke: currentColor, etc.).

### 2. Extend the `NavKey` union type (top of file)

```ts
export type NavKey =
  | "overview" | "links" | "domains" // ... existing keys
  | "health";  // ← add new key
```

### 3. Add the NAV array entry (lines ~28-42)

```tsx
{ key: "health", href: "/dashboard/health", label: "المراقبة", icon: <IconHealth />, section: "متقدم" },
```

Choose the right section:
- `"الأساس"` — core features (overview, links, domains, analytics, bio)
- `"الأدوات"` — tools (QR, A/B)
- `"الإدارة"` — management (API keys, webhooks, agency, leaderboard, settings)
- `"متقدم"` — advanced (bulk-import, health)

### 4. If using a NEW section not in the union, extend both

If `"متقدم"` is not yet in the union, add it to:
```ts
// Line ~14: NavItem type
section: "الأساس" | "الأدوات" | "الإدارة" | "متقدم";

// Line ~80: render order array
const order: NavItem["section"][] = ["الأساس", "الأدوات", "الإدارة", "متقدم"];
```

## Pitfall: subagent modifies SidebarLayout while parent also edits it

When a subagent dispatches tasks that include nav item additions, the subagent may modify SidebarLayout.tsx. If the parent also edits the same file (adding icons, sections, or nav items), conflicts arise:

1. **Icon name mismatch** — subagent uses `IconSettings` but the real icon is `IconGear`.
2. **Section misplacement** — subagent puts `settings` in `"متقدم"` when it should be `"الإدارة"`.
3. **Missing icon definition** — subagent references `IconHealth` in the NAV array but never defines it.

**Recovery:** After subagent returns, grep for new icon references and verify each one has a corresponding `function Icon...()` definition. grep for section values and verify they're all in the union type.
