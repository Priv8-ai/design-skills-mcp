# Mass i18n sweep — eliminating hardcoded Arabic across a SaaS dashboard

End-to-end workflow for finding and replacing every hardcoded Arabic string in
a Next.js 15 App Router dashboard that uses trilingual cookie-based i18n (ar/en/fr).

## Detection sweep (find ALL offenders)

```bash
# Phase 1: dashboard pages
grep -rl '[ا-ي]' src/app/dashboard/ 2>/dev/null

# Phase 2: shared layout components (easy to miss!)
grep -rl '[ا-ي]' src/components/ 2>/dev/null

# Phase 3: API routes (usually backend strings — assess whether they need i18n)
grep -rl '[ا-ي]' src/app/api/ 2>/dev/null
```

**Critical**: Phase 2 catches NotificationCenter, InstallPrompt, OfflineBadge,
PushPermissionPrompt, LanguageSwitcher — components that sit in the root layout,
not under dashboard/, so a dashboard-only scan misses them entirely.

## Fix pattern per component type

### Server Component → `makeT`
```tsx
import { getLocale, makeT } from "@/i18n/server";
export default async function MyPage() {
  const locale = await getLocale();
  const t = makeT(locale);
  // use t("key") everywhere
}
```

### Client Component → `useT`
```tsx
"use client";
import { useT } from "@/i18n/useT";
export default function MyComponent() {
  const { t } = useT();   // MUST destructure — t is { locale, dir, meta, t }
  // use t("key") everywhere
}
```

**Pitfall**: `const t = useT()` (without destructuring) makes `t` the whole context
object, not the translation function. Always `const { t } = useT()` or `useT().t`.

### Arrays with labels → `labelKey` pattern
For tab arrays, dropdown options, or config tables where each item has a display
label and the array is defined at module level:
```tsx
const TABS = [
  { id: "active", labelKey: "crm.tab.active" },
  { id: "archive", labelKey: "crm.tab.archive" },
] as const;
// In render: <button>{t(tab.labelKey)}</button>
```
This avoids moving the whole array inside the component body just for `t()`.

### Quick Links navigation list pattern

For dashboard sidebar / quick-links panels where each entry is both a `href` URL and a translated label, use an inline array of keyed objects:

```tsx
<div className="space-y-1">
  {[
    { href: "/dashboard/employees", key: "home.manageEmployees" },
    { href: "/dashboard/recruitment", key: "home.hiringPipeline" },
    { href: "/dashboard/leave",     key: "home.leaveRequests" },
    { href: "/dashboard/documents",  key: "home.documents" },
    { href: "/dashboard/reports",    key: "home.reports" },
  ].map((l) => (
    <a key={l.href} href={l.href}>
      <span>{t(l.key)}</span>
      <span>→</span>
    </a>
  ))}
</div>
```

This keeps the link list DRY — all labels live in dictionaries, and adding a new link only touches the array + 3 locale files.
```json
"notif.unreadCount": "{unread} unread",
"notif.timeAgo.min": "{m}min"
```
Usage: `t("notif.unreadCount", { unread })` or `t("notif.timeAgo.min", { m })`

## Complete dashboard audit — every surface type to check

When auditing a SINGLE page for hardcoded strings, check EVERY one of these surface types.
A heading-only pass misses half the page:

| Surface type | Example (before → after) | Dictionary key |
|---|---|---|
| Breadcrumb / crumb text | "Workspace" → `t("home.crumb.workspace")` | `home.crumb.workspace` |
| Page heading | "Welcome to HR Bridge" → `t("home.hero.title")` | `home.hero.title` |
| Section headings | "Quick links" → `t("home.quickLinks")` | `home.quickLinks` |
| Action buttons (primary) | "Open AI Agent" → `t("home.openAiAgent")` | `home.openAiAgent` |
| Action buttons (secondary) | "View employees" → `t("home.viewEmployees")` | `home.viewEmployees` |
| Navigation link labels | "Manage employees →" → `t("home.manageEmployees")` | `home.manageEmployees` |
| Table column headers | `<th>Action</th>` → `<th>{t("home.table.action")}</th>` | `home.table.action` |
| Empty-state / zero-state | "No activity yet" → `t("home.noActivity")` | `home.noActivity` |
| Fallback default values | `log.action \|\| "sync"` → `log.action \|\| t("home.recent.sync")` | `home.recent.sync` |
| Interpolation / composition | `{n}/{m} sync jobs completed` → `t("home.syncCount", {success:n, total:m})` | `home.syncCount: "{success}/{total} sync jobs completed"` |
| Button aria-labels | `aria-label="Toggle theme"` → `aria-label={t("theme.toggle")}` | `theme.toggle` |
| Helper text / captions | `<span>navigate</span>` → `<span>{t("cmd.navigate")}</span>` | `cmd.navigate` |

**Order**: after fixing any surface type, re-read the page from the top — the next hardcoded string is usually 2-3 lines below the one you just fixed. Keep going until you reach EOF.

**Interpolation pattern**: `t()` in this codebase supports `{placeholder}` syntax.
Dictionary value: `"home.syncCount": "{success}/{total} sync jobs completed"`
Call: `t("home.syncCount", { success: String(n), total: String(m) })`
The second arg is `Record<string, string | number>` — Prefer explicit primitive values over complex formatting inline (e.g. pass `"3"` not `n.toLocaleString("ar-SA")` — keep formatting in the dict value).

## Dictionary keys must exist in all 3 locale files

Before writing code that calls `t("new.key")`, add the key to:
- `src/i18n/dictionaries/en.ts`
- `src/i18n/dictionaries/ar.ts`
- `src/i18n/dictionaries/fr.ts`

Use the existing naming convention: `component.section.thing`
(e.g., `crm.tab.active`, `notif.bell`, `pwa.title`).

**Pitfall**: Duplicate keys crash at runtime, not compile. Always grep first:
```bash
grep -n '"new.key"' src/i18n/dictionaries/*.ts
```

## Parallel subagent delegation pattern

For 15+ files, delegate in batches of ~3 subagents:
```
delegate_task(tasks=[
  { goal: "Fix Arabic in AuditClient, ChatClient, AIAgentSettingsClient", context: "..." },
  { goal: "Fix Arabic in CrmClient, DocumentsClient, RecruitmentClient", context: "..." },
  { goal: "Fix Arabic in reports/page.tsx, verify SettingsClient", context: "..." },
])
```

Add dictionary keys in the parent before dispatching so subagents can use them.
Each subagent runs `tsc --noEmit` + `npm run build` before reporting done.

## Verification ladder (do NOT skip)

```bash
# 1. TypeScript
npx tsc --noEmit            # must exit 0

# 2. Build
rm -rf .next && npm run build | tail -40  # must compile all pages

# 3. Zero Arabic sweep
grep -rl '[ا-ي]' src/app/dashboard/ src/components/ 2>/dev/null
# Must return empty (or only intentional metadata/comments)

# 4. Dev server restart (fresh .next — MUST kill + rm -rf, NOT hot-reload)
pkill -f "next dev -p 4000"; sleep 2; rm -rf .next
npx next dev -p 4000 -H 127.0.0.1 > /tmp/hrb-dev.log 2>&1 &

# 5. Browser verify all 3 locales
# Set cookie: document.cookie = "hrb_locale=ar;path=/"; location.href = "/dashboard"
# Verify key pages in AR, EN, FR
```

**🚨 Build poisons dev server** — after step 2 (`npm run build`), the `.next/`
directory contains production artifacts whose chunk IDs are incompatible with
`next dev`. Symptom: all API routes return 500 `MODULE_NOT_FOUND`. Do NOT skip
the `rm -rf .next` in step 4 — a `pkill` + hot-reload (no `rm -rf`) still sees
stale chunks. This step is mandatory every time `npm run build` was run.

## Browser locale switching for testing

```js
// Switch to Arabic (use location.href for server-rendered pages)
document.cookie = "hrb_locale=ar;path=/"; location.href = "/dashboard";
// Switch to English
document.cookie = "hrb_locale=en;path=/"; location.href = "/dashboard";
// Switch to French
document.cookie = "hrb_locale=fr;path=/"; location.href = "/dashboard";
```

`location.href` (not `location.reload()`) forces a server round-trip so `makeT(locale)` picks up the new cookie.

## Files requiring translation (checklist)

- [ ] ALL dashboard `page.tsx` files
- [ ] ALL `*Client.tsx` files under `src/app/dashboard/`
- [ ] `src/components/NotificationCenter.tsx`
- [ ] `src/components/InstallPrompt.tsx`
- [ ] `src/components/OfflineBadge.tsx`
- [ ] `src/components/PushPermissionPrompt.tsx`
- [ ] `src/components/LanguageSwitcher.tsx`
- [ ] Dictionary keys added to all 3 locale files
- [ ] `tsc --noEmit` passes
- [ ] `npm run build` passes
- [ ] Browser-verified in AR, EN, FR

## Pitfall: Only patching 2 of 3 dictionaries

When adding the same set of new keys to all 3 locale files (en/ar/fr), it's
easy to accidentally skip one file — the patches all succeed silently and
`tsc --noEmit` passes because dictionary keys are not type-checked.

**Symptom**: a different locale's text leaks into the unchecked locale.
Example: `nav.admin` was added to EN and AR but NOT to FR. The French
sidebar showed the Arabic word "المشرف" instead of "Admin" because the
missing key fell through to serving the first-found value (likely the
Arabic entry from the dict that exists).

**Detection**: browser-verify ALL 3 locales after any dictionary update.
`tsc` and `build` will NOT catch this. A `grep` for the new key across
all 3 dict files catches it pre-browser:

```bash
# After adding new keys, verify they exist in all 3 dicts
for KEY in nav.admin common.workspace webhooks.group.employee; do
  for DICT in en ar fr; do
    grep -q "\"$KEY\"" src/i18n/dictionaries/$DICT.ts || echo "MISSING: $KEY in $DICT"
  done
done
```

**Fix**: patch the missing dictionary file(s) and re-verify with browser.

## Detecting hardcoded English (not just Arabic)

The Arabic sweep (`grep -rl '[ا-ي]'`) catches AR leaks but a fully-i18n'd
dashboard must also zero out hardcoded English. Use a Python regex scan
over all .tsx files:

```python
# From execute_code — scans JSX text content between >...< for English
import re
matches = re.findall(r'>([^<>{]+)<', line)
# Flag any match with 2+ capitalized English words, no {t( interpolation
```

Common hiding places hard to grep:
- **JSX group labels**: `group: "Employee"` in webhook event catalogs
- **Title/tooltip attributes**: `title="API mode"` on status dots
- **Section headings**: `<div className="nav-section">Admin</div>`
- **Fallback defaults**: `{tenant?.name || "Workspace"}`
- **Subtitle text**: `<div>Web Push API</div>` under a translated heading

These pass a naive Arabic sweep because they're Latin, but they break the
non-English locales. The fix pattern is the same: add keys to all 3 dicts.

## Pitfall: CSS text-transform hides actual locale value

CSS rules like `text-transform: uppercase` or `text-transform: lowercase`
transform the rendered text independently of locale. "Admin" → "ADMIN",
"Menu" → "MENU", "المشرف" → "المشرف" (already right).

**Symptom**: you expect to see the dictionary value verbatim in the
browser snapshot ("Admin") but it appears as "ADMIN". This is NOT a bug
— it's CSS. Check the page's CSS for `text-transform` before assuming
the wrong key is being used.

**Verification**: look at the rendered text in the browser snapshot AND
at the dictionary entry. If they match modulo casing, CSS is to blame.

## Pitfall: Raw i18n keys in data objects rendered without `t()`

When label/description fields in data objects (PROVIDERS, TOOL_LABELS,
config maps, enum tables) are stored AS i18n key strings, they MUST be
wrapped in `t()` at render time. Missing this causes raw dot-delimited
keys to display as literal text instead of translated values.

**Example — AI Agent Settings page (broken):**

```tsx
// At module level — keys stored as strings
const PROVIDERS: Record<string, { label: string; description: string }> = {
  openai: { label: "ai_agent.provider.openai", description: "ai_agent.desc.openai" },
  ...
};

// In JSX — RENDERS "ai_agent.provider.openai" literally
<div>{v.label}</div>           // ❌ raw key, not translated
<div>{v.description}</div>     // ❌ raw key, not translated
```

**Fix — wrap every label/description in `t()`:**

```tsx
<div>{t(v.label)}</div>           // ✅ "OpenAI (ChatGPT)"
<div>{t(v.description)}</div>     // ✅ "The fastest, full tool calling support..."
```

**Pattern**: the same applies to tool lists, dropdown option arrays,
enum-label maps, and any other data-driven component where the display
label is an i18n key stored at module level. Always verify with a
browser snapshot — `tsc` and `build` WILL pass because the raw key
is a valid string.

## Pitfall: `.map()` closure parameter shadowing `t()` function

When `t` is the translation function destructured from `useT()`, using
`t` as a `.map()` callback parameter shadows it, causing `t(meta.label)`
to fail with `Type 'String' has no call signatures`.

**Example (broken):**

```tsx
const { t } = useT();
// ...
{cfg.allTools.map((t) => {       // ❌ SHADOWS outer t()
  const meta = TOOL_LABELS[t];
  return (
    <div>{t(meta.label)}</div>    // ❌ t is now the tool name string, not the function
  );
})}
```

**Fix — rename the callback parameter:**

```tsx
{cfg.allTools.map((tool) => {    // ✅ no shadowing
  const meta = TOOL_LABELS[tool];
  return (
    <div>{t(meta.label)}</div>    // ✅ t is the translation function
  );
})}
```

**Symptom**: TypeScript error `TS2349: This expression is not callable.
Type 'String' has no call signatures` at the `t(meta.label)` call site.

## Full-codebase hardcoded-English scan (beyond Arabic sweep)

The `grep -rl '[ا-ي]'` sweep catches Arabic leaks but not hardcoded
English. For a complete pass, use a Python regex scan across ALL .tsx
files that finds text between JSX tags matching English patterns:

```python
import re
from hermes_tools import search_files

# Finds 2+ capitalized English words between JSX tags
# Example matches: "Base URL", "Web Push API", "All Employees"
matches = search_files(
    pattern=r'>[A-Z][a-zA-Z]+ [A-Z][a-zA-Z]+[^<]*<',
    file_glob="*.tsx",
    output_mode="content"
)
# Filter out: already-t() calls, i18n key references, dynamic values
# Filter IN: standalone hardcoded English text in JSX children
```

Also scan for standalone single-word labels:
```python
# Buttons: Save, Cancel, Delete, Edit, Submit, Close, Reset, Apply
pattern=r'>(Save|Cancel|Delete|Edit|Submit|Close|Reset|Apply)<'
# Labels: Name, Email, Phone, Status, Role, Date, Title
pattern=r'>(Name|Email|Phone|Status|Role|Date|Title):?<'
```

**Scan targets (not just dashboard/):**
- `src/app/(auth)/` — login/register pages
- `src/app/offline/page.tsx` — offline fallback
- `src/components/` — shared UI (NotificationCenter, LanguageSwitcher, etc.)
- Dictionary files themselves (untranslated keys)

## Common pitfalls

1. **`timeAgo` type**: helper functions calling `t(key, vars)` need type
   `(key: string, vars?: Record<string, string | number>) => string`
2. **patch vs write_file**: prefer write_file for complete component
   rewrites — patch silently truncates when old_string contains escaped
   quotes (e.g. the directive string in "use client" or JSX attribute values
   like aria-label={t("notif.bell")}). The text before the first escaped
   quote is applied but everything after is dropped, mangling the file.
   When this happens, use write_file to replace the whole component at
   once — faster than debugging half-applied patches. Read the original
   with read_file, construct the full replacement, then write_file.
3. **`useT` destructuring**: always `const { t } = useT()`, not `const t = useT()`
4. **Cookie persistence**: client component `useT()` reads `document.cookie`.
   If the cookie from a prior browser session is `ar`, the component renders
   Arabic even when the page was navigated to in English. Clear cookies or
   restart browser if testing gets confusing.
5. **Notifications bell**: `aria-label` on `<button>` must use `t()` or it
   shows the wrong language. This is easy to miss because screen readers
   don't render visually.
