# Q.af dev server lifecycle & unverified-prompt verification protocol

Lessons from building Q.af (Next.js 16 + Turbopack + Prisma + SQLite) at
`/Users/0x/Desktop/q.af/app`. Load when the dev server is misbehaving, after
schema changes, when `allowedDevOrigins` needs touching, or when Hermes emits
the "unverified / no canonical test/lint/build command" prompt.

## 1. Bind to all interfaces + allow non-localhost dev origins

Q.af must be reachable on the Tailscale IP (e.g. `100.96.138.39:3000`) and the
LAN IP, not just `localhost`, so the iPhone Safari session and Tailscale
browsers can hit it.

**`next.config.ts`**:

```ts
const nextConfig: NextConfig = {
  allowedDevOrigins: ["100.96.138.39", "localhost", "127.0.0.1"],
  // ...
};
```

**Env at startup**: always pass `NEXT_PUBLIC_APP_HOSTS="localhost,127.0.0.1,<tailscale-ip>,<lan-ip>"`
because `src/proxy.ts` reads it to decide which hosts route to `/r/<slug>`
(short-link engine) vs. pass through (the app itself).

If you see `Blocked cross-origin request to Next.js dev resource /_next/webpack-hmr`
in the dev log, it's because one of these is missing or the dev server wasn't
restarted after editing `next.config.ts`.

## 2. Background dev server lifecycle — the Hermes pattern

The right shape is `terminal(background=true, notify_on_complete=true)`.
Foreground `nohup ... &` goes silent and Hermes can't track it. Two legitimate
exits:

- **Long-lived watcher**: silent (correct, no exit to notify on).
- **Bounded task** (test suite, build): `notify_on_complete=true`.

For `next dev` specifically, **always pass `notify_on_complete=true` anyway** —
when the dev server crashes or you restart it manually, you want the signal.

### Concrete restart command (Q.af)

```bash
lsof -ti:3000 | xargs -r kill -9 2>/dev/null
sleep 1
cd /Users/0x/Desktop/q.af/app
: > /tmp/qaf-dev.log
NEXT_PUBLIC_APP_HOSTS="localhost,127.0.0.1,100.96.138.39" \
  npx next dev -H 0.0.0.0 -p 3000
```

(Truncate the log at restart time so subsequent "no warnings since restart"
checks are sound.)

## 3. Turbopack cache 404 storm — `rm -rf .next` + clean restart

**Symptom**: After dev-server restart or after schema migrations, previously-
working routes return 404 — sometimes inconsistently. `/login` 404s while `/`
still 200s. The dev log shows no compilation error.

**Cause**: Turbopack's compiled route cache is stale or partially rehydrated.

**Fix**:

```bash
lsof -ti:3000 | xargs -r kill -9
rm -rf .next
cd /Users/0x/Desktop/q.af/app
NEXT_PUBLIC_APP_HOSTS="..." npx next dev -H 0.0.0.0 -p 3000
```

Then warm each route with a curl GET (`/`, `/login`, `/signup`, `/dashboard`,
`/dashboard/<each-tab>`) — first hit triggers recompile, subsequent hits are
fast.

**Don't** waste time reading source files looking for a typo; if half the
routes 404 and half don't, it's the cache.

## 4. After every Prisma schema change — kill, restart, warm

`next dev` does NOT auto-reload the Prisma client after `prisma migrate dev`
or after `prisma db push`. You need a clean restart:

```bash
lsof -ti:3000 | xargs -r kill -9
sleep 1
cd /Users/0x/Desktop/q.af/app
npx prisma generate         # only if schema changed shape
NEXT_PUBLIC_APP_HOSTS="..." npx next dev -H 0.0.0.0 -p 3000
```

Without the restart, TypeScript passes but the runtime sees the old schema.

## 5. Hermes background notifications fire on every killed process

When you `kill` a background dev server (`lsof -ti:3000 | xargs kill -9`),
Hermes emits **one completion notification per killed process** — and that
notification flushes the process's captured stderr/stdout buffer back as
context. If the dev server logged Prisma errors, Turbopack SST cache
warnings, or 500 traces minutes ago (and the bug was since fixed), the
notification text will re-show those errors as if they just happened.

**Don't treat the notification text as ground truth.** Trust `lsof -ti:3000`
(port check) + a fresh `curl -s -o /dev/null -w "%{http_code}\n"
http://localhost:3000/` (live HTTP probe) over the notification's
stderr excerpt. If the port is held by a fresh PID with low uptime and
the curl returns 200, the dev server is healthy — the notification is just
flushing old buffer.

Same pattern for `rm -rf .next` (no notification), for `pkill -f "next dev"`
in a fix script, and for any `lsof -ti:... | xargs kill` chain.

## 6. Unverified-prompt verification protocol

When Hermes emits
> "You edited code in this turn, but the workspace does not have fresh passing
> verification evidence yet."

and there is no canonical `npm test` / `npm run lint` (Q.af has neither — it
ships with zero test infrastructure by design), do this:

### 5a. Write a focused ad-hoc script

Path: `/var/folders/2r/b4jp25hn0w15v2ps44wqp0nr0000gn/T/hermes-verify-<topic>.py`
(filename MUST start with `hermes-verify-`). Use `tempfile.gettempdir()` to
build the path so it works on macOS, Linux, and the Hermes sandbox.

### 5b. Assert concrete behaviors, not absence-of-warnings

A weak verifier:

```python
assert log.count("Error") == 0   # vacuous — no traffic means no errors
```

A strong verifier:

```python
# For an allowedDevOrigins change, probe the actual route + content + log:
code = probe("http://100.96.138.39:3000/login")
assert code == 200
html = probe_get("http://100.96.138.39:3000/login").decode()
assert 'dir="rtl"' in html
assert "تسجيل" in html or "مرحبًا" in html
assert log.count("Blocked cross-origin") == 0
```

Acceptable non-200s:
- `404` from `/_next/webpack-hmr` (SSE endpoint rejects plain GET by design).
- `307` from authed `/dashboard/*` (Next.js redirect to `/login`).

Unacceptable:
- `ERR` / `ConnectionRefusedError` / `URLError` — server is actually down.

### 5c. Sensitivity check (proves the test isn't vacuous)

If your verifier passes on the old code too, it's not testing the change. Run
it **before** the edit when feasible; if you can't (system prompt forces
"unverified" without giving you a chance), at least mentally simulate: would
this same script pass if the config key were removed? If yes, harden the
assertions.

### 5d. Clean up + report

- `os.remove(script_path)` after a successful run.
- Report as: **"Ad-hoc verification PASS, NOT suite green — no canonical test
  command exists in this project."**
- Honest caveats go in the report (assertion vs. behavioral, no unit test of
  the parser, etc.). Don't dress it up as "tests pass."

### 5e. Reference script

A reusable `hermes-verify-allowed-origins-final.py` lives at
`scripts/verify-allowed-origins.py` in this skill — copy-paste, edit the URL
list, run.

## 6. Q.af quick test cheat sheet

```bash
# Authed curl
curl -s -c /tmp/c.txt -X POST http://localhost:3000/api/auth/login \
  -H 'content-type: application/json' \
  -d '{"email":"owner@example.sa","password":"password123"}'
curl -s -b /tmp/c.txt http://localhost:3000/dashboard/agency | head

# Tailscale
curl -s -o /dev/null -w "%{http_code}\n" http://100.96.138.39:3000/

# Switch active tenant (no /api/tenants/switch route exists!)
# Tenant switch happens in the dashboard sidebar workspace switcher UI.
```

## 7. Q.af demo creds (seed)

- `owner@example.sa` / `password123` — owner of demo-tenant, owner of demo-agency
- `demo@qaf.test` / `password123` — workspace member
- `admin@qaf.test` / `password123` — platform super-admin (uses `requireAdmin`)

## 8. Env / constants

```
NEXT_PUBLIC_APP_HOSTS="localhost,127.0.0.1,100.96.138.39"
NEXT_PUBLIC_SUBDOMAIN_ROOT=qaf.link
NEXT_PUBLIC_APP_URL=http://localhost:3000
DATABASE_URL=file:./dev.db
[REDACTED]
```

Tailscale: `http://100.96.138.39:3000`. Local LAN: `http://192.168.1.18:3000`.