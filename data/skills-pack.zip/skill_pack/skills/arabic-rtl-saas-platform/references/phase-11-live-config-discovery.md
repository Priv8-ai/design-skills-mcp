# Phase 11 — Live Config Discovery (Dynamic Provider UI)

**When**: SaaS UI lets users pick from many providers AND each provider has dynamic configuration that can't be hardcoded (model lists, region availability, custom endpoints, etc.). Common cases: AI model providers (Ollama, OpenRouter, LM Studio), cloud regions, payment gateways.

**Pattern**: API endpoint returns live data + client component fetches on provider change + smart fallback to static presets.

## Server API (returns live data)

```ts
// src/app/api/ai/ollama-list/route.ts
import { NextRequest, NextResponse } from "next/server";
import { getSession } from "@/lib/session";
import { exec } from "child_process";
import { promisify } from "util";

const execAsync = promisify(exec);

async function listFromCli(): Promise<string[] | null> {
  try {
    const { stdout } = await execAsync("ollama list 2>/dev/null", { timeout: 4000 });
    return stdout.split("\n").filter((l) => l.trim() && !l.startsWith("NAME"))
      .map((l) => l.trim().split(/\s+/)[0]).filter(Boolean);
  } catch { return null; }
}

async function listFromHttp(baseUrl: string): Promise<string[]> {
  try {
    const r = await fetch(`${baseUrl.replace(/\/$/, "")}/api/tags`,
      { signal: AbortSignal.timeout(4000) });
    if (!r.ok) return [];
    const data: any = await r.json();
    return (data.models || []).map((m: any) => m.name).filter(Boolean);
  } catch { return []; }
}

export async function GET(req: NextRequest) {
  const s = await getSession();
  if (!s?.tenantId) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const baseUrl = new URL(req.url).searchParams.get("baseUrl") || "http://localhost:11434";
  let models = await listFromCli();
  let source: "cli" | "http" | "none" = models ? "cli" : "http";
  if (!models || models.length === 0) {
    models = await listFromHttp(baseUrl);
    if (models.length === 0) source = "none";
  }
  return NextResponse.json({ models, count: models.length, source, baseUrl, timestamp: new Date().toISOString() });
}
```

**Design note**: Try CLI first (faster, includes tags), then HTTP fallback. Return `source` field so UI can show which path worked.

## Client component (3 features in one)

```tsx
// src/app/dashboard/settings/<resource>/<Resource>Client.tsx
import { useState, useEffect } from "react";

export default function ResourceClient({ initialConfig }: { initialConfig: Config }) {
  const [cfg, setCfg] = useState<Config>(initialConfig);
  const [apiKey, setApiKey] = useState("");

  // Feature 1: live discovery state
  const [liveModels, setLiveModels] = useState<string[] | null>(null);
  const [liveSource, setLiveSource] = useState<"cli"|"http"|"none"|null>(null);
  const [liveLoading, setLiveLoading] = useState(false);
  const [liveLastFetch, setLiveLastFetch] = useState<string|null>(null);

  // Feature 2: fetch function
  async function fetchLiveModels() {
    setLiveLoading(true);
    try {
      const url = `/api/<resource>/<endpoint>?baseUrl=${encodeURIComponent(cfg.baseUrl || "")}`;
      const res = await fetch(url);
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const data = await res.json();
      setLiveModels(data.models || []);
      setLiveSource(data.source);
      setLiveLastFetch(new Date().toLocaleTimeString());
    } catch (e: any) {
      setLiveModels([]);
      setLiveSource("none");
    }
    setLiveLoading(false);
  }

  // Feature 3: auto-fetch on provider change
  useEffect(() => {
    if (cfg.provider === "live-provider" && liveModels === null && !liveLoading) {
      fetchLiveModels();
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [cfg.provider, cfg.baseUrl]);

  // Smart options: live > static
  const options = cfg.provider === "live-provider" && liveModels && liveModels.length > 0
    ? liveModels : STATIC_PRESETS[cfg.provider]?.models || [];

  return (
    <label>
      <span className="flex justify-between">
        <span>الموديل</span>
        {cfg.provider === "live-provider" && (
          <button type="button" onClick={fetchLiveModels} disabled={liveLoading}>
            {liveLoading ? "⏳ جاري الجلب..." : "🔄 جلب النماذج"}
          </button>
        )}
      </span>
      <select value={cfg.model} onChange={(e) => setCfg({...cfg, model: e.target.value})}>
        {options.map((m) => <option key={m} value={m}>{m}</option>)}
      </select>
      {cfg.provider === "live-provider" && liveSource && (
        <span className="text-[10px] text-slate-500 mt-1">
          {liveSource === "cli" && "✓ تم الجلب عبر CLI"}
          {liveSource === "http" && "✓ تم الجلب عبر HTTP"}
          {liveSource === "none" && "⚠️ غير متاح — تحقق من الخدمة"}
          {liveLastFetch && ` · ${liveLastFetch}`}
        </span>
      )}
    </label>
  );
}
```

## E2E verification

```python
import urllib.request, json, http.cookiejar
# login
opener.open(urllib.request.Request(f"{BASE}/api/auth/login", ...)).read()
# 1. Endpoint works
data = json.loads(opener.open(f"{BASE}/api/<resource>/<endpoint>").read())
assert "models" in data and "source" in data
# 2. Bundle has new strings (proves client compiled the new UI)
p = opener.open(f"{BASE}/dashboard/settings/<resource>").read().decode()
assert "جلب" in p  # button text in SSR or in client bundle chunk
# 3. If auth-gated, test unauthorized path
r = urllib.request.urlopen(urllib.request.Request(f"{BASE}/api/<resource>/<endpoint>"))
# ^ should NOT succeed without cookie
```

## Pitfalls
- **Forgetting `useEffect` dependency warning suppression**: include `// eslint-disable-next-line react-hooks/exhaustive-deps` because `fetchLiveModels` is recreated each render.
- **Don't `await fetchLiveModels()` in useEffect** — it needs to be fire-and-forget; awaiting causes cascading re-renders.
- **Don't reset `liveModels` on `cfg.provider` change** — only re-fetch. Preserving old list while fetching prevents UI flicker.
- **Source field is critical**: without it users can't tell if their model list came from CLI (probably local dev) or HTTP (might be cached/stale).
