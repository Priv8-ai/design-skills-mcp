# Add Employee modal debugging

## Problem
The "Add Employee" modal form fills correctly but clicking the submit button does nothing — no error, no network request, no console output.

## Diagnosis steps
1. Check browser console for errors: `browser_console` with `window.__errors__` — none found
2. Check React handler binding: `browser_console` querying `button.closest('form').onsubmit` — returns false because React uses synthetic events, not DOM `onsubmit`
3. Try `requestSubmit()` via console — no effect because the form reference wasn't found in DOM
4. Test API directly with `curl` — works perfectly, proving the backend is fine

## Root cause
The browser automation tool's native click event doesn't trigger React's synthetic `onSubmit` event. This is a browser automation limitation, not a code bug.

## The actual code fix (for robustness)
Even though the bug was in automation, the code was improved for production robustness:

```tsx
async function handleSubmit(e: React.FormEvent) {
  e.preventDefault();
  e.stopPropagation();
  setBusy(true);
  setErr(null);
  try {
    // manual validation before fetch
    if (!form.fullNameAr.trim()) {
      throw new Error("الاسم (عربي) مطلوب");
    }
    const payload = {
      ...form,
      basicSalary: Number(form.basicSalary) || 0,
      housingAllowance: Number(form.housingAllowance) || 0,
      transportAllowance: Number(form.transportAllowance) || 0,
    };
    const r = await fetch("/api/employees", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
    if (!r.ok) {
      const d = await r.json().catch(() => ({}));
      throw new Error(d.error ?? "فشل الحفظ");
    }
    setOpen(false);
    router.refresh();
  } catch (err: any) {
    console.error("AddEmployee submit error:", err);
    setErr(err.message ?? "فشل");
  } finally {
    setBusy(false);
  }
}
```

Key improvements:
- `e.stopPropagation()` prevents event bubbling issues
- Manual validation catches errors before network call
- `Number()` coercion prevents string values from reaching API
- `try/catch` with error display prevents silent failures
- `console.error` for debugging in production

## Verification
Always test via API when browser automation fails:
```bash
# Get session first
curl -s -X POST http://localhost:4000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"USER","password":"PASS"}' \
  -c /tmp/session.txt

# Test the endpoint
curl -s -X POST http://localhost:4000/api/employees \
  -H "Content-Type: application/json" \
  -b /tmp/session.txt \
  -d '{...}'
```
