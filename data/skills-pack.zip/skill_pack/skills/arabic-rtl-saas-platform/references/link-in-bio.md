# Link-in-bio / bio pages (Q.af Phase 5 reference)

Full recipe for shipping a `linktr.ee`-style bio / link-in-bio feature that reuses
the Phase 1 multi-tenant model and the Phase 4 analytics classifier pipeline.
Built and verified on Q.af.

## Why a dedicated phase

URL shorteners get compared against link-in-bio products daily. Once users can
track clicks per short link, the natural next question is "can I put all my
socials on one page?" The data model is the same shape (Tenant owns Links),
just rendered publicly instead of via a 302 redirect. Reuse everything possible
— the schema, the analytics classifier, the geo cascade, the demo seed
infrastructure — so this phase ships in a single sitting.

## 1. Data model — three new tables

```prisma
model BioPage {
  id          String   @id @default(cuid())
  tenantId    String
  slug        String   @unique             // global-unique, not per-tenant
  title       String                       // heading + display name
  description String?                      // bio / tagline, max 280
  avatar      String?                      // URL, max 500
  theme       String   @default("emerald") // emerald | midnight | sand | rose
  active      Boolean  @default(true)
  createdAt   DateTime @default(now())
  updatedAt   DateTime @updatedAt

  links  BioLink[]
  tenant Tenant    @relation(fields: [tenantId], references: [id], onDelete: Cascade)

  @@index([tenantId])
}

model BioLink {
  id        String   @id @default(cuid())
  bioPageId String
  label     String                          // max 60
  url       String                          // max 500
  icon      String?                         // "twitter" | "instagram" | "github" | …
  order     Int      @default(0)
  clicks    Int      @default(0)
  active    Boolean  @default(true)
  createdAt DateTime @default(now())

  bioPage BioPage          @relation(fields: [bioPageId], references: [id], onDelete: Cascade)
  events  BioClickEvent[]

  @@index([bioPageId])
}

model BioClickEvent {
  id        String   @id @default(cuid())
  bioLinkId String
  ts        DateTime @default(now())
  country   String?
  device    String?
  referrer  String?
  userAgent String?

  bioLink BioLink @relation(fields: [bioLinkId], references: [id], onDelete: Cascade)

  @@index([bioLinkId])
}
```

Migration: `npx prisma migrate dev --name bio_pages`. Add `bioPages BioPage[]`
to `Tenant`. Regenerate the client before any TypeScript work.

### Why a separate `BioClickEvent` and not a polymorphic `ClickEvent`
Two reasons that turned into real bugs:
1. `ClickEvent.linkId` is non-null FK to `Link`. Bio links don't have a `Link`
   row — adding `kind: "short" | "bio"` + a nullable FK breaks the redirect
   path's query plans.
2. Keeping bio analytics separate lets the bio dashboard query its own table
   without the workspace-wide overview ballooning into a UNION ALL.

Cost is one extra table; benefit is clean analytics per surface.

## 2. Endpoints — four, not one

### `/api/bio` — list + create
- `GET` (auth) → tenant's pages with nested links ordered asc.
- `POST` (auth) → creates a page with optional inline initial links.

Slug normalisation (must do this server-side, don't trust the client):
```ts
function normaliseSlug(raw: string): string {
  return raw
    .trim()
    .toLowerCase()
    .replace(/[\u064B-\u0652\u0670\u0640]/g, "")  // strip Arabic diacritics + tatweel
    .replace(/[^\p{L}\p{N}-]+/gu, "-")
    .replace(/-+/g, "-")
    .replace(/^-|-$/g, "")
    .slice(0, 40);
}
```

Reserved-slug set (collision with your own routes is the failure mode that hits
in production, not in dev):
```ts
const RESERVED = new Set([
  "admin", "api", "dashboard", "login", "logout", "signup",
  "r", "bio", "_next", "favicon.ico", "static", "public",
  "settings", "billing", "support", "help", "terms", "privacy",
]);
```

On collision (rare but happens), append a random suffix:
```ts
for (let i = 0; i < 5; i++) {
  const existing = await prisma.bioPage.findUnique({ where: { slug } });
  if (!existing) break;
  slug = `${slug}-${Math.random().toString(36).slice(2, 6)}`;
}
```

Theme is a closed enum; reject anything else rather than storing it.
Max 12 links per page on creation (matches the editor cap).

### `/api/bio/[id]` — PATCH (update metadata) + DELETE
Ownership check on every write — `findFirst({ where: { id, tenantId } })`, not
`findUnique({ where: { id } })`. The latter is a privilege-escalation footgun
(any tenant can patch any bio page if you forget the `tenantId` filter).

DELETE cascades through `BioLink` and `BioClickEvent` automatically because of
the `onDelete: Cascade` on the relations. Verify with `prisma migrate` that the
FK actions are actually generated; a missing `@relation(onDelete: Cascade)` is
silent until a delete fails with an FK error in prod.

### `/api/bio/[id]/links` — POST / PATCH (reorder) / DELETE
Three gotchas here, all hit on Q.af:
1. **URL scheme allowlist**: `http(s)`, `mailto:`, `tel:`. Reject everything
   else with `400 url_invalid` — prevents `javascript:`-prefixed XSS in the
   public page even if the React render path forgets `rel="noopener"`.
2. **Cap at 12 links per page** — enforce server-side. The editor already
   caps but never trust the client.
3. **Ownership-set precheck before bulk reorder**: the `PATCH` body is an
   array of `{id, order}` updates. Resolve the owned set FIRST and filter
   the updates to that set, then `prisma.$transaction` the writes. Without the
   precheck, a malicious client can reorder (and effectively "claim") links
   belonging to another page:
   ```ts
   const owned = await prisma.bioLink.findMany({
     where: { id: { in: ids }, bioPageId: page.id },
     select: { id: true },
   });
   const ownedSet = new Set(owned.map(l => l.id));
   const safe = updates.filter(u => ownedSet.has(u.id));
   await prisma.$transaction(safe.map(u =>
     prisma.bioLink.update({ where: { id: u.id }, data: { order: u.order } })
   ));
   ```

### `/api/bio/click/[linkId]` — public redirect with click tracking
Reuses `classifyDevice` / `countryFromHeaders` / `referrerHost` from
`lib/analytics.ts` — zero new code, zero new lib helpers. Fire-and-forget the
event insert in parallel with the redirect:
```ts
await Promise.allSettled([
  prisma.bioClickEvent.create({ data: { … device, country, referrer, userAgent } }),
  prisma.bioLink.update({ where: { id: link.id }, data: { clicks: { increment: 1 } } }),
]);
return NextResponse.redirect(link.url, 302);
```
`Promise.allSettled` rather than `Promise.all` — a DB write failure must NOT
block the redirect. The user clicked; take them where they want to go, log the
event best-effort.

## 3. Public page — `/bio/[slug]/page.tsx`

No auth. Mobile-first. The page reads from Prisma directly in a server
component (fast first paint, no JS required for the visible content). Layout:

```
[avatar 96×96 rounded-full]
[title h1 24px bold]
[description muted]
[link cards, full-width, 12px gap, 14px padding, 16px radius]
[footer: "صنع بـ Q.af"]
```

Themes via CSS variables on a wrapper class:
```css
.theme-emerald { --bg: #0a0f0d; --fg: #e5e7eb; --accent: #10b981; --card: #11171f; }
.theme-midnight { --bg: #0a0a14; --fg: #e5e7eb; --accent: #818cf8; --card: #14142b; }
.theme-sand     { --bg: #fdf6e3; --fg: #1c1c1c; --accent: #b45309; --card: #fffbef; }
.theme-rose     { --bg: #1a0a0f; --fg: #fce7f3; --accent: #f43f5e; --card: #2a0e1a; }
```
Apply via `<main className={`bio theme-${page.theme}`}>`. One CSS file, four
themes, no runtime branching in the page component.

Each link card wraps an `<a href="/api/bio/click/<id>" rel="noopener">` so
the click flows through the tracking endpoint. Add `target="_blank"` if you
want a new tab.

Icons: a small set of inline SVG paths keyed by the `icon` field
(`twitter | instagram | github | youtube | tiktok | mail | whatsapp | link`).
Don't pull in an icon library for 8 icons — `<svg>` markup is 1 KB per icon
and renders instantly.

## 4. Editor — `/dashboard/bio`

List view at `/dashboard/bio`: one card per page, showing avatar + title +
slug + active toggle + click total + edit / delete buttons. Use the same
`SidebarLayout` as the rest of the dashboard for nav consistency.

Edit view at `/dashboard/bio/[id]`: a single form with
- Title, description (textarea), avatar URL, theme radio buttons.
- Active toggle (saves immediately on change with `PATCH /api/bio/[id]`).
- Links section: ordered list, drag to reorder, add / delete buttons, click
  into a row to edit label / url / icon.

Reorder UX: use HTML5 drag-and-drop (`onDragStart` / `onDragOver` /
`onDrop` on each row). No library needed — it's 30 lines of React for
the basic up/down case, and the server endpoint already accepts arbitrary
`order` values. Pessimistic UI is fine here; the dataset is small (max
12 links per page) so the network round trip is imperceptible.

Optimistic UI on add/delete: send the request, update local state, revert
on error. The endpoint returns the new row / an `ok: true` — no special
plumbing needed.

## 5. Demo seed extension — `scripts/seed-bio.ts`

Build on `scripts/seed-analytics.ts`: reuse the "Demo Workspace" tenant +
the `findFirst / create-if-missing` pattern so running both seeds in
sequence is safe. Add:

```ts
// Idempotent: delete the existing demo bio page first.
await prisma.bioPage.deleteMany({ where: { slug: "تجار-الرياض" } });

const page = await prisma.bioPage.create({
  data: {
    tenantId: tenant.id,
    slug: "تجار-الرياض",
    title: "متجر الرياض",
    description: "أفضل العروض الحصرية في الرياض 🇸🇦",
    avatar: "https://i.pravatar.cc/200?img=12",
    theme: "midnight",
    links: {
      create: [
        { label: "حسابي على تويتر",  url: "https://twitter.com/example",  icon: "twitter",   order: 0 },
        { label: "إنستغرام",           url: "https://instagram.com/example", icon: "instagram", order: 1 },
        { label: "تواصل عبر واتساب",  url: "https://wa.me/966500000000",  icon: "whatsapp",  order: 2 },
        { label: "زيارة المتجر",       url: "https://shop.example.com",    icon: "link",      order: 3 },
        { label: "مدونتي",              url: "https://blog.example.com",     icon: "link",      order: 4 },
        { label: "راسلنا",              url: "mailto:hi@example.com",        icon: "mail",      order: 5 },
      ],
    },
  },
});

// Seed ~80 bio clicks over 7 days for top links (mobile-heavy, Saudi geo).
const clicks = page.links.map((l, i) => ({ linkId: l.id, weight: 12 - i }));
const events = [];
for (let d = 0; d < 7; d++) {
  for (const { linkId, weight } of clicks) {
    for (let n = 0; n < weight; n++) {
      events.push({
        id: randomUUID(),
        bioLinkId: linkId,
        ts: new Date(Date.now() - d * 86400_000 - Math.random() * 86400_000),
        device: pickWeighted([["mobile", 6], ["desktop", 3], ["tablet", 1]]),
        country: pickWeighted([["SA", 7], ["AE", 2], ["EG", 1]]),
        referrer: pickWeighted([["https://twitter.com", 3], ["https://instagram.com", 2], [null, 5]]),
      });
    }
  }
}
await prisma.bioClickEvent.createMany({ data: events });
console.log(`seeded ${events.length} bio clicks for ${page.slug}`);
```

## 6. E2E extension block to append to `scripts/e2e-analytics.sh`

```bash
# --- 8. Bio page CRUD + public render + click redirect ---
BIO_SLUG="e2e-bio-$(date +%s)"
BIO=$(curl -s -b "$COOKIES" -H "Content-Type: application/json" \
  -X POST "$BASE/api/bio" \
  -d "{\"slug\":\"$BIO_SLUG\",\"title\":\"تجريبي\",\"description\":\"صفحة اختبار\",\"theme\":\"emerald\",\"links\":[{\"label\":\"متجر\",\"url\":\"https://shop.example.com\",\"icon\":\"link\"}]}")
echo "$BIO" | grep -q "\"slug\":\"$BIO_SLUG\"" || fail "bio create missing slug"
BIO_ID=$(echo "$BIO" | python3 -c "import json,sys;print(json.load(sys.stdin)['page']['id'])")
LINK_ID=$(echo "$BIO" | python3 -c "import json,sys;print(json.load(sys.stdin)['page']['links'][0]['id'])")
ok "bio page created"

# Public page renders with the title in SSR HTML (no auth needed).
PUBLIC=$(curl -s "$BASE/bio/$BIO_SLUG")
echo "$PUBLIC" | grep -q "تجريبي"   || fail "public bio missing title"
echo "$PUBLIC" | grep -q "متجر"     || fail "public bio missing link label"
ok "public bio page renders"

# Click through the redirect and confirm an event was recorded.
curl -s -o /dev/null -w "%{http_code} -> %{redirect_url}\n" \
  -H "User-Agent: Mozilla/5.0 (iPhone; CPU iPhone OS 17_1)" \
  -H "Referer: https://twitter.com/post/123" \
  -H "X-Qaf-Geo: SA" \
  "$BASE/api/bio/click/$LINK_ID"
EVENT=$(npx tsx -e "import { PrismaClient } from '@prisma/client';const p=new PrismaClient();(async()=>{const e=await p.bioClickEvent.findFirst({where:{bioLinkId:'$LINK_ID'},orderBy:{ts:'desc'}});process.stdout.write(JSON.stringify({device:e?.device,country:e?.country,ref:e?.referrer}));await p.\$disconnect();})();" 2>/dev/null)
echo "$EVENT" | grep -q '"device":"mobile"' || fail "bio click missing device"
echo "$EVENT" | grep -q '"country":"SA"'   || fail "bio click missing country"
ok "bio click event recorded"

# Cleanup: delete the test bio page.
curl -s -b "$COOKIES" -X DELETE "$BASE/api/bio/$BIO_ID" > /dev/null
ok "bio page deleted"
```

Run order: signup → analytics seed → bio seed → e2e. Don't interleave.

## 7. Verification ladder (don't claim Phase 5 done without these)

1. `npx tsc --noEmit` clean.
2. `npx tsx scripts/seed-bio.ts` prints `seeded N bio clicks…`.
3. Public page renders: `curl http://localhost:3000/bio/تجار-الرياض | grep "متجر الرياض"` → match.
4. Click tracks: `curl -o /dev/null -w "%{http_code}" http://localhost:3000/api/bio/click/<id>` → 302 to destination.
5. Latest `bioClickEvent` row for that link has non-null `device` and `country` matching the request headers.
6. Editor renders for the demo tenant (auth-gated): `curl -b cookies.txt http://localhost:3000/dashboard/bio | grep "تجار-الرياض"` → match (title appears in SSR HTML — see pitfall #12 in the main skill).
7. Reorder works: PATCH the links array with new orders, GET the page, assert the order is reflected.
8. Slug collision is handled: POST two pages with the same requested slug, both succeed with distinct final slugs.

## 8. Common extension points

- **Custom domain for bio pages** — let users bring `links.theirbrand.com` and serve bio pages from it. Reuse the Phase 3 DNS-verification + on-demand-TLS infrastructure: add a `bioSlug` column to `Domain` (or a `Domain.kind` enum), the public `/bio/[slug]` route checks if the request host matches a verified custom domain and serves that page instead of looking up by path slug.
- **Email capture / lead form** — add `BioLink.kind = "link" | "email_capture"` and a `BioLead` table. The editor renders an inline form; the click endpoint persists an email + records a `BioClickEvent` with `kind: "lead"`. Native email marketing is a $50/mo SaaS lock-in for customers you could own.
- **Schedule / expiry** — `BioLink.startsAt` / `endsAt` columns; the public page filters out of window links. Useful for time-limited promo links (Ramadan offer, Eid discount).
- **OG image generation** — render a 1200×630 OG card per bio page at `/api/bio/[id]/og.png`. Pure-Node SVG → PNG via `resvg-js` (~5 MB binary, but 100% on-prem and one-shot per share).
- **ClickHouse for bio events** — same as Phase 4's extension note. Bio events are higher-volume per tenant (one click per visitor per visit) and ClickHouse handles this naturally.