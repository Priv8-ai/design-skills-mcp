# Per-tenant encrypted credentials — encrypt-on-save + decrypt-on-read parity

**Date discovered:** 2026-06-28 (audit during ai-5-enh)
**Project:** HR Bridge SA (Next.js 15 + Prisma + AES-256-GCM at-rest crypto)
**Status:** Bug identified in AgentConfig, fix not yet shipped. Documented for next session.

## The class of bug

ANY multi-tenant SaaS that stores per-tenant secrets (AI provider API keys, government integration credentials, OAuth tokens) MUST apply `encrypt()` at the write boundary and `decrypt()` at the read boundary. Skipping either side silently breaks the feature without crashing:

| Side | What happens if skipped |
|------|------------------------|
| `encrypt()` on save | Credentials sit in the DB in plaintext. A `sqlite3 dev.db` read exposes them. `console.log(cfg)` in tests leaks them. Compliance audit fails. |
| `decrypt()` on read | The first runtime call to use the credential passes a `v1:...` ciphertext to the upstream API. Returns 401/403 with no useful error. Hours of debugging "is the key invalid?" |
| Only one of the two | Either credential sits plaintext OR chat breaks. There is no test that catches both directions at once. |

## Concrete bug found in this session

In HR Bridge SA, `Integration` credentials (`clientId`, `clientSecret`, `apiKey`, `apiSecret`, `cookiesJson`) follow the contract correctly:

```ts
// src/app/api/integrations/route.ts — write side
if (!existing || !String(existing.apiKey ?? "").startsWith("v1:")) {
  normalized = encrypt(normalized);
}
await prisma.integration.create({ data: { ...body, apiKey: body.apiKey } });

// read side
return NextResponse.json({
  apiKeyMasked: mask(i.apiKey),  // shows "🔒 encrypted" instead of value
  clientSecretMasked: mask(i.clientSecret),
});
```

BUT `AgentConfig` (AI provider key) does NOT:

```ts
// src/app/api/ai/config/route.ts — write side (BUG)
if (body.apiKey !== undefined) {
  if (body.apiKey === "" || body.apiKey === null) {
    data.apiKey = null;
  } else {
    data.apiKey = body.apiKey;  // ❌ PLAINTEXT — should be encrypt(body.apiKey)
  }
}

// src/app/api/ai/chat/route.ts — read side (also needs fix after encryption)
const cfg = {
  apiKey: cfg.apiKey  // ❌ If we encrypt at rest, this is now ciphertext
};
// chat() then calls OpenAI/Anthropic with `v1:iv:tag:ct` as the bearer → 401
```

## The fix (3 changes, ~10 lines)

### 1. Write side — encrypt on save
```ts
// src/app/api/ai/config/route.ts
import { encrypt } from "@/lib/crypto";
// ...
if (body.apiKey !== undefined) {
  if (body.apiKey === "" || body.apiKey === null) {
    data.apiKey = null;
  } else if (body.apiKey.startsWith("v1:")) {
    data.apiKey = body.apiKey;  // already encrypted — preserve
  } else {
    data.apiKey = encrypt(body.apiKey);  // plaintext → ciphertext
  }
}
```

### 2. Read side — decrypt on read in the chat route
```ts
// src/app/api/ai/chat/route.ts
import { decrypt } from "@/lib/crypto";
// ...
const cfg = {
  ...config,
  apiKey: decrypt(config.apiKey),  // ciphertext → plaintext before passing to upstream
};
```

### 3. Add central helpers so the pair can never drift apart
```ts
// src/lib/crypto.ts — add
export function decryptApiKey(encrypted: string | null | undefined): string | null {
  const v = decrypt(encrypted);
  return v && v.startsWith("v1:") ? null : v;  // safety: never hand out raw ciphertext
}

export function encryptApiKey(plain: string | null | undefined): string | null {
  if (!plain) return null;
  if (plain.startsWith("v1:")) return plain;  // idempotent
  return encrypt(plain);
}
```

Use these two helpers EVERYWHERE instead of calling `encrypt()` / `decrypt()` directly. That makes the pair visible at every call site:

```bash
# Audit grep pattern — these two functions should appear together at each boundary
grep -rn "encryptApiKey\|decryptApiKey" src/app/api/
```

## Companion trap — when the dev session_password IS the encryption key

`src/lib/crypto.ts` derives the AES key from `INTEG_ENCRYPTION_KEY` or `SESSION_PASSWORD`:
```ts
function getKey(): Buffer {
  const env = process.env.INTEG_ENCRYPTION_KEY || process.env.SESSION_PASSWORD || "dev-only-key-do-not-use-in-production-32b";
  return crypto.createHash("sha256").update(env).digest();
}
```

This means **rotating `SESSION_PASSWORD` invalidates ALL existing encrypted credentials**. If you rotate the session secret in prod without migrating first, every tenant's API key becomes undecryptable → chat breaks silently. Three ways to handle:

1. **Production**: set `INTEG_ENCRYPTION_KEY` to a SEPARATE 32-byte hex value, independent of `SESSION_PASSWORD`. Then rotating one doesn't break the other.
2. **Migration**: write a one-shot script that reads `cfg.apiKey` (decrypts with OLD key), re-encrypts with NEW key, writes back.
3. **Dev only**: accept that `dev.db` credentials are tied to the current `.env`. Document it.

## Verification — the 4-check rule

After encrypt/decrypt parity is in place, verify ALL FOUR:

```bash
# 1. Save side encrypts (raw DB row should start with "v1:")
sqlite3 prisma/dev.db "SELECT apiKey FROM AgentConfig LIMIT 1;" | head -c 20
# Expected: v1:abc123...:...

# 2. Read side returns masked UI value (not the real key)
curl -s -b "hrb_locale=en; hrbridge_session=$SESS" \
  http://localhost:4000/api/ai/config | jq .apiKeyMasked
# Expected: true (or "🔒 encrypted")

# 3. Runtime decrypt works (chat succeeds)
curl -s -b "..." -H 'Content-Type: application/json' \
  -d '{"messages":[{"role":"user","content":"hi"}]}' \
  http://localhost:4000/api/ai/chat | jq .reply
# Expected: a string reply (NOT a 401 from upstream)

# 4. Idempotency: re-saving the same key doesn't double-encrypt
# Send apiKey="v1:abc..." (already encrypted), confirm DB row unchanged
```

## Why this is class-level

This pattern recurs for:
- AI provider keys (OpenAI, Anthropic, OpenRouter, etc.)
- Government integration creds (Qiwa, Muqeem, GOSI, Mudad, Nafath, Absher)
- SMTP passwords (transactional email)
- Webhook signing secrets
- OAuth client secrets

Every one of these needs the SAME 3-line fix (encrypt-on-save, decrypt-on-read, central helper). Skip the audit at your peril — HR Bridge SA had Integration ✓ and AgentConfig ✗ in the same codebase.

## Related pitfalls
- Phase 11.1 — Prisma `file:` path (references/phase-11-prisma-db-path.md)
- Phase 11.5 — Server-side `t()` API contract (references/phase-11-server-side-translation.md)