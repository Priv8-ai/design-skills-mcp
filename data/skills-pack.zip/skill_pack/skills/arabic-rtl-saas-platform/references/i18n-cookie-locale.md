# i18n (ar/en/fr) for Arabic-first Next.js SaaS — cookie-locale pattern

Captured 2026-06-28 from HR Bridge SA Phase 10. Adds trilingual
support (Arabic default + English + French) to an existing
Next.js 15 App Router project without adding any i18n dependencies
(`next-intl`, `react-i18next`, etc.) — flat dictionaries + a tiny
`t()` helper, server-side locale resolution from cookie →
Accept-Language → default, edge middleware that ONLY sets the
cookie (does NOT rewrite URLs).

The pattern works for any RTL-default SaaS that already has routes
(`/login`, `/register`, `/dashboard/*`) and wants to layer
translation on top without breaking the existing route structure.

---

## Why URL-prefixed locales (`/ar/...`, `/en/...`) failed first

First attempt: rewrite `/login` → `/ar/login` in edge middleware.
Result: every route 404'd because `app/ar/login/page.tsx` doesn't
exist (and shouldn't — adding `[locale]` segments to every existing
route is a massive refactor).

**Decision: cookie-only locale.** The URL stays as `/login`; the
locale is read from a cookie set by middleware + the language
switcher. SSR sees the cookie via `cookies()` and renders the right
language on first paint. No `[locale]` segment needed.

---

## File layout (zero deps)

```
src/i18n/
  index.ts          # LOCALES, DEFAULT_LOCALE, LOCALE_META, isLocale, dirFor, makeT, t
  server.ts         # getLocale() from cookie → Accept-Language → default; re-exports makeT
  useT.ts           # client hook: useLocale(), useT()
  dictionaries/
    ar.ts           # Arabic (source of truth)
    en.ts
    fr.ts
src/middleware.ts   # Edge: detects locale, sets hrb_locale cookie, skips /api/
src/components/LanguageSwitcher.tsx   # "use client", 3 flags dropdown
```

---

## Core types + helpers (`src/i18n/index.ts`)

```ts
export const LOCALES = ["ar", "en", "fr"] as const;
export type Locale = typeof LOCALES[number];
export const DEFAULT_LOCALE: Locale = "ar";

export const LOCALE_META: Record<Locale, {
  name: string; flag: string; dir: "rtl" | "ltr";
}> = {
  ar: { name: "العربية",  flag: "🇸🇦", dir: "rtl" },
  en: { name: "English",   flag: "🇬🇧", dir: "ltr" },
  fr: { name: "Français",  flag: "🇫🇷", dir: "ltr" },
};

export function isLocale(v: unknown): v is Locale {
  return typeof v === "string" && (LOCALES as readonly string[]).includes(v);
}

export function dirFor(loc: Locale): "rtl" | "ltr" {
  return LOCALE_META[loc].dir;
}

// IMPORTANT: type alias MUST come before DICTS — TS strict mode
// rejects `Record<string, string>` used as an index type otherwise.
type Dict = Record<string, string>;
export const DICTS: Record<Locale, Dict> = {
  ar: DICTS_AR,
  en: DICTS_EN,
  fr: DICTS_FR,
};

export function t(locale: Locale, key: string, vars?: Record<string, string | number>): string {
  const raw = DICTS[locale][key] ?? DICTS[DEFAULT_LOCALE][key] ?? key;
  if (!vars) return raw;
  return raw.replace(/\{(\w+)\}/g, (_, k) => String(vars[k] ?? `{${k}}`));
}

export function makeT(locale: Locale) {
  return (key: string, vars?: Record<string, string | number>) => t(locale, key, vars);
}
```

**Pitfall #34 — type ordering:** `type Dict` MUST be declared BEFORE
`const DICTS: Record<Locale, Dict>`. TS strict mode rejects
`Record<string, string>` used as a Record index type if the alias
is declared after. Symptom: `error TS2456: Type 'Dict' has no
properties in common with type 'Record<Locale, ...>'`.

**Pitfall #35 — Dict type at all:** an inline `Record<string, string>`
type DOES work but loses IntelliSense on the dict object's keys.
The named alias gives you hover-jump to the dict file from any
`t("nav.dashboard")` call.

**Pitfall #36 — duplicate keys in `const DICTS_AR = { ... }`:**
TS lets you write `"nav.foo": "x", "nav.foo": "y"` in a single
object literal, but the second value wins at runtime AND tsc
strict-mode emits `error TS1117: An object literal cannot have
multiple properties with the same name`. Build still succeeds
because `next build` uses its own checker, but the route that
imports the dict throws `TypeError: Cannot read properties of
undefined` when the bundle optimizes the duplicate property away
unexpectedly. Always `grep -nE '"nav\.' src/i18n/dictionaries/ar.ts`
before adding new keys to verify no collision.

**Pitfall #49 — `patch` tool breaks object literal indentation on nested blocks:**
when you `patch` a dict file to add a block of 5-10 new keys, the
`new_string` indentation is interpreted relative to `old_string`'s
leading whitespace, NOT relative to the surrounding object literal
scope. Result: lines 64-76 of `ar.ts` ended up with 4-space indent
inside a 2-space object literal, and the parser silently accepted
the file but the runtime evaluation of `DICTS_AR[key]` returned
`undefined` for the mis-indented keys (because the JS engine treats
them as a new block scope). Symptom: `TypeError: undefined is not
an object (evaluating 'originalFactory.call')` on routes that
import the dict — Next's RSC bundle can't resolve the dict lookup
and the React factory chain breaks at hydration. Fix: when adding
blocks of keys, **read the FULL dict file first**, then `write_file`
with the complete corrected content. Never patch more than 2-3 keys
into a dict block at a time.

**Pitfall #50 — `patch` can introduce a premature `};` close:**
when `old_string` ends with `\n` (newline) and the line after it is
already `};`, the `new_string` insertion lands ABOVE the existing
close. If the surrounding context looks "normal" to the patcher's
fuzzy match, the diff lands cleanly, but the file now has an extra
`};` mid-file. Symptom: `error TS1117: An object literal cannot have
multiple properties with the same name` (because the orphan close
turns everything after it into a separate block). Always check the
total count of `^};` lines before and after a patch:
`grep -c '^};' file.ts` — should match the expected number of object
literals in the file.

**Pitfall #51 — `patch` adding new keys to a block that already has them:**
classic extension-pitfall. If you `patch` "add `platform.qiwa` to the
sidebar block" but the file already has `platform.qiwa` from an
earlier (perhaps reverted) patch, you now have TWO
`"platform.qiwa": "..."` keys. JS keeps the last one — but tsc strict
mode emits `TS1117`. Worse, when the block ALSO has a duplicate
*value key* like `common.user`, runtime dict lookup is unreliable.
Always `grep -nE '"<key>":' file.ts | wc -l` before patching a new
key; if it's >1, you have a duplicate.

---

## Edge middleware (`src/middleware.ts`) — cookie set, no URL rewrite

```ts
import { NextResponse, type NextRequest } from "next/server";
import { DEFAULT_LOCALE, isLocale } from "@/i18n";

const LOCALE_COOKIE = "hrb_locale";

export function middleware(req: NextRequest) {
  const res = NextResponse.next();

  // 1. If cookie already set, leave it (LanguageSwitcher sets it explicitly)
  if (req.cookies.get(LOCALE_COOKIE)?.value) return res;

  // 2. Detect from Accept-Language
  const al = req.headers.get("accept-language") ?? "";
  const parts = al.split(",").map((p) => {
    const [tag, ...attrs] = p.trim().split(";");
    const qAttr = attrs.find((a) => a.trim().startsWith("q="));
    const q = qAttr ? parseFloat(qAttr.split("=")[1]) : 1;
    return { tag: tag.toLowerCase().split("-")[0], q: isNaN(q) ? 1 : q };
  }).sort((a, b) => b.q - a.q);

  const detected = parts.find((p) => isLocale(p.tag))?.tag as
    typeof DEFAULT_LOCALE | undefined;

  if (detected) {
    res.cookies.set(LOCALE_COOKIE, detected, {
      path: "/", maxAge: 60 * 60 * 24 * 365, sameSite: "lax",
    });
  }

  return res;
}

export const config = {
  // Skip /api/* (must not rewrite), /_next/*, files with extensions
  matcher: ["/((?!api|_next/static|_next/image|favicon.ico|.*\\.).*)"],
};
```

**Pitfall #37 — middleware skips `/api/`:** the matcher MUST
exclude `/api/*`. Otherwise login (`POST /api/auth/login`)
returns 307 redirect to `/ar/api/auth/login` and the form 404s.
The `PUBLIC_FILE` regex from older docs isn't enough — Next 15
matcher is exact.

**Pitfall #38 — `getLocale()` in `cookies()`:** `next/headers`'s
`cookies()` is synchronous in Next 14, **async in Next 15**. The
code above (`const c = await cookies()`) is Next 15 only. If the
codebase is on Next 14, drop the `await`.

---

## Server-side locale (`src/i18n/server.ts`)

```ts
import { cookies, headers } from "next/headers";
import { DEFAULT_LOCALE, isLocale, type Locale } from "./index";

export { LOCALES, LOCALE_META, DEFAULT_LOCALE, isLocale, dirFor, makeT } from "./index";
export type { Locale } from "./index";

export const LOCALE_COOKIE = "hrb_locale";

export async function getLocale(): Promise<Locale> {
  try {
    const c = await cookies();
    const v = c.get(LOCALE_COOKIE)?.value;
    if (isLocale(v)) return v;
  } catch {}
  try {
    const h = await headers();
    const al = h.get("accept-language") ?? "";
    const parts = al.split(",").map((p) => {
      const [tag, ...attrs] = p.trim().split(";");
      const qAttr = attrs.find((a) => a.trim().startsWith("q="));
      const q = qAttr ? parseFloat(qAttr.split("=")[1]) : 1;
      return { tag: tag.toLowerCase().split("-")[0], q: isNaN(q) ? 1 : q };
    }).sort((a, b) => b.q - a.q);
    for (const p of parts) if (isLocale(p.tag)) return p.tag;
  } catch {}
  return DEFAULT_LOCALE;
}
```

**Pitfall #39 — `makeT` MUST be re-exported from `server.ts`:** any
server component that does `import { makeT } from "@/i18n/server"`
gets `TypeError: makeT is not a function` if `server.ts` doesn't
re-export it. Add the re-export line the moment you create
`server.ts` — don't wait for the first layout import to fail.

**Pitfall #40 — `LOCALE_COOKIE` constant:** define it ONCE in
`server.ts` and import from there. Defining it locally in
`middleware.ts` causes drift if the cookie name changes.

---

## Client hook — context-based (post-fix, zero flash)

```tsx
// src/i18n/I18nProvider.tsx
"use client";
import { createContext, useContext, useMemo, type ReactNode } from "react";
import { makeT, DEFAULT_LOCALE, dirFor, LOCALE_META, type Locale } from "./index";

export interface I18nContextValue {
  locale: Locale;
  dir: "rtl" | "ltr";
  meta: (typeof LOCALE_META)[Locale];
  t: (key: string, vars?: Record<string, string | number>) => string;
}

const I18nContext = createContext<I18nContextValue | null>(null);

export function I18nProvider({ locale, children }: { locale: Locale; children: ReactNode }) {
  const value = useMemo<I18nContextValue>(() => {
    const t = makeT(locale);
    return { locale, dir: dirFor(locale), meta: LOCALE_META[locale], t };
  }, [locale]);
  return <I18nContext.Provider value={value}>{children}</I18nContext.Provider>;
}

export function useT(): I18nContextValue {
  const ctx = useContext(I18nContext);
  if (!ctx) {
    // Fallback for components rendered outside the provider (error boundaries)
    const t = makeT(DEFAULT_LOCALE);
    return { locale: DEFAULT_LOCALE, dir: dirFor(DEFAULT_LOCALE), meta: LOCALE_META[DEFAULT_LOCALE], t };
  }
  return ctx;
}

export function useLocale(): Locale { return useT().locale; }
export function useDir(): "rtl" | "ltr" { return useT().dir; }
```

```tsx
// src/i18n/useT.tsx (re-export shim so old imports still work)
export { I18nProvider, useT, useLocale, useDir } from "./I18nProvider";
```

```tsx
// src/app/layout.tsx — wrap with I18nProvider so client components read locale from context
import { getLocale, dirFor } from "@/i18n/server";
import { I18nProvider } from "@/i18n/useT";

export default async function RootLayout({ children }: { children: React.ReactNode }) {
  const locale = await getLocale();
  const dir = dirFor(locale);
  return (
    <html lang={locale} dir={dir}>
      <body>
        <I18nProvider locale={locale}>{children}</I18nProvider>
      </body>
    </html>
  );
}
```

```tsx
// In any client component (post-migration):
import { useT } from "@/i18n/useT";
export default function MyClient() {
  const { t } = useT();            // ← DESTRUCTURE .t
  return <h1>{t("page.foo.title")}</h1>;
}
```

**Pitfall #41 (SUPERSEDED) — original cookie-on-mount pattern:** the
earlier "useT reads `document.cookie` in useEffect" pattern causes
a brief flash of the default locale on first paint, AND a
hydration mismatch warning in the Next 15 console. The current
context-based pattern below replaces it. Do not use the old
pattern in new code.

**Pitfall #54 — `useT()` returns a context OBJECT, not a function.**
The hook returns `{ locale, dir, meta, t }`. If you write
`const t = useT()` and then call `t("page.foo")`, you get
`TypeError: t is not a function` at first render. Always
destructure: `const { t } = useT();` (or
`const t = useT().t;`). Symptom: page returns 500, dev log shows
`⨯ TypeError: t is not a function at <Component>` with
`digest: "2269236180"`. This pitfall is EASY to miss because in
the context Provider pattern the `t` variable looks callable
when you read the code, but it isn't.

**Pitfall #55 — file extension MUST be `.tsx` for files containing
JSX, even if the file is just a re-export.** `useT.tsx` exists
purely to re-export from `I18nProvider.tsx`, but `.ts` files
cannot have JSX, so the import of `<I18nContext.Provider>` (or
any JSX) breaks the bundler. Symptom:
`Failed to read source code from /src/i18n/useT.ts: No such file
or directory` followed by route 500s — but the file DOES exist
in your IDE. This is the bundler refusing to read a .ts file
whose content is JSX-flavored. Fix: rename `.ts` → `.tsx` and
update all imports. The `tsconfig.json` `allowJs: true` setting
does NOT save you here — JSX in `.ts` is a hard error.

**Pitfall #56 — `t()` takes `vars` as a `Record`, NOT positional
arguments.** The signature is
`t(key: string, vars?: Record<string, string | number>)`. If
you write `t("page.perms_count", n, m)` expecting `{0}` and
`{1}` interpolation (like `printf`), the dict template
`"{count} permissions × {roles} roles"` is returned UNCHANGED
because the second positional arg is ignored and `vars` is
`undefined`. The user sees literal `"{count} permissions ×
{roles} roles"` on the page with no error in the console.
Always pass a record: `t("page.perms_count", { count: n, roles: m })`.
And the dict template uses named placeholders `{count}` not
positional `{0}`.

---

## Language switcher (`src/components/LanguageSwitcher.tsx`)

```tsx
"use client";
import { useRouter } from "next/navigation";
import { LOCALES, LOCALE_META, DEFAULT_LOCALE, type Locale } from "@/i18n";

export default function LanguageSwitcher({ current }: { current?: Locale } = {}) {
  const router = useRouter();
  const [open, setOpen] = useState(false);
  const [locale, setLocale] = useState<Locale>(current ?? DEFAULT_LOCALE);

  // sync with cookie on mount + when current prop changes
  useEffect(() => {
    if (current) setLocale(current);
    else {
      const c = document.cookie.match(/(?:^|; )hrb_locale=([^;]*)/)?.[1];
      if (c === "ar" || c === "en" || c === "fr") setLocale(c);
    }
  }, [current]);

  function pick(loc: Locale) {
    document.cookie = `hrb_locale=${loc}; path=/; max-age=${60*60*24*365}; samesite=lax`;
    setLocale(loc);
    setOpen(false);
    router.refresh();   // re-fetch the server tree with new cookie
  }

  const cur = LOCALE_META[locale];

  return (
    <div className="relative">
      <button onClick={() => setOpen(!open)} className="...">
        <span>{cur.flag}</span>
        <span className="hidden sm:inline">{cur.name}</span>
        <span>▾</span>
      </button>
      {open && (
        <div className="absolute right-0 mt-1 bg-white rounded-lg shadow-lg border z-50">
          {LOCALES.map((l) => (
            <button key={l}
                    onClick={() => pick(l)}
                    className={`flex items-center gap-2 px-3 py-2 w-full hover:bg-slate-50 ${
                      l === locale ? "bg-slate-100 font-bold" : ""
                    }`}>
              <span>{LOCALE_META[l].flag}</span>
              <span>{LOCALE_META[l].name}</span>
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
```

**Pitfall #42 — `router.refresh()` after cookie change:** without
it, the server tree keeps the OLD locale until the next nav. With
it, the entire route tree re-renders server-side using the new
locale (no full page reload — just a soft refresh).

**Pitfall #43 — use `samesite=lax` on the cookie:** Next 15
middleware reads cookies via `req.cookies`, but client-side
`document.cookie` is only readable for same-site paths. `lax` is
the safe default.

**Pitfall #44 — RTL flips the dropdown position:** if you set
`right-0` on the menu, it's right-anchored in BOTH rtl and ltr.
For true RTL mirroring, use `end-0` (Tailwind logical property)
instead of `right-0`. Then LTR drops it on the right, RTL on the
left.

---

## Root layout (`src/app/layout.tsx`)

```tsx
import { Cairo, Inter } from "next/font/google";
import { getLocale, dirFor } from "@/i18n/server";

const cairo = Cairo({ subsets: ["arabic"], variable: "--font-cairo", display: "swap" });
const inter = Inter({ subsets: ["latin"], variable: "--font-inter", display: "swap" });

export default async function RootLayout({ children }: { children: React.ReactNode }) {
  const locale = await getLocale();
  const dir = dirFor(locale);
  return (
    <html lang={locale} dir={dir} className={`${cairo.variable} ${inter.variable}`}>
      <body className={dir === "rtl" ? "font-['Cairo',sans-serif]" : "font-['Inter',sans-serif]"}>
        {children}
      </body>
    </html>
  );
}
```

**Pitfall #45 — font switch per locale:** set BOTH Cairo and Inter
as CSS variables, then pick `font-family` in `<body>` based on
`dir`. Cairo's Arabic glyphs are gorgeous; Inter's Latin is
neutral. Mixing Cairo for LTR languages wastes bandwidth on
Latin glyphs it doesn't have.

**Pitfall #46 — `<html lang>` and `<html dir>`:** Next 15 sets
these on first render. If you mutate `dir` from a client component
mid-session (e.g. user toggles language), you need to update
`document.documentElement.dir` from the LanguageSwitcher, OR
force a full reload via `window.location.reload()` instead of
`router.refresh()`.

---

## Server component pattern (dashboard layout nav)

```tsx
// src/app/dashboard/layout.tsx
import { getLocale, makeT } from "@/i18n/server";
import LanguageSwitcher from "@/components/LanguageSwitcher";

export default async function DashboardLayout({ children }: { children: React.ReactNode }) {
  const s = await getSession();
  if (!s?.tenantId) redirect("/login");
  const locale = await getLocale();
  const t = makeT(locale);
  return (
    <div>
      <aside>
        <nav>
          <NavLink href="/dashboard/employees" label={t("nav.employees")} icon="👥" />
          {/* ... */}
        </nav>
      </aside>
      <main>{children}</main>
      <LanguageSwitcher />
    </div>
  );
}
```

**Pitfall #47 — existing dictionaries already have keys you forgot:**
before adding `nav.org` etc., `grep -nE '"nav\.' ar.ts` first.
The HR Bridge session discovered a complete pre-existing `nav.*`
section at lines 9-31 from a prior session, and adding duplicate
keys at line 131+ crashed the layout with `TypeError: makeT is
not a function` (because the optimized bundle of `DICTS_AR`
became invalid). Reuse existing keys (`nav.organization` vs
inventing `nav.org`); only add a new key if it really doesn't
exist.

**Pitfall #48 — login credentials in MEMORY may be stale:** the
HR Bridge memory had `admin@hrbridge.local / admin123` but the
real seed was `naif.sahw@gmail.com / Qweewq123!`. Always grep
`prisma/seed.ts` for `bcrypt.hash` and `email: ` before assuming
login works. Same applies to the session cookie name — the live
iron-session cookie was `hrbridge_session` (HttpOnly), NOT
`hrb_sess` as remembered.

**Pitfall #52 — `DATABASE_URL=file:./dev.db` SILENTLY creates TWO
databases (the silent-failure 401 trap):** this is the #1 reason
`/api/auth/login` returns 401 with the message "بيانات الدخول غير
صحة" even when bcrypt.compare returns `true` and the user exists
in the seeded DB. Mechanism: `file:./dev.db` is resolved by Prisma
from `process.cwd()` (i.e. the directory where `next dev` was
started), NOT from `prisma/schema.prisma`. The `prisma db seed`
command runs from the prisma/ directory and writes to
`prisma/dev.db`. But Next dev starts from the project root and
writes to `<project-root>/dev.db`. SQLite silently creates the
empty file on first open, so you get a fully-functional empty DB
that responds to all queries (just returns no rows). Symptoms:
- `prisma.user.findUnique()` returns `null` for the seeded email
- The seeded user IS visible via `sqlite3 prisma/dev.db`
- `bcrypt.compareSync('Qweewq123!', '<hash-from-prisma/dev.db>')` returns `true` from a node REPL
- `lsof -p <next-dev-pid>` shows the process has BOTH `.db` files open at different times
Fix: in `.env`, set `DATABASE_URL="file:./prisma/dev.db"` (relative
to cwd, which IS the project root). Then `npx prisma generate`
to bake the new path into the generated client, then `pkill -f
"next dev"` + `rm -rf .next` + restart. Verification recipe:
```bash
# After fix, both should show the SAME user count and SAME hash
sqlite3 prisma/dev.db "SELECT count(*), length(password) FROM User"
ls -la /<project-root>/dev.db /<project-root>/prisma/dev.db
# The ROOT dev.db should NOT exist after the fix
# If both exist, Next is still reading the empty one
```
ALSO add `dev.db` AND `prisma/dev.db` to `.gitignore` so a
stray empty DB never gets committed.

**Pitfall #53 — Prisma client caches the DATABASE_URL path at
generate time, not at runtime:** changing `.env` does NOT update
the generated client. Symptom: you fix the URL, restart Next, but
the error is the SAME `Unable to open the database file`. The
generated `@prisma/client` has the OLD path baked in. Fix: ALWAYS
`npx prisma generate` after changing `DATABASE_URL`, BEFORE
restarting the dev server. If you forget this, you'll chase a
phantom config bug for an hour.

---

## Verification recipe

```bash
# 1. Build clean (the i18n middleware adds a 32 kB chunk to the
#    output, look for `ƒ Middleware` in the build summary)
cd /Users/0x/Desktop/shaker/hr-bridge
rm -rf .next
npm run build 2>&1 | tail -30
# expect: `ƒ Middleware  32 kB` and exit 0

# 2. Restart dev (with clean .next because the build mutated it)
pkill -f "next dev -p 4000"
sleep 2
rm -rf .next
npx next dev -p 4000 2>&1 | tee /tmp/hrb-devN.log &
sleep 8

# 3. Probe each locale — login first (use REAL credentials, not memory)
JAR=/tmp/cj.txt; rm -f "$JAR"
curl -s -c "$JAR" -X POST http://localhost:4000/api/auth/login \
  -H "content-type: application/json" \
  -d '{"email":"naif.sahw@gmail.com","password":"Qweewq123!"}'
# expect: {"ok":true}  and cookie hrbridge_session in $JAR

# 4. For each locale, curl /dashboard with the cookie set
for L in ar en fr; do
  RESP=$(curl -s -b "$JAR" -w "\nSTATUS:%{http_code}" \
         -H "Cookie: hrb_locale=$L" \
         http://localhost:4000/dashboard)
  STATUS=$(echo "$RESP" | tail -1 | cut -d: -f2)
  HTML=$(echo "$RESP" | head -1)
  echo "$L: status=$STATUS html=$(echo "$HTML" | grep -oE '<html[^>]*>' | head -1)"
done
# expect:
#   ar: status=200 html=<html lang="ar" dir="rtl" ...>
#   en: status=200 html=<html lang="en" dir="ltr" ...>
#   fr: status=200 html=<html lang="fr" dir="ltr" ...>

# 5. Check that nav items translate in each locale
curl -s -b "$JAR" -H "Cookie: hrb_locale=ar" http://localhost:4000/dashboard \
  | grep -oE 'الموظفون|الإعدادات|القائمة' | sort -u
# expect: all three Arabic strings
curl -s -b "$JAR" -H "Cookie: hrb_locale=en" http://localhost:4000/dashboard \
  | grep -oE 'Employees|Settings|Menu' | sort -u
# expect: all three English strings
curl -s -b "$JAR" -H "Cookie: hrb_locale=fr" http://localhost:4000/dashboard \
  | grep -oE 'Employés|Paramètres|Menu' | sort -u
# expect: all three French strings
```

---

## What this pattern deliberately does NOT do

- **No URL-prefixed locales** (`/ar/login`). Cookies-only is
  simpler for retrofitting; SEO is acceptable since most Arabic
  SaaS doesn't need `/en/` for English-speaking search bots to
  find individual pages.
- **No `[locale]` dynamic segment.** Avoids a massive refactor
  of every existing route.
- **No `next-intl` / `react-i18next` / `@formatjs/intl`.** Zero
  bundle overhead, zero version conflicts.
- **No ICU MessageFormat.** Just `{varName}` interpolation.
  Sufficient for 95% of UI strings. If you need pluralization,
  reach for `Intl.PluralRules` directly.
- **No per-tenant locale override.** All tenants share the
  user's locale. Add `tenant.locale` and prefer it in
  `getLocale()` if you need per-tenant defaults.

---

**Pitfall #57 — `withLocale()` generates locale-prefixed URLs that 404 in
cookie-only locale projects.** The helper `withLocale(locale, path)` in
`src/i18n/index.ts` prepends `/${locale}` to paths (e.g. `/en/dashboard`).
This is correct ONLY if you have `[locale]` dynamic route segments. In the
HR Bridge cookie-locale pattern (no URL prefixes, no middleware rewrites),
`withLocale` produces paths that don't exist — the app 404s after login
because `router.push(withLocale("en", "/dashboard"))` navigates to
`/en/dashboard` which has no matching `app/en/dashboard/page.tsx`.

Symptom: login form submits successfully (API returns `{ok:true}`) but
the browser lands on a 404 page. The URL bar shows `/en/dashboard` or
`/ar/dashboard` instead of `/dashboard`.

Fix: in cookie-locale projects, `withLocale` should strip any existing
locale prefix and return the clean path:
```ts
export function withLocale(_locale: Locale, path: string): string {
  const stripped = path.replace(/^\/(ar|en|fr)(?=\/|$)/, "") || "/";
  return stripped.startsWith("/") ? stripped : "/" + stripped;
}
```
This is a one-line change but it affects login (`router.push(dashboardPath)`)
and register redirects. Always test the full login → dashboard redirect
flow in the browser after touching `withLocale`.

**Pitfall #58 — stale `.next` cache causes "Cannot find module './NNN.js'"
after incremental rebuilds.** When the dev server has been running through
multiple code changes, the `.next` directory accumulates stale chunk
references. Symptom: pages return 200 (Next serves a fallback) but the
dev log shows `⨯ Error: Cannot find module './681.js'` (or similar chunk
numbers) and Fast Refresh does a full reload. This is NOT a source bug —
typecheck and build pass clean. Fix: `pkill -f "next dev"` → `rm -rf .next`
→ restart dev server → hard-refresh browser. This is the same class of
stale-chunk error documented in the nextjs-runtime-errors reference file.

**Pitfall #59 — child client components hardcode Arabic strings instead of
using `t()`.** The parent `page.tsx` server components correctly use
`makeT(locale)` / `t()` for headings and KPI labels, but child client
components (`*Client.tsx`, `EmployeeTable.tsx`, `AddEmployeeButton.tsx`,
etc.) often have Arabic strings hardcoded directly in JSX — table headers,
button labels, search placeholders, toast messages, status badges, form
field labels, select option labels, etc.

Symptom: switching the language from Arabic to English (or French) only
translates the page heading and KPI labels — everything inside the child
component (table, buttons, forms, status badges) stays in Arabic. The
language switcher appears to "not work" for most of the page.

Root cause: when the i18n layer was retrofitted, the parent `page.tsx`
files were updated to use `t()` but the interactive child components
were left with their original Arabic strings. This is a systemic issue
that can affect 20+ files.

Fix pattern (for each affected client component):
1. Add `import { useT } from "@/i18n/useT";` at the top
2. Add `const { t } = useT();` inside the component
3. Replace every hardcoded Arabic string with `t("key")` call
4. Add the new keys to ALL 3 dictionary files (ar.ts, en.ts, fr.ts)
5. For option labels (nationalities, contract types, etc.), use `t()`
   keys for those too — don't leave any Arabic in the JSX
6. For toast/confirm messages with variables, use interpolation:
   `t("employees.sync.toast.all", { count: 5 })` → `"{count} employees synced"`

Detection: `grep -rl '"[ا-ي]' src/app/dashboard` finds all files with
hardcoded Arabic strings in JSX. Filter to `*Client.tsx` and similar
interactive component files.

Scale: this can be a 20+ file fix. Use subagent delegation (delegate_task)
to fix files in parallel batches of 3-5 files per subagent. Each
subagent adds its own dictionary keys — coordinate to avoid duplicate
key conflicts by having each subagent work on distinct feature areas
(employees, leave, billing, etc.).

**Pitfall #60 — `useT.ts` vs `useT.tsx` import path ambiguity.** The
import is `import { useT } from "@/i18n/useT"` (no extension). If both
`useT.ts` and `useT.tsx` exist, the bundler resolution order may pick
the wrong one. Ensure only ONE file exists at `src/i18n/useT.tsx` (it
must be `.tsx` if it contains or re-exports JSX — see pitfall #55).
Delete any stale `useT.ts` to prevent resolution ambiguity.

---

## Debugging: FR shows Arabic text even though dict key exists

### Root cause: stale Next.js module cache

**Symptom:** The FR dictionary has `"ai_agent.base_url": "URL de base"` (confirmed via `grep` and `tsx -e "import..."`), but the browser renders `الرابط الأساسي` (Arabic) for that one label while the rest of the page is French. No error boundary, no "Hide Errors" button.

**Diagnostic chain:**

1. **Understand the fallback:** `DICTS[locale][key] ?? DICTS[DEFAULT_LOCALE][key] ?? key`
   - `DICTS[fr]["ai_agent.base_url"]` = `undefined` (stale module) → falls through to `DICTS[ar]["ai_agent.base_url"]` → "الرابط الأساسي"
   - If the key were missing from ALL three dicts, you'd see the **raw key** `"ai_agent.base_url"` on screen
   - Seeing `الرابط الأساسي` means FR dict lookup failed but AR dict succeeded → the FR module is stale, not missing

2. **Verify the dict file is correct at the filesystem level:**
   ```bash
   npx tsx -e "import { fr } from './src/i18n/dictionaries/fr'; console.log(Object.keys(fr).length, JSON.stringify(fr['ai_agent.base_url']))"
   # Expected: "1082 \"URL de base\""
   ```

3. **Inject a console.log into `makeT()` to see what the runtime returns:**
   ```ts
   // In src/i18n/index.ts, temporarily patch:
   export function makeT(locale: Locale) {
     const dict = getDict(locale);
     if (typeof window !== 'undefined') {
       console.log('[MAKET] locale=' + locale + ' ai_agent.base_url=', dict['ai_agent.base_url']);
     }
     return function t(key: string, vars?: Record<string, string | number>): string {
       // ...
   ```
   Then reload the page and check the browser console. If `console.log` shows `undefined` for the FR locale even though `tsx` found the key, the module cache is stale.

4. **Fix:**
   ```bash
   pkill -f "next dev"
   rm -rf .next
   npx next dev -p 4000
   ```
   Then hard-refresh the browser (Cmd+Shift+R).

**Pitfall #61 — FR (or any non-default locale) shows DEFAULT_LOCALE text for individual labels after adding new keys to the dict file.** This is NOT a source code bug — it's Next's module graph holding a stale version of the FR dict that predates the key addition. The AR dict works because `DEFAULT_LOCALE = "ar"` means AR modules are prioritized in the initial chunk and always fresh; FR/EN modules are lazy-loaded and may reference old chunk IDs after `rm -rf .next` + restart. Fix is always: clean `.next`, restart dev server, hard-refresh browser. Do NOT waste time re-adding the key, changing the value, or checking TypeScript — if `tsx` finds it and the build compiles clean, the problem is the runtime cache.

**Pitfall #62 — cookie must be set with `path=/` BEFORE the first page navigation for SSR to pick it up.** Setting `document.cookie = "hrb_locale=fr"` (no path) scopes the cookie to the current URL path. Subsequent navigation to `/dashboard/settings/ai-agent` won't send the cookie in the request (the browser checks path scope). Always use `document.cookie = "hrb_locale=fr;path=/"`. When testing via browser_console, set the cookie BEFORE navigating (or on the login page before submitting) so the SSR render sees it:

```js
document.cookie = "hrb_locale=fr;path=/";
// THEN navigate or submit login form
```

**Pitfall #63 — the `browser_navigate` snapshot shows localized text immediately after setting the cookie.** If you set the cookie and the snapshot still shows the default locale, the cookie wasn't set correctly (missing `path=/` or wrong syntax). Verify with `document.cookie` output — the cookie value must match one of `"ar"`, `"en"`, `"fr"`.

---

## Comprehensive i18n audit procedure

When asked to verify that all three locales work correctly across the entire app:

### 1. Static audit: cross-reference all `t()` calls against dicts

```bash
# Extract all unique keys from t() calls in source
grep -rhoP "(?<=t\()['\"]([^'\"]+)['\"]" src/app/ src/components/ | sort -u > /tmp/all_keys.txt

# Check each key exists in all three dictionaries
for dict in ar en fr; do
  echo "=== Missing in $dict ==="
  while read -r key; do
    grep -q "\"$key\":" src/i18n/dictionaries/$dict.ts || echo "  $key"
  done < /tmp/all_keys.txt
done
```

### 2. Browser-based visual verification

For each locale, check at least these pages via `browser_navigate` + `browser_snapshot`:

| Page | AR known value | FR known value | EN known value |
|---|---|---|---|
| Dashboard | `عرض الموظفين` | `Voir les employés` | `View employees` |
| AI Agent Settings | `الرابط الأساسي` | `URL de base` | `Base URL` |
| Employees | `الموظفون` (nav) | `Employés` (nav) | `Employees` (nav) |
| AI Chat | `وكيل الذكاء الاصطناعي` | `Agent IA` | `AI Agent` |
| Reports | `التقارير والذكاء` | `Rapports & BI` | `Reports & BI` |

```javascript
// Per-locale test pattern in browser_console:
document.cookie = "hrb_locale=ar;path=/";
// Reload and snapshot — check heading/prominent text for locale-specific value

document.cookie = "hrb_locale=fr;path=/";
// Reload and snapshot — check same element

document.cookie = "hrb_locale=en;path=/";
// Reload and snapshot — check same element
```

Look for these failure signals in the snapshot:
- **Raw key string** (e.g., `nav.employees`) → key missing from ALL three dicts
- **Arabic text on FR page** → key exists in AR dict but missing from FR dict (fallback to DEFAULT_LOCALE)
- **English text on AR/FR page** → hardcoded English string in JSX (not using `t()`) — see pitfall #59
- **"Hide Errors" button or error boundary** → runtime crash in component, often from undefined `t()` value

### 3. Full-page check: all visible StaticText

The accessibility tree snapshot (`browser_snapshot`) lists every `StaticText` and `link` on the page. For a complete audit, check that ALL text nodes under `- main` are translated. Pay special attention to:
- Button labels
- Form placeholders
- Table column headers
- Status badges
- Toast/notification messages
- Empty-state messages

---

## When to graduate to `next-intl`

This pattern is fine until ~200 keys. After that:
- ICU plural/gender selection becomes painful with `t()`
- Date/number formatting needs per-locale customization
- You want type-safe keys (`t("nav.dashboard")` errors on typo)

At that point migrate to `next-intl` with URL-prefixed locales.
The cookie-only approach above will have given you the locale
detection + middleware skeleton already.