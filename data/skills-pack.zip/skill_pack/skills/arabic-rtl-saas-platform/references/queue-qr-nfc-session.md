# Q.af Session — 2026-06-28
## Phase 9.7: Queue Manager + QR Design + NFC Tag Manager

### What was built
1. **Queue Manager dashboard** (`/dashboard/queue`, `/dashboard/queue/settings`, `/dashboard/queue/employee`, `/dashboard/queue/scanner`)
   - Server components fetching live data, client components for interactivity.
   - Employee PIN auth via `emp_session` cookie (scrypt-based).
   - Public ticket lookup via `/q/_/[queueSlug]/ticket/[token]`.
   - Manager QR scanner issuing tickets atomically.
2. **QR Design page** (`/dashboard/qr/design`)
   - Preset CRUD via `/api/qr-designs` + `/api/qr-designs/[id]`.
   - Live SVG preview via `/api/qr-render` (debounced).
   - Logo upload via `/api/upload-logo` (stores to `public/uploads/{tenantId}/`).
3. **NFC Tag Manager** (`/dashboard/qr/nfc`)
   - Payload CRUD via `/api/nfc` + `/api/nfc/[id]`.
   - Encode endpoint `/api/nfc/encode` generates printable SVG card + NDEF binary.
   - Supports kinds: `shortlink`, `bio`, `vcard`, `wifi`, `text`.

### Dev server restart pattern
For this project, the Next.js dev server should be started with:
```bash
cd /Users/0x/Desktop/q.af/app && npx next dev --port 3000
```
Use Hermes `terminal(background=true)` with `notify_on_complete=true` for long-running dev servers. Check `/tmp/qaf-dev.log` for startup errors if the server fails to bind.

### File paths
- Dashboard pages:
  - `src/app/dashboard/queue/page.tsx`
  - `src/app/dashboard/queue/settings/page.tsx`
  - `src/app/dashboard/queue/employee/page.tsx`
  - `src/app/dashboard/queue/scanner/page.tsx`
  - `src/app/dashboard/qr/design/page.tsx` + `QRDesignClient.tsx`
  - `src/app/dashboard/qr/nfc/page.tsx` + `NFCClient.tsx`
- API routes:
  - `src/app/api/qr-designs/route.ts` (GET/POST)
  - `src/app/api/qr-designs/[id]/route.ts` (PATCH/DELETE)
  - `src/app/api/upload-logo/route.ts` (multipart, stores to `public/uploads/{tenantId}/`)
  - `src/app/api/nfc/route.ts` (GET/POST)
  - `src/app/api/nfc/[id]/route.ts` (DELETE)
  - `src/app/api/nfc/encode/route.ts` (POST → printable SVG + NDEF binary)
  - `src/app/api/qr-render/route.ts` (existing QR SVG renderer)
- Shared styles: `src/app/globals.css` (added QR + NFC + shared component classes)
- Dashboard pages:
  - `src/app/dashboard/queue/page.tsx`
  - `src/app/dashboard/queue/settings/page.tsx`
  - `src/app/dashboard/queue/employee/page.tsx`
  - `src/app/dashboard/queue/scanner/page.tsx`
  - `src/app/dashboard/qr/design/page.tsx` + `QRDesignClient.tsx`
  - `src/app/dashboard/qr/nfc/page.tsx` + `NFCClient.tsx`
- API routes:
  - `src/app/api/qr-designs/route.ts` (GET/POST)
  - `src/app/api/qr-designs/[id]/route.ts` (PATCH/DELETE)
  - `src/app/api/upload-logo/route.ts` (multipart, stores to `public/uploads/{tenantId}/`)
  - `src/app/api/nfc/route.ts` (GET/POST)
  - `src/app/api/nfc/[id]/route.ts` (DELETE)
  - `src/app/api/nfc/encode/route.ts` (POST → printable SVG + NDEF binary)
  - `src/app/api/qr-render/route.ts` (existing QR SVG renderer)
- Shared styles: `src/app/globals.css` (added QR + NFC + shared component classes)

### Key technique: NFC encode endpoint self-POSTs to `/api/qr-render`
The `/api/nfc/encode` route generates a printable NFC card SVG that includes a QR code. It does this by making an internal `fetch("http://localhost:3000/api/qr-render", { method: "POST", ... })` with the payload URL. This reuses the existing QR renderer instead of duplicating SVG generation logic.

### Schema changes
- `Tenant.slug` added (nullable unique) for URL-friendly tenant identifiers.
- `Queue`, `QueueTicket`, `QueueEvent`, `Employee`, `QRDesign`, `NFCPayload` models all present.
- `QueueTicket.label` format: `{prefix}-{zeroPaddedNumber}` (e.g., `A-014`).
- `Queue.dailyCounter` resets at midnight (handled in DB logic or cron).
- `NFCPayload.lastPrintedAt` added (`DateTime?`) to track print history.

### Key pitfall discovered: Date vs string serialization
When passing Prisma objects from Server Components to Client Components via props:
- Prisma returns `Date` objects (e.g., `createdAt: Date`, `lastPrintedAt: Date | null`).
- Client component TypeScript types declare these as `string | null` for JSON-safe props.
- **Fix**: In the server page, explicitly map `.toISOString()` before passing:
  ```tsx
  <ClientComponent items={items.map(i => ({
    ...i,
    createdAt: i.createdAt.toISOString(),
    lastPrintedAt: i.lastPrintedAt?.toISOString() ?? null,
  }))} />
  ```
- Do NOT spread the raw Prisma object (`...i`) — the spread infers Prisma's types and will fail `tsc`.

### Styling approach
All queue/QR/NFC styles were moved from inline `<style jsx>` into `src/app/globals.css` with BEM-style class names:
- `.queue-tabs`, `.queue-tab`, `.queue-tab--active`
- `.employee-console__grid`, `.counter-card`
- `.scanner__viewport`, `.scanner__video`, `.scanner__frame`
- `.qr-design__layout`, `.qr-design__form`, `.qr-design__svg-wrap`
- `.nfc-manager__layout`, `.nfc-manager__form`, `.nfc-manager__item`
- `.issued-banner`, `.badge--ok`, `.badge--warn`, `.badge--danger`, `.badge--info`
- `.form-row`, `.form-row--inline`, `.form-row__label`

### Component exports
- `SidebarLayout` is a **default export** from `src/components/SidebarLayout.tsx`.
- `PageHeader` is a **default export** from `src/components/PageHeader.tsx`.
- Import as: `import { SidebarLayout } from "@/components/SidebarLayout"` and `import PageHeader from "@/components/PageHeader"`.
- **Do not** use `import { Shell }` or `import { PageHeader }` (those do not exist as named exports).
