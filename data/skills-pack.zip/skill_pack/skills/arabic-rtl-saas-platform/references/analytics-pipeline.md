# Analytics pipeline + dashboard (Q.af Phase 4 reference)

Full recipe for shipping an analytics dashboard that *means something*: end-to-end
redirect capture, two endpoints, an RTL dashboard with charts, demo seed, and an
e2e harness that proves the round trip. Built and verified on Q.af.

## Why a dedicated phase

A URL shortener without analytics is a toy. Users need:
- How many clicks, where, when, on what device, from what referrer.
- A view that speaks their language (Arabic, RTL, Hijri dates, Arabic-Indic numerals).
- Per-link drill-down so they can compare their campaigns.

The hard part is NOT the chart — it's the data pipeline:
1. Capture the right fields on every redirect without adding latency.
2. Geo-resolve without a paid MaxMind license (use CDN headers, not a local DB).
3. Aggregate efficiently across thousands of events per tenant.
4. Filter bot traffic from headlines but keep it in raw event logs.

## 1. Capture path — enrich the redirect engine

The `ClickEvent` table already exists (Phase 1 schema). Wire `/r/[slug]/route.ts` to
record device + country + referrer host + UA on every redirect. The work must NOT
block the redirect — wrap it in `Promise.all` with the `NextResponse.redirect` so the
user gets the destination URL and the event insert runs in parallel.

```ts
// inside the GET handler, after the lookup + gates:
const ua = req.headers.get("user-agent") || "";
const rawRef = req.headers.get("referer");
const refHost = referrerHost(rawRef);      // strips path, drops "www.", returns host|null
const country = resolveCountry(req);        // header cascade, see below

// Fire-and-forget the insert (best-effort, never fail the redirect on it):
const recordEvent = prisma.clickEvent.create({
  data: {
    linkId: link.id,
    ts: new Date(),
    device: classifyDevice(ua),             // "mobile"|"desktop"|"tablet"|"bot"
    country,
    referrer: refHost ? rawRef?.slice(0, 500) : null,  // store full URL but capped
    userAgent: ua.slice(0, 300),
  },
});
const bumpCounter = prisma.link.update({
  where: { id: link.id },
  data: { clicks: { increment: 1 } },
});

const [res] = await Promise.all([recordEvent, bumpCounter]);  // eslint-disable-line
return NextResponse.redirect(link.destination, 302);
```

### Geo header cascade (no MaxMind required)

```ts
function resolveCountry(req: NextRequest): string | null {
  const h = req.headers;
  return (
    h.get("x-qaf-geo") ||             // dev override for e2e tests
    h.get("cf-ipcountry") ||          // Cloudflare
    h.get("x-vercel-ip-country") ||   // Vercel
    h.get("x-country-code") ||        // generic CDN
    geoFromIp(                         // last-resort offline lookup
      h.get("x-forwarded-for")?.split(",")[0]?.trim() ||
      h.get("x-real-ip") ||
      null
    )
  );
}
```

`geoFromIp(ip)` is a stub for MVP that returns `null`. For prod, drop in a tiny
offline DB (e.g. `ip2country` from npm, ~2 MB) or pass the IP through a serverless
edge function. Never block the redirect on geo — if the IP lookup throws, return
`null` and let the event still record.

### Device classifier (zero-dep)

```ts
function classifyDevice(ua: string): "mobile"|"tablet"|"desktop"|"bot" {
  const u = ua.toLowerCase();
  if (/bot|crawl|spider|facebookexternalhit|slurp|bingpreview/.test(u)) return "bot";
  if (/ipad|tablet|kindle|playbook|silk/.test(u)) return "tablet";
  if (/iphone|ipod|android.*mobile|mobile|blackberry|opera mini/.test(u)) return "mobile";
  return "desktop";
}
```

Order matters: check bots first (so a Googlebot UA isn't classified as desktop),
then tablets before "mobile" (so "iPad" doesn't match "Mobile"), then mobile,
then desktop as the catch-all.

## 2. Endpoints — two, not one

`/api/analytics/[linkId]` returns the per-link drill-down. `/api/analytics/overview`
returns workspace-wide stats + top links. Both auth-checked via `getAuth()` and 401
if not signed in.

### Convention: filter bots from headlines, keep them in raw

```ts
const HUMAN = { device: { not: "bot" as const } };
// apply to: clicksInRange, today, yesterday, byCountry, byDevice, topLinks
// do NOT apply to: recent (so users see raw traffic including preview bots)
```

This is the right product behavior — preview crawlers (Slack, Twitter, Discord)
inflate counters but don't represent real audience engagement. Users WANT to see
them in the "Recent events" stream (because that's where they debug preview links)
but NOT in the headline number.

### Overview endpoint shape

```ts
// GET /api/analytics/overview?days=30
{
  window: { days: 30, since: "2026-05-27T..." },
  summary: {
    links: 12,
    domains: 2,
    clicks: 1834,             // all-time, human
    clicksInRange: 412,
    today: 23,
    yesterday: 18,
    trendPct: 28,
  },
  timeseries: [{ day: "2026-05-27", clicks: 14 }, ...],
  byCountry: [{ country: "SA", count: 89 }, ...],
  byDevice: [{ device: "mobile", count: 234 }, ...],
  recent: [{ id, ts, device, slug, title, destination }, ...],
  topLinks: [{ id, slug, hostname, clicks, title, destination }, ...],
}
```

### Per-link endpoint shape

Same structure but `link: { id, slug, destination, title, hostname, clicks }` instead
of `summary`, and `byReferrer: [{ referrer, count }, ...]` instead of `topLinks`.

## 3. Dashboard UI — zero-dep SVG charts

Don't reach for Chart.js / Recharts / D3 just for three charts. A ~250-line
component that emits self-contained SVGs (line, bar, donut) with `<path>` + `<rect>` +
`<circle>` and inherits `currentColor` from CSS variables is enough and keeps the
bundle slim. Each chart takes `data: Array<{label, value}>` and renders.

- Line chart: `<path d="M ... L ...">` for the line + `<path d="M ... L ... Z">` for
  the fill, with one `<circle>` per data point.
- Bar chart: one `<rect>` per data point, height proportional to value/max.
- Donut chart: stroke-dasharray on `<circle>` segments — total circumference / value
  per segment, rotated by the cumulative offset.

All three accept a `width`, `height`, and inherit color from `currentColor` so the
dashboard theme drives every chart via CSS variables (`--c1`, `--c2`, ...).

## 4. RTL + Hijri + Arabic-Indic — utility classes, not locale switch

Don't switch `lang` to `en` for charts. Add three utility classes in `globals.css`:

```css
/* Arabic-Indic numerals (٠١٢٣٤٥٦٧٨٩) on any element */
.num-ar { font-feature-settings: "ss01"; }
/* Hijri grouping: font-variant-numeric tabular + heavier weight */
.hijri { font-variant-numeric: tabular-nums; }
/* Gregorian grouping: same tabular but a different token so the toggle visually differs */
.gregorian { font-variant-numeric: tabular-nums; opacity: 0.85; }
```

A calendar toggle in the dashboard flips a state variable between `"gregorian"` and
`"hijri"`. The x-axis labels re-render accordingly:

```ts
function fmtDay(d: Date, cal: "gregorian"|"hijri"): string {
  if (cal === "gregorian") return d.toISOString().slice(5, 10);  // "05-27"
  // Hijri: use Intl with islamic-umalqura calendar (Node + browsers both support it)
  return new Intl.DateTimeFormat("ar-SA-u-ca-islamic-umalqura", {
    day: "2-digit", month: "short",
  }).format(d);
}
```

Numbers (counts, percentages, click totals) are formatted via `Intl.NumberFormat("ar-SA")`
which automatically produces Arabic-Indic digits. Wrap in `<span class="num-ar">` for
extra emphasis. Do NOT use a third-party date library for Hijri — Intl is enough.

## 5. Demo seed — proves the dashboard immediately

`scripts/seed-analytics.ts` runs in <5 s and creates:
- 1 demo tenant (`Demo Workspace`)
- 1 verified subdomain domain (`demo.qaf.link`)
- 4 Arabic-slug links (`متجر`, `whatsapp`, `تنزيل-التطبيق`, `العروض`)
- 30 days × weighted distribution × {4 devices, 5 countries, 6 referrers} = ~2400 clicks

Idempotent: re-runs delete the prior demo domain's links and re-attach the domain to
the current demo tenant. See the multi-tenant seed pitfall in the main skill for the
full explanation of why this needs an explicit re-attach.

The seed writes events in chunks of 500 via `prisma.clickEvent.createMany` and
finally sets `link.clicks = total` so the persistent counter matches.

## 6. E2E harness — proves the full round trip

`scripts/e2e-analytics.sh` runs the entire pipeline as a shell script:

1. Sign up a fresh user (so the auth cookie is real).
2. Attach the demo domain + create 3 Arabic-slug links for the new tenant.
3. Seed 500 synthetic events with varied UAs/referrers/countries.
4. Hit `/r/متجر` with `Host: demo.qaf.link` + `User-Agent: iPhone` +
   `Referer: https://twitter.com/post/123` + `X-Qaf-Geo: SA`.
5. Assert the latest event in the DB has `device=mobile, country=SA`.
6. GET `/api/analytics/overview?days=30` and grep for `"summary"`, `"timeseries"`,
   `"topLinks"`, and `clicks > 0`.
7. GET `/api/analytics/<linkId>?days=30` and grep for `"link"`, `"byReferrer"`,
   `"byCountry"`, `"timeseries"`.
8. GET `/dashboard/analytics` (HTML) and grep for the Arabic title `التحليلات`,
   the stat label `إجمالي النقرات`, and the recent-events heading `آخر النقرات`.

The script exits non-zero on any failure with a `FAIL: ...` line, so it's CI-runnable.

## 7. Verification ladder (don't claim Phase 4 done without these)

1. `npx tsc --noEmit` clean.
2. Seed runs: `npx tsx scripts/seed-analytics.ts` prints "seeded N clicks...".
3. Dev server up: `curl -o /dev/null -w "%{http_code}" http://localhost:3000/` → 200.
4. Real redirect round-trip: `curl -H "Host: demo.qaf.link" http://localhost:3000/r/متجر`
   → 302 to the destination. Latest event in DB has the right device/country.
5. Overview endpoint: `curl -b cookies.txt http://localhost:3000/api/analytics/overview`
   → JSON with `summary.clicks > 0` and `timeseries.length === days`.
6. Dashboard renders: `curl -b cookies.txt http://localhost:3000/dashboard/analytics | grep "التحليلات"`
   → match.
7. `browser_vision` on the dashboard for the RTL visual check — confirm Arabic title
   is right-anchored, numbers are Arabic-Indic, and the chart x-axis uses the active
   calendar's labels.

## 8. Common extension points

- **QR code generation** — add a `/api/qr/[linkId]` endpoint that returns a PNG
  with the short URL encoded. Pure-Node QR generator (`qrcode` npm package, ~50 KB)
  or a one-shot canvas in the browser. Keep it server-side so the dashboard can
  embed `<img src="/api/qr/...">` directly.
- **A/B testing** — add a `LinkVariant` table with `linkId, label, destination,
  weight`. On redirect, pick a variant weighted-randomly and record which one
  converted. Same analytics pipeline, just an extra `variant` field on ClickEvent.
- **ClickHouse** — when SQLite/Postgres can't keep up with the event write rate,
  dual-write to ClickHouse for analytics and keep ClickEvent only as a recent-events
  buffer (last 7 days). The endpoint queries ClickHouse; the schema stays the same.
- **Webhooks on click** — add a `Webhook` table (`tenantId, url, secret, events[]`).
  In the capture path, fan out to webhooks AFTER the redirect returns so latency
  isn't added. Use a queue if reliability matters.