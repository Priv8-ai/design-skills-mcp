# Design extraction from a reference HTML mockup

Full recipe for taking a designer-supplied reference HTML (typically several MB
with embedded base64 PNGs) and re-skinning an existing product to match it.
Built and verified on Q.af (Phase 5 → Phase 6 restyle, using
`~/Downloads/qaf-assets/qaf_professional_landing.html`).

## When to use

- A user / designer hands you a single-file HTML mockup and says
  "make it look like this" / "design like this file" / "use the colors
  and layout from `<reference>.html`".
- The reference is the *visual target* — product behaviour, copy, and
  features stay the same; only the look changes.
- The reference is usually large (1–10 MB) because designers embed
  logos + showcase art as inline base64.

## Step 0 — Strip inline images before reading

Do NOT `read_file` the whole reference. It's 95% `src="data:image/png;base64,..."`
and will blow your context. Strip them first:

```python
import re
src = open(ref_path).read()
src = re.sub(r'src="data:[^"]*"', 'src=""', src)  # remove inline images
body = re.search(r'<body>(.*)</body>', src, re.S).group(1)
head = re.search(r'<head>(.*)</head>', src, re.S).group(1)
# Now write body and head to small temp files for further inspection
```

After stripping, the typical 8 MB reference becomes ~50 KB of HTML + CSS —
easily `read_file`-able.

Also separate the brand assets (logos) from the design:
```bash
ls /path/to/assets/  # usually logo.png + logo-white.png + showcase.png
cp /path/to/logo*.png /project/app/public/brand/
```

## Step 1 — Extract the CSS-var palette + font stack from `<head>`

Read the head section. Look for:
- `:root { --color-x: ... }` blocks → defines the palette tokens.
- `@import url('https://fonts.googleapis.com/css2?...')` or
  `<link href="...fonts...">` → defines the font stack.
- A `<style>` block at the top of body or head → defines utility classes.

Distill into:
- **Palette**: primary, secondary, accent, ink (text), paper (background),
  muted, border, gradient endpoints.
- **Fonts**: heading font (display), body font (UI), mono font (URLs/code).
- **Geometry**: container max-width, card border-radius, spacing scale,
  shadow scale.

## Step 2 — Extract the section structure + utility class names

Read the body section. Identify:
- **Top-level sections** in order (usually: topbar → hero → strip → features
  → showcase → pricing → CTA → footer).
- **Recurring class names** (sorted unique, then grouped):
  - Layout: `.topbar`, `.hero`, `.features`, `.showcase`, `.pricing`, `.cta`,
    `.footer`, `.panel`, `.container`.
  - Components: `.card`, `.btn`, `.btn-primary`, `.btn-ghost`, `.pill`, `.eyebrow`,
    `.nav-link`, `.brand`, `.composer`, `.input`, `.bio-link`.
  - Atoms: `.grad` (gradient text), `.strip-row`, `.metric-grid`, `.chart-card`.

These become the names of your own utility classes in `globals.css`. The
benefit: e2e tests can later `grep -E 'class="(topbar|hero|composer|...|cta)"'`
to prove the restyle landed.

### Step 2a — CSS class gap analysis (MANDATORY before writing pages)

**Do NOT write any page until you've checked which design-reference CSS classes
already exist in the project.** The reference HTML uses class names that may not
be defined in your `globals.css` or `dashboard.css`. If you write a page using
`.card`, `.logo`, `.ticket-number`, `.nav-shell`, etc. without first adding them
to the CSS, the page will render with broken styling.

Workflow:

```bash
# 1. Extract every class name from the design reference HTML
grep -oP 'class="[^"]*"' reference.html | tr ' ' '\n' | sort -u > /tmp/ref-classes.txt

# 2. For each class, check if it exists in the project CSS
while read cls; do
  grep -q "\.${cls}\b" src/app/globals.css src/app/dashboard.css 2>/dev/null \
    || echo "MISSING: .${cls}"
done < /tmp/ref-classes.txt

# 3. Add all missing classes to globals.css (or dashboard.css for dark-theme classes)
#    Copy the exact CSS rules from the design reference's style.css
```

Common missing classes from `qaf_advanced_complete_ui`:
- `.card` — glass-morphism card with backdrop-filter
- `.logo` — flex row with ltr direction, Inter font
- `.logo-small` — 42×42 rounded icon
- `.ltr` — left-to-right text with Inter font
- `.ticket-number` — 96px gradient text for queue display
- `.nav-shell` — frosted-glass topbar container
- `.nav-links` — horizontal nav link row
- `.nav-actions` — button group in topbar
- `.section` — 70px vertical padding wrapper
- `.section-head` — centered heading block
- `.grid` / `.g4` — CSS grid with 4 columns
- `.price` / `.amount` / `.featured` — pricing card variants
- `.btn-outline` / `.btn-dark` — button variants

**Pitfall**: The design reference's `style.css` may define classes that conflict
with existing project classes (e.g., both define `.card` differently). When this
happens, scope the new classes under a parent selector or use the design
reference's definition as the canonical one and update existing pages to match.

## Step 3 — Rewrite `globals.css` with the new tokens

Match the reference's token names and values:
```css
:root {
  --paper: #f7f7fb;       /* was: dark base */
  --ink:   #0f172a;       /* was: light text */
  --muted: #6b7280;
  --border: #e5e7eb;
  --primary: #6366f1;     /* indigo accent */
  --accent: #06b6d4;      /* cyan */
  --grad: linear-gradient(135deg, var(--primary) 0%, var(--accent) 100%);
  /* fonts */
  --font-display: "Noto Kufi Arabic", system-ui;
  --font-body:    "IBM Plex Sans Arabic", system-ui;
  --font-ui:      "Inter", system-ui;
}
```

Then write utility classes for every section + component class you extracted
in Step 2. Keep them shallow (no nested selectors) so the React markup
reads like the reference HTML.

Also redefine the `.card` / `.btn` / `.input` / `.pill` classes to match —
every dashboard page uses these.

## Step 4 — Rewrite the Logo component to serve the new asset

```tsx
// /public/brand/logo.png       (color logo, used on light surfaces)
// /public/brand/logo-white.png  (white logo, used on dark / gradient surfaces)
export function Logo({ size = 32, variant = "color" }: Props) {
  const src = variant === "white" ? "/brand/logo-white.png" : "/brand/logo.png";
  return <img src={src} alt="Q.af" width={size} height={size} />;
}
```

Add an alias `variant="mark"` → `variant="white"` if existing code references
the old name. Don't rename the variant prop without searching for callers.

## Step 5 — Rewrite the landing page section-by-section

Order matters (each section often references utility classes from the prior):
1. **Topbar** — `<header className="topbar">` with brand + nav + buttons.
2. **Hero** — eyebrow + gradient `<h1>` + lead + composer + CTAs + hero-art.
3. **Strip** — 4 quick stat cards.
4. **Features** — 6 feature cards (icon + title + description).
5. **Showcase** — phone mockup + dashboard panel mockup (inline SVG, no images).
6. **Pricing** — 3 cards (Starter / Pro-featured / Business).
7. **CTA** — single gradient banner.
8. **Footer** — minimal links + copyright.

If the landing has any `onSubmit` / `onClick` / `useState`, the page must be
`"use client"`. Otherwise keep it as a server component and push interactivity
into a small `<ComposerClient>` child component.

## Step 6 — Re-skin the `SidebarLayout` shell to match

If landing and dashboard drift apart visually, the product feels disjoint.
Same tokens, same font stack, same card style. Search for hardcoded `#hex`
colors in `.tsx` files and replace with `var(--paper)` / `var(--ink)` etc.

Pitfall: `SidebarLayout` is usually a NAMED export, not default — verify
with `grep -n "^export" <component-file>` before importing in new pages.

## Step 7 — Rebuild dashboard pages to use the new tokens

For each `src/app/dashboard/**/page.tsx`:
- Replace inline `#hex` colors with `var(--paper)` / `var(--ink)` / etc.
- Replace any hand-rolled `style={{...}}` blocks with the new utility
  classes (`.card`, `.btn`, `.btn-primary`).
- Wrap in `<SidebarLayout active="...">` for nav consistency.

If a dashboard page has an editor / list / form, follow the same pattern
as the public bio editor (live preview pane + form pane).

## Step 8 — Extend the e2e harness

Add a "restyle landed" assertion to `e2e-analytics.sh` (or a new
`e2e-design.sh`):

```bash
# Landing has the new design classes
HOME=$(curl -s "$BASE/")
for c in topbar hero composer features showcase pricing cta footer; do
  grep -q "class=\"$c" "$HOME" || grep -q "class=\"$c " "$HOME" \
    || fail "home missing design class '$c'"
done

# Landing has the new Arabic copy
for s in "قصّر روابطك" "ابدأ مجاناً" "المزايا" "التحليلات" "الأسعار"; do
  grep -q "$s" "$HOME" || fail "home missing copy '$s'"
done
ok "landing restyle verified"
```

This catches regressions when someone later edits `globals.css` and breaks
a class. Cheap, deterministic, no browser needed.

## Verification ladder (don't claim restyle done without these)

1. `npx tsc --noEmit` → clean.
2. `curl http://localhost:3000/ | wc -c` → typically 20–30 KB for a fully
   populated landing; under 5 KB usually means the page is a 500/loading shell.
3. `curl http://localhost:3000/ | grep -oE 'class="(topbar|hero|composer|features|showcase|pricing|cta|footer)"' | sort -u | wc -l` → ≥ 7.
4. `curl http://localhost:3000/ | grep -c "قصّر روابطك"` → 1 (or more).
5. `browser_vision` on `http://localhost:3000/` to confirm the RTL layout,
   font rendering, and brand colors match the reference visually.
6. `browser_vision` on `http://localhost:3000/dashboard/bio` (after auth)
   to confirm the shell + cards + buttons match the landing's design language.
7. Run the extended `e2e-*.sh` suite → all green.

## Common pitfalls (also covered in the main skill)

- **`"use client"` required when any event handler exists** — Next.js App
  Router 500s on a server-component page with `onSubmit`.
- **LSP cache goes stale after Prisma schema changes** — `npx prisma generate
  && rm -rf .next/dev/types` clears it.
- **Named-export components need `import { X }` not `import X`** — verify
  with `grep -n "^export"` before writing imports.
- **DO NOT over-engineer design implementations** — when the user provides a
  design reference HTML, match it EXACTLY: same class names, same structure,
  same element hierarchy. Do NOT invent custom inline styles, gradient themes,
  or extra features that aren't in the reference. The reference is the spec.
  If the user says "use the old design" or reverts your work, it means you
  deviated from the reference. Revert cleanly with `git checkout HEAD -- <files>`.
- **CSS class gap analysis is MANDATORY before writing any page** (Step 2a).
  Skipping it causes pages to render with broken styling because the design
  reference's class names (`.card`, `.logo`, `.ticket-number`, `.nav-shell`,
  `.ltr`, etc.) may not exist in the project CSS. Add all missing classes to
  `globals.css` or `dashboard.css` BEFORE writing the page components.
- **When the user rejects a design approach**, revert ALL changed files
  atomically with `git checkout HEAD -- <file1> <file2> ...`. Don't try to
  salvage partial changes — start fresh from the known-good state.

## Reusable artifacts from the Q.af Phase 6 restyle

- `references/design-extraction.md` — this file.
- The brand assets in `public/brand/` (`logo.png`, `logo-white.png`).
- The `globals.css` rewrite (470+ lines of CSS-var tokens + utility classes).
- The new `app/page.tsx` (360 lines, section-by-section match to reference).
- The new `SidebarLayout.tsx` (170 lines, light theme + RTL nav).
- The `e2e-bio.sh` script — extended with a "restyle landed" assertion block.