# Q.af Inline-Style Migration Session

Session: 2026-06-28 — Batch rewrite of dashboard components from legacy CSS classes to zero-CSS-footprint inline styles.

## Context
The project uses Tailwind CSS v4 (`@tailwindcss/postcss` in `postcss.config.mjs`), but many dashboard client components were written before Tailwind with custom `.btn`, `.card`, `.surface`, `.toolbar`, `.table`, `.modal-backdrop`, etc. classes defined in `src/app/globals.css`. The goal is to eliminate all legacy CSS classes and replace them with inline styles, making components portable and the stylesheet lean.

## Files migrated (chronological order)

### Wave 1 — Shell + wrappers
1. `src/components/SidebarLayout.tsx` — full rewrite (15,225 → ~15,000 chars). Glass-morphism sidebar, sticky topbar, emoji icons, CSS variable theming.
2. `src/app/dashboard/links/page.tsx` — thin wrapper, design-system PageHeader.
3. `src/app/dashboard/settings/page.tsx` — thin wrapper.
4. `src/app/dashboard/bio/page.tsx` — thin wrapper.

### Wave 2 — Queue system
5. `src/app/dashboard/queue/page.tsx` — manager overview.
6. `src/app/dashboard/queue/QueueBoardClient.tsx` — ticket board (12,370 → 276 lines inline).
7. `src/app/dashboard/queue/employee/page.tsx` — employee console gate.
8. `src/app/dashboard/queue/employee/EmployeeConsole.tsx` — counter console.
9. `src/app/dashboard/queue/employee/EmployeePinForm.tsx` — PIN entry.
10. `src/app/dashboard/queue/scanner/page.tsx` — scanner gate.
11. `src/app/dashboard/queue/scanner/ScannerClient.tsx` — barcode/QR scanner.
12. `src/app/dashboard/queue/settings/page.tsx` — settings gate.
13. `src/app/dashboard/queue/settings/QueueSettingsClient.tsx` — queue + employee CRUD.

### Wave 3 — QR / NFC / Code generation
14. `src/app/dashboard/qr/page.tsx` — wrapper.
15. `src/app/dashboard/qr/CodeGeneratorClient.tsx` — 7 symbology generator (10,434 → 15,816 chars, all inline).
16. `src/app/dashboard/qr/design/page.tsx` — wrapper.
17. `src/app/dashboard/qr/design/QRDesignClient.tsx` — preset list + live preview (12,814 → 14,530 chars).
18. `src/app/dashboard/qr/nfc/page.tsx` — wrapper.
19. `src/app/dashboard/qr/nfc/NFCClient.tsx` — NFC tag manager (11,388 → 12,345 chars).

### Wave 4 — Simple server pages
20. `src/app/dashboard/api-keys/page.tsx`
21. `src/app/dashboard/ab/page.tsx`
22. `src/app/dashboard/payments/page.tsx`
23. `src/app/dashboard/webhooks/page.tsx`
24. `src/app/dashboard/team/page.tsx`

## Files NOT yet migrated (remaining legacy CSS consumers)

| File | Size | Legacy classes used |
|------|------|-------------------|
| `LinksListClient.tsx` | ~10KB | `.surface`, `.toolbar`, `.search`, `.stat-strip`, `.table`, `.modal-backdrop`, `.row-action`, `.badge`, `.btn-primary`, `.btn-ghost`, `.grid-3`, `.select`, `.input`, `.link`, `.truncate`, `.slug`, `.muted`, `.small`, `.stack` |
| `SettingsClient.tsx` | ~10KB | `.tabs`, `.tab-active`, `.tab-danger`, `.card-section`, `.kv-list`, `.kv-row`, `.alert`, `.data-table`, `.btn-danger`, `.btn-ghost`, `.input`, `.badge` |
| `AnalyticsClient.tsx` | ~18.8KB | Tailwind `q-*` utility classes + custom `Shell` wrapping `SidebarLayout` |
| `AgencyClient.tsx` | ~8KB | (unknown, grep needed) |
| `BioListClient.tsx` | ~8KB | (unknown, grep needed) |
| `BioEditorClient.tsx` | ~9KB | (unknown, grep needed) |

## Legacy CSS rules still in `globals.css` (~50 matches)

Confirmed present in `src/app/globals.css` as of 2026-06-28:

```
.btn-primary { ... }
.btn-primary:hover { box-shadow: ... }
.table, .source-card { ... }
.table h3, .source-card h3 { ... }
.table thead th { ... }
.table tbody tr { ... }
.table tbody tr:hover { ... }
.table tbody td { ... }
.table .num { ... }
.table .truncate { ... }
.table .small { ... }
.slug { ... }
.row-action { ... }
.row-action:hover { ... }
.row-action.danger { ... }
.row-action.danger:hover { ... }
.badge { ... }
.badge-success { ... }
.badge-danger { ... }
.badge-info { ... }
.badge-warn { ... }
.modal-backdrop { ... }
.modal { ... }
.modal-title { ... }
.modal-actions { ... }
.stack { ... }
.surface { ... }
.toolbar { ... }
.search { ... }
.search:focus-within { ... }
.search input { ... }
.stat-strip { ... }
.stat { ... }
.stat-label { ... }
.stat-value { ... }
.grid-3 { ... }
.table-wrap { ... }
.alert { ... }
.alert-danger { ... }
.alert-ok { ... }
.alert-warn { ... }
.card-section { ... }
.kv-list { ... }
.kv-row { ... }
.kv-row-label { ... }
.page-title { ... }
.page-subtitle { ... }
.tabs { ... }
.tab-active { ... }
.tab-danger { ... }
.select { ... }
.input { ... }
.link { ... }
.muted { ... }
.small { ... }
.empty-card { ... }
.empty-card-icon { ... }
.empty-card-title { ... }
.empty-card-text { ... }
```

**Dead CSS cleanup strategy**: Only remove rules after verifying zero consumers with:
```bash
grep -rn 'className="<rule>"' src/ --include="*.tsx"
```

## Inline-style pattern adopted

See SKILL.md Pitfall #34 for the full set of reusable constants. Key decisions:
- **Card**: `background: white`, `borderRadius: 14`, `border: 1px solid var(--line, rgba(0,0,0,.06))`, `boxShadow: 0 1px 3px rgba(0,0,0,.04)`, `padding: 24`.
- **Card head**: flex between title and actions, `borderBottom` separator.
- **Primary button**: gradient purple (`#6f2cff` → `#7c3aed`), white text, `borderRadius: 10`, `boxShadow: 0 8px 18px rgba(111,44,255,.22)`.
- **Secondary/Ghost**: `#f1f5f9` background, `border: 1px solid rgba(0,0,0,.06)`.
- **Danger**: `#ef4444` background, white text.
- **Input**: `width: 100%`, `borderRadius: 10`, `border: 1px solid rgba(0,0,0,.12)`.
- **Badge**: `borderRadius: 99`, small padding, semantic background colors.
- **Alert**: `borderRadius: 12`, semantic background, bold text.
- **Grid layouts**: `gridTemplateColumns: "minmax(280px, 360px) 1fr"` for form + preview side-by-side.

## Commits
- `e0967ab` — "feat: SidebarLayout v2 + queue pages v2 + qr/nfc wrapper pages migrated to inline styles" (32 files)
- `a0f9349` — "feat: qr/nfc clients v2 + scanner + employee + queue settings inline styles" (21 files)
