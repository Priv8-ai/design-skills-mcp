# Zero-dependency auth + session→tenant resolution (Phase 2)

Goal: replace the dev-time `getTenantId()` header shim with real signup/login/logout
and a session that resolves the active tenant — using ONLY Node's built-in `crypto`.
No NextAuth, no bcrypt, no jose, no external auth lib. Proven on Q.af.

## Why a shim first, then this
Phase 1 ships data routes (`/api/links`, `/api/domains`, `/api/analytics`,
`/api/links/[id]`) that read `tenantId` from a header shim so the product is testable
before auth exists. Phase 2 swaps every shim call for `getAuth()` in one pass. Keep the
shim signature (`-> tenantId`) close to the real one (`getAuth() -> {userId, tenantId, role}`)
so the swap is mechanical.

## Schema additions (Prisma)
- `User.passwordHash String?` (nullable so OAuth users can exist later).
- `User.sessions Session[]`.
- New `Session` model: `id`, `tokenHash` (UNIQUE, indexed — store the **sha256 of the
  token**, never the token), `userId`, `tenantId` (the active workspace for this session),
  `expiresAt`, `createdAt`. Migrate: `npx prisma migrate dev --name auth_sessions`.

## lib/auth.ts (the whole auth core, ~150 lines)
- Password hashing: `crypto.scryptSync(password, salt, 64)` with a per-user random 16-byte
  salt; store `salt:hash` hex. Verify with `crypto.timingSafeEqual`. scrypt is in Node core
  — no native bcrypt build step, no install.
- Token: `crypto.randomBytes(32).toString('base64url')` is the opaque token handed to the
  client; `sha256(token)` is what lands in `Session.tokenHash`. DB compromise ≠ usable tokens.
- Cookie: `SESSION_COOKIE = "qaf_session"`, `httpOnly`, `sameSite:"lax"`, `secure` in prod,
  `path:"/"`, 30-day TTL. Use `cookies()` from `next/headers` (await it in Next 16).
- Exports: `hashPassword`, `verifyPassword`, `createSession(userId,tenantId)`,
  `setSessionCookie`, `getAuth()` (reads cookie → sha256 → Session lookup → null if
  missing/expired), `destroySession`, `clearSessionCookie`, and `requireTenant(role?)`
  for RBAC gating.

## Route handlers
- `POST /api/auth/signup` — validate email + password (≥8). Check email_taken. Then ONE
  atomic `prisma.$transaction`: create User → create Tenant → create owner Membership →
  create Session. Set cookie. This is what makes the very first login land in a real
  workspace with no orphan state.
- `POST /api/auth/login` — verify creds; return a **generic** `invalid_credentials` for both
  unknown-email and bad-password (no user enumeration). Create session, set cookie.
- `POST /api/auth/logout` — `destroySession` + `clearSessionCookie`.
- `GET /api/auth/me` — return user, `activeTenantId`, role, and ALL workspaces (drives a
  workspace switcher later).

## The swap (mechanical, do all at once)
In every data route replace the shim with:
```ts
const auth = await getAuth();
if (!auth) return NextResponse.json({ error: "unauthorized" }, { status: 401 });
const tenantId = auth.tenantId;
```
Routes touched on Q.af: `links`, `links/[id]`, `domains`, `analytics`. Drop now-unused
`NextRequest` imports the linter flags.

## Auth UI (RTL)
- `app/(auth)/AuthForm.tsx` — one `"use client"` shared form, `mode: "login"|"signup"`,
  an Arabic `ERRORS` map keyed by the server error codes, `useRouter().push("/dashboard")`
  on success, Next `<Link>` cross-link between login/signup.
- `login/page.tsx` and `signup/page.tsx` are thin server components with Arabic `metadata`
  that render `<AuthForm mode=.../>`. Route group `(auth)` keeps them out of the dashboard
  layout.

## Verify
1. `npx tsc --noEmit` clean.
2. `curl -i -X POST /api/auth/signup -d '{email,password}'` → 200 + `set-cookie: qaf_session=`.
3. Reuse that cookie jar (`curl -c jar -b jar`) to `GET /api/auth/me` → 200 with tenant+role.
4. `POST /api/links` with the cookie → 200; without it → 401.
5. Bad password on login → generic `invalid_credentials`, never "no such user".
