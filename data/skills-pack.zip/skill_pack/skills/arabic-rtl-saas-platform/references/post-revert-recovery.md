# Post-revert recovery: restoring inline-style migrations

Use this recipe when you discover that earlier commits (e.g. inline-style
v2 migrations) were silently undone by revert commits in the history.

## Detection

```bash
# Check recent history for reverts
git log --oneline -20

# A commit that LOOKS like it has the feature may have been reverted.
# Verify by comparing the feature commit against HEAD:
git diff <feature_commit> --stat | head

# If the diff shows the files are different, the feature was reverted.
```

## Recovery workflow

```bash
# 1. Identify which files need recovery
git show <feature_commit> --name-only

# 2. Restore each file from the feature commit.
# IMPORTANT: path must match the commit's stored path.
# If repo was restructured (e.g. app/src/ → src/), use the OLD path:
git checkout <feature_commit> -- app/src/app/dashboard/links/LinksListClient.tsx

# 3. Verify no stale imports (e.g. old PageHeader path)
grep -rn 'import.*PageHeader' src/app/dashboard/ src/components/

# 4. Type-check and build
cd app && npx tsc --noEmit && npx next build
```

## Key pitfalls

**Reverts hide in plain sight.** A `git log --oneline` may show:
```
abc123 feat: migrate to inline styles
```
But earlier in history there may be:
```
def456 Revert "feat: migrate to inline styles"
```
If you don't scroll far enough, you miss it. Always check for reverts
when re-discovering "missing" work.

**Path mismatch after repo restructure.** If the repo was restructured
between the feature commit and HEAD, `git checkout <commit> -- src/foo`
may fail with "did not match any file(s) known to git". Use the path
as it existed in the commit (e.g. `app/src/foo`). Run from the git
toplevel (`git rev-parse --show-toplevel`).

**Phantom CSS classes.** Some files may use classes like `q-card`,
`q-badge`, `q-btn` that have NO CSS definitions anywhere. These are
Tailwind-like utility names but the project has no `@theme` or
`@utility` declarations for them. Replace with inline style objects.

## Inline-style pattern for dashboard cards

```tsx
const CARD: React.CSSProperties = {
  background: "white", borderRadius: 14,
  border: "1px solid var(--line, rgba(0,0,0,.06))",
  boxShadow: "0 1px 3px rgba(0,0,0,.04)",
  padding: 24, marginBottom: 14,
};
```

## Inline-style pattern for primary buttons

```tsx
const BTN_PRIMARY: React.CSSProperties = {
  display: "inline-flex", alignItems: "center", gap: 6,
  minHeight: 40, padding: "0 18px", borderRadius: 10,
  fontSize: ".88rem", fontWeight: 700, color: "white",
  background: "linear-gradient(135deg, #6f2cff, #7c3aed)",
  border: "none", cursor: "pointer",
  boxShadow: "0 8px 18px rgba(111,44,255,.22)",
};
```

## Verification after recovery

```bash
# Confirm no legacy CSS classes remain in migrated files
grep -rl 'className="\(card\b\|btn\b\|badge\b\|alert\b\|table\b\)' \
  src/app/dashboard/<migrated>/ --include="*.tsx"
# Should return nothing

# Confirm inline styles are present
grep -c 'style={{\|const CARD:\|const BTN_' \
  src/app/dashboard/<migrated>/*.tsx
```
