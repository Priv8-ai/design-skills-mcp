# UX and Code Quality Patterns for Arabic RTL SaaS

## 1. Loading Skeletons (Next.js App Router)

When adding loading states to a Next.js RTL SaaS:

- Create `src/components/Skeleton.tsx` with these variants:
  - `SkeletonCard` — pulsing card placeholder (used on dashboards, overviews)
  - `SkeletonTable` — pulsing table with N rows (used on list pages)
  - `SkeletonOverlay` — full-page skeleton matching the page layout
  - `SkeletonStats` — stat card row skeleton (3-4 stat cards side by side)

- Each variant renders `<div className="animate-pulse bg-slate-200 rounded ...">` blocks matching the layout of the actual content.

- Add `loading.tsx` to EVERY dashboard route group:
  ```tsx
  // src/app/dashboard/[page]/loading.tsx
  export default function DashboardLoading() {
    return <SkeletonOverlay />;
  }
  ```
  Route groups that benefit: crm, documents, recruitment, leave, performance, reports, billing, webhooks, automations, audit, integrations, settings, permissions, ai, organization, employees.

- For pages with specific layouts (e.g. employees has a table and stat cards), customize the loading file to match the exact layout shape.

## 2. SSR-Safe ToastProvider and Root-Layout Hooks

When a root-layout component (used in `layout.tsx`) needs to use `useToastContext()`:

1. Ensure `<ToastProvider>` wraps it in the root layout:
   ```tsx
   // src/app/layout.tsx
   <I18nProvider locale={locale}>
     <ToastProvider>
       <PWABanner />
       {children}
       <ToastContainer />
     </ToastProvider>
   </I18nProvider>
   ```

2. If the login page (or any public page) 500s with `useToastContext must be used within a ToastProvider`:
   - First, clean `.next`: `rm -rf .next && restart dev server`. Stale cache mimics SSR context errors.
   - If still broken, the page needs `export const dynamic = "force-dynamic"` — this prevents Next.js from statically pre-rendering the page, which would run client hooks during SSR.

3. The page file change is minimal:
   ```tsx
   // src/app/login/page.tsx — add this at module level:
   export const dynamic = "force-dynamic";
   ```

## 3. i18n Dead Key Validation

When someone says "these i18n keys are unused" or you want to audit dictionary coverage:

```python
import os, re
os.chdir("/path/to/project")

# Extract all t() calls from source files
t_calls = set()
for root, dirs, files in os.walk("src"):
    for f in files:
        if f.endswith((".tsx", ".ts")):
            path = os.path.join(root, f)
            with open(path) as fh:
                content = fh.read()
            # Find t("key") or t('key') calls
            for m in re.finditer(r't\(["\']([^"\']+)["\']\)', content):
                t_calls.add(m.group(1))

# Extract all keys from the EN dictionary
with open("src/i18n/dictionaries/en.ts") as f:
    en_content = f.read()
dict_keys = set(re.findall(r'"([a-z]+\.[a-z.]+)"', en_content))

# Dead keys = in dictionary but never called
dead = dict_keys - t_calls
print(f"Dead keys: {len(dead)}")
for k in sorted(dead):
    print(f"  {k}")
```

**2026-07-04 finding:** 19 keys across `documents.*`, `recruitment.*`, and `integrations.*` namespaces were dead. Deleting them from `en.ts` was safe — they didn't exist in `ar.ts` or `fr.ts` (those dictionaries already omitted them).

## 4. SVG Icon Extraction (Inline → Shared Barrel)

When extracting inline SVG icon definitions from a component file into `src/components/icons.tsx`:

1. **Identify unique icons** — `rg 'const \w+Icon' ComponentName.tsx` finds local definitions.
2. **Check for duplicates** — `rg 'export const \w+Icon' src/components/icons.tsx` shows what already exists.
3. **For truly unique ones:** Add new named exports to `icons.tsx` using the shared base helpers.
4. **Update imports in the source file:** Replace local definitions with imports from `@/components/icons`.
5. **Don't move icons that have specific sizing/preserving:** Icons with hardcoded width/height that differ from the shared base may be better left inline.

Example shared icon structure:
```tsx
// src/components/icons.tsx
const base = "w-5 h-5";
export function HospitalIcon(props: { className?: string }) {
  return (
    <svg className={`${base} ${props.className || ""}`} viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="1.5">
      {/* SVG paths */}
    </svg>
  );
}
```

**2026-07-04 finding:** 15 inline SVG components were in LeaveClient.tsx (454 lines). 7 were moved to shared icons.tsx, 3 replaced with existing shared icons, 5 stayed inline (too specific styling). The file dropped to 384 lines.
