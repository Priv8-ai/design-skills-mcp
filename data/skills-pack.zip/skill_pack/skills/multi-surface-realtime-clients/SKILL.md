---
name: multi-surface-realtime-clients
description: "Use when one API feeds dashboard, extension, and TUI."
version: 1.0.0
author: Hermes Agent
license: MIT
metadata:
  hermes:
    tags: [frontend, tui, browser-extension, websocket, state-management, integration-testing]
    related_skills: [systematic-debugging, frontend-anti-pattern-audit, vanilla-js-spa, requesting-code-review]
---

# Multi-Surface Real-Time Clients

## Overview

Use this skill when a single backend is consumed by several operator surfaces—typically a browser dashboard, a Manifest V3 extension, and a CLI/TUI—and those clients combine persistent REST state with WebSocket/SSE events.

The central risk is not styling drift. It is **semantic drift**: different selected entities, lifecycle labels, action payloads, event filters, settings ownership, and recovery behavior across clients. A surface can look correct and report “connected” while silently dropping every relevant live event.

## When to Use

- Redesigning or adding two or more clients over one API.
- A dashboard and extension disagree about active work.
- A TUI launches private in-process state instead of observing the shared control plane.
- WebSocket is connected but activity does not update.
- Historical work disappears after backend restart even though files/DB records remain.
- Manifest V3 notifications work briefly and then stop after worker suspension.
- Route changes or entity switching paint stale asynchronous results.

Skip for a single client with no live event stream.

## Core Invariants

### One authoritative selected entity

Keep one selected ID per client. Route data, event filtering, actions, inspectors, and URL handoff derive from it. A selection change clears entity-scoped records and invalidates older in-flight requests.

Selection precedence should be explicit and tested:

1. ID requested by URL/CLI handoff.
2. Valid stored selection.
3. Active entity.
4. Newest history.

Test the real boot sequence where state starts empty and the index arrives later; constructor-only tests miss this.

### Persistent state is not event state

REST detail/summary/findings may survive process restart while event buses and snapshot backlogs do not. Historical workspace loading must tolerate an expected snapshot 404 and continue with an empty activity buffer. Non-404 failures remain errors.

### Resolve effective event identity

A global fan-out envelope may carry a sentinel outer ID and the real entity ID in nested data. Resolve identity before filtering:

- Concrete outer ID wins.
- Missing/global outer ID falls back to nested ID.
- Nested ID never overrides another concrete outer entity.

### Sequence numbers are source-local

Never globally sort events from independent buses by `seq`. Preserve arrival order across sources and deduplicate by `(source identity, sequence)`. Bound event records and dedupe keys together.

### Async commits are conditional

Every route load captures entity ID and route before I/O, performs I/O without holding the render lock, then commits only if both values still match current state.

### Action contracts come from the backend

Inventory OpenAPI/router declarations before wiring actions. Similar names may represent different operations, such as batch model assessment versus per-record probe verification. Use pure URL/payload builders with exact encoding tests. Display IDs required by the endpoint.

Treat 2xx as a request receipt unless the backend proves synchronous completion. Label later observed lifecycle state separately.

### Surface capability follows lifecycle

Derive `can_*` flags in view models. Hide or disable live-worker actions for terminal records while retaining historical-safe actions such as evidence review.

## Surface Ownership

Avoid cloning the whole product three times:

- **Dashboard:** investigation, dense comparison, findings, evidence, configuration, reviewed actions.
- **Extension:** current-page context, workspace match, reviewed capture/handoff, lightweight status.
- **TUI:** keyboard-first observation, scan switching, concise commands, scriptable snapshot.

Use shared vocabulary and contract tests even when implementation languages differ.

## Implementation Workflow

1. Inventory HTTP routes, WebSockets, payload models, persistence boundaries, and lifecycle values.
2. Write a cross-surface ownership matrix and normalized state vocabulary.
3. Define pure reducers, selectors, and URL builders before rendering.
4. Add RED tests for selection, event identity/dedupe, verification labels, stale-response rejection, and action URLs.
5. Implement one read-only tracer bullet per surface.
6. Add reviewed mutations; capture entity/record IDs at review time and re-check before submit.
7. Exercise restart behavior, concurrent entity traffic, extension suspension, and actual full-screen TUI execution.
8. Run focused security and independent logic review; verify each finding against source before patching.

## Browser Dashboard Rules

- Install global error and unhandled-rejection catchers before module boot.
- Escape all backend/tool/finding text before HTML insertion.
- Retain stale data with timestamp during reconnect; do not replace it with zeroes.
- A connection badge proves transport only. Prove delivery with a controlled reversible event.
- URL handoff preserves requested entity or reviewed target.
- Test desktop and narrow viewport overflow, off-canvas navigation, and inspectors.

## Manifest V3 Rules

- Service workers are disposable. Persist notification transition baselines in extension-local storage.
- Persist only minimal non-secret fields: stable ID, display name/domain, lifecycle status, and relevant counters.
- An absent baseline is initialization and must not generate first-poll spam.
- Keep page capture under explicit user gesture and require destination review before upload.
- Separate extension-only preferences from canonical backend settings.
- Verify with Chromium/Chrome for Testing in a temporary profile and inspect the expected worker URL; do not mistake a built-in worker for yours.

## TUI Rules

- The TUI observes the shared control plane; do not create a private orchestrator unless explicitly required.
- If the caller already runs under asyncio, use the UI framework's async runner rather than nesting `asyncio.run()`.
- Key handlers never block on REST.
- Exercise the full-screen app in a PTY, quit through the normal binding, and require exit 0.
- Provide a noninteractive snapshot mode, but do not treat it as proof of full-screen event-loop integration.

## Verification Ladder

1. Pure reducer/selector/path tests.
2. Syntax, type, and compile checks.
3. API-backed snapshot and read-only route sweep.
4. Real browser DOM and responsive screenshots.
5. Actual unpacked extension worker, popup, and Options.
6. Actual WebSocket event with relevant and unrelated entity traffic.
7. Temporary protected mutation with cleanup (`N → N+1 → N`).
8. Full-screen PTY launch and clean exit.
9. Focused security scan and independent logic review.
10. Final canonical test command after the last source edit.

## Reference

See `references/wehax-vector-ledger-hardening.md` for a verified case study covering global event envelopes, process-local snapshot loss, per-finding action routing, MV3 suspension, extension testing, and PTY verification.
