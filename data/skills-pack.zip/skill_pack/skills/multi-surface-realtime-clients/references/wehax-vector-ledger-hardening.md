# WeHaX VECTOR LEDGER Hardening Case Study

This case study records verified details from a dashboard + MV3 extension + prompt_toolkit TUI redesign over one FastAPI backend. Use the parent skill for general rules.

## Contract discovered

- Persistent HTTP state: scan index/detail/summary/findings/assets/evidence.
- Per-scan snapshot: `GET /scans/{scan_id}/snapshot`.
- Selected-scan socket: `WS /ws/{scan_id}`.
- Global fan-out implementation: the selected-scan WebSocket subscribes to a process-global bus and clients filter events.
- Per-finding probe reverify: `POST /scans/{scan_id}/findings/{finding_id}/reverify`.
- Batch/model verification is a different endpoint: `POST /scans/{scan_id}/verify`.

## Global envelope that broke live updates

Observed event:

```json
{
  "scan_id": "global",
  "seq": 3,
  "channel": "screenshots",
  "type": "new",
  "data": {"scan_id": "bab.sa-..."}
}
```

Both initial clients filtered only `event.scan_id === selectedScanId`, so sockets reported connected while all relevant global envelopes were discarded. The fix resolved the effective ID from `data.scan_id` only when the outer ID was missing or `global`.

A second bug sorted merged events by numeric `seq`. Global sequence `3` was treated as older than per-scan snapshot sequence `145255`, so live events would render at the wrong end. The fix preserved arrival order and deduplicated by outer source bus ID plus sequence.

End-to-end proof used a temporary bridge-protected one-pixel screenshot event:

1. Activity started with zero events after backend restart.
2. Upload emitted a nested global event.
3. Dashboard changed to one event and rendered the screenshot URL.
4. The artifact was deleted.
5. Evidence count returned to zero.

Concurrent traffic from another scan was rejected while the selected scan's nested event was accepted.

## Restart boundary

After restarting FastAPI:

- `/scans`, detail, summary, and findings rebuilt from disk.
- `/snapshot` returned 404 `scan bus not found` for historical scans.
- A fresh WebSocket connected but had only new process-global events.

The dashboard already used independent `Promise.allSettled` requests. The Python client called detail, summary, and snapshot sequentially and failed the entire workspace on snapshot 404. Snapshot retrieval was made optional only for 404; other failures still propagate.

## Requested TUI selection bug

The TUI was instantiated with a requested scan ID while its scan list was initially empty. Later `update_scans()` ignored the pending requested ID and selected the active scan. Constructor tests passed because they supplied scans immediately.

Regression shape:

```python
state = TUIState(requested_scan="historical")
state.update_scans(scans_with_live_and_historical)
assert state.selected_scan_id == "historical"
```

Keep the requested ID until that exact record is selected during the asynchronous index load.

## TUI event-loop and stale-response bugs

- Calling prompt_toolkit `Application.run()` inside an async CLI dispatcher raised `RuntimeError: asyncio.run() cannot be called from a running event loop`. The shared entry uses `run_async()`.
- Tab handlers performed synchronous REST under the render lock. They were changed to local route transitions plus background fetch.
- Route responses captured scan ID and route, fetched without the lock, and committed only if both still matched.
- Full-screen PTY verification caught issues that snapshot mode could not. Acceptance required selected scan/system rendering, normal `q`, and exit 0.

## Action-route mismatch

The TUI advertised `:reverify` and posted to nonexistent `/scans/{id}/reverify`. OpenAPI showed only per-finding probe reverify plus a semantically different batch/model verify endpoint.

Fix:

- Display finding IDs.
- Require `:reverify <positive finding_id>`.
- Use a tested URL builder.
- Dashboard finding detail uses the same per-finding route behind a review dialog.
- UI text says current backend probe verifier, not independent attestation.

## Lifecycle capability gating

Page Lens matched completed scans and showed “Add page context,” but `/command` requires a live orchestrator and returned 404. The popup view model now exposes `canAddContext` based on live lifecycle status. Evidence capture remains available for completed scans.

## MV3 suspension baseline

The worker kept prior scan state in a module-level `Map`, which is lost on suspension. The fixed worker stores a minimal `scanStateBaseline` in `chrome.storage.local`:

```text
scan_id, domain, status, vuln_count
```

Transition tests cover running→completed, confirmed-count increase, and no notifications for records first seen during baseline initialization.

## Extension verification path

Branded Google Chrome reported that command-line `--disable-extensions-except` was ignored. Chrome for Testing from the Playwright cache successfully loaded the unpacked extension in a temporary profile.

Verification required:

- A service worker URL ending in the project's `background.js` (not any extension worker).
- Shared globals loaded in that worker.
- Popup and Options real titles and zero page errors.
- Contextual target matching.
- Terminal-workspace action gating.
- Persisted baseline in extension-local storage.
- Zero horizontal overflow.

## Tests added

- Nested global envelope acceptance and unrelated rejection.
- Independent sequence-space collision.
- Event records and dedupe keys bounded together.
- Historical snapshot 404 fallback.
- Stale route response rejection.
- Requested selection surviving empty boot state.
- Exact per-finding reverify path.
- Terminal scan action gating.
- MV3 notification transition persistence semantics.

The final test ladder included Node behavior tests, targeted pytest, standalone async integration scripts, design lint, focused security scans, a live browser route/action review, actual MV3 loading, a controlled event upload/delete, WebSocket mixed-traffic filtering, and a full-screen PTY exit.
