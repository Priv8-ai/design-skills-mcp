# Tool Routing — Capability-First Execution

Use this reference when a UI task depends on browser inspection, media creation, deployment, or an unfamiliar host. Choose tools by capability and contract rather than by product name.

## Contents

1. Capability inventory
2. Routing order
3. Media operations
4. Browser and visual validation
5. Deployment
6. Permission and failure handling

## 1. Capability inventory

At the start of the task, mark each capability as available, unavailable, or approval-gated:

| Capability | Typical use | Minimum safe contract |
|---|---|---|
| File read/search | inspect project and references | preserve unrelated user files |
| File edit/patch | implement UI | edit the smallest relevant scope |
| Shell/build | install, build, test, package | inspect commands and working directory first |
| Browser/preview | render and interact | do not submit or publish without request |
| Screenshot/image inspection | compare layout and references | verify the actual rendered artifact |
| Web research | current docs, standards, assets | prefer primary sources and honor licenses |
| Image retrieval | editorial or product imagery | keep source/usage rights clear |
| Image generation/editing | custom art, mockups, cutouts | ask before paid or bulk generation |
| Video/3D generation | hero loops or spatial assets | estimate cost and payload first |
| Deployment/hosting | publish a working build | require explicit user intent and verify rollback |

Do not infer a capability from a familiar product name. Inspect the tools the host actually exposes.

## 2. Routing order

Use this order:

1. Reuse repository-local assets, components, and scripts.
2. Use a host-native capability already available for the task.
3. Use an installed connector or MCP tool that matches the capability.
4. Use a local deterministic fallback.
5. Ask the user only when the missing capability blocks a material requirement.

Never fabricate a tool call, tool result, URL, screenshot, or successful deployment. If a preferred provider is unavailable, continue with the next valid route and disclose any material difference.

## 3. Media operations

Map the intent to the narrowest operation:

| Intent | Preferred operation | Fallback |
|---|---|---|
| Understand an attachment | image/file inspection | ask the user to reattach if inaccessible |
| Find factual/reference imagery | licensed image search or web research | repository assets or procedural art |
| Create a new hero illustration | image generation | CSS/SVG/canvas composition |
| Modify an existing visual | image editing with the source attached | rebuild as code only if the user permits |
| Remove a background | background-removal/edit tool | CSS mask only for simple geometric subjects |
| Produce icons | code-native SVG when precision matters | generated raster only for illustrative icons |
| Produce a data diagram | HTML/SVG/chart library | never use generative imagery for exact data |

Before paid generation, bulk generation, video, or 3D, present the shot list and ask for approval unless the user's request already clearly authorizes it. Do not put provider credentials in generated client code.

## 4. Browser and visual validation

When a browser or preview is available:

1. start the project's documented development command;
2. wait for a healthy URL;
3. inspect console and network failures;
4. capture representative mobile and desktop views;
5. interact with navigation, forms, overlays, and primary flows;
6. compare against the brief and reference images;
7. iterate and repeat the affected checks.

When only screenshots are available, inspect them but do not claim interaction coverage. When no renderer is available, run build/static checks and state that visual QA remains unverified.

## 5. Deployment

Deploy only after an explicit request. Prefer:

1. the repository's existing deployment workflow;
2. an already-connected hosting provider selected by the user;
3. a reversible preview deployment;
4. documented manual steps when no deployment capability exists.

Before any production write, resolve the target project, branch, environment, and public URL. After deployment, read back the deployment state and open the URL when possible.

## 6. Permission and failure handling

- Treat payment, external writes, account changes, and publication as explicit boundaries.
- Preserve the host's sandbox and approval model; do not work around denied access.
- If a tool fails, inspect the error, retry only when safe and likely transient, then use a fallback.
- Do not replace a required capability with a lower-quality route when that would violate the user's acceptance criteria; stop and explain the blocker.

## iOS/Xcode verification cautions

- SwiftUI clipping does not reliably constrain hit-testing bounds. A scaled decorative image can invisibly intercept sibling controls on a tablet even when the phone works. Compare accessibility frames with rendered bounds; apply `.allowsHitTesting(false)` and `.accessibilityHidden(true)` to decorative background layers, not to interactive content.
- Await the newly presented destination/control before the next XCTest action. A control found during a modal transition may not yet accept the intended tap. Investigate traces/screenshots before rewriting navigation or weakening assertions.
- For landscape evidence, await a landscape window frame and capture `XCUIScreen.main.screenshot()`; an app-cropped screenshot during rotation can produce misleading black/cropped images.
- Keep simulator signing enabled for real Keychain-backed integration tests. An unsigned command-line probe is not a substitute for a correctly signed iOS test host.
- Distinguish build, signing, installation, foreground launch and hardware behavior. A successful install on a locked phone is not a successful launch. Require the user to unlock; do not attempt to bypass the lock.
- Cached development certificates/profiles can sign an ordinary app while Xcode still reports `No Accounts` when requesting a new restricted capability. Verify the actual requested entitlement/profile; simulator entitlements do not establish device or vehicle support.
- Use a separate local StoreKit test configuration and establish `.xcode` transaction environment before invoking a purchase path. `notEntitled`/configuration errors are test-environment blockers, not green purchase tests. Never substitute a fake entitlement, real charge or automated Apple login to make the test pass.
