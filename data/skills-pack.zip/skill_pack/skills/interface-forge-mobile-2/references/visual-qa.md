# Visual QA — Render, Interact, Measure

Use this reference after implementation and after every material visual change. Verification depth must match the available tools and the risk of the surface.

## Contents

1. Build and runtime checks
2. Viewport matrix
3. Interaction checks
4. Accessibility checks
5. State and content checks
6. Performance checks
7. Evidence and handoff

## 1. Build and runtime checks

Run the project's relevant build, typecheck, lint, and focused tests. Then inspect the rendered app for:

- uncaught console errors and warnings;
- hydration failures;
- missing assets, fonts, and API responses;
- layout shifts during load;
- broken route transitions;
- cleanup errors after navigation;
- WebGL context loss or memory growth when applicable.

Do not suppress errors to make the preview look clean. Fix the cause or report a real blocker.

## 2. Viewport matrix

Use the smallest representative set that covers layout changes:

| Surface | Minimum viewports |
|---|---|
| Responsive web | 320×568, 375×812, 768×1024, 1440×900 |
| Mobile-first/PWA | 375×667 and 430×932, portrait plus one landscape check |
| Dashboard | 1024×768 and 1440×900; verify collapsed navigation |
| Native mobile | smallest and largest supported device classes with text scaling |
| Embedded widget | minimum documented container and a wide container |

At each breakpoint inspect the first viewport, longest content section, navigation, forms, overlays, footer/tab bar, and any pinned or horizontal sequence.

## 3. Interaction checks

- Traverse every visible navigation target and primary CTA.
- Exercise hover, active, focus-visible, disabled, loading, success, and error states.
- Submit forms with empty, invalid, and valid values.
- Open and dismiss menus/dialogs/sheets by every promised method.
- Confirm focus moves into overlays, stays trapped when modal, and returns to the trigger.
- Test Escape, browser/system Back, and keyboard-only operation.
- Verify pointer effects do not block clicks and touch surfaces do not depend on hover.

## 4. Accessibility checks

Use automated checks when available, then manually verify:

- landmarks and heading order;
- accessible names for icons and controls;
- labels, instructions, errors, and status announcements;
- text contrast ≥4.5:1 and large text ≥3:1;
- non-text/control contrast ≥3:1 where required;
- visible focus and sensible focus order;
- 44×44 CSS px touch targets where touch is expected;
- 200% zoom and text spacing without content loss;
- inspect native navigation labels at maximum Dynamic Type even when UI tests pass: existence/tappability assertions do not detect ellipsized labels. Adapt the layout, or deliberately bound navigation-chrome scaling and provide full accessibility names plus the platform Large Content Viewer; do not cap body/form scaling to hide layout defects;
- native Form/List rows may be virtualized outside a small-device viewport. Scroll the real container and await the target before asserting its state; do not weaken validation assertions merely because a row has not been materialized;
- reduced motion, forced colors, and screen-reader semantics;
- no information conveyed by color, motion, or position alone.

## 5. State and content checks

Use realistic short, long, empty, and localized content. Confirm:

- loading skeletons resemble final geometry;
- empty states explain the next action;
- errors preserve user input and offer recovery;
- optimistic actions reconcile or roll back;
- numbers, dates, currency, and pluralization are locale-aware;
- RTL mirrors layout and directional icons without reversing media that should remain unchanged;
- user-generated content cannot break the layout.

## 6. Performance checks

For ordinary pages, check the project's existing performance budget. For media/motion-heavy work, also verify:

- hero media is correctly sized and prioritized;
- noncritical media lazy-loads and reserves space;
- animation avoids layout work in continuous loops;
- scroll handlers are passive and rate-limited or rAF-coordinated;
- long tasks do not appear during primary interaction;
- hidden/offscreen animations pause;
- WebGL DPR is capped, textures/meshes are bounded, and resources dispose after navigation;
- reduced-data and reduced-motion paths remain complete.

Prefer measured results over generic scores. Record the environment and distinguish lab estimates from real-user data.

## 7. Evidence and handoff

Report:

1. commands/checks actually run;
2. viewports/devices actually inspected;
3. primary flows exercised;
4. defects fixed during QA;
5. checks not possible in the current environment;
6. any remaining risk with a concrete next action.

Do not say "pixel-perfect," "fully accessible," or "production-ready" without evidence proportional to that claim.
