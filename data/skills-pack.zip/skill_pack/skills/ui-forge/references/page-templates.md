# Page Templates — Complete Multi-Page Delivery Contract

When the user asks for "the full UI", "complete pages", "a whole template", or builds an app/product site, deliver a COMPLETE page set — never a single hero page with placeholder links. This file defines what "complete" means per product type and gives skeletons for every secondary page.

---

## 1. Completeness rules

1. **Every nav item and CTA on a page must resolve to a real page/state.** Dead links and `#` hrefs are a defect. In static previews, use hash routing or in-app navigation so every route works.
2. **Minimum viable complete set:** primary page + every page reachable in one click from it + auth (if the product has accounts) + 404/empty states.
3. **Shared chrome is identical across pages:** same navbar, footer, tokens, motion system. Extract it once, reuse everywhere.
4. **Each page still gets ONE dominant element** and the full Phase 2 theme — secondary pages are not excuses for plain design.
5. **States, not just screens:** every list/table ships with loading skeleton, empty state, and error state; every form ships with validation + success feedback.

## 2. Page-set matrix (pick the product row, build ALL its pages)

| Product | Required pages |
|---|---|
| Marketing / landing site | Home · Features/Product · Pricing · About/Story · Blog index + post · Contact · Legal (privacy/terms) · 404 |
| SaaS app | Landing · Login · Signup · Forgot password · Onboarding wizard · Dashboard home · Core feature pages (2–4) · Settings (profile/billing/notifications) · Empty + error states |
| Mobile app UI | Onboarding (3–5 slides) · Login/OTP · Home tab · 2–4 remaining tabs · Key detail screen · Sheet/modal flows · Profile/settings — per `mobile-ui-patterns.md` |
| E-commerce | Home · Category/grid · Product detail · Cart · Checkout (address → payment → confirm) · Order success · Account/orders · 404 |
| Dashboard / admin / AI console | Login · Overview (KPIs + charts) · Data table page (filter/sort/paginate) · Detail/entity page · Live activity or console feed · Settings · Empty/error states |
| Portfolio | Home · Work index · Case-study detail · About · Contact · 404 |
| Docs / knowledge base | Docs home (search hero) · Article page (sidebar TOC, prev/next) · Changelog · 404 |

## 3. Secondary page skeletons

### 3.1 Pricing
Eyebrow + headline → billing toggle (monthly/yearly, yearly shows "save 20%") → 3 tier cards (middle elevated: accent border, scale-105, "Most popular" pill) → feature checklist rows with ✓ → FAQ accordion → final CTA band. Award-level: toggle animates prices counting; recommended card has slow ambient glow.

### 3.2 Auth (login / signup / forgot)
Split layout: left = form card (logo, headline "Welcome back", social buttons → divider → email/password → submit → footer link swap login/signup), right = brand panel with product visual or animated gradient. Mobile: form only, brand panel becomes a compact header. Award-level: inputs float labels; submit button morphs to spinner → success check → redirect.

### 3.3 Onboarding wizard (app setup)
3–5 steps, top progress bar or dots, one question per screen, big selectable cards/chips, Back ghost + Continue primary (disabled until valid), final "All set" celebration (confetti or scale-in check). Skippable.

### 3.4 Settings
Sidebar section list (desktop) / inset grouped list (mobile) → panels: Profile (avatar upload, fields), Account (email, password, delete — danger zone separated, red), Notifications (toggle rows), Billing (plan card + invoices table), API/Integrations (key rows with copy + reveal). Award-level: unsaved-changes bar slides up ("Save / Discard").

### 3.5 Data table page
Header (title + primary action "New X") → toolbar (search, filter chips, sort, column toggle) → table (sticky header, row hover, status pill cells, row actions ⋮) → pagination or infinite scroll. States: skeleton rows, empty ("No X yet" + CTA), error banner with retry.

### 3.6 Detail / entity page
Breadcrumb → title row (name + status pill + actions) → stat cards row → tabbed body (Overview / Activity / Settings) → right rail (meta, assignees, timestamps) on desktop, stacked on mobile.

### 3.7 Blog index + post
Index: featured post card (large) + grid of cards (image 16:9, tag chip, title, date · read time). Post: centered 680–720px column, H1 + meta row, hero image, prose styles (h2 anchors, code blocks, pull quotes), author card, prev/next. Award-level: reading-progress hairline bar; headings reveal on scroll.

### 3.8 Contact / about
Contact: split — left headline + channels (email, socials, office), right form card (name/email/message) with inline validation + success state replacing the form. About: story timeline, values grid, team cards with hover photo treatment, stats band.

### 3.9 404 / empty / error
404: oversized display numeral (dominant element), one-line wit, "Back home" primary + search or popular links. Empty: icon 80px + headline + sub + CTA. Error: banner or full-page with retry button and reference ID.

### 3.10 Checkout (3 steps, single column)
Step indicator (1 Address → 2 Payment → 3 Review) → forms with validation → order summary card sticky right (desktop) / collapsible top (mobile) → success page: big animated check, order number, "Track order" + "Continue shopping".

## 4. Navigation between pages

- **React (webapp-building):** routes wired in App.tsx with the provided router — every page is a real component in `src/pages/`.
- **Vanilla HTML:** one folder, `index.html` links to sibling pages (`pricing.html`, …); identical header/footer markup on each; motion via `assets/motion-utils.js` auto-init.
- **Mobile shell:** bottom tab bar on every tab page; detail pages push over with back chevron (see `mobile-ui-patterns.md` §1.3).

## 5. Handoff checklist for "complete template" deliveries

1. Every route in the nav/footer/CTAs renders real content.
2. Shared chrome consistent; tokens identical on all pages.
3. Loading / empty / error states present on data pages.
4. 3D scroll layer on the primary page (unless opted out), lighter motion on utility pages (auth/settings get entrance transitions only).
5. All pages pass the Phase 5 quality gate + responsive check at 375px and 1440px.
