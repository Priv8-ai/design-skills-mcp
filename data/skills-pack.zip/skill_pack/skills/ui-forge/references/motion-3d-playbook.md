# Motion & 3D Playbook — Copy-Paste Recipes

Every recipe: real code, when to use, performance note, and a `prefers-reduced-motion` fallback. Golden rules: animate ONLY `transform` + `opacity`; use `will-change` sparingly; lazy-mount heavy layers; never animate more than 8 staggered items.

## Contents

- **Motion tokens (use these everywhere)**
- **1. Smooth scroll setup (Lenis + GSAP ScrollTrigger)** — React wiring · Vanilla wiring
- **2. 3D scroll effects** — 2a. Perspective card tilt on scroll · 2b. Horizontal scroll-jacked section · 2c. Z-depth parallax layers (CSS perspective + translateZ) · 2d. Scroll-driven camera dolly (CSS) · 2e. R3F ScrollControls variant (true 3D — only when explicitly requested)
- **3. Hero entrance choreography** — 3a. Staggered word reveal + clip-path mask (GSAP) · 3b. Blur-in entrance (Framer Motion)
- **4. Animated navigation** — 4a. Hide-on-scroll-down glass navbar · 4b. Scroll-progress indicator · 4c. Active-section underline morph · 4d. Mobile menu — 3D flip overlay + staggered links · 4e. Hamburger → X morph (pure CSS/SVG)
- **5. Buttons & micro-interactions** — 5a. Magnetic button (JS) · 5b. Ripple / shine sweep (pure CSS) · 5c. Gradient border spin · 5d. Press physics + success morph (Framer Motion) · 5e. Icon swap on hover (pure CSS)
- **6. Card interactions** — 6a. 3D tilt-on-hover with glare · 6b. Bento hover expansion · 6c. Image zoom + caption reveal
- **7. Scroll reveals** — 7a. Fade-up stagger (IntersectionObserver, framework-free) · 7b. Clip reveal (sections/images) · 7c. Counter animation (stats bands) · 7d. Marquee (logo cloud / ticker)
- **8. Ambient effects** — 8a. Aurora / mesh gradient background (pure CSS) · 8b. Grain overlay (premium texture on dark/gradient heroes) · 8c. Cursor glow follower · 8d. Floating particles (canvas)
- **9. Three.js scroll world (premium tier)** — escalation criteria · quickstart · full playbook pointer
- **10. Particle ambient effects (packaged)** — 10a. Falling leaves · 10b. Pointer trail emitter · 10c. Floating orbs
- **Recipe cheat-sheet**


## Motion tokens (use these everywhere)

```css
:root {
  --dur-micro: 150ms;  /* hover/press (120–200ms) */
  --dur-ui: 300ms;     /* cards, sheets (250–350ms) */
  --dur-hero: 700ms;   /* entrances (500–800ms) */
  --ease-out-expo: cubic-bezier(0.16, 1, 0.3, 1);   /* default entrance/UI curve */
  --ease-spring: cubic-bezier(0.34, 1.56, 0.64, 1); /* overshoot for playful press */
  --ease-in-out: cubic-bezier(0.65, 0, 0.35, 1);
}
/* Stagger formula: delay = index * 50ms (40–60ms range), max 8 items.
   GSAP: stagger: 0.05 — CSS: transition-delay: calc(var(--i) * 50ms) */
```

Global reduced-motion safety net (include in every project):

```css
@media (prefers-reduced-motion: reduce) {
  *, *::before, *::after {
    animation-duration: 0.01ms !important;
    animation-iteration-count: 1 !important;
    transition-duration: 0.01ms !important;
  }
  html { scroll-behavior: auto; }
}
```

---

## 1. Smooth scroll setup (Lenis + GSAP ScrollTrigger)

**When:** every premium page. Lenis gives inertial scroll; ScrollTrigger must be synced to Lenis's ticker.
**Performance:** Lenis uses rAF + transform on the scroller — GPU friendly. Don't combine with `scroll-behavior: smooth`.

### React wiring

```bash
npm i lenis gsap
```

```jsx
// hooks/useSmoothScroll.js
import { useEffect } from "react";
import Lenis from "lenis";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";

gsap.registerPlugin(ScrollTrigger);

export function useSmoothScroll() {
  useEffect(() => {
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;

    const lenis = new Lenis({ lerp: 0.1, smoothWheel: true });
    lenis.on("scroll", ScrollTrigger.update);          // keep triggers in sync

    const tick = (time) => lenis.raf(time * 1000);     // gsap ticker drives lenis
    gsap.ticker.add(tick);
    gsap.ticker.lagSmoothing(0);

    return () => {
      gsap.ticker.remove(tick);
      lenis.destroy();
    };
  }, []);
}
```

### Vanilla wiring

```html
<script src="https://cdn.jsdelivr.net/npm/gsap@3.12.5/dist/gsap.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/gsap@3.12.5/dist/ScrollTrigger.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/lenis@1.1.14/dist/lenis.min.js"></script>
<script>
  gsap.registerPlugin(ScrollTrigger);
  if (!matchMedia("(prefers-reduced-motion: reduce)").matches) {
    const lenis = new Lenis({ lerp: 0.1 });
    lenis.on("scroll", ScrollTrigger.update);
    gsap.ticker.add((t) => lenis.raf(t * 1000));
    gsap.ticker.lagSmoothing(0);
  }
</script>
```

**Reduced-motion fallback:** skip Lenis entirely (native scroll stays).

---

## 2. 3D scroll effects

### 2a. Perspective card tilt on scroll
**When:** hero screenshots, pricing cards — product UI that "rises up" as you scroll into it.
**Performance:** one transform per card; wrap in a `perspective` parent, not `transform-style` chains.

```html
<div class="tilt-stage">
  <div class="tilt-card"><img src="/dashboard.png" alt="Dashboard" /></div>
</div>
<style>
  .tilt-stage { perspective: 1200px; }
  .tilt-card {
    border-radius: 24px; overflow: hidden; box-shadow: var(--shadow-3);
    transform: rotateX(18deg) scale(0.94); transform-origin: center top;
    will-change: transform;
  }
  @media (prefers-reduced-motion: reduce) { .tilt-card { transform: none; } }
</style>
<script>
  if (!matchMedia("(prefers-reduced-motion: reduce)").matches) {
    gsap.to(".tilt-card", {
      rotateX: 0, scale: 1, ease: "none",
      scrollTrigger: { trigger: ".tilt-stage", start: "top 90%", end: "top 30%", scrub: 0.6 },
    });
  }
</script>
```

### 2b. Horizontal scroll-jacked section
**When:** showcasing 3–5 panels (features, case studies). Pin the section, translate the track horizontally.
**Performance:** translateX on one track only. **Mobile/reduced-motion: degrade to a vertical stack (media query + `ScrollTrigger.matchMedia`).**

```html
<section class="hscroll">
  <div class="hscroll-track">
    <article class="hpanel">…panel 1…</article>
    <article class="hpanel">…panel 2…</article>
    <article class="hpanel">…panel 3…</article>
  </div>
</section>
<style>
  .hscroll { overflow: hidden; }
  .hscroll-track { display: flex; gap: 24px; padding: 0 24px; will-change: transform; }
  .hpanel { flex: 0 0 70vw; max-width: 720px; height: 70vh; border-radius: 24px; }
  @media (max-width: 768px), (prefers-reduced-motion: reduce) {
    .hscroll-track { flex-direction: column; }
    .hpanel { flex: none; width: 100%; height: auto; }
  }
</style>
<script>
  const mm = gsap.matchMedia();
  mm.add("(min-width: 769px) and (prefers-reduced-motion: no-preference)", () => {
    const track = document.querySelector(".hscroll-track");
    gsap.to(track, {
      x: () => -(track.scrollWidth - window.innerWidth),
      ease: "none",
      scrollTrigger: {
        trigger: ".hscroll", pin: true, scrub: 1,
        end: () => "+=" + (track.scrollWidth - window.innerWidth),
        invalidateOnRefresh: true,
      },
    });
  });
</script>
```

### 2c. Z-depth parallax layers (CSS perspective + translateZ)
**When:** hero backgrounds — orbs/blobs/chips floating at different depths. Pure CSS transform, JS-free parallax on scroll is impossible, so pair with a tiny ScrollTrigger scrub or scroll listener.
**Performance:** layers use translateZ (GPU-composited); limit to 3–4 decorative layers; parallax rate 0.2–0.4.

```html
<div class="depth-scene">
  <div class="layer layer-back"></div>   <!-- big blurred orb -->
  <div class="layer layer-mid"></div>    <!-- smaller orb -->
  <div class="layer layer-front"></div>  <!-- chip -->
</div>
<style>
  .depth-scene { position: absolute; inset: 0; perspective: 1000px; overflow: hidden; pointer-events: none; }
  .layer { position: absolute; border-radius: 50%; will-change: transform; }
  .layer-back  { inset: 10% 50% 30% -10%; background: radial-gradient(circle, var(--accent) 0%, transparent 70%); opacity: .25; filter: blur(60px); transform: translateZ(-300px) scale(1.4); }
  .layer-mid   { inset: 40% -5% 10% 60%; background: radial-gradient(circle, #8B5CF6 0%, transparent 70%); opacity: .2; filter: blur(50px); transform: translateZ(-150px) scale(1.2); }
  .layer-front { width: 120px; height: 120px; right: 12%; top: 20%; background: var(--glass, rgba(255,255,255,.1)); backdrop-filter: blur(12px); border-radius: 24px; transform: translateZ(60px); }
</style>
<script>
  if (!matchMedia("(prefers-reduced-motion: reduce)").matches) {
    gsap.to(".layer-back",  { yPercent: 20, ease: "none", scrollTrigger: { trigger: ".depth-scene", start: "top top", end: "bottom top", scrub: true } });
    gsap.to(".layer-mid",   { yPercent: 35, ease: "none", scrollTrigger: { trigger: ".depth-scene", start: "top top", end: "bottom top", scrub: true } });
    gsap.to(".layer-front", { yPercent: -25, ease: "none", scrollTrigger: { trigger: ".depth-scene", start: "top top", end: "bottom top", scrub: true } });
  }
</script>
```

### 2d. Scroll-driven camera dolly (CSS)
**When:** a hero visual that the user "flies into" — headline scales away, product scales up.
**Performance:** two elements scaling; keep `transform-origin` fixed.

```html
<section class="dolly">
  <h1 class="dolly-title">Enter the studio</h1>
  <div class="dolly-target"><img src="/product.jpg" alt="Product" /></div>
</section>
<style>
  .dolly { min-height: 200vh; }
  .dolly-title { position: sticky; top: 35vh; text-align: center; font-size: var(--fs-display); will-change: transform, opacity; }
  .dolly-target { position: sticky; top: 15vh; margin: 0 auto; width: min(70vw, 900px); border-radius: 24px; overflow: hidden; will-change: transform; }
</style>
<script>
  if (!matchMedia("(prefers-reduced-motion: reduce)").matches) {
    const tl = gsap.timeline({ scrollTrigger: { trigger: ".dolly", start: "top top", end: "bottom bottom", scrub: 0.8 } });
    tl.to(".dolly-title", { scale: 1.6, opacity: 0, ease: "none" }, 0)
      .fromTo(".dolly-target", { scale: 0.6, borderRadius: "48px" }, { scale: 1, borderRadius: "24px", ease: "none" }, 0);
  }
</script>
```

### 2e. R3F ScrollControls variant (true 3D — only when explicitly requested)
**When:** the user asks for real WebGL scenes. **Performance:** mount `<Canvas>` lazily (IntersectionObserver), cap `dpr={[1, 2]}`, pause rendering off-screen with `frameloop="demand"`. Reduced motion: render a static frame (`frameloop="never"` + one `invalidate()`).

```bash
npm i three @react-three/fiber @react-three/drei
```

```jsx
import { Canvas } from "@react-three/fiber";
import { ScrollControls, Scroll, useScroll, Float } from "@react-three/drei";
import { useRef } from "react";
import { useFrame } from "@react-three/fiber";

function HeroModel() {
  const mesh = useRef(null);
  const scroll = useScroll();               // 0..1 across ScrollControls pages
  useFrame(() => {
    const r = scroll.range(0, 1);           // dolly in as user scrolls
    mesh.current.position.z = -4 + r * 3;
    mesh.current.rotation.y = r * Math.PI;
  });
  return (
    <mesh ref={mesh}>
      <torusKnotGeometry args={[1, 0.3, 200, 32]} />
      <meshStandardMaterial color="#8B5CF6" roughness={0.2} metalness={0.8} />
    </mesh>
  );
}

export default function Scene3D() {
  return (
    <Canvas dpr={[1, 2]} frameloop="demand" camera={{ position: [0, 0, 5], fov: 45 }}>
      <ambientLight intensity={0.6} />
      <directionalLight position={[4, 4, 4]} intensity={1.2} />
      <ScrollControls pages={3} damping={0.2}>
        <Float speed={1.5} floatIntensity={1.2}>
          <HeroModel />
        </Float>
        <Scroll html>
          <h1 style={{ fontSize: "clamp(48px,7vw,96px)", letterSpacing: "-0.03em" }}>True depth.</h1>
        </Scroll>
      </ScrollControls>
    </Canvas>
  );
}
```

---

## 3. Hero entrance choreography

**When:** every hero, on page load. Sequence: eyebrow → H1 words (stagger) → sub → CTAs → media.
**Performance:** transform+opacity only; total ≤ 1.2s. Reduced motion: everything visible, no animation (guard with `gsap.matchMedia`).

### 3a. Staggered word reveal + clip-path mask (GSAP)

```html
<p class="hero-eyebrow">Now in public beta</p>
<h1 class="hero-title"><span class="line"><span class="word">Design</span> <span class="word">beyond</span></span>
   <span class="line"><span class="word">the</span> <span class="word">screen</span></span></h1>
<p class="hero-sub">Interfaces that feel alive.</p>
<div class="hero-ctas"><a class="btn-primary" href="#">Start</a></div>
<style>
  .hero-title .line { display: block; overflow: hidden; }       /* mask */
  .hero-title .word { display: inline-block; transform: translateY(110%); will-change: transform; }
  .hero-eyebrow, .hero-sub, .hero-ctas { opacity: 0; transform: translateY(20px); }
</style>
<script>
  const mm = gsap.matchMedia();
  mm.add("(prefers-reduced-motion: no-preference)", () => {
    const tl = gsap.timeline({ defaults: { duration: 0.7, ease: "expo.out" } });
    tl.to(".hero-eyebrow", { opacity: 1, y: 0 })
      .to(".hero-title .word", { y: 0, stagger: 0.06, duration: 0.8 }, "-=0.4")
      .to(".hero-sub", { opacity: 1, y: 0 }, "-=0.5")
      .to(".hero-ctas", { opacity: 1, y: 0 }, "-=0.55");
    return () => tl.kill();
  });
  mm.add("(prefers-reduced-motion: reduce)", () => {
    gsap.set(".hero-eyebrow,.hero-sub,.hero-ctas", { opacity: 1, y: 0 });
    gsap.set(".hero-title .word", { y: 0 });
  });
</script>
```

### 3b. Blur-in entrance (Framer Motion)

```jsx
import { motion } from "framer-motion";

const container = { hidden: {}, show: { transition: { staggerChildren: 0.08, delayChildren: 0.1 } } };
const item = {
  hidden: { opacity: 0, y: 24, filter: "blur(8px)" },
  show: { opacity: 1, y: 0, filter: "blur(0px)", transition: { duration: 0.7, ease: [0.16, 1, 0.3, 1] } },
};

export function HeroCopy() {
  return (
    <motion.div variants={container} initial="hidden" animate="show">
      <motion.p variants={item} className="text-eyebrow uppercase text-accent">New</motion.p>
      <motion.h1 variants={item} className="text-display">Design beyond the screen</motion.h1>
      <motion.p variants={item} className="text-muted">Interfaces that feel alive.</motion.p>
    </motion.div>
  );
}
// Framer Motion auto-respects prefers-reduced-motion for transform/opacity
// when wrapped in <MotionConfig reducedMotion="user">.
```

---

## 4. Animated navigation

### 4a. Hide-on-scroll-down glass navbar
**When:** long marketing pages. Show on scroll up, hide on scroll down, glass blur after 24px.
**Performance:** toggles one class; transform transition only.

```html
<header id="navbar" class="navbar">
  <a class="logo" href="#">forge.</a>
  <nav class="links"><a href="#features">Features</a><a href="#pricing">Pricing</a></nav>
  <a class="btn-primary" href="#">Get started</a>
</header>
<style>
  .navbar {
    position: fixed; inset: 0 0 auto 0; z-index: 50; height: 64px;
    display: flex; align-items: center; justify-content: space-between; padding: 0 24px;
    border-bottom: 1px solid transparent;
    transition: transform var(--dur-ui) var(--ease-out-expo), background var(--dur-ui), border-color var(--dur-ui);
  }
  .navbar--scrolled { background: color-mix(in srgb, var(--bg) 70%, transparent); backdrop-filter: blur(12px); border-color: var(--border); }
  .navbar--hidden { transform: translateY(-100%); }
</style>
<script>
  (() => {
    const nav = document.getElementById("navbar");
    let lastY = window.scrollY;
    window.addEventListener("scroll", () => {
      const y = window.scrollY;
      nav.classList.toggle("navbar--scrolled", y > 24);
      nav.classList.toggle("navbar--hidden", y > 200 && y > lastY);
      lastY = y;
    }, { passive: true });
  })();
</script>
```

### 4b. Scroll-progress indicator

```html
<div class="scroll-progress" aria-hidden="true"></div>
<style>
  .scroll-progress {
    position: fixed; top: 0; left: 0; z-index: 60; height: 3px; width: 100%;
    background: linear-gradient(90deg, var(--accent), #8B5CF6);
    transform-origin: left; transform: scaleX(0); will-change: transform;
  }
</style>
<script>
  if (!matchMedia("(prefers-reduced-motion: reduce)").matches) {
    gsap.to(".scroll-progress", {
      scaleX: 1, ease: "none",
      scrollTrigger: { trigger: document.body, start: "top top", end: "max", scrub: 0.3 },
    });
  }
</script>
```

### 4c. Active-section underline morph
**When:** navbar links track the section in view; one shared underline slides/morphs between links.

```html
<nav class="navlinks">
  <a href="#features" class="active">Features</a><a href="#work">Work</a><a href="#pricing">Pricing</a>
  <span class="nav-underline"></span>
</nav>
<style>
  .navlinks { position: relative; display: flex; gap: 32px; }
  .navlinks a { padding: 8px 0; font-size: 15px; font-weight: 500; color: var(--muted); transition: color var(--dur-micro); }
  .navlinks a.active { color: var(--ink); }
  .nav-underline {
    position: absolute; bottom: 0; left: 0; height: 2px; width: 0; border-radius: 2px;
    background: var(--accent);
    transition: transform var(--dur-ui) var(--ease-out-expo), width var(--dur-ui) var(--ease-out-expo);
  }
</style>
<script>
  (() => {
    const nav = document.querySelector(".navlinks");
    const bar = nav.querySelector(".nav-underline");
    const links = [...nav.querySelectorAll("a")];
    function moveBar(link) {
      bar.style.width = link.offsetWidth + "px";
      bar.style.transform = `translateX(${link.offsetLeft}px)`;
    }
    const sections = links.map((a) => document.querySelector(a.hash));
    const io = new IntersectionObserver((entries) => {
      entries.forEach((e) => {
        if (!e.isIntersecting) return;
        links.forEach((a) => a.classList.toggle("active", a.hash === "#" + e.target.id));
        moveBar(nav.querySelector("a.active"));
      });
    }, { rootMargin: "-40% 0px -55% 0px" });
    sections.forEach((s) => s && io.observe(s));
    moveBar(links[0]);
  })();
</script>
```

### 4d. Mobile menu — 3D flip overlay + staggered links
**When:** mobile nav. Overlay flips open with perspective; links stagger up.

```html
<button id="burger" class="burger" aria-label="Menu" aria-expanded="false"><span></span><span></span><span></span></button>
<div id="mmenu" class="mmenu">
  <a href="#features" style="--i:0">Features</a>
  <a href="#work" style="--i:1">Work</a>
  <a href="#pricing" style="--i:2">Pricing</a>
  <a href="#contact" style="--i:3">Contact</a>
</div>
<style>
  .mmenu {
    position: fixed; inset: 0; z-index: 40; display: flex; flex-direction: column;
    align-items: center; justify-content: center; gap: 8px;
    background: var(--bg); transform: perspective(900px) rotateX(-8deg) translateY(-100%);
    transform-origin: top; transition: transform 500ms var(--ease-out-expo);
    visibility: hidden;
  }
  .mmenu.open { transform: perspective(900px) rotateX(0) translateY(0); visibility: visible; }
  .mmenu a {
    font-family: var(--font-display); font-size: clamp(32px, 8vw, 48px); font-weight: 700;
    letter-spacing: -0.02em; color: var(--ink); opacity: 0; transform: translateY(24px);
    transition: opacity 400ms var(--ease-out-expo), transform 400ms var(--ease-out-expo);
    transition-delay: calc(150ms + var(--i) * 60ms);
  }
  .mmenu.open a { opacity: 1; transform: translateY(0); }
  @media (prefers-reduced-motion: reduce) {
    .mmenu { transition: none; transform: translateY(-100%); }
    .mmenu.open { transform: none; }
    .mmenu a { transition: none; opacity: 1; transform: none; }
  }
</style>
<script>
  const burger = document.getElementById("burger");
  const mmenu = document.getElementById("mmenu");
  burger.addEventListener("click", () => {
    const open = mmenu.classList.toggle("open");
    burger.classList.toggle("open", open);
    burger.setAttribute("aria-expanded", String(open));
  });
</script>
```

### 4e. Hamburger → X morph (pure CSS/SVG)

```css
.burger { position: relative; z-index: 50; display: grid; gap: 5px; padding: 10px; background: none; border: 0; cursor: pointer; }
.burger span { display: block; width: 24px; height: 2px; border-radius: 2px; background: var(--ink);
  transition: transform var(--dur-ui) var(--ease-out-expo), opacity var(--dur-micro); }
.burger.open span:nth-child(1) { transform: translateY(7px) rotate(45deg); }
.burger.open span:nth-child(2) { opacity: 0; transform: scaleX(0); }
.burger.open span:nth-child(3) { transform: translateY(-7px) rotate(-45deg); }
```

---

## 5. Buttons & micro-interactions

### 5a. Magnetic button (JS)
**When:** hero primary CTAs — cursor pulls the button toward itself. Desktop only.
**Performance:** single rAF-driven transform; disable on touch + reduced motion.

```js
// Framework-agnostic; also in assets/motion-utils.js
export function magnetic(el, strength = 0.35) {
  if (window.matchMedia("(hover: none), (prefers-reduced-motion: reduce)").matches) return () => {};
  let raf = 0, tx = 0, ty = 0, cx = 0, cy = 0;
  const onMove = (e) => {
    const r = el.getBoundingClientRect();
    tx = (e.clientX - (r.left + r.width / 2)) * strength;
    ty = (e.clientY - (r.top + r.height / 2)) * strength;
  };
  const onLeave = () => { tx = 0; ty = 0; };
  const loop = () => {
    cx += (tx - cx) * 0.15;               // lerp = butter
    cy += (ty - cy) * 0.15;
    el.style.transform = `translate(${cx.toFixed(2)}px, ${cy.toFixed(2)}px)`;
    raf = requestAnimationFrame(loop);
  };
  el.addEventListener("mousemove", onMove);
  el.addEventListener("mouseleave", onLeave);
  raf = requestAnimationFrame(loop);
  return () => { cancelAnimationFrame(raf); el.removeEventListener("mousemove", onMove); el.removeEventListener("mouseleave", onLeave); };
}
```

### 5b. Ripple / shine sweep (pure CSS)

```css
.btn-primary { position: relative; overflow: hidden; height: 48px; padding: 0 24px; border: 0;
  border-radius: 999px; background: var(--accent); color: var(--accent-ink);
  font: 600 15px/1 var(--font-body); letter-spacing: -0.01em; cursor: pointer;
  transition: transform var(--dur-micro) var(--ease-out-expo), box-shadow var(--dur-micro), filter var(--dur-micro); }
.btn-primary:hover { filter: brightness(1.06); transform: translateY(-1px); box-shadow: var(--shadow-2); }
.btn-primary::after {                       /* shine sweep */
  content: ""; position: absolute; inset: 0;
  background: linear-gradient(105deg, transparent 40%, rgba(255,255,255,.45) 50%, transparent 60%);
  transform: translateX(-120%);
}
.btn-primary:hover::after { transform: translateX(120%); transition: transform 600ms var(--ease-out-expo); }
@media (prefers-reduced-motion: reduce) { .btn-primary::after { display: none; } }
```

### 5c. Gradient border spin

```css
.btn-border-spin { position: relative; border-radius: 999px; padding: 2px; border: 0; background:
  conic-gradient(from var(--spin, 0deg), #3B4BF0, #8B5CF6, #22D3EE, #3B4BF0);
  animation: border-spin 3s linear infinite; cursor: pointer; }
.btn-border-spin > span { display: block; border-radius: 999px; background: var(--bg); color: var(--ink);
  padding: 12px 22px; font: 600 15px/1 var(--font-body); }
@property --spin { syntax: "<angle>"; initial-value: 0deg; inherits: false; }
@keyframes border-spin { to { --spin: 360deg; } }
@media (prefers-reduced-motion: reduce) { .btn-border-spin { animation: none; } }
```

### 5d. Press physics + success morph (Framer Motion)

```jsx
import { motion } from "framer-motion";
import { useState } from "react";

export function BuyButton() {
  const [done, setDone] = useState(false);
  return (
    <motion.button
      onClick={() => setDone(true)}
      whileHover={{ y: -1, filter: "brightness(1.06)" }}
      whileTap={{ scale: 0.94 }}
      animate={done ? { backgroundColor: "#16A34A", width: 180 } : { width: 160 }}
      transition={{ type: "spring", stiffness: 500, damping: 30 }}
      style={{ height: 48, borderRadius: 999, border: 0, cursor: "pointer",
               background: "var(--accent)", color: "#fff", fontWeight: 600 }}
    >
      <motion.span
        key={String(done)}
        initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.2 }}
      >
        {done ? "✓ Added" : "Add to cart"}
      </motion.span>
    </motion.button>
  );
}
```

### 5e. Icon swap on hover (pure CSS)

```css
.link-arrow { display: inline-flex; align-items: center; gap: 6px; font-weight: 500; color: var(--ink); }
.link-arrow .ic { position: relative; width: 16px; height: 16px; overflow: hidden; }
.link-arrow .ic svg { position: absolute; inset: 0; transition: transform var(--dur-ui) var(--ease-out-expo); }
.link-arrow .ic svg:last-child { transform: translate(-120%, 120%); }
.link-arrow:hover .ic svg:first-child { transform: translate(120%, -120%); }
.link-arrow:hover .ic svg:last-child { transform: translate(0, 0); }
```

```html
<a class="link-arrow" href="#">Read the story
  <span class="ic">
    <svg viewBox="0 0 16 16" width="16" height="16" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M3 13 13 3M5 3h8v8"/></svg>
    <svg viewBox="0 0 16 16" width="16" height="16" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M3 13 13 3M5 3h8v8"/></svg>
  </span>
</a>
```

---

## 6. Card interactions

### 6a. 3D tilt-on-hover with glare
**When:** feature/pricing/media cards. Desktop only; subtle (≤8°).
**Performance:** one transform + one gradient position per card.

```js
// Also in assets/motion-utils.js
export function tilt(card, maxDeg = 8) {
  if (window.matchMedia("(hover: none), (prefers-reduced-motion: reduce)").matches) return () => {};
  card.style.transformStyle = "preserve-3d";
  const glare = document.createElement("div");
  glare.style.cssText = "position:absolute;inset:0;border-radius:inherit;pointer-events:none;opacity:0;transition:opacity 300ms;background:radial-gradient(circle at var(--gx,50%) var(--gy,50%),rgba(255,255,255,.25),transparent 60%)";
  card.style.position ||= "relative";
  card.appendChild(glare);
  const onMove = (e) => {
    const r = card.getBoundingClientRect();
    const px = (e.clientX - r.left) / r.width, py = (e.clientY - r.top) / r.height;
    card.style.transform = `perspective(800px) rotateX(${((0.5 - py) * maxDeg).toFixed(2)}deg) rotateY(${((px - 0.5) * maxDeg).toFixed(2)}deg) translateY(-4px)`;
    glare.style.setProperty("--gx", `${px * 100}%`);
    glare.style.setProperty("--gy", `${py * 100}%`);
  };
  const onEnter = () => { glare.style.opacity = "1"; card.style.transition = "transform 80ms"; };
  const onLeave = () => { glare.style.opacity = "0"; card.style.transition = "transform 400ms cubic-bezier(0.16,1,0.3,1)"; card.style.transform = ""; };
  card.addEventListener("pointermove", onMove);
  card.addEventListener("pointerenter", onEnter);
  card.addEventListener("pointerleave", onLeave);
  return () => { card.removeEventListener("pointermove", onMove); card.removeEventListener("pointerenter", onEnter); card.removeEventListener("pointerleave", onLeave); glare.remove(); };
}
```

### 6b. Bento hover expansion

```css
.bento { display: grid; grid-template-columns: repeat(4, 1fr); gap: 16px; transition: grid-template-columns 500ms var(--ease-out-expo); }
.bento:has(.cell-1:hover) { grid-template-columns: 1.6fr 0.8fr 0.8fr 1fr; }
.bento-cell { overflow: hidden; border-radius: 24px; transition: transform var(--dur-ui) var(--ease-out-expo); }
.bento-cell:hover { transform: translateY(-4px); }
.bento-cell img { transition: transform 600ms var(--ease-out-expo); }
.bento-cell:hover img { transform: scale(1.05); }
@supports not (selector(:has(*))) { .bento-cell:hover { transform: translateY(-4px) scale(1.02); } }
@media (prefers-reduced-motion: reduce) { .bento, .bento-cell, .bento-cell img { transition: none; } }
```

### 6c. Image zoom + caption reveal

```html
<figure class="imgcard">
  <img src="/case.jpg" alt="Case study" />
  <figcaption><span>Rebrand</span><h3>Nimbus Bank</h3></figcaption>
</figure>
<style>
  .imgcard { position: relative; overflow: hidden; border-radius: 24px; }
  .imgcard img { display: block; width: 100%; transition: transform 600ms var(--ease-out-expo); }
  .imgcard:hover img { transform: scale(1.06); }
  .imgcard figcaption {
    position: absolute; inset: auto 0 0 0; padding: 24px; color: #fff;
    background: linear-gradient(transparent, rgba(0,0,0,.65));
    opacity: 0; transform: translateY(12px);
    transition: opacity var(--dur-ui), transform var(--dur-ui) var(--ease-out-expo);
  }
  .imgcard:hover figcaption, .imgcard:focus-within figcaption { opacity: 1; transform: translateY(0); }
  .imgcard figcaption span { font-size: 12.5px; letter-spacing: .08em; text-transform: uppercase; opacity: .7; }
  @media (hover: none) { .imgcard figcaption { opacity: 1; transform: none; } }
  @media (prefers-reduced-motion: reduce) { .imgcard img, .imgcard figcaption { transition: none; } }
</style>
```

---

## 7. Scroll reveals

### 7a. Fade-up stagger (IntersectionObserver, framework-free)
**When:** default reveal for every section. Trigger at 15% viewport; once.
Also available as `scrollReveal()` in `assets/motion-utils.js`.

```html
<div class="reveal-group">
  <div class="reveal" style="--i:0">…</div>
  <div class="reveal" style="--i:1">…</div>
  <div class="reveal" style="--i:2">…</div>
</div>
<style>
  .reveal { opacity: 0; transform: translateY(28px);
    transition: opacity 600ms var(--ease-out-expo), transform 600ms var(--ease-out-expo);
    transition-delay: calc(var(--i, 0) * 60ms); }
  .reveal.is-visible { opacity: 1; transform: none; }
  @media (prefers-reduced-motion: reduce) { .reveal { opacity: 1; transform: none; transition: none; } }
</style>
<script>
  const io = new IntersectionObserver((entries) => {
    entries.forEach((e) => { if (e.isIntersecting) { e.target.classList.add("is-visible"); io.unobserve(e.target); } });
  }, { threshold: 0.15 });
  document.querySelectorAll(".reveal").forEach((el) => io.observe(el));
</script>
```

### 7b. Clip reveal (sections/images)

```css
.clip-reveal { clip-path: inset(0 0 100% 0); transition: clip-path 800ms var(--ease-out-expo); }
.clip-reveal.is-visible { clip-path: inset(0 0 0% 0); }
@media (prefers-reduced-motion: reduce) { .clip-reveal { clip-path: none; transition: none; } }
```

### 7c. Counter animation (stats bands)

```js
// Animates [data-counter] elements once on first view. 800ms ease-out.
export function counters(root = document) {
  const els = root.querySelectorAll("[data-counter]");
  if (!els.length) return;
  const format = (n) => n.toLocaleString("en-US");
  if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
    els.forEach((el) => { el.textContent = format(+el.dataset.counter); });
    return;
  }
  const io = new IntersectionObserver((entries) => {
    entries.forEach((e) => {
      if (!e.isIntersecting) return;
      io.unobserve(e.target);
      const target = +e.target.dataset.counter;
      const start = performance.now();
      const step = (now) => {
        const p = Math.min((now - start) / 800, 1);
        e.target.textContent = format(Math.round(target * (1 - Math.pow(1 - p, 4)))); // ease-out-quart
        if (p < 1) requestAnimationFrame(step);
      };
      requestAnimationFrame(step);
    });
  }, { threshold: 0.5 });
  els.forEach((el) => io.observe(el));
}
```

### 7d. Marquee (logo cloud / ticker)

```html
<div class="marquee"><div class="marquee-track">
  <span>Acme</span><span>Globex</span><span>Initech</span><span>Umbrella</span>
  <span>Acme</span><span>Globex</span><span>Initech</span><span>Umbrella</span><!-- duplicate for seamless loop -->
</div></div>
<style>
  .marquee { overflow: hidden; mask-image: linear-gradient(90deg, transparent, #000 10%, #000 90%, transparent); }
  .marquee-track { display: flex; gap: 64px; width: max-content; animation: marquee 24s linear infinite; }
  .marquee:hover .marquee-track { animation-play-state: paused; }
  .marquee-track span { font: 600 20px var(--font-display); color: var(--muted); opacity: .5; }
  @keyframes marquee { to { transform: translateX(-50%); } }
  @media (prefers-reduced-motion: reduce) { .marquee-track { animation: none; flex-wrap: wrap; } }
</style>
```

---

## 8. Ambient effects

**Performance for all ambient layers:** decorative-only, `pointer-events: none`, `position: absolute`, lazy-mount, and fully disabled under `prefers-reduced-motion`.

### 8a. Aurora / mesh gradient background (pure CSS)

```css
.aurora { position: absolute; inset: 0; overflow: hidden; pointer-events: none; }
.aurora::before, .aurora::after {
  content: ""; position: absolute; width: 60vmax; height: 60vmax; border-radius: 50%;
  filter: blur(80px); opacity: .35; will-change: transform;
}
.aurora::before { background: #8B5CF6; top: -20%; left: -10%; animation: drift-a 28s ease-in-out infinite alternate; }
.aurora::after  { background: #22D3EE; bottom: -25%; right: -10%; animation: drift-b 34s ease-in-out infinite alternate; }
@keyframes drift-a { to { transform: translate(12vw, 8vh) scale(1.15); } }
@keyframes drift-b { to { transform: translate(-10vw, -6vh) scale(1.1) rotate(20deg); } }
@media (prefers-reduced-motion: reduce) { .aurora::before, .aurora::after { animation: none; } }
```

### 8b. Grain overlay (premium texture on dark/gradient heroes)

```css
.grain { position: absolute; inset: 0; pointer-events: none; opacity: .05; z-index: 1;
  background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='160' height='160'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='2'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)'/%3E%3C/svg%3E");
}
```

### 8c. Cursor glow follower

```js
// Also in assets/motion-utils.js. Add: <div class="cursor-glow"></div>
// .cursor-glow { position: fixed; width: 480px; height: 480px; border-radius: 50%;
//   pointer-events: none; z-index: 0; background: radial-gradient(circle, rgba(139,92,246,.14), transparent 65%);
//   transform: translate(-50%,-50%); }
export function cursorGlow(el) {
  if (window.matchMedia("(hover: none), (prefers-reduced-motion: reduce)").matches) { el.remove(); return () => {}; }
  let tx = innerWidth / 2, ty = innerHeight / 2, x = tx, y = ty, raf = 0;
  const onMove = (e) => { tx = e.clientX; ty = e.clientY; };
  const loop = () => {
    x += (tx - x) * 0.08; y += (ty - y) * 0.08;
    el.style.left = x + "px"; el.style.top = y + "px";
    raf = requestAnimationFrame(loop);
  };
  window.addEventListener("pointermove", onMove, { passive: true });
  raf = requestAnimationFrame(loop);
  return () => { cancelAnimationFrame(raf); window.removeEventListener("pointermove", onMove); };
}
```

### 8d. Floating particles (canvas)
**When:** dark heroes (AI/crypto). ≤ 60 particles, one rAF loop, paused when off-screen. Inline one-off only — for reusable/cleanup-returning systems (leaves, pointer trail, orbs) use `assets/particle-effects.js` via §10.

```html
<canvas class="particles" aria-hidden="true"></canvas>
<script>
  (() => {
    if (matchMedia("(prefers-reduced-motion: reduce)").matches) return;
    const canvas = document.querySelector(".particles");
    const ctx = canvas.getContext("2d");
    let w, h, running = false, raf = 0;
    const N = Math.min(60, Math.floor(innerWidth / 24));
    const dots = Array.from({ length: N }, () => ({
      x: Math.random(), y: Math.random(),
      r: 1 + Math.random() * 2,
      vx: (Math.random() - 0.5) * 0.0004, vy: (Math.random() - 0.5) * 0.0004,
    }));
    function resize() { w = canvas.width = canvas.offsetWidth * devicePixelRatio; h = canvas.height = canvas.offsetHeight * devicePixelRatio; }
    function frame() {
      if (!running) return;
      ctx.clearRect(0, 0, w, h);
      ctx.fillStyle = "rgba(192,132,252,.6)";
      for (const d of dots) {
        d.x = (d.x + d.vx + 1) % 1; d.y = (d.y + d.vy + 1) % 1;
        ctx.beginPath(); ctx.arc(d.x * w, d.y * h, d.r * devicePixelRatio, 0, 7); ctx.fill();
      }
      raf = requestAnimationFrame(frame);
    }
    resize();
    addEventListener("resize", resize);
    new IntersectionObserver(([e]) => {
      running = e.isIntersecting;
      if (running) raf = requestAnimationFrame(frame); else cancelAnimationFrame(raf);
    }).observe(canvas);
  })();
</script>
```

---

## 9. Three.js scroll world (premium tier)

**When:** the user asks for a scroll world, fly-through, or 3D journey, or the product narrative genuinely suits a camera moving through space. It is a **page architecture, not a recipe** — the whole primary page scrolls through one continuous WebGL scene, and it replaces the signature scene. Escalate via Phase 4-W; the full architecture (beat ledger, R3F + vanilla patterns, art-direction studies, mobile degradation, debug checklist) lives in **`references/threejs-scroll-world.md`**, with the annotated React reference in **`assets/ScrollWorld3D.jsx`**.

**Non-negotiables (details in the full playbook):** scroll is the sole conductor and the story reads identically in reverse; native reversible scrolling (never own the wheel); DPR capped at 2 (1.5 mobile); lazy-mount + RAF pause off-screen + full `dispose()` on teardown; static poster fallback (with H1 + CTA) for WebGL failure or `prefers-reduced-motion`; Three.js + scene code ≤ 1MB.

Quickstart shape (vanilla, condensed — see the full playbook for the complete boot with fallback + teardown):

```html
<div id="world-wrap" style="height:600vh"><canvas id="world" style="position:sticky;top:0;height:100vh;width:100%"></canvas></div>
<script type="module">
import * as THREE from "three"; // importmap CDN; claude.ai artifacts pin r128
// renderer (DPR ≤ 2) + scene (+fog) + PerspectiveCamera + one world group …
let progress = 0;
addEventListener("scroll", () => {
  const rect = document.getElementById("world-wrap").getBoundingClientRect();
  progress = Math.min(1, Math.max(0, -rect.top / (rect.height - innerHeight)));
}, { passive: true });
// rAF loop: interpolate camera along the beat ledger from `progress`, render.
</script>
```

---

## 10. Particle ambient effects (packaged)

Reusable systems in **`assets/particle-effects.js`**. Every helper: no-op under `prefers-reduced-motion`, ≤60 particles, one rAF loop, IntersectionObserver pause, DPR-safe (`setTransform`), and returns a cleanup function — call it on unmount. Canvas prerequisites: `position:absolute` (fixed for the trail), `inset:0`, `pointer-events:none`, `aria-hidden="true"`. Pick **exactly one** per page, dark heroes only.

### 10a. Falling leaves

**When:** autumnal, seasonal, warm themes.

```html
<canvas class="leaves" aria-hidden="true"></canvas>
<script type="module">
  import { fallingLeaves } from "./assets/particle-effects.js";
  const cleanup = fallingLeaves(document.querySelector(".leaves"), {
    count: 40, colors: ["#D97706", "#B45309", "#F59E0B", "#78350F"],
  });
</script>
```

### 10b. Pointer trail emitter

**When:** dark futuristic heroes where the cursor should feel magical. Auto-disabled on touch devices. `color` is an `"R,G,B"` string.

```html
<canvas class="ptrail" aria-hidden="true" style="position:fixed;inset:0;pointer-events:none;z-index:9999"></canvas>
<script type="module">
  import { pointerTrailEmitter } from "./assets/particle-effects.js";
  const cleanup = pointerTrailEmitter(document.querySelector(".ptrail"), { color: "139,92,246", length: 20 });
</script>
```

### 10c. Floating orbs

**When:** AI / crypto / futuristic dark heroes — subtle rising bubbles.

```html
<canvas class="orbs" aria-hidden="true"></canvas>
<script type="module">
  import { floatingOrbs } from "./assets/particle-effects.js";
  const cleanup = floatingOrbs(document.querySelector(".orbs"), { count: 30, color: "#8B5CF6" });
</script>
```

React usage: call inside `useEffect` and return the cleanup. Non-module embeds get `window.UIParticles.*`.

---

## Recipe cheat-sheet

| Need | Recipe | Cost |
|---|---|---|
| "Feels premium" baseline | §1 Lenis + §7a reveals + §5b buttons | Low |
| 3D wow, no WebGL | §2a tilt + §2c z-depth parallax | Low |
| Scroll storytelling | §2b horizontal jack + §2d dolly | Medium |
| True 3D | §2e R3F ScrollControls | High (lazy-mount) |
| Spatial narrative / fly-through | §9 scroll world → `references/threejs-scroll-world.md` | High (replaces signature scene) |
| Nav polish | §4a + §4b + §4c | Low |
| Ambience | §8a aurora + §8b grain | Low |
| Ambient magic (one only) | §10a leaves · §10b pointer trail · §10c orbs | Low |
