# Three.js Scroll World — Scroll-Driven 3D Storytelling

The premium tier: the entire page scrolls through ONE continuous WebGL scene. Scroll drives the camera; DOM copy floats above the canvas at story beats. Use when the user asks for a scroll world, fly-through, or 3D journey, or when the product narrative genuinely suits a spatial metaphor (travel, exploration, systems, data worlds, planets, cities, archives). This replaces the signature scene — never combine both.

## Contents

Core contract · Story architecture (beat ledger) · Performance rules · R3F implementation · Vanilla implementation · Art-direction guardrails · Mobile degradation · Debug checklist

## Core contract

- One scene, one perspective camera, one renderer, one world group. Everything the user "travels past" lives in that group.
- Scroll drives camera position, camera target, object rotation, light intensity, and scene state. Ambient motion (a slow float, a shimmer) is seasoning only — **scroll is the sole conductor**, and the story must read identically scrolling up as scrolling down.
- **Native reversible scrolling.** Never hijack the wheel, never `preventDefault` scroll, never animate `scrollTop`. Lenis smoothing is fine; ownership transfer is not.
- Lazy-mount the canvas when its section approaches the viewport; cancel RAF when it is not intersecting; dispose geometry/materials/textures/renderer on teardown.
- Static CSS/SVG poster fallback whenever WebGL is unavailable or `prefers-reduced-motion` applies. The poster carries the H1 and primary CTA so the page still converts.
- Budget: Three.js + scene code ≤ 1MB on disk (~300KB gzipped). No megabyte GLBs, no 4K textures — geometry primitives, flat-shaded materials, and fog do the heavy lifting.

## Story architecture — the beat ledger

Reduce the narrative to **5–7 beats**. The ledger is the single source of truth for both the camera path and the DOM overlay — write it before any Three.js code:

```js
// Each beat: normalized scroll range + camera keyframe + overlay copy.
export const BEATS = [
  { id: "hook",     scroll: [0.00, 0.15], camPos: [0, 2, 8],   camTarget: [0, 0, 0],   label: "01 / Premise", title: "Enter the archive" },
  { id: "origin",   scroll: [0.15, 0.30], camPos: [3, 1, 5],   camTarget: [2, 0, -2],  label: "02 / Origin",  title: "Where it began" },
  { id: "system",   scroll: [0.30, 0.50], camPos: [0, 4, 2],   camTarget: [0, 0, -4],  label: "03 / System",  title: "The engine underneath" },
  { id: "conflict", scroll: [0.50, 0.70], camPos: [-3, 1, 5],  camTarget: [-2, 0, -2], label: "04 / Tension", title: "What breaks at scale" },
  { id: "proof",    scroll: [0.70, 0.85], camPos: [0, 2, 6],   camTarget: [0, 1, -3],  label: "05 / Proof",   title: "Built for it" },
  { id: "cta",      scroll: [0.85, 1.00], camPos: [0, 1, 4],   camTarget: [0, 0, 0],   label: "06 / Start",   title: "Begin the journey" },
];
```

Ledger rules:

1. Ranges tile 0→1 with no gaps; the camera **eases between keyframes** (interpolate per-axis with an ease, or drive a GSAP timeline with `scrub`), so cuts never pop.
2. The **hero object carries the metaphor** — sculpture, machine, archive, constellation, city, product, planetary system. Pick one; secondary objects orbit it.
3. One dominant object per beat. If two things compete for the eye in a single beat, cut one.
4. Beats 1 and N are the conversion bookends: beat 1 holds the H1, beat N holds the CTA. Pricing/footer live in normal DOM **after** the world container ends.
5. Total scroll length: `pages ≈ beats` (R3F `ScrollControls pages={6}`) or a `height: 600vh` container in vanilla — roughly one viewport per beat.

## Performance rules

1. **Cap DPR:** `renderer.setPixelRatio(Math.min(devicePixelRatio, 2))` — 1.5 on mobile. DPR is the #1 fill-rate killer.
2. **Resize correctly:** update `camera.aspect` + `camera.updateProjectionMatrix()` + `renderer.setSize()` on resize. Never let CSS stretch the canvas.
3. **Lazy mount:** create the renderer only when the world section enters (IntersectionObserver, `rootMargin: "25%"`). Above the fold, the world usually IS the fold — mount immediately then.
4. **Pause off-screen:** cancel the RAF loop while the canvas is not intersecting; resume on re-entry. In R3F, unmount the `<Canvas>` instead — R3F disposes for you.
5. **Dispose on teardown:** vanilla Three.js leaks by default. On cleanup: traverse the scene, `geometry.dispose()`, `material.dispose()` (and each `material.map?.dispose()`), then `renderer.dispose()`.
6. **Reduced motion:** never boot the world. Render the static poster (see fallback pattern) — a single frozen frame via `frameloop="never"` is acceptable only if the copy remains fully readable.
7. **Draw-call diet:** primitives + `flatShading` + `MeshStandardMaterial`; fog instead of distant geometry; ≤ 3 lights; shadows only if a single 1024 map covers everything.

## R3F implementation (default for React builds)

```bash
npm i three @react-three/fiber @react-three/drei gsap lenis
```

The full annotated reference lives in `assets/ScrollWorld3D.jsx` — copy it and swap the geometry/beats. The load-bearing pattern:

```jsx
import { Canvas, useFrame, useThree } from "@react-three/fiber";
import { ScrollControls, useScroll } from "@react-three/drei";

function WorldScene() {
  const scroll = useScroll();            // 0..1 across ScrollControls pages
  const { camera } = useThree();
  useFrame(() => {
    const r = scroll.offset;             // native, reversible, damped
    // Interpolate camera along the beat ledger (see helper in ScrollWorld3D.jsx)
    applyBeats(camera, r);
  });
  return <group>{/* hero object, satellites, lights, fog */}</group>;
}

export default function ScrollWorld() {
  return (
    <div className="sticky top-0 h-screen">           {/* inside a tall wrapper */}
      <Canvas dpr={[1, 2]} camera={{ position: [0, 2, 8], fov: 45 }}>
        <ScrollControls pages={6} damping={0.15}>
          <WorldScene />
        </ScrollControls>
      </Canvas>
    </div>
  );
}
```

`ScrollControls` renders its own scroll container, so DOM beat overlays either go in drei's `<Scroll html>` layer or (the `ScrollWorld3D.jsx` approach) as sibling sections driven by GSAP ScrollTrigger — the sibling approach keeps overlay markup ordinary and SEO-visible.

## Vanilla implementation (no build step)

For standalone HTML deliverables, load Three.js via importmap from a CDN; for claude.ai artifacts, note the environment pins Three.js r128 (no `OrbitControls` import, no `CapsuleGeometry` — use Cylinder/Sphere/custom geometry and manual camera math, which a scroll world needs anyway since the camera is scroll-driven, not orbit-controlled).

```html
<div id="world-wrap" style="height:600vh; position:relative;">
  <canvas id="world" style="position:sticky; top:0; width:100%; height:100vh; display:block;"></canvas>
</div>
<script type="importmap">{ "imports": { "three": "https://unpkg.com/three@0.160.0/build/three.module.js" } }</script>
<script type="module">
import * as THREE from "three";

const REDUCED = matchMedia("(prefers-reduced-motion: reduce)").matches;
const canvas = document.getElementById("world");
if (REDUCED || !window.WebGLRenderingContext) { showPoster(); } else { boot(); }

function boot() {
  const renderer = new THREE.WebGLRenderer({ canvas, antialias: true, alpha: true });
  renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
  renderer.setSize(innerWidth, innerHeight);

  const scene = new THREE.Scene();
  scene.fog = new THREE.Fog(0x0f0b2e, 8, 25);
  const camera = new THREE.PerspectiveCamera(45, innerWidth / innerHeight, 0.1, 100);

  const world = new THREE.Group();
  const hero = new THREE.Mesh(
    new THREE.IcosahedronGeometry(1.4, 1),
    new THREE.MeshStandardMaterial({ color: 0x8b5cf6, roughness: 0.2, metalness: 0.7, flatShading: true })
  );
  world.add(hero);
  const key = new THREE.DirectionalLight(0xffffff, 1.2); key.position.set(4, 6, 4);
  world.add(new THREE.AmbientLight(0xffffff, 0.4), key);
  scene.add(world);

  // Scroll → progress (native, passive, reversible)
  let progress = 0;
  const wrap = document.getElementById("world-wrap");
  const onScroll = () => {
    const rect = wrap.getBoundingClientRect();
    progress = Math.min(1, Math.max(0, -rect.top / (rect.height - innerHeight)));
  };
  addEventListener("scroll", onScroll, { passive: true });

  let raf = 0, running = true;
  function frame() {
    if (!running) return;
    const a = progress * Math.PI * 0.8;                 // arc path from the ledger
    camera.position.set(Math.sin(a) * 6, 2 + Math.sin(progress * Math.PI) * 1.5, Math.cos(a) * 6);
    camera.lookAt(0, 0, 0);
    hero.rotation.y = progress * Math.PI;
    renderer.render(scene, camera);
    raf = requestAnimationFrame(frame);
  }
  frame();

  addEventListener("resize", () => {
    camera.aspect = innerWidth / innerHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(innerWidth, innerHeight);
  });

  new IntersectionObserver(([e]) => {
    running = e.isIntersecting;
    if (running) raf = requestAnimationFrame(frame); else cancelAnimationFrame(raf);
  }).observe(canvas);

  // Teardown (SPA navigations): dispose everything.
  window.__disposeWorld = () => {
    cancelAnimationFrame(raf);
    scene.traverse(o => { o.geometry?.dispose(); (Array.isArray(o.material) ? o.material : [o.material]).forEach(m => { m?.map?.dispose(); m?.dispose(); }); });
    renderer.dispose();
  };
}

function showPoster() {
  canvas.replaceWith(Object.assign(document.createElement("div"), { className: "world-poster" }));
  // .world-poster: static gradient/SVG scene + H1 + CTA — the page must convert without WebGL.
}
</script>
```

## Art-direction guardrails

1. **Reject the generic default** — a glowing blue planet in dark space — unless the brief specifically earns it. Same for "random floating cubes".
2. **Three studies before committing.** Vary field color, hero material, light behavior, typography relationship, and composition across the studies; pick the one with a defensible point of view. Ten minutes of studies beats an hour of re-lighting.
3. **One hue family.** The 3D world palette and the DOM UI palette derive from the same Phase-2 bundle; the accent appears in exactly one material (emissive or key light), mirroring the ONE-accent token rule.
4. **Fog is composition.** `scene.fog` blends distant geometry into the background color — it creates depth, hides the world's edges, and softens the draw-call diet.
5. **Copy stays sovereign.** Beat text sits on a glass panel (`backdrop-filter: blur`) or gets a text-shadow; if the copy fails 4.5:1 over the busiest frame of its beat, darken the scene, not the text.

## Mobile degradation

- Halve geometry segments; cap DPR at 1.5; drop shadows entirely.
- Camera path amplitude shrinks (tighter arcs) so beats stay legible on a tall narrow frame.
- Touch scrolling stays native — `ScrollControls` and the vanilla pattern both already comply.
- On low-power devices (`navigator.hardwareConcurrency <= 4` is a fair heuristic) or any WebGL context loss, swap to the poster immediately and silently.

## Debug checklist (when the world "feels wrong")

- Scrolling up doesn't perfectly reverse the story → something animates on time instead of scroll progress; remove it.
- Jank on scroll → DPR uncapped, shadows on everything, or a `getBoundingClientRect` per frame outside the scroll handler.
- Text unreadable mid-beat → violate neither gate 11 nor guardrail 5; add the glass panel.
- Blank canvas on some machines → missing WebGL/poster fallback path; test with WebGL disabled in devtools.
- Memory climbs across SPA navigations → teardown never ran; call the dispose routine on unmount.
