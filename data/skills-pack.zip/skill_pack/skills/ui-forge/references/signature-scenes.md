# Signature Scenes — One Show-Stopper Per Page

A signature scene is the moment people screenshot. Pick **exactly ONE** per primary page (utility pages get none), execute it flawlessly, and let the rest of the page stay calm — two show-stoppers cancel each other out. All recipes assume the playbook §1 boot (Lenis + GSAP ScrollTrigger registered) and a `REDUCED` guard:

```js
const REDUCED = matchMedia("(prefers-reduced-motion: reduce)").matches;
// wrap every scene: if (REDUCED) { /* leave static end-state */ } else { ... }
```

Mobile: shorten every pin to ≤ `+=150%`, or swap the scene for its static end-state. Only `transform`/`opacity`/CSS-vars animate.

## Picker

| Brief smells like… | Scene |
|---|---|
| Cinematic product, film-grade brand | S1 video scrub · S2 frame sequence |
| Feature story told in steps | S3 card deck · S4 color-morph journey |
| Type-driven, editorial, portfolio | S5 kinetic type · S9 spotlight reveal |
| Process, route, "how it works" | S6 line draw |
| AI / abstract / no product shots exist | S7 shader gradient |
| Gallery, work index, screenshots | S8 coverflow rail |
| Bento features grid | S10 exploded bento |
| Physical product / device | S11 GLB orbit stage |
| Multi-page template polish | S12 view transitions |
| Spatial world, fly-through, 3D journey | **Escalate to the Scroll World tier** (`references/threejs-scroll-world.md`) — the world replaces the signature scene entirely |

## S1 — Scroll-scrubbed video (pinned)

Generated 5s loop (see `asset-generation.md` §2) becomes a scroll-controlled sequence.

```html
<section class="s1"><video class="s1-v" muted playsinline preload="auto"
  poster="POSTER_URL" width="1920" height="1080"><source src="LOOP_URL" type="video/mp4"></video></section>
```
```js
const v = document.querySelector(".s1-v");
const prep = () => gsap.timeline({ scrollTrigger: {
    trigger: ".s1", start: "top top", end: "+=250%", pin: true, scrub: 0.5 } })
  .fromTo(v, { currentTime: 0 }, { currentTime: v.duration || 5, ease: "none" });
v.readyState >= 1 ? prep() : v.addEventListener("loadedmetadata", prep, { once: true });
```
Encode the mp4 with dense keyframes (`-g 15`) or scrubbing stutters. REDUCED: show poster, no pin.

## S2 — Image-sequence canvas scrub (Apple-style)

When video scrubbing is too heavy: 24–40 stills (batch-generate with a consistent seed phrase, or extract frames) drawn to canvas.

```js
const canvas = document.querySelector(".s2-c"), ctx = canvas.getContext("2d");
const N = 32, imgs = Array.from({ length: N }, (_, i) => {
  const im = new Image(); im.src = `frames/${String(i).padStart(3, "0")}.webp`; return im;
});
const state = { f: 0 };
const draw = () => { const im = imgs[Math.round(state.f)]; if (!im?.complete) return;
  const s = Math.max(canvas.width / im.width, canvas.height / im.height);
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  ctx.drawImage(im, (canvas.width - im.width * s) / 2, (canvas.height - im.height * s) / 2, im.width * s, im.height * s); };
imgs[0].onload = draw;
gsap.to(state, { f: N - 1, ease: "none", onUpdate: draw, scrollTrigger: {
  trigger: ".s2", start: "top top", end: "+=300%", pin: true, scrub: 0.4 } });
```
Size the canvas to `devicePixelRatio` on resize. Keep frames ≤120KB each (webp q70).

## S3 — Sticky card deck

Feature cards stack on one spot; each incoming card presses the last one back.

```html
<section class="s3">
  <article class="s3-card">…</article><article class="s3-card">…</article><article class="s3-card">…</article>
</section>
<style>.s3{display:grid;gap:12vh}.s3-card{position:sticky;top:12vh;min-height:70vh;border-radius:var(--r-xl);background:var(--surface);transform-origin:top center}</style>
```
```js
gsap.utils.toArray(".s3-card").forEach((card, i, all) => {
  if (i === all.length - 1) return;
  gsap.to(card, { scale: 0.92 - (all.length - 2 - i) * 0.03, opacity: 0.55, filter: "blur(2px)",
    ease: "none", scrollTrigger: { trigger: all[i + 1], start: "top bottom", end: "top 12vh", scrub: true } });
});
```
CSS `position: sticky` does the pinning — cheap and touch-safe. REDUCED: cards simply scroll.

## S4 — Background color-morph journey

The page's background travels through 2–4 theme-consistent stops as sections pass — the whole site feels like one continuous scene.

```html
<section data-bg="#0B0E16">…</section><section data-bg="#101B3A">…</section><section data-bg="#F4F5FA" data-ink="#0F1115">…</section>
```
```js
document.querySelectorAll("[data-bg]").forEach(sec => ScrollTrigger.create({
  trigger: sec, start: "top 55%", end: "bottom 55%",
  onToggle: ({ isActive }) => isActive && gsap.to("body", {
    "--bg": sec.dataset.bg, "--ink": sec.dataset.ink || getComputedStyle(document.body).getPropertyValue("--ink"),
    duration: 0.8, ease: "power2.out", overwrite: "auto" }),
}));
```
`body { background: var(--bg); color: var(--ink); transition: none; }` — GSAP owns the interpolation. Verify contrast at every stop (Phase 6.1).

## S5 — Kinetic type: scramble-in + variable weight on scroll

```html
<h1 class="s5" data-text="Design that moves">Design that moves</h1>
<style>.s5{font-variation-settings:"wght" 400;transition:none}</style>
```
```js
// scramble entrance
const el = document.querySelector(".s5"), final = el.dataset.text, glyphs = "!<>-_\\/[]{}—=+*^?#";
let frame = 0; const total = 24;
(function scramble() {
  el.textContent = final.split("").map((ch, i) =>
    i < (frame / total) * final.length ? ch : glyphs[(Math.random() * glyphs.length) | 0]).join("");
  if (frame++ < total) requestAnimationFrame(scramble); else el.textContent = final;
})();
// weight rides the scroll (variable font e.g. Inter/Sora/Fraunces axis)
gsap.fromTo(el, { fontVariationSettings: '"wght" 400' },
  { fontVariationSettings: '"wght" 850', ease: "none",
    scrollTrigger: { trigger: el, start: "top 90%", end: "top 30%", scrub: true } });
```
REDUCED: skip scramble, render final text, keep weight static at 700.

## S6 — SVG line draw (routes, diagrams, signatures)

```js
document.querySelectorAll(".s6 path").forEach(p => {
  const L = p.getTotalLength();
  gsap.fromTo(p, { strokeDasharray: L, strokeDashoffset: L }, { strokeDashoffset: 0, ease: "none",
    scrollTrigger: { trigger: p.closest("section"), start: "top 75%", end: "bottom 60%", scrub: true } });
});
```
Stroke in `var(--accent)`, 2–3px, `stroke-linecap="round"`. Pair with playbook §7c counters for "how it works" stats.

## S7 — WebGL shader-gradient hero (tiny, token-driven)

Living liquid gradient in exact theme colors — the AI-product hero when no photography exists.

```html
<canvas class="s7" aria-hidden="true"></canvas>
```
```js
const cv = document.querySelector(".s7"), gl = cv.getContext("webgl");
const hex = n => getComputedStyle(document.documentElement).getPropertyValue(n).trim();
const rgb = h => [1, 3, 5].map(i => parseInt(h.slice(i, i + 2), 16) / 255);
const vs = "attribute vec2 p;void main(){gl_Position=vec4(p,0.,1.);}";
const fs = `precision mediump float;uniform vec2 r;uniform float t;uniform vec3 c0,c1,c2;
void main(){vec2 u=gl_FragCoord.xy/r;
float a=sin(u.x*3.+t*.4)*.5+.5, b=cos(u.y*4.-t*.3+u.x*2.)*.5+.5;
vec3 col=mix(c0,c1,smoothstep(.2,.8,a)); col=mix(col,c2,b*.45*smoothstep(.9,.2,u.y));
gl_FragColor=vec4(col,1.);}`;
const sh = (t, s) => { const o = gl.createShader(t); gl.shaderSource(o, s); gl.compileShader(o); return o; };
const pr = gl.createProgram();
gl.attachShader(pr, sh(gl.VERTEX_SHADER, vs)); gl.attachShader(pr, sh(gl.FRAGMENT_SHADER, fs));
gl.linkProgram(pr); gl.useProgram(pr);
gl.bindBuffer(gl.ARRAY_BUFFER, gl.createBuffer());
gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1,-1, 3,-1, -1,3]), gl.STATIC_DRAW);
const loc = gl.getAttribLocation(pr, "p"); gl.enableVertexAttribArray(loc); gl.vertexAttribPointer(loc, 2, gl.FLOAT, false, 0, 0);
["c0","c1","c2"].forEach((n, i) => gl.uniform3fv(gl.getUniformLocation(pr, n),
  rgb(hex(["--bg", "--accent", "--accent2"][i]) || "#8B5CF6")));
const rU = gl.getUniformLocation(pr, "r"), tU = gl.getUniformLocation(pr, "t");
const fit = () => { cv.width = cv.clientWidth; cv.height = cv.clientHeight; gl.viewport(0, 0, cv.width, cv.height); };
addEventListener("resize", fit); fit();
let run = true; new IntersectionObserver(([e]) => run = e.isIntersecting).observe(cv);
(function loop(ms) { if (run && !REDUCED) { gl.uniform2f(rU, cv.width, cv.height);
  gl.uniform1f(tU, ms / 1000); gl.drawArrays(gl.TRIANGLES, 0, 3); } requestAnimationFrame(loop); })(0);
```
REDUCED: one draw with `t=0` gives a static gradient. Layer playbook §8b grain on top.

## S8 — 3D coverflow rail

Horizontal gallery where distance from center drives rotation and depth.

```html
<div class="s8"><figure class="s8-i">…</figure>×6</div>
<style>.s8{display:flex;gap:24px;overflow-x:auto;padding:10vh 40vw;perspective:900px;scroll-snap-type:x mandatory;scrollbar-width:none}.s8-i{flex:0 0 min(420px,70vw);scroll-snap-align:center;border-radius:var(--r-lg);will-change:transform}</style>
```
```js
const rail = document.querySelector(".s8"), items = [...rail.children];
const paint = () => { const mid = rail.scrollLeft + rail.clientWidth / 2;
  items.forEach(el => { const d = (el.offsetLeft + el.offsetWidth / 2 - mid) / rail.clientWidth;
    const c = Math.max(-1, Math.min(1, d));
    el.style.transform = `rotateY(${c * -32}deg) translateZ(${(1 - Math.abs(c)) * 90}px) scale(${1 - Math.abs(c) * 0.12})`;
    el.style.opacity = 1 - Math.abs(c) * 0.35; }); };
rail.addEventListener("scroll", () => requestAnimationFrame(paint), { passive: true }); paint();
```
Native scroll → free touch/inertia/a11y. REDUCED: leave transforms flat (skip `paint`).

## S9 — Spotlight mask reveal

Cursor carves a light circle through a dark veil, revealing the "true" layer beneath (alt copy, colored art, the answer).

```html
<section class="s9"><div class="s9-base">…public layer…</div><div class="s9-top">…hidden layer…</div></section>
<style>.s9{position:relative}.s9-top{position:absolute;inset:0;--x:50%;--y:50%;
  -webkit-mask-image:radial-gradient(circle 180px at var(--x) var(--y),#000 99%,transparent 100%);
  mask-image:radial-gradient(circle 180px at var(--x) var(--y),#000 99%,transparent 100%)}</style>
```
```js
const top = document.querySelector(".s9-top"), sec = document.querySelector(".s9");
const xTo = gsap.quickTo(top, "--x", { duration: 0.35, ease: "power3" }),
      yTo = gsap.quickTo(top, "--y", { duration: 0.35, ease: "power3" });
matchMedia("(hover:hover)").matches && !REDUCED
  ? sec.addEventListener("pointermove", e => { const r = sec.getBoundingClientRect();
      xTo(((e.clientX - r.left) / r.width) * 100 + "%"); yTo(((e.clientY - r.top) / r.height) * 100 + "%"); })
  : gsap.to(top, { "--x": "70%", "--y": "40%", duration: 6, repeat: -1, yoyo: true, ease: "sine.inOut" }); // touch: auto-orbit
```
Register the vars first: `gsap.registerPlugin(ScrollTrigger); CSS.registerProperty?.({name:"--x",syntax:"<length-percentage>",inherits:false,initialValue:"50%"});` (same for `--y`) so they tween smoothly.

## S10 — Exploded bento assembly (pinned)

Bento tiles begin gathered at center, then fly to their grid seats as you scroll.

```js
const tiles = gsap.utils.toArray(".s10 .tile");
if (!REDUCED) {
  const tl = gsap.timeline({ scrollTrigger: { trigger: ".s10", start: "top top",
    end: innerWidth < 768 ? "+=150%" : "+=220%", pin: true, scrub: 0.6 } });
  tiles.forEach((t, i) => {
    const r = t.getBoundingClientRect(), host = t.parentElement.getBoundingClientRect();
    const dx = host.width / 2 - (r.left - host.left) - r.width / 2,
          dy = host.height / 2 - (r.top - host.top) - r.height / 2;
    tl.from(t, { x: dx, y: dy, scale: 0.6, opacity: 0, rotation: gsap.utils.random(-14, 14),
      ease: "power3.out", duration: 1 }, i * 0.07);
  });
}
```
Recompute on `ScrollTrigger.refresh` (resize). Grid markup = playbook-standard bento (`layout-blueprints.md` §3).

## S11 — GLB orbit stage (generated 3D product)

Mesh from `generate_3d` (see `asset-generation.md` §2/§4d) on a slow turntable; pointer nudges the orbit; scroll adds a gentle dolly.

```js
import * as THREE from "https://unpkg.com/three@0.160.0/build/three.module.js";
import { GLTFLoader } from "https://unpkg.com/three@0.160.0/examples/jsm/loaders/GLTFLoader.js";
const host = document.querySelector(".s11");
const scene = new THREE.Scene(), cam = new THREE.PerspectiveCamera(38, 1, 0.1, 50);
const ren = new THREE.WebGLRenderer({ alpha: true, antialias: true });
host.appendChild(ren.domElement);
scene.add(new THREE.AmbientLight(0xffffff, 1.1));
const key = new THREE.DirectionalLight(0xffffff, 2.2); key.position.set(3, 4, 5); scene.add(key);
let model; new GLTFLoader().load("MODEL_URL.glb", g => {
  model = g.scene; const box = new THREE.Box3().setFromObject(model);
  const s = 2.2 / box.getSize(new THREE.Vector3()).length(); model.scale.setScalar(s);
  box.getCenter(model.position).multiplyScalar(-s); scene.add(model); });
cam.position.z = 3.2;
const fit = () => { const w = host.clientWidth, h = host.clientHeight;
  ren.setSize(w, h); ren.setPixelRatio(Math.min(devicePixelRatio, 2)); cam.aspect = w / h; cam.updateProjectionMatrix(); };
addEventListener("resize", fit); fit();
let tx = 0; host.addEventListener("pointermove", e =>
  tx = (e.clientX / innerWidth - 0.5) * 0.9, { passive: true });
!REDUCED && gsap.to(cam.position, { z: 2.4, ease: "none",
  scrollTrigger: { trigger: host, start: "top 80%", end: "bottom 30%", scrub: true } });
let on = true, drift = 0; new IntersectionObserver(([e]) => on = e.isIntersecting).observe(host);
(function loop() { requestAnimationFrame(loop); if (!on || !model) return;
  if (!REDUCED) model.rotation.y += 0.004;            // slow turntable
  drift += ((REDUCED ? 0 : tx) - drift) * 0.06;       // eased pointer influence
  cam.position.x = drift * 0.6; cam.lookAt(0, 0, 0);
  ren.render(scene, cam); })();
```
Lazy-mount the whole block with IntersectionObserver on first approach; mesh budget < 5MB.

## S12 — View Transitions polish (multi-page templates)

Free-feeling page morphs for the Phase 5 complete-set deliveries. Progressive enhancement — zero cost where unsupported.

```html
<!-- MPA (separate .html pages): one rule in shared CSS -->
<style>
  @view-transition { navigation: auto; }
  ::view-transition-old(root), ::view-transition-new(root) { animation-duration: .35s; }
  .card-hero { view-transition-name: hero-img; } /* same name on list card + detail hero */
  @media (prefers-reduced-motion: reduce) { ::view-transition-group(*) { animation: none !important; } }
</style>
```
```js
// SPA/theme flips: wrap DOM swaps
const go = fn => document.startViewTransition ? document.startViewTransition(fn) : fn();
go(() => document.documentElement.dataset.theme = "luxury-dark");
```
Give the traveling element (card image → detail hero) the same `view-transition-name` on both pages for a shared-element morph.
