# Mobile UI Patterns — Study & Build Guide

Complete mobile UI vocabulary: every navigation model, component pattern, gesture, and per-domain screen blueprint. Use alongside `theme-derivation.md` (tokens) and `motion-3d-playbook.md` (motion). All skeletons are HTML/Tailwind mobile-web (375–430px viewport) — the same structures map 1:1 to React Native / Flutter widgets.

---

## 0. Platform doctrine (never mix blindly)

| Concern | iOS (HIG) | Android (Material 3) |
|---|---|---|
| Nav bar | Bottom tab bar, 49pt, blur material | Navigation bar, 80dp, tonal surface |
| Back affordance | Top-left chevron + swipe-from-left-edge | System back button/gesture |
| Corners | Continuous (squircle), 10–39px radii | Shape scale 4–28dp |
| Primary buttons | Rounded rect or capsule, tinted | Filled / tonal pill, state layers |
| Sheets | Detents (medium/large), grabber | Modal bottom sheet, drag handle |
| Typography | SF Pro — 17pt body, semibold nav titles | Roboto/M3 type scale |
| Haptics | Impact/notification feedback per action | Vibration effects, subtler |

Pick ONE doctrine per product unless the user asks for a hybrid. Mobile-web hybrid default: iOS-style tab bar + capsule CTAs + M3-style state layers on press.

**Safe areas:** always pad with `env(safe-area-inset-*)`. Tab bar: `padding-bottom: env(safe-area-inset-bottom)`. Status bar overlays: `padding-top: env(safe-area-inset-top)`.

**Touch targets:** ≥44×44px. Primary CTA height 48–56px. One-thumb reach: put primary actions in the bottom 60% of the screen.

---

## 1. Navigation models (pick ONE primary)

### 1.1 Bottom tab bar — the default
3–5 tabs. Active tab: accent icon + label; inactive: muted. Center tab can be a raised FAB (camera/compose).

```html
<nav class="fixed inset-x-0 bottom-0 z-40 border-t border-border bg-surface/80 pb-[env(safe-area-inset-bottom)] backdrop-blur-xl">
  <div class="mx-auto flex max-w-md items-center justify-around px-4 pt-2">
    <a class="flex flex-col items-center gap-1 py-1 text-accent">
      <svg class="h-6 w-6"><!-- home --></svg>
      <span class="text-[10px] font-medium">Home</span>
    </a>
    <!-- inactive tabs: text-muted -->
    <button class="-mt-6 flex h-14 w-14 items-center justify-center rounded-full bg-accent text-accent-ink shadow-3 transition-transform active:scale-90">＋</button>
  </div>
</nav>
```

### 1.2 Top segmented control
For 2–4 sibling views (Feed/Discover, Daily/Weekly). Pill track, sliding indicator (layoutId in Framer Motion; CSS `transform` transition in vanilla).

### 1.3 Stack navigation + large title
iOS pattern: nav title starts 34pt bold inline with content, collapses to centered 17pt semibold on scroll. Implement with a scroll listener toggling two headers.

### 1.4 Drawer / side rail
Only for 6+ sections or enterprise tools. On mobile-web: slide-over panel with scrim, `translateX` animation, focus-trapped.

### 1.5 Gesture-first (no visible chrome)
Stories/swipe decks (card decks, short-video feeds). Always include a first-run hint (coach mark) and an escape button.

---

## 2. Core component patterns

### Sheets & modals
- **Bottom sheet** (default modal on mobile): slides up, scrim 40% black, drag-to-dismiss, detents 40%/90%, 28px top radius.
- **Action sheet**: list of destructive/neutral actions + separated Cancel.
- **Full-screen modal**: only for focused creation (compose, checkout) — X top-left, primary action top-right or sticky bottom.

```html
<div class="fixed inset-0 z-50 flex items-end justify-center">
  <div class="absolute inset-0 bg-ink/40" data-dismiss></div>
  <div class="relative w-full max-w-md rounded-t-[28px] bg-surface p-6 pb-[calc(24px+env(safe-area-inset-bottom))] shadow-3">
    <div class="mx-auto mb-4 h-1.5 w-10 rounded-full bg-muted/30"></div>
    <!-- content -->
  </div>
</div>
```

### Lists & cards
- **Inset grouped list** (settings): rounded-16 sections on `bg-bg`, rows 44–56px, chevron right, separators inset 16px.
- **Feed card**: image 4:3 or 16:9 rounded-20, title 17px semibold, meta row muted 13px, icon action row.
- **Horizontal rail**: snap-scroll (`snap-x snap-mandatory`), card width 75–85% so the next card peeks. Peek = affordance.

### Inputs & forms
- One field per row, 16px text (prevents iOS zoom), input height 48–52px.
- Sticky bottom primary CTA above keyboard.
- OTP: 4–6 segmented boxes, auto-advance, paste fill.
- Toggles: iOS-style switch (accent when on), 51×31px pill.

### Feedback
- **Toast/snackbar**: bottom, above tab bar, auto-dismiss 3s, one action max.
- **Skeletons over spinners**: shimmer blocks matching the final layout for any load >300ms.
- **Empty states**: icon/illustration 80px, one-line headline, one-line sub, one CTA. Never a bare "No data".
- **Pull-to-refresh**: spinner synced to drag distance.

---

## 3. Gesture & motion vocabulary (mobile)

| Gesture | Use | Motion |
|---|---|---|
| Tap | all actions | scale 0.97, 120ms |
| Long-press | context menu / preview | haptic + scale-in menu from touch point |
| Swipe horizontal | card deck, tab change, list actions | follow finger, spring release |
| Swipe down | dismiss sheet/photo, refresh | translateY follows finger, scrim fades |
| Pinch | photo/map zoom | transform scale, clamp 0.5–3× |
| Edge swipe (left) | back | interactive pop transition |

Mobile hero motion: entrance stagger (eyebrow → headline → sub → CTA → visual, 80ms steps), hero visual floats on a 4px y-loop, scroll parallax on decorative blobs only. 3D scroll effects from `motion-3d-playbook.md` apply on mobile too, but clamp `translateZ` depths ≤60px and never scroll-jack on touch — use native vertical scroll with parallax layers instead.

---

## 4. Domain screen blueprints (the full idea catalog)

Each entry: structure + the ONE thing that makes it award-level.

### 4.1 Onboarding / auth
Splash → 3–5 swipeable value slides (illustration + headline + page dots) → sign-up (social first, email last) → OTP → permission priming (explain WHY before the system prompt). Award-level: illustration morphs between slides; progress dot expands into a pill.

### 4.2 Social / feed
Stories rail (rings for unseen) → infinite feed cards → FAB compose → detail with shared-element transition from the card. Award-level: shared-element hero image + like-button particle burst.

### 4.3 Finance / wallet
Balance hero (huge mono number, sparkline) → quick actions row (send/request/scan/top-up as circular icon buttons) → transactions grouped by day with category chips → card screen with a 3D-tilting card. Award-level: balance counts up on load; amounts blur until tapped (privacy toggle).

### 4.4 Health / fitness / yoga
Daily ring/progress hero → today's plan as timeline cards → session player (full-bleed video, big timer, minimal chrome) → weekly bar stats. Award-level: breathing-animation circle; rings draw on via stroke-dashoffset.

### 4.5 Food / delivery
Sticky search + location header → category chip rail → hero dish carousel (snap) → restaurant cards (image, rating pill, ETA) → dish detail with parallax header that shrinks into the navbar → cart sheet with steppers → live order tracking. Award-level: add-to-cart flies the item into the cart icon.

### 4.6 E-commerce / product
2-col product grid (image 1:1, bold price, wishlist heart) → product page: gallery pager → title/price → color/size chips → sticky bottom "Add to bag" → cart → single-column checkout. Award-level: pointer-tilt product hero; size-chip selection springs.

### 4.7 Smart home / IoT dashboard
Room selector chips → device grid cards (icon + name + state + inline toggle) → device detail: BIG radial/slider control center-stage → scenes row. Award-level: draggable radial thermostat dial with haptic ticks; active device cards glow in accent (neumorphic or glass — pick per theme).

### 4.8 Chat / messaging
Conversation list (avatar, name, last message, time, unread badge) → thread: grouped bubbles, day separators, sticky input bar → media viewer with pinch-zoom + swipe-down dismiss. Award-level: message send morphs from the input; typing indicator with bouncing dots.

### 4.9 Music / media player
Library lists → now-playing: blurred album-art background, big art rounded-24, scrubber, controls (72px play), lyrics sheet. Award-level: background hue extracted from the art; mini-player expands with shared-element.

### 4.10 Reading / novel / docs
Cover grid → reader: serif 19px, line-height 1.7, tap zones (prev/next/menu), chapter sheet, theme presets (paper/sepia/dark), hairline progress bar. Award-level: ambient theme that shifts with time of day.

### 4.11 Game UI
Hex/tile grids, HUD overlays (health, resources in top corners), bottom ability bar with radial cooldown sweeps. Award-level: floating damage numbers with physics; cooldown sweep via conic-gradient mask.

### 4.12 AI chat / agent console
Thread list → chat: user right-bubbles, agent left with avatar, streaming text reveal, tool-call cards (collapsible, status → result), code blocks with copy, sticky composer with model-picker chip. Award-level: "thinking" shimmer state; tool cards expand inline with spring; text streams in word-by-word.

### 4.13 Profile / settings
Header (avatar 88px, name, handle, edit) → stats row → content tabs or inset grouped list. Settings: destructive actions separated in red, version line in footer. Award-level: stretchy header — avatar parallax-zooms on pull-down.

---

## 5. Mobile quality gate (in addition to SKILL.md Phase 5)

1. Safe-area insets on ALL fixed chrome (tab bar, sheets, sticky CTAs).
2. Every interactive element ≥44px; primary CTA reachable one-handed.
3. Text inputs ≥16px font (no iOS auto-zoom).
4. Sheets dismiss by drag AND scrim tap AND back button.
5. Skeletons for all async content; optimistic UI for likes/sends/toggles.
6. Horizontal rails always show a peek of the next item.
7. No scroll-jacking on touch; parallax depth ≤60px; everything honors `prefers-reduced-motion`.
8. Test at 375×667 (SE) and 430×932 (Pro Max). Content must never hide behind the tab bar — bottom padding = tab bar height + safe area.
