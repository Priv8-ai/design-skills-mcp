# Layout Blueprints — Wireframes + Structural Skeletons

Pick ONE archetype per page. Every skeleton uses theme tokens (`var(--*)`) and Tailwind utilities — swap token values, never the structure. Vertical rhythm: section padding 96–128px desktop / 64px mobile; max content width 1120–1280px; gutters 24px.

## Contents

- **1. Hero Archetypes** — Archetype A — Split type + media · Archetype B — Centered stack · Archetype C — Full-bleed photo · Archetype D — Blob / organic
- **2. Landing Page Section Sequencing (universal order)**
- **3. Bento Grid**
- **4. Dashboard Skeleton**
- **5. Mobile Screen Patterns**


---

## 1. Hero Archetypes

### Archetype A — Split type + media
**When:** SaaS, fintech, apps with a strong product shot. Most versatile.

```
┌────────────────────────────────────────────────┐
│ NAVBAR (sticky, 64–80px)                       │
├──────────────────────┬─────────────────────────┤
│ EYEBROW              │                         │
│ H1 (56–72px, -0.03em)│   Photo / phone mockup  │
│ Sub (≤2 lines, muted)│   bleeding to viewport  │
│ [Pill CTA] [Ghost →] │   edge, slight 5–15°    │
│                      │   tilt + floating chips │
└──────────────────────┴─────────────────────────┘
```

```html
<section class="relative overflow-hidden">
  <div class="mx-auto grid max-w-6xl grid-cols-1 items-center gap-12 px-6 py-24 md:grid-cols-2 md:py-32">
    <div>
      <p class="font-body text-eyebrow font-semibold uppercase text-accent">Now in public beta</p>
      <h1 class="mt-4 font-display text-display text-ink">
        Banking that <em class="font-serif-accent italic">moves</em> with you
      </h1>
      <p class="mt-6 max-w-[480px] text-[18px] leading-relaxed text-muted">
        One account for spending, saving, and investing — with real-time everything.
      </p>
      <div class="mt-8 flex items-center gap-4">
        <a href="#" class="rounded-full bg-accent px-6 py-3 text-[15px] font-semibold text-accent-ink shadow-2 transition duration-micro ease-out-expo hover:-translate-y-px hover:brightness-105">Open account</a>
        <a href="#" class="group text-[15px] font-medium text-ink">See how it works <span class="inline-block transition-transform duration-micro group-hover:translate-x-1">→</span></a>
      </div>
    </div>
    <div class="relative">
      <img src="/hero-phone.png" alt="App on a phone" class="w-full rotate-6 rounded-xl2 shadow-3" />
      <!-- floating glass chips layered by motion-3d-playbook §3 -->
    </div>
  </div>
</section>
```

### Archetype B — Centered stack
**When:** dev tools, SaaS with a beautiful product UI. Biggest type; screenshot carries the sale.

```
┌────────────────────────────────────────────────┐
│              EYEBROW (centered)                │
│         H1 (64–96px, centered, 2 lines)        │
│            Sub (≤2 lines, muted)               │
│            [CTA] [Ghost]                       │
│      ┌──────────────────────────────┐          │
│      │   Product screenshot in      │          │
│      │   device frame, r-32,        │          │
│      │   shadow-3, tilts on scroll  │          │
│      └──────────────────────────────┘          │
└────────────────────────────────────────────────┘
```

```html
<section class="relative overflow-hidden px-6 pb-0 pt-24 text-center md:pt-32">
  <p class="text-eyebrow font-semibold uppercase text-accent">v3.0 is here</p>
  <h1 class="mx-auto mt-4 max-w-4xl font-display text-display text-ink">Ship faster than your roadmap</h1>
  <p class="mx-auto mt-6 max-w-[560px] text-[18px] text-muted">The deploy platform your whole team already knows how to use.</p>
  <div class="mt-8 flex justify-center gap-4">
    <a href="#" class="rounded-full bg-accent px-6 py-3 text-[15px] font-semibold text-accent-ink shadow-2">Start deploying</a>
    <a href="#" class="rounded-full border border-border px-6 py-3 text-[15px] font-medium text-ink">Read the docs</a>
  </div>
  <div class="mx-auto mt-16 max-w-5xl rounded-t-xl2 border border-border bg-surface p-2 shadow-3">
    <img src="/dashboard.png" alt="Product dashboard" class="w-full rounded-lg2" />
  </div>
</section>
```

### Archetype C — Full-bleed photo
**When:** premium/lifestyle, travel, wellness. Photo + scrim; white type; floating glass stat chips.

```
┌────────────────────────────────────────────────┐
│ ██████████████████████████████████████████████ │
│ ██ photo bg + bottom scrim gradient         ██ │
│ ██                                          ██ │
│ ██        H1 white, 64–96px                 ██ │
│ ██        sub white/80, [white CTA]         ██ │
│ ██  ╭glass chip╮              ╭glass chip╮  ██ │
│ ██████████████████████████████████████████████ │
└────────────────────────────────────────────────┘
```

```html
<section class="relative flex min-h-[92vh] items-center justify-center overflow-hidden">
  <img src="/hero-photo.jpg" alt="" class="absolute inset-0 h-full w-full object-cover" />
  <div class="absolute inset-0 bg-gradient-to-t from-black/60 via-black/20 to-black/10"></div>
  <div class="relative z-10 px-6 text-center text-white">
    <p class="text-eyebrow font-semibold uppercase text-white/70">Kyoto · 6 nights</p>
    <h1 class="mx-auto mt-4 max-w-3xl font-display text-display">Travel slower, remember more</h1>
    <a href="#" class="mt-8 inline-block rounded-full bg-white px-6 py-3 text-[15px] font-semibold text-ink">Plan my trip</a>
  </div>
  <div class="absolute bottom-10 left-10 z-10 rounded-lg2 border border-white/20 bg-white/10 px-5 py-4 text-white backdrop-blur-xl">
    <p class="text-[28px] font-bold">4.9</p><p class="text-[13px] text-white/70">2,400 reviews</p>
  </div>
</section>
```

### Archetype D — Blob / organic
**When:** education, food, health, charity. Photo cut into circle/blob masks + floating UI chips.

```
┌────────────────────────────────────────────────┐
│ EYEBROW                       ╭───────╮        │
│ H1 with [marker highlight]   ( circle )  chip  │
│ Sub                          ( photo  )        │
│ [CTA] [Text →]                ╰───────╯        │
│  chip        ╭blob╮                            │
└────────────────────────────────────────────────┘
```

```html
<section class="mx-auto grid max-w-6xl grid-cols-1 items-center gap-12 px-6 py-24 md:grid-cols-2">
  <div>
    <p class="text-eyebrow font-semibold uppercase text-accent">1,200 courses</p>
    <h1 class="mt-4 font-display text-display text-ink">
      Learn anything with a
      <span class="bg-[linear-gradient(transparent_62%,var(--accent2)_62%)]">great teacher</span>
    </h1>
    <p class="mt-6 max-w-[480px] text-[18px] text-muted">Live classes, real feedback, zero fluff.</p>
    <div class="mt-8 flex gap-4">
      <a href="#" class="rounded-full bg-accent px-6 py-3 text-[15px] font-semibold text-white shadow-2">Browse courses</a>
      <a href="#" class="self-center text-[15px] font-medium text-ink">Meet the teachers →</a>
    </div>
  </div>
  <div class="relative mx-auto aspect-square w-full max-w-[480px]">
    <img src="/teacher.jpg" alt="Teacher" class="h-full w-full rounded-full object-cover" />
    <div class="absolute -left-6 top-8 rounded-md2 bg-surface px-4 py-3 shadow-3">
      <p class="text-[13px] text-muted">Live now</p><p class="text-[15px] font-semibold text-ink">🎨 Watercolor basics</p>
    </div>
    <div class="absolute -right-4 bottom-10 rounded-md2 bg-surface px-4 py-3 shadow-3">
      <p class="text-[22px] font-bold text-accent">98%</p><p class="text-[13px] text-muted">completion rate</p>
    </div>
  </div>
</section>
```

---

## 2. Landing Page Section Sequencing (universal order)

```
1. Navbar (sticky, 64–80px)
2. Hero (one archetype above)
3. Logo cloud / trusted-by — mono logos at 30–50% opacity, h 24–32px
4. Feature grid — 3-col cards OR alternating 2-col rows
5. Product showcase — device mockup or big screenshot, angled or in-frame
6. Stats band — dark strip, 3–4 numerals (count-up on view)
7. Testimonials — cards or carousel
8. Pricing — 3 tiers, middle highlighted (dark fill or 2px accent border + "Most popular" chip)
9. CTA panel — colored/dark card, radius 24–32, single input + button fused in one pill
10. Footer — 4-col links, muted
```

```html
<main>
  <nav class="sticky top-0 z-50 h-16 border-b border-border bg-bg/70 backdrop-blur-xl"><!-- §motion playbook 4 --></nav>
  <section id="hero"><!-- archetype A–D --></section>
  <section class="mx-auto max-w-6xl px-6 py-16">
    <div class="flex flex-wrap items-center justify-center gap-10 opacity-40 grayscale">
      <img src="/logos/acme.svg" alt="Acme" class="h-7" /><!-- ×5–7 -->
    </div>
  </section>
  <section class="mx-auto max-w-6xl px-6 py-24 md:py-32">
    <h2 class="max-w-xl font-display text-h2 text-ink">Everything you need, nothing you don't</h2>
    <div class="mt-12 grid gap-6 md:grid-cols-3">
      <article class="rounded-lg2 border border-border bg-surface p-7 transition duration-ui ease-out-expo hover:-translate-y-1 hover:shadow-2">
        <div class="flex h-10 w-10 items-center justify-center rounded-sm2 bg-accent/10 text-accent">⚡</div>
        <h3 class="mt-5 text-[18px] font-semibold text-ink">Instant sync</h3>
        <p class="mt-2 text-[14px] leading-relaxed text-muted">Changes propagate in under 50ms, everywhere.</p>
      </article><!-- ×3–6 -->
    </div>
  </section>
  <section class="bg-[var(--band,#122B1D)] py-20 text-white">
    <div class="mx-auto grid max-w-5xl grid-cols-2 gap-8 px-6 text-center md:grid-cols-4">
      <div><p class="font-display text-[48px] font-bold" data-counter="2400000">0</p><p class="text-[13px] text-white/60">Users</p></div>
      <!-- stats band: count-up per motion-3d-playbook §7 -->
    </div>
  </section>
  <section class="mx-auto max-w-4xl px-6 py-24">
    <div class="rounded-xl2 bg-accent p-10 text-center text-accent-ink md:p-16">
      <h2 class="font-display text-h2">Start free today</h2>
      <form class="mx-auto mt-8 flex max-w-md items-center rounded-full bg-white p-1.5 shadow-2">
        <input type="email" required placeholder="you@work.com" class="w-full bg-transparent px-4 text-[15px] text-ink outline-none" />
        <button class="shrink-0 rounded-full bg-ink px-5 py-2.5 text-[14px] font-semibold text-white">Get started</button>
      </form>
    </div>
  </section>
</main>
```

---

## 3. Bento Grid

**When:** feature-dense products (AI, dev tools, productivity) — show 5–7 features with varied visual weight. One cell is 2× the others (the dominant element).

```
┌───────────────┬─────────┬─────────┐
│               │ cell 2  │ cell 3  │
│  HERO CELL    ├─────────┴─────────┤
│  (2 rows)     │    cell 4 (wide)  │
├───────────────┼─────────┬─────────┤
│ cell 5        │ cell 6  │ cell 7  │
└───────────────┴─────────┴─────────┘
```

```html
<section class="mx-auto max-w-6xl px-6 py-24">
  <div class="grid auto-rows-[220px] gap-4 md:grid-cols-4">
    <article class="group relative overflow-hidden rounded-lg2 border border-border bg-surface p-7 md:col-span-2 md:row-span-2">
      <h3 class="text-[22px] font-semibold text-ink">AI copilot built in</h3>
      <p class="mt-2 max-w-xs text-[14px] text-muted">Drafts, refactors, and explains — inline.</p>
      <img src="/bento-copilot.png" alt="" class="absolute -bottom-8 left-7 w-[85%] rounded-t-md2 shadow-3 transition-transform duration-ui ease-out-expo group-hover:-translate-y-2" />
    </article>
    <article class="rounded-lg2 border border-border bg-surface p-6 transition duration-ui hover:-translate-y-1 hover:shadow-2">
      <h3 class="text-[16px] font-semibold text-ink">Edge deploys</h3>
      <p class="mt-1 text-[13px] text-muted">35 regions, zero config.</p>
    </article>
    <!-- cells 3–7: same anatomy, hero cell holds the only screenshot -->
  </div>
</section>
```

Rules: hero cell gets the visual; all other cells are icon + title + one line. Hover: lift + shadow on cards, image translate inside the hero cell. See motion playbook §6 for bento hover expansion.

---

## 4. Dashboard Skeleton

**When:** any app/admin/analytics product.

```
┌──────────────────────────────────────────────┐
│ Topbar: search · actions · avatar            │
├────────┬──────────────────────────┬──────────┤
│Sidebar │ KPI row (3–4 cards)      │ Right    │
│ 240px  │ Main chart card          │ rail:    │
│ or 72px│ Secondary chart + table  │ profile, │
│icon rail│                         │ alerts   │
└────────┴──────────────────────────┴──────────┘
```

```html
<div class="flex min-h-screen bg-bg text-ink">
  <aside class="hidden w-60 shrink-0 border-r border-border bg-surface p-4 md:block">
    <p class="px-3 pb-2 text-[11px] font-semibold uppercase tracking-wider text-muted">Workspace</p>
    <a href="#" class="flex h-10 items-center gap-3 rounded-sm2 bg-accent/10 px-3 text-[14px] font-medium text-accent">▦ Overview</a>
    <a href="#" class="flex h-10 items-center gap-3 rounded-sm2 px-3 text-[14px] text-muted transition duration-micro hover:bg-ink/5 hover:text-ink">◔ Analytics</a>
  </aside>
  <main class="flex-1 p-6 lg:p-8">
    <div class="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
      <article class="rounded-md2 border border-border bg-surface p-5">
        <div class="flex items-center justify-between">
          <div class="flex h-9 w-9 items-center justify-center rounded-sm2 bg-accent/10 text-accent">↗</div>
          <span class="rounded-full bg-[#16A34A]/10 px-2 py-0.5 text-[12px] font-semibold text-[#16A34A]">▲ 8.2%</span>
        </div>
        <p class="mt-4 text-[13px] text-muted">Monthly revenue</p>
        <p class="mt-1 text-[26px] font-bold tracking-tight [font-variant-numeric:tabular-nums]">$84,290</p>
      </article><!-- ×3–4 KPI cards -->
    </div>
    <div class="mt-4 grid gap-4 lg:grid-cols-3">
      <article class="rounded-md2 border border-border bg-surface p-6 lg:col-span-2"><!-- main chart, ≤2 series --></article>
      <article class="rounded-md2 border border-border bg-surface p-6"><!-- right-rail card --></article>
    </div>
  </main>
</div>
```

Anatomy rules: canvas `#F4F5FA`–class (light) or near-black (dark); cards 4–6% lighter than canvas; card padding 20–28px; grid gap 16–24px; KPI delta green `#16A34A` / red `#DC2626`; gridlines at 6% alpha; dark dashboards use 1px borders, not shadows.

---

## 5. Mobile Screen Patterns

**When:** mobile-web apps, PWAs. Page padding 20–24px; card padding 16–20px; list rows 64–72px; primary button h 52–56px full-width pill.

```
Status bar
App header: greeting/title 28–34px/700 + avatar or icon buttons
Hero component: balance card / photo card / progress ring, radius 24–28
Section header row: title 18–20px/700 ··· "See all" accent 13px
Horizontal card carousel OR vertical list rows
Bottom tab bar: 72–80px, 4–5 icons 24px, active = accent fill or dot,
  optional center FAB 56px
```

```html
<div class="mx-auto flex min-h-dvh max-w-sm flex-col bg-bg pb-24 text-ink">
  <header class="flex items-center justify-between px-5 pt-6">
    <div>
      <p class="text-[13px] text-muted">Good morning</p>
      <h1 class="text-[28px] font-bold tracking-tight">Amara</h1>
    </div>
    <img src="/avatar.jpg" alt="" class="h-11 w-11 rounded-full object-cover" />
  </header>
  <section class="mx-5 mt-6 rounded-lg2 bg-[linear-gradient(135deg,var(--accent),var(--cta,#6C5CE7))] p-6 text-white shadow-2">
    <p class="text-[13px] text-white/70">Total balance</p>
    <p class="mt-1 text-[38px] font-extrabold [font-variant-numeric:tabular-nums]">$12,480.32</p>
    <div class="mt-5 flex gap-3">
      <button class="flex-1 rounded-full bg-white/15 py-2.5 text-[14px] font-semibold backdrop-blur">Send</button>
      <button class="flex-1 rounded-full bg-white/15 py-2.5 text-[14px] font-semibold backdrop-blur">Request</button>
    </div>
  </section>
  <div class="mt-7 flex items-center justify-between px-5">
    <h2 class="text-[18px] font-bold">Recent activity</h2>
    <a href="#" class="text-[13px] font-medium text-accent">See all</a>
  </div>
  <ul class="mt-3 space-y-1 px-5">
    <li class="flex h-16 items-center gap-3 rounded-md2 px-2 transition duration-micro hover:bg-ink/5">
      <div class="flex h-10 w-10 items-center justify-center rounded-full bg-accent/10 text-accent">☕</div>
      <div class="flex-1"><p class="text-[15px] font-medium">Blue Bottle</p><p class="text-[12px] text-muted">Today, 9:41</p></div>
      <p class="text-[15px] font-semibold [font-variant-numeric:tabular-nums]">−$6.40</p>
    </li><!-- rows ×4–6 -->
  </ul>
  <nav class="fixed inset-x-0 bottom-0 mx-auto flex h-20 max-w-sm items-center justify-around rounded-t-lg2 border-t border-border bg-surface/80 backdrop-blur-xl">
    <a href="#" class="text-accent">●</a><a href="#" class="text-muted">◔</a>
    <button class="-mt-8 flex h-14 w-14 items-center justify-center rounded-full bg-accent text-[22px] text-accent-ink shadow-3">＋</button>
    <a href="#" class="text-muted">▦</a><a href="#" class="text-muted">☺</a>
  </nav>
</div>
```

Signature components by domain (drop into the hero slot): fintech = gradient balance card; health = progress ring (stroke 14–18px, round caps, track = accent@12%); portfolio = donut (stroke 28–32px); trading = timeframe pills + glowing line; travel = route visual (CODE ╌╌ ✈ ╌╌ CODE, dashed 2px); social/dating = story progress bars (h 3, r 2) + FAB cluster.
