# Asset Generation — Real Images, Video & 3D in Every Build

Award-level UIs are media-rich: real key visuals, ambient video, floating product cutouts, believable avatars. This file turns the theme tokens into an art-directed media pipeline. Primary engine: the **Higgsfield MCP connector** (image / video / 3D / audio generation). When it isn't connected, use §7's procedural fallback ladder — **never ship gray placeholder boxes or hotlinked stock**.

## 0. Rules before spending anything

1. **Credits are the user's money.** Generation runs on the user's Higgsfield credits. Generate when the user asked for imagery/video/cinematic quality or approved your proposed shot list; otherwise propose the shot list first ("I can generate a hero visual + ambient loop + 3 avatars — want me to?"). For >3 assets or any video, preflight with `get_cost: true` and surface the number.
2. **Never pass `use_unlim: true` on your own initiative** — omit it and let the server ask.
3. Higgsfield tools are a third-party connector: if they aren't available in the session, don't stall — fall back (§7) and note the upgrade path to the user.
4. Every generated asset must obey the **media quality gate** (SKILL.md Phase 6, item 9): explicit `width/height` or `aspect-ratio` (zero CLS), lazy-load all non-hero media, `alt` text, video muted + `playsinline` + poster + paused off-screen and under `prefers-reduced-motion`.

## 1. Art-direction contract (tokens → prompts)

Every prompt inherits the theme so media looks *designed in*, not pasted on. Build one **media DNA** line per project and append it to every prompt:

`"<subject>. <style words>, color palette <bg hex>, <accent hex>, <support hex>, <lighting>, <camera/finish>, no text, no watermark"`

| data-theme | Style words | Lighting / finish |
|---|---|---|
| trust / fintech | minimal 3D render, soft studio product shot, clean geometry | soft diffuse light, matte, high key |
| neon-trading / acid | dark cinematic 3D, glossy black surfaces, neon rim light | volumetric glow, reflections, low key |
| ai-glass | iridescent glass abstract, refractive orb, chromatic dispersion | backlit gradient, dreamy bloom |
| organic / health | natural photography, organic shapes, film grain | golden hour, soft shadows, warm |
| luxury / luxury-dark | editorial photography, architectural, negative space | dramatic single-source light, deep shadow |
| navy / dating | bold graphic 3D, chunky shapes, high energy | punchy contrast, saturated accent |
| education / neobank / candy | playful clay 3D render, rounded friendly forms | bright even light, pastel pop |

Add the actual hex values from the active theme into the palette slot — the models honor them well. For photorealistic humans prefer `soul_2`/`soul_cast`; for everything graphic, `nano_banana_pro` (crisp 4K, handles UI mockups and diagram-like art).

## 2. The shot list (what to generate per surface)

| Surface | Asset | Aspect / notes |
|---|---|---|
| Hero (split/blob archetype) | 1 key visual | `4:5` or `1:1`; generate `count: 3` variants, embed the best |
| Hero (full-bleed archetype) | 1 wide visual | `16:9`; need ultrawide? generate `16:9` → `outpaint_image` to `21:9` |
| Hero (cinematic tier) | 5s ambient loop | `generate_video` `kling3_0_turbo`, `16:9`, slow drift/loops well; plus a matching still (same prompt, same model family) as `poster` |
| Product/feature cards | floating object PNGs | generate object on plain bg → `remove_background` → layer with shadows |
| Testimonials/team | 3–6 avatars | batch `soul_cast` portraits, `1:1`, consistent lighting phrase across all |
| Showcase / bento | 2–4 texture or detail shots | `1:1`/`4:3`; keep one shared style phrase |
| 3D scene (GLB orbit/exploded) | 1 mesh | best still → `generate_3d` (`image_to_3d`, texture+PBR; `models_explore(type:'3d')` first) |
| OG/social card | 1 image | `16:9`, bold, includes headline space left/top third |
| Mobile app | hero card art, empty-state illos, avatar set | `4:5` cards, `1:1` illos; keep depth subtle |

Ceiling: **≤ 8 generated assets per page** — art direction beats volume.

## 3. Exact pipeline (tool choreography)

1. **Pick models:** `models_explore(action:'recommend', query:'<goal + input context>')` if unsure; else defaults above.
2. **Single hero asset:** `generate_image` with `params: { model, prompt, aspect_ratio, count: 2–4 }` → pick the strongest variant.
3. **Many distinct assets (≤12):** `generate_image_batch` / `generate_video_batch` with indexed `requests: [{ index, params: { model, prompt, aspect_ratio } }]`.
4. **Wait:** `jobs_wait({ jobs: [{index, job_id}...], timeout_seconds: 15 })`; if `all_terminal` is false, wait `poll_after_seconds`, call again. Collect **result URLs** from terminal jobs.
5. **Show the user once:** after all groups are terminal, one `show_generation_by_ids` with the full indexed set (never per-job displays).
6. **Post-process as needed:** `remove_background` (cutouts), `outpaint_image` (wider canvas), `upscale_image` (only when the user wants print/4K — pass real `width`/`height`).
7. **Embed the returned CDN URLs** directly in the build (§4). For a user-supplied reference image URL, `media_import_url` → use returned `media_id` in `medias: [{ value, role }]`.
8. Any `recovery_tool` in a response → call it immediately; apply any `adjustments` echoed back.

Reference media rule: `medias[].value` takes a **media_id or prior job_id — never a raw URL**.

## 4. Embed patterns (copy-paste)

### 4a. Hero image with LQIP blur-up (zero CLS)
```html
<figure class="hero-media" style="--lqip: radial-gradient(120% 120% at 30% 20%, var(--accent) 0%, var(--bg) 70%);">
  <img src="HERO_URL" alt="Abstract render of the product's core idea"
       width="1600" height="2000" fetchpriority="high" decoding="async">
</figure>
<style>
  .hero-media { aspect-ratio: 4/5; overflow: hidden; border-radius: var(--r-lg);
    background: var(--lqip); }
  .hero-media img { width: 100%; height: 100%; object-fit: cover;
    opacity: 0; transition: opacity .6s var(--ease-out-expo); }
  .hero-media img.loaded, .hero-media img[data-nojs] { opacity: 1; }
</style>
<script>
  document.querySelectorAll(".hero-media img").forEach(img => {
    if (img.complete) img.classList.add("loaded");
    else img.addEventListener("load", () => img.classList.add("loaded"), { once: true });
  });
</script>
```
Non-hero media: add `loading="lazy"` and drop `fetchpriority`.

### 4b. Ambient video hero (polite by default)
```html
<video class="ambient" autoplay muted loop playsinline preload="metadata"
       poster="POSTER_URL" width="1920" height="1080" aria-hidden="true">
  <source src="LOOP_URL" type="video/mp4">
</video>
<script>
  const v = document.querySelector(".ambient");
  const rm = matchMedia("(prefers-reduced-motion: reduce)");
  const sync = () => { if (rm.matches) { v.pause(); v.removeAttribute("autoplay"); } };
  rm.addEventListener?.("change", sync); sync();
  new IntersectionObserver(([e]) =>
    e.isIntersecting && !rm.matches ? v.play().catch(()=>{}) : v.pause()
  ).observe(v);
</script>
```
Reduced motion shows the poster — which is why the poster must be a real generated still, not a black frame. Scroll-scrubbed video: `signature-scenes.md` S1.

### 4c. Floating cutout stack (depth without WebGL)
```html
<div class="stack" style="perspective:1000px">
  <img class="stack-glow" src="CUTOUT_URL" alt="" width="900" height="900">
  <img class="stack-obj" src="CUTOUT_URL" alt="Product name" width="900" height="900">
</div>
<style>
  .stack { position: relative; }
  .stack img { width: 100%; height: auto; }
  .stack-glow { position: absolute; inset: 0; filter: blur(40px) saturate(1.6); opacity:.45; transform: translateY(6%) scale(.92); }
  .stack-obj  { position: relative; filter: drop-shadow(0 30px 60px rgb(0 0 0 / .35)); }
</style>
```
Then attach playbook §6a tilt or §2c z-parallax to `.stack-obj`.

### 4d. Generated GLB in a build
Vanilla (ES modules CDN):
```html
<script type="module">
  import * as THREE from "https://unpkg.com/three@0.160.0/build/three.module.js";
  import { GLTFLoader } from "https://unpkg.com/three@0.160.0/examples/jsm/loaders/GLTFLoader.js";
  // scene/camera/renderer boilerplate → then:
  new GLTFLoader().load("MODEL_URL.glb", (g) => scene.add(g.scene));
</script>
```
React: `useGLTF("MODEL_URL.glb")` via `@react-three/drei` inside R3F (only when the user asked for true WebGL — SKILL.md routing). Full orbit stage recipe: `signature-scenes.md` S11. Keep meshes < 5MB; lazy-mount the canvas (IntersectionObserver) and pause the RAF loop off-screen.

### 4e. UI sound layer (optional, off by default)
Only when the user asks for sound: `generate_audio` (`seed_audio`) can voice a short product line for a demo scene. Never autoplay audio; gate strictly behind a click on a visible mute-toggle. Skip SFX entirely — this connector is speech-only.

## 5. Runtime-generated imagery inside AI artifacts (advanced)

For claude.ai artifacts that should create imagery **at runtime** (e.g. "generate my banner" button), call the Anthropic API from the artifact with the Higgsfield MCP attached and have Claude run the generation:
```js
const r = await fetch("https://api.anthropic.com/v1/messages", {
  method: "POST", headers: { "Content-Type": "application/json" },
  body: JSON.stringify({
    model: "claude-sonnet-4-6", max_tokens: 1000,
    messages: [{ role: "user", content: promptForImage }],
    mcp_servers: [{ type: "url", url: "https://mcp.higgsfield.ai/mcp", name: "higgsfield" }],
  }),
});
const data = await r.json();
const urls = data.content.filter(b => b.type === "mcp_tool_result")
  .flatMap(b => (b.content?.[0]?.text?.match(/https:\/\/\S+\.(png|jpe?g|webp|mp4)/g) ?? []));
```
Label the control clearly ("uses your Higgsfield credits") and handle the no-connector error path.

## 6. Ship it live (when the user wants a URL)

Static builds can be deployed straight through connected MCPs: **Higgsfield websites** (`create_website` → follow `get_website_creation_instructions` → commit/push → `deploy_website`; `publish_website` only lists the already-live build on the feed) or **Vercel / Replit** connectors when present. Fill real OG metadata before publishing — generate the `og_image_url` with this pipeline.

## 7. Fallback ladder (no Higgsfield connected)

1. **SVG mesh-gradient + film grain** — hero-grade backdrop from pure tokens:
```html
<svg class="mesh" viewBox="0 0 1200 800" preserveAspectRatio="xMidYMid slice" aria-hidden="true">
  <defs>
    <radialGradient id="a" cx="25%" cy="20%" r="60%"><stop offset="0%" stop-color="var(--accent)"/><stop offset="100%" stop-color="transparent"/></radialGradient>
    <radialGradient id="b" cx="80%" cy="75%" r="55%"><stop offset="0%" stop-color="var(--accent2, var(--accent))" stop-opacity=".7"/><stop offset="100%" stop-color="transparent"/></radialGradient>
    <filter id="grain"><feTurbulence type="fractalNoise" baseFrequency="0.9" numOctaves="2"/><feColorMatrix type="saturate" values="0"/><feComponentTransfer><feFuncA type="linear" slope="0.06"/></feComponentTransfer></filter>
  </defs>
  <rect width="1200" height="800" fill="var(--bg)"/>
  <rect width="1200" height="800" fill="url(#a)"/><rect width="1200" height="800" fill="url(#b)"/>
  <rect width="1200" height="800" filter="url(#grain)"/>
</svg>
```
2. **Pure-CSS aurora** (playbook §8a) + grain (§8b) when even SVG feels heavy.
3. **Canvas generative art** — particles (§8d) or the shader-gradient signature scene (S7) as the "key visual".
4. **Hand-drawn SVG product glyphs** — outline illustrations in `--accent` with S6 line-draw as the reveal.
5. **CSS device mock + typographic screenshot** — fake the app UI in HTML inside a device frame instead of a screenshot image.

The ladder is also the **reduced-data path**: prefer it for backgrounds even when generation is available, and spend generated media on foreground subjects the user will actually look at.
