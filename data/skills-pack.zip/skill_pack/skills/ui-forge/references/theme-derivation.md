# Theme Derivation — From Any Product Domain to a Full Design System

Mechanically derive a complete, proven design system (color, type, spacing, radius, shadow, motion) from nothing but the product's domain and mood. All hex values are distilled from award-level designs — reuse them verbatim.

---

## The 8-Step Method

**Step 1 — Classify the domain.** Match the product to a row in the Domain → Formula table below. Take its base (light/dark), accent direction, type voice, and signature component.

**Step 2 — Pick the accent by emotion:** trust = blue, money = green, energy = orange/yellow, luxury = gold or ink-only, playful = violet, fresh = teal, urgent = coral/pink, futuristic = neon mint/lime.

**Step 3 — Derive the base surfaces.**
- Light theme: `bg = hsl(accentHue, 15–30%, 96–98%)` (tint the near-white toward the accent); `surface = #FFFFFF`; `ink = #0F1115`.
- Dark theme: NEVER pure black. `bg = hsl(accentHue, 20–35%, 4–8%)`; `surface = bg + 4–6% lightness`; push accent lightness to 60–75% (neon) for contrast.

**Step 4 — Derive text + border tokens.**
- Muted text = ink at 60–65% alpha, or a hue-shifted gray (e.g. `#9AA3C7` on navy).
- Border = ink at 6–8% alpha (light) / `rgba(255,255,255,0.06–0.10)` (dark).

**Step 5 — Pick the type voice** (see Type Pairing below): grotesque default; +1 expressive accent font for ONE keyword per headline on marketing pages; mono for data/terminal voices; soft serif for wellness/luxury.

**Step 6 — Lock the token scales.** Copy the spacing, radius, shadow, and motion scales below verbatim. Choose a radius system: small (8–12px, dense/enterprise) OR large (16–28px, consumer/marketing). Pills (999px) always for buttons/chips.

**Step 7 — Choose ONE layout archetype + ONE signature component** (see `layout-blueprints.md` §5.5). Never mix hero archetypes on one page.

**Step 8 — Apply the discipline rules:**
1. ONE accent; ≤2 chart series; ≤3 categorical colors per view.
2. One type family, ≥2 weight contrast (400 vs 800); display sizes always get negative tracking.
3. Sections breathe 96–128px; when in doubt, add whitespace, not borders.
4. Every screen gets exactly ONE dominant element (huge number, photo, or headline).
5. Design hover/active/selected/empty states with the same tokens.
6. Light themes separate with shadows; dark themes with 1px borders + occasional accent glow. Never heavy shadows on dark.
7. Reserve saturated fills for actions and key data; keep 80% of the UI neutral.
8. Tinted tags: `bg = color @ 12% alpha`, `text = color`, `radius = 999px`, `12px/600`.

---

## Domain → Formula Mapping

| Domain | Base | Accent direction | Type voice | Signature layout/component |
|---|---|---|---|---|
| Finance / B2B SaaS | light cool gray or navy dark | blue/indigo `#3B4BF0`, green `#17B26A` | grotesque, tabular nums | split hero, balance card, KPI row |
| Crypto / trading / dev tools | near-black tinted | neon mint `#4EF0A6` / lime `#D9FF2E` / cyan + glow | mono numerals | chart hero, swap card, gauge |
| AI / futuristic | purple-black gradient | violet `#8B5CF6` + glass surfaces | grotesque + glow | glass cards, orb motif |
| Food / restaurant | warm cream/sage | orange-red `#FF4D24` or teal `#3D7A6B` | chunky grotesque | circular photos, price chips |
| Health / fitness / wellness | warm cream or pastel light | orange `#FF8A3C`, sage `#7A8B6F` | grotesque or soft serif | progress rings, stat grid, calming blobs |
| Education / charity | light warm | teal+orange, emerald+lime | friendly grotesque | blob masks, progress bars, stat band |
| Fashion / luxury | off-white or true dark | ink-only or single metallic gold `#C9A96A` | serif display | editorial grid, huge type, no pill buttons |
| Social / dating / media | violet-black dark | electric lime `#D8FF3E` / pink | bold display | full-bleed cards, FAB cluster |
| Travel / mobility | airy light blue or map-dark | sky `#3B9EFF` | grotesque | photo cards, route lines, bottom sheets |
| Automotive / hardware | pure dark | one accent (red/silver/gold) | thin caps + display | full-bleed product shots, spec callouts |
| Productivity / consumer tools | cool near-white | cobalt `#2E5BFF` + 2 candy support tiles | chunky grotesque | bento grid, chip filters, playful stat tiles |

---

## The 15 Proven Palette Bundles (CSS variables — copy verbatim)

```css
/* A. Trust SaaS (light) — B2B SaaS, finance */
[data-theme="trust"] {
  --bg:#F4F5FA; --surface:#FFFFFF; --ink:#0F1115; --muted:#5A6069;
  --accent:#3B4BF0; --accent-ink:#FFFFFF; --border:#E5E7F0; --success:#16A34A;
}

/* B. Fintech indigo+coral (light) — banking, wallets */
[data-theme="fintech"] {
  --bg:#EDEEFA; --surface:#FFFFFF; --ink:#191B2A; --muted:#9BA0B5;
  --accent:#3F3DDB; --accent2:#F0506E; --chart1:#4C6FFF; --chart2:#FF6B8A;
}

/* C. Neon trading (dark) — crypto, trading terminals */
[data-theme="neon-trading"] {
  --bg:#050B08; --surface:#0B100D; --card:#111611; --ink:#E8F5EE; --muted:#5F6B63;
  --accent:#4EF0A6; --accent-glow:rgba(46,255,179,.35); --link:#4A9EFF;
}

/* D. Dev/security acid (dark) — developer tools, security */
[data-theme="acid"] {
  --bg:#1B1B21; --card:#26262E; --ink:#FFFFFF; --muted:#6E6E78; --accent:#D9FF2E;
}

/* E. Sports navy (dark) — sports, media, gaming */
[data-theme="navy"] {
  --bg:#232A4A; --card:#2C3555; --ink:#FFFFFF; --muted:#9AA3C7;
  --accent:#4E8DFF; --hot:#F43F5E; --gradient:linear-gradient(135deg,#7B5CFA,#4A7BF7);
}

/* F. Organic/food (light warm) — restaurants, grocery, agriculture */
[data-theme="organic"] {
  --bg:#E3E9DC; --surface:#FFFFFF; --ink:#101512; --muted:#6B7264;
  --accent:#3D7A6B; --accent2:#8FA56B; --rating:#F6C344;
}

/* G. Playful education (light) — LMS, kids, courses */
[data-theme="education"] {
  --bg:#F7F8FA; --surface:#FFFFFF; --ink:#131A2E; --muted:#6A7280;
  --accent:#0E5E4F; --accent2:#F5A524; --support:#7CD4F0;
}

/* H. Charity/lime (light) — non-profit, fundraising */
[data-theme="charity"] {
  --bg:#FBFCFA; --ink:#141A16; --accent:#0B7A4B; --lime:#D9F99D; --band:#122B1D;
}

/* I. Luxury editorial (light) — fashion, architecture, editorial */
[data-theme="luxury"] {
  --bg:#F5F3EF; --ink:#101010; --muted:#7A756C; --accent:#101010;
  /* accent = ink; use links/arrows, not pill buttons */
}

/* J. Luxury dark / automotive */
[data-theme="luxury-dark"] {
  --bg:#0B0B0C; --card:#151517; --ink:#F5F5F4; --muted:#8E8E93; --accent:#C9A96A; /* gold */
}

/* K. AI glass (dark purple gradient) — AI products, web3 */
[data-theme="ai-glass"] {
  --bg:linear-gradient(160deg,#2A1B5E,#0F0B2E);
  --glass:rgba(255,255,255,.10); --glass-border:rgba(255,255,255,.22);
  --ink:#FFFFFF; --muted:rgba(255,255,255,.65); --accent:#C084FC;
}

/* L. Neo-bank playful (mobile light) */
[data-theme="neobank"] {
  --bg:#EFEFEA; --surface:#FFFFFF; --ink:#111111; --accent:#17B26A; --accent2:#FFC21C; --cta:#6C5CE7;
}

/* M. Dating night (mobile dark) — social, dating, nightlife */
[data-theme="dating"] {
  --bg:#101015; --card:#1A1A21; --ink:#FFFFFF; --muted:#8A8A93; --accent:#D8FF3E;
}

/* N. Health pastel (mobile light) — health, fitness, meditation */
[data-theme="health"] {
  --bg:#F7F8FA; --surface:#FFFFFF; --ink:#191C1E; --muted:#8A94A6;
  --accent:#FF8A3C; --blue:#4C9AFF; --purple:#8B5CF6; --green:#22C55E;
}

/* O. Candy bento (light multi-tile) — productivity, consumer tools, playful SaaS */
[data-theme="candy"] {
  --bg:#ECF2F9; --surface:#FFFFFF; --ink:#10131A; --muted:#5F6C82;
  --accent:#2E5BFF; --accent2:#FFB020; --accent3:#FF6B5E; --accent4:#8B5CF6;
  /* bento discipline: neutral tiles + at most TWO saturated feature tiles per grid */
}
```

### Semantic & categorical tokens (any theme)

```css
--success:#16A34A; --warning:#F59E0B; --danger:#DC2626; --info:#3B82F6;
/* categorical chart set (light bg): */ /* #4C6FFF #FF6B8A #F5A524 #2FB8A6 #8B5CF6 */
/* categorical chart set (dark bg):  */ /* #2DFFB3 #FF3D8A #3D7BFF #B04DFF #FACC15 */
```

---

## Type-Pairing Strategy

Pick ONE voice. One family minimum, two weights (400 vs 800) mandatory contrast. All picks are on Google Fonts.

| Voice | Display font | Body font | Use for |
|---|---|---|---|
| Product UI default | **Inter** (700–800) | Inter (400) | SaaS, fintech, dashboards — one family, weights 400–800 |
| Marketing punch | **Space Grotesk** or **Sora** (700) + **Instrument Serif** italic for ONE keyword | Inter | SaaS/AI landing pages |
| Data/terminal | **JetBrains Mono** or **Space Mono** for numerals | Inter | dev tools, trading, VPN ("62.5", prices) |
| Wellness/editorial | **Fraunces** or **Playfair Display** (soft serif) | Inter | meditation, fashion, luxury |
| Chunky consumer | **Clash Display**-class grotesque / **Archivo** (800) | Inter | food, education, neo-banks |
| Thin luxury caps | **Cormorant Garamond** display + caps eyebrows | Inter | automotive, high-end real estate |

Google Fonts import example (Inter + Sora + Instrument Serif):
```html
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=Sora:wght@600;700;800&family=Instrument+Serif:ital@0;1&family=JetBrains+Mono:wght@500;700&display=swap" rel="stylesheet">
```

CSS font stacks:
```css
--font-display: "Sora", "Inter", system-ui, sans-serif;
--font-body: "Inter", system-ui, -apple-system, sans-serif;
--font-serif-accent: "Instrument Serif", Georgia, serif;  /* italic keyword only */
--font-mono: "JetBrains Mono", ui-monospace, "SF Mono", monospace;
```

### Type scale (web, 1.25–1.333 ratio)

```css
--fs-display: clamp(48px, 7vw, 96px);  /* hero H1: weight 700-800, ls -0.03em, lh 1.02 */
--fs-h1: 56px;  --fs-h2: 40px;  --fs-h3: 28px;  --fs-h4: 22px;
--fs-body-lg: 18px; --fs-body: 16px; --fs-small: 14px; --fs-caption: 13px;
--fs-eyebrow: 12.5px; /* caps, ls .08em, weight 600, accent or muted */
```

Mobile: title 28–34px/700, section head 18–20px/700, body 15–16px/400 (lh 1.5), caption 12–13px, big numbers 34–56px/700–800. Finance numerals: `font-variant-numeric: tabular-nums`.

### Headline devices (use ONE per hero)

- **Marker highlight:** brush swash behind a keyword (`.mark { background: linear-gradient(transparent 62%, var(--accent2) 62%); }`).
- **Mixed weight/gray:** secondary words at 50% opacity or weight 400.
- **Pill-in-headline:** keyword wrapped in a dark pill with an icon.
- **Outlined stroke text:** `-webkit-text-stroke: 1.5px var(--ink); color: transparent;` for one word/numeral.

---

## Spacing, Radius, Shadow, Motion Token Scales

```css
/* spacing — 4px base */
--s1:4px; --s2:8px; --s3:12px; --s4:16px; --s5:24px; --s6:32px;
--s7:48px; --s8:64px; --s9:96px; --s10:128px;

/* radius */
--r-xs:6px;   /* inputs, tags in dense tools */
--r-sm:10px;  /* enterprise cards, table rows */
--r-md:16px;  /* default cards */
--r-lg:24px;  /* hero panels, mobile cards (20–28) */
--r-xl:32px;  /* CTA panels, app frames */
--r-pill:999px; /* buttons, chips, toggles */

/* elevation (light themes) */
--shadow-1: 0 1px 2px rgba(16,24,40,.06), 0 1px 3px rgba(16,24,40,.10);
--shadow-2: 0 8px 24px rgba(16,24,40,.10);
--shadow-3: 0 16px 48px rgba(16,24,40,.14);  /* floating chips over photos */
/* dark themes: borders + glow, not shadows */
--border-dark: 1px solid rgba(255,255,255,.08);
--glow-accent: 0 0 24px rgba(78,240,166,.35), 0 0 64px rgba(78,240,166,.15);

/* motion */
--dur-micro: 150ms;   /* hover/press (120–200ms) */
--dur-ui: 300ms;      /* cards, sheets (250–350ms) */
--dur-hero: 700ms;    /* entrances (500–800ms) */
--ease-out-expo: cubic-bezier(0.16, 1, 0.3, 1);
--ease-spring: cubic-bezier(0.34, 1.56, 0.64, 1);  /* slight overshoot */
--stagger: 50ms;      /* per-item list stagger (40–60ms, max 8 items) */
```

### Tailwind config snippet

```js
// tailwind.config.js — maps tokens into Tailwind utilities
module.exports = {
  theme: {
    extend: {
      colors: {
        bg: "var(--bg)", surface: "var(--surface)", ink: "var(--ink)",
        muted: "var(--muted)", accent: "var(--accent)", "accent-ink": "var(--accent-ink)",
        border: "var(--border)",
      },
      fontFamily: {
        display: ["var(--font-display)"], body: ["var(--font-body)"],
        mono: ["var(--font-mono)"],
      },
      fontSize: {
        display: ["var(--fs-display)", { lineHeight: "1.02", letterSpacing: "-0.03em" }],
        h2: ["40px", { lineHeight: "1.1", letterSpacing: "-0.02em" }],
        eyebrow: ["12.5px", { lineHeight: "1", letterSpacing: "0.08em" }],
      },
      borderRadius: { sm2: "10px", md2: "16px", lg2: "24px", xl2: "32px" },
      boxShadow: {
        1: "var(--shadow-1)", 2: "var(--shadow-2)", 3: "var(--shadow-3)",
        glow: "var(--glow-accent)",
      },
      transitionTimingFunction: {
        "out-expo": "cubic-bezier(0.16, 1, 0.3, 1)",
        spring: "cubic-bezier(0.34, 1.56, 0.64, 1)",
      },
      transitionDuration: { micro: "150ms", ui: "300ms", hero: "700ms" },
    },
  },
};
```
