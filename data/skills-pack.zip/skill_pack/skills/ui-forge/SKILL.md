---
name: ui-forge
description: >-
  Build MAGNIFICENT, award-caliber (Awwwards-level) UIs for any product — landing pages, SaaS dashboards, e-commerce, portfolios, mobile app UIs, and complete multi-page templates (landing→dashboard→404). v2 adds Three.js Scroll Worlds (scroll-driven camera journeys through one 3D scene) and ambient particles (leaves, pointer trails, orbs). 3D scroll effects (parallax, tilt, scroll-jack) are ON by default, plus animated navigation, magnetic/tilt/ripple micro-interactions, Lenis+GSAP smooth scrolling, REAL media via the Higgsfield MCP (procedural fallbacks) and live deployment via website MCPs. Triggers on any request to design, build, or redesign a UI: 'landing page', 'make it premium/cinematic', 'scroll animations', 'scroll world', 'fly-through', '3D journey', 'particle effects', 'animated navbar', 'mobile app UI', 'full template', 'generate a hero image', 'ship it live'.
---

# UI Forge — Award-Caliber UI Engineering

Follow the phased workflow below in order. Load reference files only when you reach their phase (progressive disclosure). Distilled from 171 award-level designs; every token has proven hex values — never invent palette colors.

## Defaults that apply unless the user says otherwise

- **3D scroll layer is ON by default.** Every landing/hero/primary page gets smooth scroll (Lenis), scroll-driven parallax depth, and at least one 3D effect (perspective tilt, z-depth parallax, horizontal scroll-jack on desktop, or camera dolly). Only skip it when the user explicitly declines animations/3D, the page is a utility screen (settings, auth, table), or `prefers-reduced-motion` applies.
- **Scroll World escalation.** When the request smells like a spatial narrative — "scroll world", "fly-through", "3D journey", "travel through", or the product's story genuinely suits moving a camera through space (exploration, systems, archives, planets, cities, products-in-space) — escalate the primary page to the Three.js Scroll World tier (Phase 4-W). It is a page architecture, not a garnish: the whole page scrolls through one continuous WebGL scene. Never bolt it onto an ordinary landing page and never use it for utility pages.
- **Particle ambience for dark heroes.** Dark cinematic heroes (AI, crypto, futuristic, seasonal) get exactly one ambient particle layer from `assets/particle-effects.js` — falling leaves, pointer trail, or floating orbs — chosen to serve the theme. Light/corporate themes skip particles. All particle layers are decorative-only, ≤60 particles, and vanish under `prefers-reduced-motion`.
- **Real media, never placeholders.** Gray boxes and hotlinked stock are defects. When the Higgsfield MCP connector is available, generate on-palette imagery/video/3D per `references/asset-generation.md` (it costs the user credits — follow that file's consent rules); otherwise build the procedural fallbacks in its §7. Either way every media slot ships filled.
- **Complete pages by default.** When the user asks for an app, site, template, or "the whole UI", deliver the full page set from `references/page-templates.md` — never a single page with dead links. Every nav item, footer link, and CTA must resolve to a real page or state.
- **Mobile parity.** Every web build is verified at 375px; when the request is a mobile app UI, use `references/mobile-ui-patterns.md` as the primary source of structure.

## Tech-stack routing (decide first)

- **Default:** React + Tailwind CSS + Framer Motion (component animation) + GSAP ScrollTrigger (scroll-driven) + Lenis (smooth scroll).
- **Fallback:** vanilla HTML/CSS/JS — use `assets/motion-utils.js` (framework-agnostic) + `assets/tokens.css`.
- **Scroll World tier:** React + Tailwind + Three.js + @react-three/fiber + @react-three/drei + GSAP ScrollTrigger + Lenis. Use ONLY when the Scroll World escalation above fires — the narrative must earn the WebGL cost. Vanilla Three.js variant exists for no-build demos (see `references/threejs-scroll-world.md`). Budget: Three.js + scene code ≤ 1MB on disk (~300KB gzipped).
- **CSS-3D (`perspective` + `translateZ`):** for ordinary pages wanting depth, fake it with CSS — cheaper and more reliable than WebGL. Reserve true WebGL for the Scroll World tier or an explicitly requested R3F scene.
- **Mobile web/app UI:** same stack, constrained to a 390–430px shell with safe-area insets; structures from `references/mobile-ui-patterns.md`.

## Phase 1 — Brief extraction

Extract from the request (or infer from the product): **domain** (fintech, AI, food, health, luxury…), **mood** (trust, energy, calm, opulence), **audience** (developers, consumers, enterprise), **form factor** (web landing, dashboard, mobile app, or full multi-page template), and **scope** (single page vs. complete page set — when in doubt and the user said "app/site/template", treat as complete set). Run the **Scroll World check**: set `scrollWorld: true` only when the user asked for one or the narrative genuinely benefits from a camera moving through space; a flag set here changes Phase 4 routing. If the domain is ambiguous, pick the closest row in the domain table in `references/theme-derivation.md` — do not stall asking questions.

## Phase 2 — Theme derivation

Load **`references/theme-derivation.md`**. Classify the domain → pick a proven palette bundle (14 bundles with hex) or derive tokens with the 8-step method → choose the type voice + Google Fonts pairing → copy spacing/radius/shadow/motion tokens. Start from **`assets/tokens.css`** and set `[data-theme]` values. Rules that separate award-level from average: ONE accent color; one type family with 400/800 weight contrast; negative letter-spacing on display type; 4px spacing scale; one dominant element per screen; light themes separate with shadows, dark themes with 1px borders + glow. When `scrollWorld: true`, the 3D world palette and the DOM UI palette must live in the same hue family — derive both from the same bundle.

## Phase 3 — Layout composition (web, mobile, or full template)

- **Web pages:** load **`references/layout-blueprints.md`**. Pick ONE hero archetype (split, centered stack, full-bleed, blob/organic) and follow the universal landing section sequence (navbar → hero → logo cloud → features → showcase → stats → testimonials → pricing → CTA → footer), or the dashboard shell. Copy the ASCII wireframe + Tailwind skeleton, then substitute your theme tokens.
- **Scroll World pages:** the layout IS the beat ledger — skip hero archetypes and instead architect 5–7 story beats per `references/threejs-scroll-world.md` §Story architecture. Conversion sections (pricing, CTA, footer) live in normal DOM after the world ends.
- **Mobile app UI:** load **`references/mobile-ui-patterns.md`**. Pick a platform doctrine (iOS / Material / hybrid), ONE navigation model (tab bar default), then compose screens from the domain blueprint catalog (§4: onboarding, finance, social, food, smart home, chat, AI console, player, reader, game, profile…).
- **Complete template / whole app or site:** load **`references/page-templates.md`**. Select the product row in the page-set matrix and build ALL its pages with shared chrome, plus loading/empty/error states, using the secondary-page skeletons (pricing, auth, onboarding, settings, table, detail, blog, contact, 404, checkout).

## Phase 3.5 — Media & asset layer

Load **`references/asset-generation.md`**. Derive the project's media-DNA prompt line from the active theme, write the shot list (hero key visual, ambient loop, cutouts, avatars, textures, optional GLB — ≤8 assets), get the user's go-ahead when spending credits, then run the batch pipeline (`generate_image_batch`/`generate_video_batch` → `jobs_wait` → one `show_generation_by_ids`) and embed the returned URLs with the zero-CLS patterns in that file. No connector → its §7 fallback ladder. Assets must exist before Phase 4 so motion can choreograph them.

## Phase 4 — Motion & 3D layer (default-on)

Load **`references/motion-3d-playbook.md`** (copy-paste recipes). Minimum bar for "premium": smooth scroll (Lenis synced to ScrollTrigger), hero entrance choreography (staggered reveal + clip-path masks), scroll reveals at 15% viewport, and hover micro-interactions on every interactive element. **Unless the user opted out, add at least one 3D scroll effect** on the primary page: perspective tilt, z-depth parallax, horizontal scroll-jack (desktop only), or camera dolly. On mobile/touch: no scroll-jacking — native vertical scroll with parallax layers clamped to ≤60px depth. Then pick **exactly ONE signature scene** for the primary page from **`references/signature-scenes.md`** (scroll-scrubbed video, card deck, color-morph journey, shader hero, GLB orbit stage…) using its picker table — one show-stopper, executed flawlessly; never two. Dark heroes additionally get one particle layer per playbook §10. Reference implementation: **`assets/Hero3D.jsx`**; vanilla helpers: **`assets/motion-utils.js`**.

## Phase 4-W — Three.js Scroll World (only when `scrollWorld: true`)

Replaces the signature scene — the world IS the show-stopper; adding a second one violates the one-per-page rule. Load **`references/threejs-scroll-world.md`** (full architecture) and **`assets/ScrollWorld3D.jsx`** (annotated React reference). Non-negotiable contract, enforced there in detail:

1. One scene, one perspective camera, one renderer, one world group. Scroll progress drives camera position/target, object rotation, lights, and scene state via GSAP ScrollTrigger scrub or drei `useScroll`.
2. 5–7 story beats, each mapped to a normalized scroll range; the hero object carries the product metaphor (sculpture, machine, archive, constellation, city, product, planetary system).
3. Native reversible scrolling — never hijack the wheel; scroll only drives time.
4. Lazy-mount the canvas; pause RAF off-screen; dispose geometry/materials/textures/renderer on teardown; cap DPR at 2 (1.5 mobile).
5. Static CSS/SVG poster fallback whenever WebGL fails or `prefers-reduced-motion` applies.
6. Run the three art-direction studies before committing — the generic glowing-blue-planet-in-space default is rejected unless the brief specifically earns it.

## Phase 5 — Completeness pass (multi-page deliveries)

1. Walk every link/button on every page — each resolves to a real page, sheet, or state; zero dead `#` links.
2. Shared chrome (navbar/footer/tab bar) pixel-identical across pages; tokens consistent.
3. Data pages ship loading skeleton + empty state + error state; forms ship validation + success feedback.
4. Utility pages (auth, settings) get entrance transitions only — save the heavy 3D for primary surfaces.
5. Follow the handoff checklist in `references/page-templates.md` §5.

## Phase 6 — Quality gate (check every item before delivering)

1. **Contrast:** body text ≥ 4.5:1; muted text used only for non-critical labels; white text on accent passes.
2. **Hierarchy:** exactly one dominant element per viewport; H1 uses `--fs-display` with `letter-spacing: -0.03em`.
3. **Spacing rhythm:** all spacing from the 4px scale; sections pad 96–128px desktop / 64px mobile; max content width 1120–1280px.
4. **Token discipline:** all colors/radii/shadows come from tokens — zero hard-coded hex in components.
5. **Performance:** animations touch ONLY `transform` + `opacity`; never width/height/top/left in scroll handlers; `will-change` used sparingly; 3D/canvas layers lazy-mounted (IntersectionObserver) and paused off-screen.
6. **Reduced motion:** every animation recipe includes a `prefers-reduced-motion` fallback — smooth scroll, parallax, marquee, particles, and ambient effects must be disabled under it.
7. **Interaction coverage:** every button/link/card has hover + active + focus-visible states derived from tokens.
8. **Media:** every image has `alt` + explicit dimensions or `aspect-ratio` (zero CLS); non-hero media lazy-loads; hero asset gets `fetchpriority="high"`; video is muted + `playsinline` + real poster, paused off-screen and under reduced motion; total generated payload ≤ 2.5MB above the fold; zero gray placeholders or dead media slots.
9. **Responsive & mobile:** verify at 375px and 1440px; horizontal scroll-jacked sections degrade to vertical stacks on mobile; mobile builds also pass the mobile quality gate in `references/mobile-ui-patterns.md` §5 (safe areas, 44px targets, sheet dismissals, peek affordances).
10. **WebGL discipline (Scroll World / any Three.js layer):** DPR capped at 2 (1.5 mobile); canvas lazy-mounted and RAF cancelled when not intersecting; `geometry/material/texture/renderer.dispose()` on teardown; resize handler updates aspect + size (never stretches); static poster renders when WebGL is unavailable or reduced motion applies; total Three.js + scene payload ≤ 1MB.
11. **Scroll-world integrity (when `scrollWorld: true`):** wheel/touch scrolling stays native and reversible; every beat's DOM copy stays readable over the canvas (text-shadow or glass panel); one dominant object per beat; no continuous ambient spin unless it serves the metaphor — scroll is the sole conductor.

## Worked example (compressed)

**Brief:** "Build a cinematic scroll-world site for Nimbus, an AI code-review tool — fly through the codebase."
**Flow:** Phase 1: domain AI/dev, mood technical power, single landing, `scrollWorld: true` ("fly through"). Phase 2: `neon-trading` bundle, Space Grotesk + JetBrains Mono, world + DOM share the violet family. Phase 3: beat ledger — hook (enter the archive) → origin → system → conflict → proof → CTA; pricing/footer in DOM after the world. Phase 3.5: batch-generate poster key visual + 4 avatars. Phase 4-W: camera arcs around an icosahedral "codebase core" per `ScrollWorld3D.jsx`, beats scrubbed by `useScroll`, floating-orbs particle layer, static poster fallback. Phase 6: gates 10–11 pass (DPR 2, dispose on unmount, native scroll, readable glass panels). Closing note offers the calmer CSS-3D variant if WebGL feels heavy.

## Phase 7 — Ship (only when the user wants it live)

Static builds deploy through connected MCPs: Higgsfield websites (`create_website` → follow its creation instructions → commit/push → `deploy_website`), or Vercel/Replit connectors. Before publishing anywhere, fill real OG metadata and generate the `og_image` via Phase 3.5. Never deploy without the user asking.

## Files

| File | Load when |
|---|---|
| `references/theme-derivation.md` | Phase 2 — palettes, type, token scales, domain mapping |
| `references/layout-blueprints.md` | Phase 3 — web wireframes + HTML/Tailwind skeletons |
| `references/mobile-ui-patterns.md` | Phase 3 — mobile doctrines, nav models, gestures, 13 domain screen blueprints, mobile quality gate |
| `references/page-templates.md` | Phase 3 + 5 — complete page-set matrix + skeletons for every secondary page (multi-page/template deliveries) |
| `references/asset-generation.md` | Phase 3.5 — Higgsfield media pipeline, prompts-from-tokens, embed patterns, fallback ladder |
| `references/motion-3d-playbook.md` | Phase 4 — all animation/3D recipes incl. §9 scroll-world quickstart + §10 particles |
| `references/signature-scenes.md` | Phase 4 — the one-per-page show-stopper library (12 scenes + Scroll World escalation) |
| `references/threejs-scroll-world.md` | Phase 4-W — full scroll-world architecture, beat ledger, R3F + vanilla patterns, art direction, mobile degradation |
| `assets/tokens.css` | Phase 2 — starter token stylesheet, themes via `[data-theme]` |
| `assets/motion-utils.js` | Phase 4 — vanilla JS helpers (magnetic, tilt, reveals, Lenis+GSAP init, cursor glow) |
| `assets/Hero3D.jsx` | Phase 4 — annotated React reference hero with layered 3D parallax |
| `assets/ScrollWorld3D.jsx` | Phase 4-W — annotated React scroll-world reference (beats, camera path, poster fallback) |
| `assets/particle-effects.js` | Phase 4 — falling leaves, pointer trail, floating orbs (reduced-motion-safe, cleanup-returning) |

Repo meta (`README.md`, `CHANGELOG.md`, `LICENSE`, `install.sh`) documents installation and versioning — never loaded at runtime.
