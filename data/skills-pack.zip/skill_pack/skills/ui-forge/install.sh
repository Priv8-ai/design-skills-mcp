#!/usr/bin/env bash
# Install ui-forge into the local Claude skills directory (Claude Code / Desktop).
set -euo pipefail
DEST="${CLAUDE_SKILLS_DIR:-$HOME/.claude/skills}/ui-forge"
SRC="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
mkdir -p "$DEST"
if command -v rsync >/dev/null 2>&1; then
  rsync -a --delete --exclude '.git' --exclude '*.skill' --exclude '*-workspace' "$SRC"/ "$DEST"/
else
  rm -rf "$DEST" && mkdir -p "$DEST"
  (cd "$SRC" && tar --exclude ./.git --exclude '*.skill' -cf - .) | (cd "$DEST" && tar -xf -)
fi
echo "✔ ui-forge installed → $DEST"
echo "  Restart Claude Code or start a new session to pick it up."
