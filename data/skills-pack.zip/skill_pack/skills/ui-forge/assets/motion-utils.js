/* ==========================================================================
 * UI FORGE — motion-utils.js
 * Framework-agnostic motion helpers. No dependencies except optional GSAP
 * (only used inside initSmoothScroll). Every helper:
 *   - is a no-op under `prefers-reduced-motion: reduce` and/or touch devices
 *   - animates ONLY transform / opacity
 *   - returns a cleanup function
 *
 * Usage (ES module):
 *   import { magnetic, tilt, scrollReveal, initSmoothScroll, cursorGlow, counters }
 *     from "./motion-utils.js";
 *
 * Usage (classic script):
 *   <script src="motion-utils.js"></script>
 *   <script> UIMotion.scrollReveal(); </script>
 * ========================================================================== */

const REDUCED = "(prefers-reduced-motion: reduce)";
const NO_HOVER = "(hover: none)";

function prefersReduced() {
  return window.matchMedia(REDUCED).matches;
}
function isTouch() {
  return window.matchMedia(NO_HOVER).matches;
}
function lerp(a, b, t) {
  return a + (b - a) * t;
}

/* --------------------------------------------------------------------------
 * magnetic(el, strength = 0.35)
 * Button follows the cursor with lerped easing. Hero primary CTAs.
 * Desktop + full-motion only. Returns cleanup.
 * ------------------------------------------------------------------------ */
export function magnetic(el, strength = 0.35) {
  if (prefersReduced() || isTouch() || !el) return () => {};
  let raf = 0;
  let tx = 0, ty = 0, cx = 0, cy = 0;

  const onMove = (e) => {
    const r = el.getBoundingClientRect();
    tx = (e.clientX - (r.left + r.width / 2)) * strength;
    ty = (e.clientY - (r.top + r.height / 2)) * strength;
  };
  const onLeave = () => { tx = 0; ty = 0; };
  const loop = () => {
    cx = lerp(cx, tx, 0.15);
    cy = lerp(cy, ty, 0.15);
    el.style.transform = `translate(${cx.toFixed(2)}px, ${cy.toFixed(2)}px)`;
    raf = requestAnimationFrame(loop);
  };

  el.addEventListener("mousemove", onMove);
  el.addEventListener("mouseleave", onLeave);
  raf = requestAnimationFrame(loop);

  return () => {
    cancelAnimationFrame(raf);
    el.removeEventListener("mousemove", onMove);
    el.removeEventListener("mouseleave", onLeave);
    el.style.transform = "";
  };
}

/* --------------------------------------------------------------------------
 * tilt(card, maxDeg = 8)
 * 3D tilt-on-hover with a moving glare highlight. Feature/pricing cards.
 * Desktop + full-motion only. Returns cleanup.
 * ------------------------------------------------------------------------ */
export function tilt(card, maxDeg = 8) {
  if (prefersReduced() || isTouch() || !card) return () => {};

  if (!card.style.position) card.style.position = "relative";
  card.style.transformStyle = "preserve-3d";

  const glare = document.createElement("div");
  glare.setAttribute("aria-hidden", "true");
  glare.style.cssText =
    "position:absolute;inset:0;border-radius:inherit;pointer-events:none;" +
    "opacity:0;transition:opacity 300ms;" +
    "background:radial-gradient(circle at var(--gx,50%) var(--gy,50%)," +
    "rgba(255,255,255,.25),transparent 60%)";
  card.appendChild(glare);

  const onMove = (e) => {
    const r = card.getBoundingClientRect();
    const px = (e.clientX - r.left) / r.width;
    const py = (e.clientY - r.top) / r.height;
    const rx = ((0.5 - py) * maxDeg).toFixed(2);
    const ry = ((px - 0.5) * maxDeg).toFixed(2);
    card.style.transform =
      `perspective(800px) rotateX(${rx}deg) rotateY(${ry}deg) translateY(-4px)`;
    glare.style.setProperty("--gx", `${(px * 100).toFixed(1)}%`);
    glare.style.setProperty("--gy", `${(py * 100).toFixed(1)}%`);
  };
  const onEnter = () => {
    glare.style.opacity = "1";
    card.style.transition = "transform 80ms";
  };
  const onLeave = () => {
    glare.style.opacity = "0";
    card.style.transition = "transform 400ms cubic-bezier(0.16,1,0.3,1)";
    card.style.transform = "";
  };

  card.addEventListener("pointermove", onMove);
  card.addEventListener("pointerenter", onEnter);
  card.addEventListener("pointerleave", onLeave);

  return () => {
    card.removeEventListener("pointermove", onMove);
    card.removeEventListener("pointerenter", onEnter);
    card.removeEventListener("pointerleave", onLeave);
    glare.remove();
    card.style.transform = "";
  };
}

/* --------------------------------------------------------------------------
 * scrollReveal(selector = ".reveal", { threshold = 0.15, stagger = 60 })
 * Fade-up reveal once per element at 15% viewport. Pair with the CSS below
 * (or include it via injectRevealStyles()):
 *
 *   .reveal { opacity: 0; transform: translateY(28px);
 *     transition: opacity 600ms var(--ease-out-expo, cubic-bezier(.16,1,.3,1)),
 *                 transform 600ms var(--ease-out-expo, cubic-bezier(.16,1,.3,1));
 *     transition-delay: calc(var(--i, 0) * 60ms); }
 *   .reveal.is-visible { opacity: 1; transform: none; }
 *
 * Auto-assigns --i stagger index within each .reveal-group parent.
 * Under reduced motion: elements are made visible immediately.
 * Returns cleanup.
 * ------------------------------------------------------------------------ */
export function scrollReveal(selector = ".reveal", options = {}) {
  const { threshold = 0.15, stagger = 60 } = options;
  const els = Array.from(document.querySelectorAll(selector));
  if (!els.length) return () => {};

  // Assign per-group stagger indices (max 8 per group, per motion principles).
  const groups = new Map();
  els.forEach((el) => {
    const g = el.closest(".reveal-group") || document.body;
    if (!groups.has(g)) groups.set(g, 0);
    const i = groups.get(g);
    el.style.setProperty("--i", Math.min(i, 7));
    el.style.transitionDelay = `calc(var(--i, 0) * ${stagger}ms)`;
    groups.set(g, i + 1);
  });

  if (prefersReduced()) {
    els.forEach((el) => el.classList.add("is-visible"));
    return () => {};
  }

  const io = new IntersectionObserver((entries) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        entry.target.classList.add("is-visible");
        io.unobserve(entry.target);
      }
    });
  }, { threshold });

  els.forEach((el) => io.observe(el));
  return () => io.disconnect();
}

/* Injects the companion .reveal CSS if you don't ship it yourself. */
export function injectRevealStyles() {
  if (document.getElementById("ui-motion-reveal-styles")) return;
  const style = document.createElement("style");
  style.id = "ui-motion-reveal-styles";
  style.textContent =
    ".reveal{opacity:0;transform:translateY(28px);" +
    "transition:opacity 600ms cubic-bezier(.16,1,.3,1)," +
    "transform 600ms cubic-bezier(.16,1,.3,1);" +
    "transition-delay:calc(var(--i,0)*60ms)}" +
    ".reveal.is-visible{opacity:1;transform:none}" +
    "@media (prefers-reduced-motion:reduce){.reveal{opacity:1;transform:none;transition:none}}";
  document.head.appendChild(style);
}

/* --------------------------------------------------------------------------
 * initSmoothScroll({ lerp = 0.1 } = {})
 * Lenis + GSAP ScrollTrigger sync (the "premium feel" baseline).
 * Requires CDN/global `Lenis` and `gsap` + `ScrollTrigger`, e.g.:
 *   <script src="https://cdn.jsdelivr.net/npm/lenis@1.1.14/dist/lenis.min.js"></script>
 *   <script src="https://cdn.jsdelivr.net/npm/gsap@3.12.5/dist/gsap.min.js"></script>
 *   <script src="https://cdn.jsdelivr.net/npm/gsap@3.12.5/dist/ScrollTrigger.min.js"></script>
 * Under reduced motion or missing libs: returns a no-op cleanup.
 * ------------------------------------------------------------------------ */
export function initSmoothScroll({ lerp: smoothness = 0.1 } = {}) {
  if (prefersReduced()) return () => {};
  if (typeof Lenis === "undefined" || typeof gsap === "undefined") {
    console.warn("[ui-motion] initSmoothScroll: Lenis and gsap globals are required.");
    return () => {};
  }
  if (typeof ScrollTrigger !== "undefined") gsap.registerPlugin(ScrollTrigger);

  const lenis = new Lenis({ lerp: smoothness, smoothWheel: true });
  if (typeof ScrollTrigger !== "undefined") lenis.on("scroll", ScrollTrigger.update);

  const tick = (time) => lenis.raf(time * 1000);
  gsap.ticker.add(tick);
  gsap.ticker.lagSmoothing(0);

  return () => {
    gsap.ticker.remove(tick);
    lenis.destroy();
  };
}

/* --------------------------------------------------------------------------
 * cursorGlow(el)
 * Fixed radial-gradient blob that lazily follows the pointer. Dark heroes.
 * Suggested CSS:
 *   .cursor-glow { position: fixed; width: 480px; height: 480px; border-radius: 50%;
 *     pointer-events: none; z-index: 0; transform: translate(-50%,-50%);
 *     background: radial-gradient(circle, rgba(139,92,246,.14), transparent 65%); }
 * Touch/reduced-motion: element is removed. Returns cleanup.
 * ------------------------------------------------------------------------ */
export function cursorGlow(el) {
  if (!el) return () => {};
  if (prefersReduced() || isTouch()) {
    el.remove();
    return () => {};
  }
  let raf = 0;
  let tx = window.innerWidth / 2, ty = window.innerHeight / 2;
  let x = tx, y = ty;

  const onMove = (e) => { tx = e.clientX; ty = e.clientY; };
  const loop = () => {
    x = lerp(x, tx, 0.08);
    y = lerp(y, ty, 0.08);
    el.style.left = `${x.toFixed(1)}px`;
    el.style.top = `${y.toFixed(1)}px`;
    raf = requestAnimationFrame(loop);
  };

  window.addEventListener("pointermove", onMove, { passive: true });
  raf = requestAnimationFrame(loop);

  return () => {
    cancelAnimationFrame(raf);
    window.removeEventListener("pointermove", onMove);
  };
}

/* --------------------------------------------------------------------------
 * counters(selector = "[data-counter]", { duration = 800 } = {})
 * Count-up animation for stats bands, once on first view (ease-out-quart).
 *   <p data-counter="2400000">0</p>
 * Reduced motion: final value is set immediately. Returns cleanup.
 * ------------------------------------------------------------------------ */
export function counters(selector = "[data-counter]", { duration = 800 } = {}) {
  const els = Array.from(document.querySelectorAll(selector));
  if (!els.length) return () => {};
  const format = (n) => n.toLocaleString("en-US");

  if (prefersReduced()) {
    els.forEach((el) => { el.textContent = format(Number(el.dataset.counter)); });
    return () => {};
  }

  const io = new IntersectionObserver((entries) => {
    entries.forEach((entry) => {
      if (!entry.isIntersecting) return;
      io.unobserve(entry.target);
      const el = entry.target;
      const target = Number(el.dataset.counter);
      const start = performance.now();
      const step = (now) => {
        const p = Math.min((now - start) / duration, 1);
        el.textContent = format(Math.round(target * (1 - Math.pow(1 - p, 4))));
        if (p < 1) requestAnimationFrame(step);
      };
      requestAnimationFrame(step);
    });
  }, { threshold: 0.5 });

  els.forEach((el) => io.observe(el));
  return () => io.disconnect();
}

/* --------------------------------------------------------------------------
 * hideOnScrollNavbar(el, { hideAfter = 200, scrolledAt = 24 } = {})
 * Toggles `.navbar--scrolled` / `.navbar--hidden` classes (see playbook §4a).
 * ------------------------------------------------------------------------ */
export function hideOnScrollNavbar(el, { hideAfter = 200, scrolledAt = 24 } = {}) {
  if (!el) return () => {};
  let lastY = window.scrollY;
  const onScroll = () => {
    const y = window.scrollY;
    el.classList.toggle("navbar--scrolled", y > scrolledAt);
    el.classList.toggle("navbar--hidden", y > hideAfter && y > lastY);
    lastY = y;
  };
  window.addEventListener("scroll", onScroll, { passive: true });
  onScroll();
  return () => window.removeEventListener("scroll", onScroll);
}

/* Classic-script global fallback */
if (typeof window !== "undefined") {
  window.UIMotion = {
    magnetic, tilt, scrollReveal, injectRevealStyles,
    initSmoothScroll, cursorGlow, counters, hideOnScrollNavbar,
  };
}
