/* ==========================================================================
   UI FORGE — particle-effects.js
   Framework-agnostic ambient particle systems for dark cinematic heroes.
   Pick EXACTLY ONE per page (defaults rule: dark heroes only).

   Every helper:
     - is a no-op under prefers-reduced-motion: reduce (returns cleanup anyway)
     - caps at 60 particles and runs ONE rAF loop
     - pauses via IntersectionObserver when off-screen
     - uses ctx.setTransform for DPR (no cumulative-scale bugs on resize)
     - returns a cleanup function — always call it on unmount/navigation

   Canvas prerequisites (all effects):
     position:absolute (or fixed for the pointer trail); inset:0;
     pointer-events:none; aria-hidden="true"; sized by CSS (width/height 100%).
   ========================================================================== */

const REDUCED = "(prefers-reduced-motion: reduce)";
const prefersReduced = () => matchMedia(REDUCED).matches;

/* Shared plumbing: DPR-safe sizing + IO pause + single rAF loop. */
function runLoop(canvas, draw) {
  const ctx = canvas.getContext("2d");
  if (!ctx) return () => {};
  let w = 0, h = 0, raf = 0, running = false;

  const resize = () => {
    const dpr = Math.min(devicePixelRatio || 1, 2);
    w = canvas.offsetWidth;
    h = canvas.offsetHeight;
    canvas.width = Math.max(1, w * dpr);
    canvas.height = Math.max(1, h * dpr);
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0); // absolute, never cumulative
  };

  const frame = () => {
    if (!running) return;
    ctx.clearRect(0, 0, w, h);
    draw(ctx, w, h);
    raf = requestAnimationFrame(frame);
  };

  resize();
  addEventListener("resize", resize);

  const io = new IntersectionObserver(([e]) => {
    const next = e.isIntersecting;
    if (next && !running) { running = true; raf = requestAnimationFrame(frame); }
    else if (!next) { running = false; cancelAnimationFrame(raf); }
  });
  io.observe(canvas);

  return () => {
    running = false;
    cancelAnimationFrame(raf);
    io.disconnect();
    removeEventListener("resize", resize);
    ctx.clearRect(0, 0, w, h);
  };
}

/* --------------------------------------------------------------------------
 * fallingLeaves(canvas, { count = 40, colors })
 * Autumnal / seasonal drift. Warm themes, light or dark backgrounds.
 * ------------------------------------------------------------------------ */
export function fallingLeaves(canvas, options = {}) {
  if (prefersReduced() || !canvas) return () => {};
  const count = Math.min(options.count ?? 40, 60);
  const colors = options.colors ?? ["#D97706", "#B45309", "#F59E0B", "#78350F"];

  const leaves = Array.from({ length: count }, () => ({
    x: Math.random(),                       // normalized 0..1
    y: Math.random() * -0.2,
    r: 3 + Math.random() * 5,
    fall: 0.0006 + Math.random() * 0.0008,  // per-frame normalized fall
    phase: Math.random() * Math.PI * 2,     // sway phase
    sway: 0.0006 + Math.random() * 0.0012,  // sway amplitude (normalized)
    swaySpeed: 0.015 + Math.random() * 0.02,
    color: colors[(Math.random() * colors.length) | 0],
    rot: Math.random() * Math.PI * 2,
    rotSpeed: (Math.random() - 0.5) * 0.03,
  }));

  return runLoop(canvas, (ctx, w, h) => {
    for (const l of leaves) {
      l.y += l.fall;
      l.phase += l.swaySpeed;
      l.x += Math.sin(l.phase) * l.sway;
      l.rot += l.rotSpeed;
      if (l.y > 1.05) { l.y = -0.05; l.x = Math.random(); }

      ctx.save();
      ctx.translate(l.x * w, l.y * h);
      ctx.rotate(l.rot);
      ctx.globalAlpha = 0.7;
      ctx.fillStyle = l.color;
      ctx.beginPath();
      ctx.ellipse(0, 0, l.r, l.r * 0.6, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
    }
  });
}

/* --------------------------------------------------------------------------
 * pointerTrailEmitter(canvas, { color = "139,92,246", length = 20 })
 * Cursor-following comet trail. Dark futuristic heroes; pointer devices only.
 * Canvas should be position:fixed; inset:0 so client coords map 1:1.
 * `color` is an "R,G,B" string — alpha is driven by particle life.
 * ------------------------------------------------------------------------ */
export function pointerTrailEmitter(canvas, options = {}) {
  if (!canvas) return () => {};
  if (prefersReduced() || matchMedia("(hover: none)").matches) {
    canvas.style.display = "none";
    return () => {};
  }
  const rgb = options.color ?? "139,92,246";
  const length = Math.min(options.length ?? 20, 40);
  const trail = [];
  let tx = innerWidth / 2, ty = innerHeight / 2;

  const onMove = (e) => { tx = e.clientX; ty = e.clientY; };
  addEventListener("pointermove", onMove, { passive: true });

  const stopLoop = runLoop(canvas, (ctx) => {
    trail.push({ x: tx, y: ty });
    if (trail.length > length) trail.shift();
    for (let i = 0; i < trail.length; i++) {
      const life = (i + 1) / trail.length; // oldest → newest
      ctx.beginPath();
      ctx.arc(trail[i].x, trail[i].y, 3 * life, 0, Math.PI * 2);
      ctx.fillStyle = `rgba(${rgb},${(life * 0.6).toFixed(3)})`;
      ctx.fill();
    }
  });

  return () => {
    stopLoop();
    removeEventListener("pointermove", onMove);
  };
}

/* --------------------------------------------------------------------------
 * floatingOrbs(canvas, { count = 30, color = "#8B5CF6" })
 * Ambient bubbles rising and fading. AI / crypto / futuristic dark heroes.
 * ------------------------------------------------------------------------ */
export function floatingOrbs(canvas, options = {}) {
  if (prefersReduced() || !canvas) return () => {};
  const count = Math.min(options.count ?? 30, 60);
  const color = options.color ?? "#8B5CF6";

  const orbs = Array.from({ length: count }, () => ({
    x: Math.random(),
    y: 1 + Math.random() * 0.2,
    r: 2 + Math.random() * 6,
    rise: 0.0004 + Math.random() * 0.0008,
    wobble: Math.random() * Math.PI * 2,
    wobbleSpeed: 0.01 + Math.random() * 0.02,
    alpha: 0.1 + Math.random() * 0.3,
  }));

  return runLoop(canvas, (ctx, w, h) => {
    ctx.fillStyle = color;
    for (const o of orbs) {
      o.y -= o.rise;
      o.wobble += o.wobbleSpeed;
      if (o.y < -0.1) { o.y = 1.05; o.x = Math.random(); }
      // fade out near the top so orbs never pop
      ctx.globalAlpha = o.alpha * (o.y < 0.2 ? Math.max(0, o.y) / 0.2 : 1);
      ctx.beginPath();
      ctx.arc(o.x * w + Math.sin(o.wobble) * 20, o.y * h, o.r, 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.globalAlpha = 1;
  });
}

/* Classic-script global fallback (non-module embeds):
   <script src="particle-effects.js"></script> → window.UIParticles.* */
if (typeof window !== "undefined") {
  window.UIParticles = { fallingLeaves, pointerTrailEmitter, floatingOrbs };
}
