/**
 * UI FORGE — ScrollWorld3D.jsx
 * Reference scroll world: React + Three.js + @react-three/fiber + @react-three/drei
 * + GSAP ScrollTrigger for the DOM overlay.
 *
 * Demonstrates the full Phase 4-W contract:
 *   - Beat ledger drives BOTH the camera path and the DOM overlay (single source of truth)
 *   - Per-beat camera interpolation with easing (not one global arc)
 *   - Native reversible scrolling (drei ScrollControls; wheel never hijacked)
 *   - Lazy mount via IntersectionObserver; R3F disposes GPU resources on unmount
 *   - DPR capped [1, 2]; fog for depth; ≤3 lights; flat-shaded primitives
 *   - Static poster fallback for prefers-reduced-motion / missing WebGL
 *
 * Deps:  npm i three @react-three/fiber @react-three/drei gsap
 * Theme: expects ui-forge tokens on :root/[data-theme] (see assets/tokens.css).
 *        Swap the two hex materials for your Phase-2 bundle values.
 */

import { useEffect, useMemo, useRef, useState } from "react";
import * as THREE from "three";
import { Canvas, useFrame, useThree } from "@react-three/fiber";
import { ScrollControls, useScroll } from "@react-three/drei";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";

gsap.registerPlugin(ScrollTrigger);

/* ------------------------------------------------------------------ */
/* 1. THE BEAT LEDGER — single source of truth for camera + overlay.   */
/*    Edit this, not the render code. Ranges tile 0→1 with no gaps.    */
/* ------------------------------------------------------------------ */
export const BEATS = [
  { id: "hook",    scroll: [0.00, 0.18], camPos: [0, 2, 8],   camTarget: [0, 0, 0],   label: "01 / Premise", title: "Enter the archive" },
  { id: "origin",  scroll: [0.18, 0.36], camPos: [3, 1, 5],   camTarget: [2, 0, -2],  label: "02 / Origin",  title: "Where it began" },
  { id: "system",  scroll: [0.36, 0.56], camPos: [0, 4, 2],   camTarget: [0, 0, -4],  label: "03 / System",  title: "The engine underneath" },
  { id: "proof",   scroll: [0.56, 0.78], camPos: [-3, 1, 5],  camTarget: [-2, 0, -2], label: "04 / Proof",   title: "Built for scale" },
  { id: "cta",     scroll: [0.78, 1.00], camPos: [0, 1, 4],   camTarget: [0, 0, 0],   label: "05 / Start",   title: "Begin the journey" },
];

const PAGES = BEATS.length; // ~one viewport of scroll per beat

/* Interpolate camera through the ledger with an eased blend per beat. */
const easeInOut = (t) => t * t * (3 - 2 * t); // smoothstep — no lib needed per frame
function applyBeats(camera, r, tmp) {
  const i = Math.min(BEATS.length - 1, Math.max(0, BEATS.findIndex(b => r <= b.scroll[1])));
  const beat = BEATS[i === -1 ? BEATS.length - 1 : i];
  const prev = BEATS[Math.max(0, (i === -1 ? BEATS.length - 1 : i) - 1)];
  const [s, e] = beat.scroll;
  const t = easeInOut(Math.min(1, Math.max(0, (r - s) / Math.max(1e-5, e - s))));
  tmp.pos.fromArray(prev.camPos).lerp(tmp.b.fromArray(beat.camPos), t);
  tmp.look.fromArray(prev.camTarget).lerp(tmp.c.fromArray(beat.camTarget), t);
  camera.position.copy(tmp.pos);
  camera.lookAt(tmp.look);
}

/* ------------------------------------------------------------------ */
/* 2. THE WORLD — one group; hero object carries the metaphor.         */
/* ------------------------------------------------------------------ */
function WorldContents() {
  const hero = useRef(null);
  const satellite = useRef(null);
  const key = useRef(null);
  const scroll = useScroll();
  const { camera } = useThree();
  // Reusable vectors — never allocate inside useFrame.
  const tmp = useMemo(() => ({ pos: new THREE.Vector3(), look: new THREE.Vector3(), b: new THREE.Vector3(), c: new THREE.Vector3() }), []);

  useFrame(() => {
    const r = scroll.offset; // 0..1, damped, natively reversible
    applyBeats(camera, r, tmp);
    if (hero.current) hero.current.rotation.y = r * Math.PI;            // scroll-driven only
    if (satellite.current) satellite.current.rotation.x = r * Math.PI * 0.5;
    if (key.current) key.current.intensity = 0.6 + r * 0.8;             // lights tell time too
  });

  return (
    <group>
      {/* Hero object — swap geometry/material for the product metaphor */}
      <mesh ref={hero}>
        <icosahedronGeometry args={[1.4, 1]} />
        <meshStandardMaterial color="#8B5CF6" roughness={0.2} metalness={0.7} flatShading />
      </mesh>

      {/* One satellite max per beat's field of view */}
      <mesh ref={satellite} position={[2.5, 0.5, -1]}>
        <octahedronGeometry args={[0.6, 0]} />
        <meshStandardMaterial color="#22D3EE" roughness={0.1} metalness={0.8} emissive="#22D3EE" emissiveIntensity={0.2} />
      </mesh>

      {/* Ground plane anchors depth perception */}
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -2, 0]}>
        <planeGeometry args={[30, 30]} />
        <meshStandardMaterial color="#0F1115" roughness={0.8} metalness={0.2} />
      </mesh>

      {/* ≤3 lights, one castable */}
      <ambientLight intensity={0.4} />
      <directionalLight ref={key} position={[4, 6, 4]} intensity={1.2} />
      <pointLight position={[-4, 2, -4]} intensity={0.5} color="#C084FC" />

      {/* Fog = composition: hides world edges, creates depth for free */}
      <fog attach="fog" args={["#0F0B2E", 8, 25]} />
    </group>
  );
}

/* ------------------------------------------------------------------ */
/* 3. DOM OVERLAY — sibling sections (SEO-visible), ScrollTrigger-lit. */
/* ------------------------------------------------------------------ */
function BeatOverlay() {
  const [active, setActive] = useState(0);

  useEffect(() => {
    const triggers = BEATS.map((_, i) =>
      ScrollTrigger.create({
        trigger: `.sw-beat-${i}`,
        start: "top center",
        end: "bottom center",
        onEnter: () => setActive(i),
        onEnterBack: () => setActive(i),
      })
    );
    return () => triggers.forEach((t) => t.kill());
  }, []);

  return (
    <div className="pointer-events-none absolute inset-0 z-10">
      {BEATS.map((beat, i) => (
        <section key={beat.id} className={`sw-beat-${i} flex h-screen items-center justify-center px-6`}>
          {/* Glass panel keeps copy sovereign over any frame of the scene (gate 11) */}
          <div
            className="max-w-2xl rounded-2xl px-8 py-6 text-center backdrop-blur-md transition-all duration-700"
            style={{
              background: "rgba(15, 11, 46, 0.35)",
              opacity: active === i ? 1 : 0,
              transform: active === i ? "translateY(0)" : "translateY(24px)",
              transitionTimingFunction: "var(--ease-out-expo)",
            }}
          >
            <p style={{ fontSize: "var(--fs-eyebrow)", letterSpacing: ".08em", fontWeight: 600 }} className="uppercase text-[color:var(--accent)]">
              {beat.label}
            </p>
            <h2 style={{ fontFamily: "var(--font-display)", fontSize: "var(--fs-h2)", letterSpacing: "-0.02em" }} className="mt-4 text-white">
              {beat.title}
            </h2>
          </div>
        </section>
      ))}
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* 4. STATIC POSTER — reduced motion / no WebGL. Must still convert:   */
/*    carries the H1 and the primary CTA.                              */
/* ------------------------------------------------------------------ */
function StaticPoster() {
  return (
    <div className="flex min-h-screen items-center justify-center" style={{ background: "radial-gradient(120% 100% at 50% 0%, #1B1145 0%, #0F0B2E 60%)" }}>
      <div className="px-6 text-center">
        <p style={{ fontSize: "var(--fs-eyebrow)", letterSpacing: ".08em", fontWeight: 600 }} className="uppercase text-[color:var(--accent)]">
          {BEATS[0].label}
        </p>
        <h1 style={{ fontFamily: "var(--font-display)", fontSize: "var(--fs-display)", letterSpacing: "-0.03em", lineHeight: 1.02 }} className="mt-4 text-white">
          {BEATS[0].title}
        </h1>
        <a href="#start" className="mt-8 inline-block rounded-[var(--r-pill)] px-6 py-3 font-semibold text-white" style={{ background: "var(--accent)" }}>
          Begin the journey
        </a>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* 5. SHELL — capability gates + lazy mount + tall scroll wrapper.     */
/* ------------------------------------------------------------------ */
function supportsWebGL() {
  try {
    const c = document.createElement("canvas");
    return !!(c.getContext("webgl2") || c.getContext("webgl"));
  } catch {
    return false;
  }
}

export default function ScrollWorld3D() {
  const wrap = useRef(null);
  const [mode, setMode] = useState("pending"); // pending | world | poster
  const [near, setNear] = useState(false);      // lazy mount

  useEffect(() => {
    const reduced = matchMedia("(prefers-reduced-motion: reduce)");
    const decide = () => setMode(reduced.matches || !supportsWebGL() ? "poster" : "world");
    decide();
    reduced.addEventListener("change", decide);
    return () => reduced.removeEventListener("change", decide);
  }, []);

  useEffect(() => {
    if (!wrap.current) return;
    const io = new IntersectionObserver(([e]) => e.isIntersecting && setNear(true), { rootMargin: "25%" });
    io.observe(wrap.current);
    return () => io.disconnect();
  }, [mode]);

  if (mode === "poster") return <StaticPoster />;

  return (
    <div ref={wrap} className="relative" style={{ height: `${PAGES * 100}vh` }}>
      <div className="sticky top-0 h-screen w-full overflow-hidden" style={{ background: "#0F0B2E" }}>
        {mode === "world" && near && (
          <Canvas dpr={[1, 2]} camera={{ position: BEATS[0].camPos, fov: 45 }} gl={{ antialias: true, alpha: false }}>
            {/* damping keeps the camera silky without owning the wheel */}
            <ScrollControls pages={PAGES} damping={0.15}>
              <WorldContents />
            </ScrollControls>
          </Canvas>
        )}
        {/* Grain overlay — premium texture (playbook §8b) */}
        <div
          className="pointer-events-none absolute inset-0 opacity-[0.04] mix-blend-overlay"
          style={{
            backgroundImage: `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='160' height='160'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='2'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)'/%3E%3C/svg%3E")`,
          }}
        />
      </div>
      <BeatOverlay />
    </div>
  );
}
