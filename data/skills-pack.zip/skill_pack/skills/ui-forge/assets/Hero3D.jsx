/**
 * UI FORGE — Hero3D.jsx
 * Reference hero: React + Tailwind + GSAP ScrollTrigger + Lenis-ready.
 * Demonstrates: layered z-depth parallax orbs, perspective screenshot tilt
 * on scroll, staggered word-mask entrance, floating glass chips.
 *
 * Deps:  npm i gsap lenis   (tailwind configured with ui-forge tokens)
 * Theme: expects ui-forge tokens on :root/[data-theme] (see assets/tokens.css).
 * Reduced motion: all animation skipped, content renders statically.
 */
import { useEffect, useRef } from "react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";

gsap.registerPlugin(ScrollTrigger);

export default function Hero3D() {
  const root = useRef(null);

  useEffect(() => {
    // matchMedia scopes every animation to full-motion users and
    // provides automatic cleanup (reverts inline styles) on unmount.
    const mm = gsap.matchMedia();

    mm.add("(prefers-reduced-motion: no-preference)", () => {
      const ctx = gsap.context(() => {
        /* --- 1. Entrance choreography: eyebrow → words → sub → CTAs → media --- */
        const intro = gsap.timeline({
          defaults: { duration: 0.7, ease: "expo.out" },
        });
        intro
          .to(".hz-eyebrow", { opacity: 1, y: 0 })
          .to(".hz-word", { y: 0, stagger: 0.06, duration: 0.8 }, "-=0.4")
          .to(".hz-sub", { opacity: 1, y: 0 }, "-=0.5")
          .to(".hz-ctas", { opacity: 1, y: 0 }, "-=0.55")
          .to(".hz-media", { opacity: 1, y: 0, duration: 0.9 }, "-=0.6")
          .to(".hz-chip", { opacity: 1, scale: 1, stagger: 0.12 }, "-=0.5");

        /* --- 2. Perspective tilt: screenshot rises flat as it scrolls in --- */
        gsap.to(".hz-shot", {
          rotateX: 0,
          scale: 1,
          ease: "none",
          scrollTrigger: {
            trigger: ".hz-media",
            start: "top 90%",
            end: "top 30%",
            scrub: 0.6,
          },
        });

        /* --- 3. Z-depth parallax: orbs drift at different rates (0.2–0.4) --- */
        gsap.to(".hz-orb-a", {
          yPercent: 25, ease: "none",
          scrollTrigger: { trigger: root.current, start: "top top", end: "bottom top", scrub: true },
        });
        gsap.to(".hz-orb-b", {
          yPercent: 40, ease: "none",
          scrollTrigger: { trigger: root.current, start: "top top", end: "bottom top", scrub: true },
        });

        /* --- 4. Floating chips: slow ambient bob (decorative only) --- */
        gsap.to(".hz-chip", {
          y: -8, duration: 3, ease: "sine.inOut",
          yoyo: true, repeat: -1, stagger: 0.6,
        });
      }, root);
      return () => ctx.revert();
    });

    // Reduced motion: no animation — snap everything to its final visible state.
    mm.add("(prefers-reduced-motion: reduce)", () => {
      const ctx = gsap.context(() => {
        gsap.set(".hz-eyebrow, .hz-sub, .hz-ctas, .hz-media", { opacity: 1, y: 0 });
        gsap.set(".hz-word", { y: 0 });
        gsap.set(".hz-chip", { opacity: 1, scale: 1, clearProps: "transform" });
        gsap.set(".hz-shot", { rotateX: 0, scale: 1 });
      }, root);
      return () => ctx.revert();
    });

    return () => mm.revert();
  }, []);

  return (
    <section
      ref={root}
      className="relative overflow-hidden bg-bg px-6 pb-0 pt-28 text-center md:pt-36"
    >
      {/* Ambient z-depth layers — decorative, GPU-composited, pointer-events:none */}
      <div aria-hidden="true" className="pointer-events-none absolute inset-0">
        <div className="hz-orb-a absolute -left-40 -top-40 h-[34rem] w-[34rem] rounded-full bg-accent opacity-20 blur-[100px] will-change-transform" />
        <div className="hz-orb-b absolute -right-40 top-1/3 h-[30rem] w-[30rem] rounded-full bg-[#8B5CF6] opacity-20 blur-[90px] will-change-transform" />
        {/* Grain overlay for premium texture */}
        <div className="absolute inset-0 opacity-[0.05] [background-image:url('data:image/svg+xml,%3Csvg_xmlns=%22http://www.w3.org/2000/svg%22_width=%22160%22_height=%22160%22%3E%3Cfilter_id=%22n%22%3E%3CfeTurbulence_type=%22fractalNoise%22_baseFrequency=%220.9%22_numOctaves=%222%22/%3E%3C/filter%3E%3Crect_width=%22100%25%22_height=%22100%25%22_filter=%22url(%23n)%22/%3E%3C/svg%3E')]" />
      </div>

      {/* Copy — initial hidden states are inline so reduced-motion/no-JS still
          renders: the matchMedia branch above only animates when safe, and
          context revert restores visibility. For no-JS, add a <noscript> style
          that forces opacity-100. */}
      <p className="hz-eyebrow translate-y-5 text-[12.5px] font-semibold uppercase tracking-[0.08em] text-accent opacity-0">
        Introducing Forge 3.0
      </p>

      <h1 className="mx-auto mt-4 max-w-4xl font-display text-[clamp(48px,7vw,96px)] font-bold leading-[1.02] tracking-[-0.03em] text-ink">
        {/* Each line is an overflow-hidden mask; words slide up from 110% */}
        <span className="block overflow-hidden">
          <span className="hz-word inline-block translate-y-[110%] will-change-transform">Design</span>{" "}
          <span className="hz-word inline-block translate-y-[110%] will-change-transform">beyond</span>
        </span>
        <span className="block overflow-hidden">
          <span className="hz-word inline-block translate-y-[110%] will-change-transform">the</span>{" "}
          <span className="hz-word inline-block translate-y-[110%] font-serif-accent italic will-change-transform">screen</span>
        </span>
      </h1>

      <p className="hz-sub mx-auto mt-6 max-w-[560px] translate-y-5 text-[18px] leading-relaxed text-muted opacity-0">
        Interfaces that feel alive — smooth scroll, real depth, and motion with
        intent. Built for teams who sweat the last 5%.
      </p>

      <div className="hz-ctas mt-8 flex translate-y-5 items-center justify-center gap-4 opacity-0">
        <a
          href="#start"
          className="rounded-full bg-accent px-6 py-3 text-[15px] font-semibold text-accent-ink shadow-2 transition duration-150 ease-out hover:-translate-y-px hover:brightness-105 active:scale-[0.97]"
        >
          Start building
        </a>
        <a
          href="#demo"
          className="group rounded-full border border-border px-6 py-3 text-[15px] font-medium text-ink transition duration-150 hover:border-ink"
        >
          Watch the film{" "}
          <span className="inline-block transition-transform duration-150 group-hover:translate-x-1">→</span>
        </a>
      </div>

      {/* Media — perspective stage; the shot tilts flat on scroll (recipe §2a) */}
      <div className="hz-media relative mx-auto mt-16 max-w-5xl translate-y-8 opacity-0 [perspective:1200px]">
        <div className="hz-shot origin-top scale-[0.94] rounded-t-[24px] border border-border bg-surface p-2 shadow-3 will-change-transform [transform:rotateX(18deg)]">
          <div className="flex h-[420px] items-center justify-center rounded-[16px] bg-[linear-gradient(135deg,var(--accent),#8B5CF6)] text-white/80">
            {/* Replace with <img src="/dashboard.png" … /> */}
            <span className="font-mono text-sm">product screenshot</span>
          </div>
        </div>

        {/* Floating glass chips — staggered entrance + ambient bob */}
        <div className="hz-chip glass absolute -left-4 top-10 scale-90 rounded-[16px] border border-white/20 bg-white/10 px-4 py-3 text-left opacity-0 shadow-3 backdrop-blur-xl md:-left-12">
          <p className="text-[12px] text-muted">Uptime</p>
          <p className="text-[20px] font-bold text-ink [font-variant-numeric:tabular-nums]">99.99%</p>
        </div>
        <div className="hz-chip glass absolute -right-4 bottom-16 scale-90 rounded-[16px] border border-white/20 bg-white/10 px-4 py-3 text-left opacity-0 shadow-3 backdrop-blur-xl md:-right-12">
          <p className="text-[12px] text-muted">Deploy</p>
          <p className="text-[20px] font-bold text-accent [font-variant-numeric:tabular-nums]">1.2s</p>
        </div>
      </div>
    </section>
  );
}
