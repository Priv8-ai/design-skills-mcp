# UI Forge

**Award-caliber UI engineering as a Claude skill.** Give Claude this skill and every UI it builds — landing pages, dashboards, e-commerce, portfolios, mobile app UIs, full multi-page templates — ships with a derived design system, cinematic motion, real media, and a quality gate. Distilled from 171 award-level designs.

> `v2.0.0` adds **Three.js Scroll Worlds** (scroll-driven camera journeys through one continuous 3D scene) and **packaged particle systems** (falling leaves, pointer trails, floating orbs).

## What it does

When this skill is installed, any prompt like *"build me a landing page for X"*, *"make it premium/cinematic"*, or *"fly through my product"* routes Claude through a phased playbook:

| Phase | What happens |
|---|---|
| 1. Brief extraction | Domain, mood, audience, form factor, scope — plus the **Scroll World check** |
| 2. Theme derivation | 14 proven palette bundles, type pairing, full token system (`assets/tokens.css`) |
| 3. Layout composition | Hero archetypes, landing sequence, dashboards, mobile blueprints, complete page sets |
| 3.5 Media layer | AI-generated on-palette imagery/video/3D via the Higgsfield MCP, or procedural fallbacks — zero gray placeholders |
| 4. Motion & 3D | Lenis + GSAP ScrollTrigger, entrance choreography, micro-interactions, **one** signature scene, particle ambience on dark heroes |
| 4-W. Scroll World | *(when the narrative earns it)* the whole page scrolls through one WebGL scene — beat ledger, camera path, poster fallback |
| 5. Completeness | Zero dead links, shared chrome, loading/empty/error states |
| 6. Quality gate | 11 checks: contrast, hierarchy, tokens, performance, reduced motion, media, responsive, WebGL discipline, scroll-world integrity |
| 7. Ship | Optional live deployment via Higgsfield / Vercel / Replit MCPs |

## New in 2.0 — Scroll Worlds & particles

- **`references/threejs-scroll-world.md`** — full architecture: the beat ledger (5–7 story beats as the single source of truth for camera + DOM overlay), R3F and vanilla implementations, art-direction studies, mobile degradation, debug checklist.
- **`assets/ScrollWorld3D.jsx`** — annotated React reference: per-beat eased camera interpolation, native reversible scrolling, lazy mount, WebGL/reduced-motion poster fallback that still converts.
- **`assets/particle-effects.js`** — `fallingLeaves`, `pointerTrailEmitter`, `floatingOrbs`. All: ≤60 particles, one rAF loop, IntersectionObserver pause, DPR-safe, reduced-motion no-op, cleanup-returning.
- Hard budgets baked into the quality gate: Three.js + scene ≤ 1MB, DPR ≤ 2 (1.5 mobile), full `dispose()` on teardown, scroll never hijacked.

## Install

### Claude Code / Claude Desktop

```bash
git clone git@github.com:Priv8-ai/ui-forge.git ~/.claude/skills/ui-forge
```

or, from a local clone:

```bash
./install.sh          # copies the skill into ~/.claude/skills/ui-forge
```

### Claude.ai / Claude Cowork

Upload the packaged `ui-forge.skill` file (built with `skill-forge`'s `package_skill`, or just zip this folder) under **Settings → Capabilities → Skills**.

### Verify

Ask Claude: *"Using the ui-forge skill, build a cinematic landing page for a coffee brand."* Phase headers should appear in its plan.

## Repository layout

```
ui-forge/
├── SKILL.md                     # the playbook Claude loads (start here)
├── references/                  # loaded per-phase (progressive disclosure)
│   ├── theme-derivation.md      # palettes, type, tokens, domain mapping
│   ├── layout-blueprints.md     # web wireframes + Tailwind skeletons
│   ├── mobile-ui-patterns.md    # mobile doctrines, nav models, 13 blueprints
│   ├── page-templates.md        # complete page-set matrix + skeletons
│   ├── asset-generation.md      # Higgsfield media pipeline + fallback ladder
│   ├── motion-3d-playbook.md    # all animation/3D recipes (§1–§10)
│   ├── signature-scenes.md      # 12 show-stoppers + Scroll World escalation
│   └── threejs-scroll-world.md  # NEW: scroll-world architecture
├── assets/
│   ├── tokens.css               # starter design-token stylesheet
│   ├── motion-utils.js          # vanilla motion helpers
│   ├── Hero3D.jsx               # React reference hero (CSS 3D parallax)
│   ├── ScrollWorld3D.jsx        # NEW: React scroll-world reference
│   └── particle-effects.js      # NEW: leaves / pointer trail / orbs
├── install.sh · CHANGELOG.md · LICENSE
```

## Example prompts

- "Build a cinematic scroll-world site for an AI code-review tool — fly through the codebase."
- "Design a complete SaaS template: landing, pricing, auth, dashboard, settings, 404."
- "Redesign this page to feel premium — scroll animations, animated navbar, real imagery."
- "Mobile app UI for a meditation product, iOS doctrine, tab bar navigation."

## Sharing (private repo)

This repo is private under **Priv8-ai**. To share: add collaborators to the repo, or attach the packaged `ui-forge.skill` to a GitHub Release so teammates can install without cloning.

## Credits

Scroll-world and particle techniques inspired by Meng To's open-source **Kage** skills (`build-threejs-scroll-worlds`, `falling-leaves`, `pointer-trail-emitter`); implementations here are original to UI Forge. Built and iterated with `skill-forge`.

## License

MIT — see [LICENSE](LICENSE).
