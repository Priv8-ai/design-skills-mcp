# Changelog

## 2.0.0 — 2026-08-09

The Scroll Worlds release. UI Forge graduates from "3D effects on pages" to "pages inside 3D worlds".

### Added
- **Three.js Scroll World tier** (`Phase 4-W`): the primary page scrolls through one continuous WebGL scene. New `references/threejs-scroll-world.md` (beat-ledger architecture, R3F + vanilla patterns, art-direction studies, mobile degradation, debug checklist) and `assets/ScrollWorld3D.jsx` (annotated reference: per-beat eased camera interpolation, lazy mount, poster fallback that still converts).
- **Packaged particle systems** — `assets/particle-effects.js`: `fallingLeaves`, `pointerTrailEmitter`, `floatingOrbs`. All ≤60 particles, one rAF loop, IntersectionObserver pause, DPR-safe (`setTransform`), reduced-motion no-op, cleanup-returning.
- **Playbook §9 + §10** in `references/motion-3d-playbook.md` (scroll-world quickstart, particle usage) with updated ToC and cheat-sheet rows.
- **Quality gates 10 + 11**: WebGL discipline (DPR ≤ 2, RAF pause, full dispose, poster fallback, ≤1MB budget) and scroll-world integrity (native reversible scroll, readable copy over canvas, one dominant object per beat).
- **Defaults**: Scroll World escalation heuristic in Phase 1; one particle layer on dark heroes.
- **Repo packaging**: README, install.sh, LICENSE, this changelog — the skill now lives as a shareable GitHub repo.

### Changed
- `SKILL.md` description now triggers on "scroll world", "fly-through", "3D journey", "particle effects".
- Tech-stack routing gains the Scroll World tier; CSS-3D remains the default depth strategy for ordinary pages.
- `references/signature-scenes.md` picker gains the Scroll World escalation row (the world **replaces** the signature scene — the one-show-stopper rule holds).
- Playbook §8d cross-references the packaged particle module.

### Notes
- Scroll-world and particle techniques inspired by Meng To's open-source Kage skills; implementations are original.

## 1.x

Baseline: 7-phase workflow, 14 palette bundles, layout/mobile/page-template blueprints, Higgsfield media pipeline, motion playbook §1–§8, 12 signature scenes, 9-point quality gate.
