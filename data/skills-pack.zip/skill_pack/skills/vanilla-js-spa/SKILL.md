---
name: vanilla-js-spa
description: Build a single-page web app with no build step — one HTML file, one IIFE-wrapped JS file, served by FastAPI StaticFiles or any backend. Pattern includes defensive renders, the `el()`/`$()` DOM helpers, the `el()` null-guard gotcha, the IIFE state-on-window trick for debugging, the single-Future mechanism for sync chat replies, the 3-way theme cycle, 4-breakpoint responsive layout, the CSS-var cascade gotcha, the script-tag `defer` pitfall (silent IIFE boot crash), the `fetch('/relative/path')` cross-port silent-404 pitfall, the inline global `window.onerror` catcher, and a verification ladder. Trigger when the user wants a "small web UI" / "no React" / "no build" / "no npm" / "single HTML file" / "static SPA" / "vanilla JS dashboard" / "no Vite" — especially for an agentic/scan/script backend that already has REST endpoints. Also trigger when a vanilla-JS dashboard renders statically with empty stats + "no error in console" — that's an IIFE boot crash; this skill has the catcher that diagnoses it.
tags: []
related_skills: []
---

# Vanilla-JS SPA (no build step)

For projects that need a web UI but don't justify React + Vite + npm —
typically a small agentic tool, a scan dashboard, an admin panel, an
internal console. One HTML file (~50 KB), one IIFE JS file (~30 KB),
served by the backend. No bundler, no transpiler, no framework, no
hot-reload. The whole thing fits in a single `web/` directory and
works the moment you reload the page.

This pattern came out of building WeHax v0.4.2 (3-pane dashboard,
~100 KB total, five tabs, real-time WebSocket, no build step). It's
appropriate whenever the UI surface is one screen with tabs and
modals, not a multi-page app or a marketing site.

## Design language this user wants (load first)

When this user asks for a UI/UI-redesign, "make it pretty", or anything
visual, the bar is:

- **"Super simple and stunning" / "Linear-grade" / "Vercel-grade"** —
  a single hand-written 3-column page, monochrome with ONE electric
  accent (purple `#8B5CF6` is the default, has been for 3+ projects),
  SF Pro / Inter type, sharp borders, generous whitespace, minimal
  animation. **Not** PlainAdmin / Tabler / AdminLTE / any Bootstrap
  bento with 138 asset files. The total UI payload target is **60-70 KB**
  (HTML 10 + CSS 23 + JS 35 — verified). From the original 8.6 MB
  WeHax PlainAdmin tree, the user wants a 144× reduction. If the user
  sees anything that looks "default template", they'll ask for a
  rebuild to the minimalist look.
- **No bento grid. No glassmorphism. No gradient mesh.** A 2-col or
  3-col grid with clear sections. A top bar + left aside + center pane
  is the canonical layout.
- **One primary action visible at all times** (Launch / Send / Go).
  Secondary actions are in a single ⌘K command bar, NOT in a toolbar
  full of icons.
- **Real-time data shown live, not on demand.** Stats, counters, and
  status pills should update from polling/WebSocket without the user
  refreshing. Use `flashIfChanged()` on counter tiles so the user
  sees "something happened in the last 1.5s."
- **Auto-load previous state.** When the user types a domain /
  filename / query, immediately check history and offer to resume.
  The "Previous [thing] banner with View + Rescan buttons" is a
  required pattern.

Reference: `references/minimalist-redesign-and-fastapi-fallback.md`
has the full CSS, the Linear/Vercel design tokens, the 3-col grid,
the ⌘K command bar with filter-aware items, the 5-phase pipeline
visual tracker, and the 8 pitfalls (the [hidden] override, the
command-bar auto-launch, the empty-domain scan, the OCR script for
blank pages, the 3-tier serve in FastAPI, etc.).

## File layout

```
web/
├── dashboard.html   # all markup, CSS, modals, inline styles
└── dashboard.js     # one IIFE, all logic, one state object
```

In FastAPI, mount the directory. **Note: if you keep the JS inside `web/`** mount `web/`. **If you move JS into `web/static/`** (to group all assets under one mount), mount `web/static/`:

```python
# Mount 1: dashboard.html at /, plain JS at /static/dashboard.js
app.mount("/static", StaticFiles(directory=str(WEB_DIR / "static")), name="static")
# Optional Mount 2: shorthand for /assets/...
app.mount("/assets", StaticFiles(directory=str(WEB_DIR / "static" / "assets")), name="assets")
```

Reference the JS from the HTML:

```html
<script src="/static/dashboard.js"></script>
```

**The script-tag ordering trap** — never rely on "script at end of body".
If you put `<script src="/static/dashboard.js">` in `<head>`, or even
near the top of `<body>` but BEFORE modals/late-rendered panels, the
JS runs while the DOM is still incomplete. A `$('dedupCancel').addEventListener(...)`
call that runs at line 323 of the script hits `null.addEventListener`,
throws TypeError, and the IIFE that owns the entire app crashes
**before** `DOMContentLoaded` ever fires — so your `boot()` safety
net never runs, and the user sees a static page with no JS error
in the console (just empty state).

**Three rules for script tags in vanilla-JS SPAs:**

1. **Default to `<script src="..." defer>`** regardless of position.
   `defer` makes the browser wait until HTML parsing finishes, then
   run the script, in declaration order. Works from `<head>`,
   works from `<body>` middle, works with modals that are at the
   bottom. This is the single highest-leverage change.
2. **If you can't use `defer`** (e.g. inline `<script>` that must
   run synchronously), put the `<script>` tag at the literal end of
   `<body>`, AFTER every element it references. Auditing for this
   is cheap: `grep -n '<script' app.html` and `grep -n 'getElementById\|$\(' app.js`.
3. **Never trust DOMContentLoaded as the safety net.** A throw in
   top-level IIFE code (before `document.addEventListener('DOMContentLoaded', boot)`)
   kills the whole app silently. `DOMContentLoaded` covers late
   script execution, not script execution that already crashed.

For the diagnostic pattern that catches this kind of crash after
the fact, see **"Global window.onerror / unhandledrejection catcher
injected BEFORE app.js"** below.

Bind to `DOMContentLoaded` for the safety net on top of `defer`:

```js
document.addEventListener('DOMContentLoaded', () => {
  boot().catch(e => console.error('BOOT', e));
});
```

## The IIFE shape

Everything inside one immediately-invoked function expression with
'use strict'. State is one `S` object, all helpers are local `const`
arrows, all renders are `function` declarations (so they can be
hoisted and assigned to `window.fnName` for debugging):

```js
(() => {
  'use strict';

  const S = { /* all UI state lives here */ };
  const $ = (id) => document.getElementById(id);
  const el = (tag, attrs, ...children) => { /* see helper below */ };
  const esc = (s) => String(s ?? '').replace(/[&<>"']/g, c => /* ... */);
  const api = { /* fetch wrapper, see below */ };

  function renderSidebar() { /* ... */ }
  function renderPill() { /* ... */ }
  function renderInspector() { /* ... */ }
  // ...

  async function boot() {
    wire();           // attach event listeners
    await loadAll();  // initial data load
    setInterval(loadAll, 15000);  // periodic resync
  }

  document.addEventListener('DOMContentLoaded', () => {
    boot().catch(e => console.error('BOOT', e));
  });
})();
```

`S` is **closure-scoped** — not on `window` by default. That keeps
the global namespace clean but makes debugging harder. See the
debug trick below.

## The `el()` helper — and its famous null-guard gotcha

The single most useful DOM helper:

```js
const el = (tag, attrs, ...children) => {
  const n = document.createElement(tag);
  if (attrs && typeof attrs === 'object' && !(attrs instanceof Node)) {
    for (const [k, v] of Object.entries(attrs)) {
      if (v === false || v == null) continue;
      if (k === 'class') n.className = v;
      else if (k === 'html') n.innerHTML = v;
      else if (k === 'text') n.textContent = v;
      else if (k === 'style' && typeof v === 'object') Object.assign(n.style, v);
      else if (k.startsWith('on') && typeof v === 'function') {
        n.addEventListener(k.slice(2).toLowerCase(), v);
      } else {
        n.setAttribute(k, v);
      }
    }
  }
  for (const c of children) {
    if (c == null) continue;
    n.appendChild(typeof c === 'string' ? document.createTextNode(c) : c);
  }
  return n;
};
```

Supports:
- `el('div', { class: 'foo', onclick: () => alert() }, 'text')`
- `el('div', null, 'text')` — null attrs is OK
- `el('div', { style: { color: 'red' } }, ...)` — object style
- `el('div', { html: '<b>raw</b>' })` — explicit raw HTML (use sparingly)
- Conditional children: `cond ? el(...) : null` — null is filtered

**The gotcha**: JavaScript default parameters only fire for
`undefined`, not `null`. So `el(tag, attrs = {}, ...children)`
will pass `null` straight through to `Object.entries(null)` which
throws `TypeError: Cannot convert undefined or null to object`.

If you write the helper with `attrs = {}`, every call site that
passes `null` (e.g. `el('div', null, 'text')` because the caller
doesn't have any attrs) will throw. **The `attrs && typeof attrs === 'object'`
guard above is the fix.** Do not use default parameters here.

The error surfaces as silent render failures because the throw
inside a render function bubbles up to whoever called it, which
is usually `renderAll()` wrapped in nothing. The DOM stays
empty and the user sees "nothing rendered, no error in console."
See the verification ladder below.

## The API wrapper

```js
const api = {
  base() { return S.API.replace(/\/$/, ''); },
  async req(path, opts = {}) {
    const o = Object.assign({ headers: {} }, opts);
    if (o.body && typeof o.body !== 'string') {
      o.body = JSON.stringify(o.body);
      o.headers['content-type'] = 'application/json';
    }
    const r = await fetch(this.base() + path, o);
    const text = await r.text();
    let d = text;
    try { d = text ? JSON.parse(text) : {}; } catch {}
    if (!r.ok) {
      const msg = (d && (d.detail || d.error)) || ('HTTP ' + r.status);
      throw new Error(msg);
    }
    return d;
  },
  get(p)  { return this.req(p); },
  post(p, b) { return this.req(p, { method: 'POST', body: b }); },
  put(p, b)  { return this.req(p, { method: 'PUT', body: b }); },
  del(p)     { return this.req(p, { method: 'DELETE' }); },
};
```

Three important properties:
1. **Unwraps `{scans: [...]}` style envelopes** — the caller does
   `api.get('/scans')` and gets the body, not the wrapper. This is
   the most common source of "sidebar empty" bugs when the API
   returns `{scans: [...]}` but the JS does `.length` on the wrapper.
**Never use raw `fetch('/relative/...')` — always go through `api.*`.**

A common bug when the static server is on a DIFFERENT port than the
API server (e.g. dashboard frontend at `:8124`, backend at `:8777`,
mounted at the same hostname) is to write an aggregator inside an
async function like:

```js
// ❌ BROKEN — relative URL hits the static server, not the API
const r = await fetch('/scans/' + scanId + '/findings?limit=2000');
```

The browser resolves `/scans/...` against the static-server origin
(`http://127.0.0.1:8124`), which returns 404 silently. The `await`
resolves with an empty body, `.json()` throws or returns garbage,
and your stat counter stays at 0 with no error in the console. The
user sees "stats stuck at 0" — the worst class of bug because
nothing is visibly broken.

**The rule**: every API call MUST go through `api.*` (which prefixes
`S.API`) or use an absolute URL built from the same `S.API` constant
the wrapper uses. Two safe patterns:

```js
// ✅ Pattern 1: through the wrapper
const findings = await api.get(`/scans/${scanId}/findings?limit=2000`);

// ✅ Pattern 2: absolute URL when you need streaming / AbortController
const url = (window.WHX_API_ORIGIN || '') +
            '/scans/' + encodeURIComponent(scanId) + '/findings?limit=2000';
const r = await fetch(url);
```

**Auditing for stragglers**: `grep -n "fetch('/" app.js` and
`grep -n 'fetch("/' app.js` should return ZERO matches. Every
hit is a candidate for the same silent-404 bug.

Other important properties of this wrapper:

3. **JSON-encodes bodies automatically** when given an object.
3. **Throws on non-2xx** with the API's error message. Caller's
   `try/catch` shows a toast.

## Defensive renders — the 4-step ladder

A render function that throws is the worst class of WebUI bug —

**Server-side complement**: see `references/fastapi-defensive-stack.md`
for the 5-layer server-side defense that prevents these from
ever throwing in the first place (state method → endpoint →
exception handler → middleware → client).
nothing shows, no error in the console, no obvious next step.
The 4-step ladder finds these in 1-3 iterations:

1. **Verify the API returns what you think.** `curl /endpoint` and
   compare shape to what the JS reads. If API and UI disagree, the
   render path can't be wrong — the data path is.
2. **Verify the data made it into the IIFE state.** Expose the state
   to `window` from inside the IIFE on a short `setTimeout` (after
   `boot()`): `setTimeout(() => { window._S = S; window._el = el; window._render = { renderSidebar, ... }; }, 500)`.
   Then in the browser console: `(function(){ return { allScans: window._S.allScans.length, ... }; })()`.
   If state has the data and DOM is empty, the render path is
   throwing — go to step 3.
3. **Reproduce the throw in isolation.** Call
   `window._render.renderSidebar()` and `window._el('div', {class:'x'}, 'test')`
   directly. The exact line that throws becomes visible. The fix
   is usually trivial once you see it (one missing null guard,
   one wrong type).
4. **Fix the root cause, not the symptom.** Once the throw is
   found, don't just wrap more code in try/catch — that hides the
   bug. Fix the helper that threw (the `el()` null-guard fix
   above). Then remove the debug-exposure `setTimeout` and the
   inner try/catch.

This ladder is faster than speculative wrapping because each step
narrows the search space by an order of magnitude — from "the
page" to "the data flow" to "the IIFE state" to "one function
call" to "one line."

### The loadAll() variant: step-by-step console logging

When `loadAll()` (or any multi-fetch render aggregator) silently
dies and renders the wrong scan, the 4-step ladder is too coarse
because there are 5-10 sequential `await api(...)` calls and you
can't tell which one broke. The fix is to **wrap each `await` in
its own try/catch with a numbered step log** and put a FATAL-tagged
outer catch:

```js
function step(n, msg, extra) { console.log(`[loadAll] step ${n}: ${msg}`, extra ?? ''); }
function stepErr(n, e) { console.error(`[loadAll] step ${n} FAILED:`, e); }

async function loadAll() {
  try {
    let data; try { step(1,'list scans'); data = await api.get('/scans'); }
    catch (e) { stepErr(1, e); return; }
    if (!data || !data.scans) { console.error('[loadAll] FATAL: no scans in response'); return; }
    step(2,'pick scan');
    // ... select + state hydration ...
    step(3,'state hydration', {running: S.scans.filter(s => s.status === 'running').length});
    // ... auto-pick with user-pinned guard ...
    step(4,'select active scan', {pinned: S.userPinned, picked: S.scanId});
    // ... fetch detail for rescan_of, which /scans omits ...
    step(5,'detail-merge');
    // ... render ...
    step(6,'render scans list');
    step(7,'render findings');
    step(8,'diff fetch (parent + child)');
    step(9,'render diff banner + chips');
  } catch (e) {
    console.error('[loadAll] FATAL:', e);
  }
}
```

Five properties that make this the only viable diagnostic when
you can't run vision (no `browser_vision`, `computer_use`, or
`vision_analyze` available — see the vision-tool fallback ladder
above):

1. **Each step logs in order, with a tag prefix.** Search the
   console for `[loadAll] step N:` to see exactly how far it got.
2. **A single broken step doesn't kill the pipeline.** Step 5
   failing (e.g. `/scans/{id}` 404) just logs and returns; the
   user can still see the sidebar list from step 1.
3. **The FATAL-tagged outer catch** catches the case where the
   step logs themselves were the only thing keeping the function
   from throwing uncaught.
4. **Payloads are logged too** (`{pinned, picked, count}`) so you
   can verify the data flow without a vision tool.
5. **The user can verify in DevTools** — open the console, watch
   `[loadAll] step 1: ...` come in, click a row, watch steps 1-9
   re-run. This is the verification ladder when you cannot see
   pixels.

## State + settings sync

- **macOS screenshot filenames contain `\u202f` (narrow no-break space, U+202F).** When the user attaches a screenshot via path or asks you to read/analyze one (`/Users/0x/Desktop/Screenshot 1448-01-03 at 5.18.49 PM.png`), the literal `cp`, `mv`, `open`, or any shell-quoted command will mangle the filename silently — bash tokenizes on `\u202f` differently than on a regular space, and the file won't be found. **Always use `glob` + `shutil` (Python) to copy user-supplied screenshots to a safe path before any tool tries to read them.** Pattern:

  ```python
  import glob, shutil
  srcs = sorted(glob.glob('/Users/0x/Desktop/Screenshot*.png'))
  for i, s in enumerate(srcs):
      shutil.copy(s, f'/tmp/sshots/{i+1}.png')
  ```

  Then point `vision_analyze`, `browser_vision`, `terminal sips`, etc. at the `/tmp/sshots/N.png` paths. Trying `cp '/Users/0x/Desktop/Screenshot 1448-01-03 at 5.18.49 PM.png' /tmp/1.png` from the shell produces "no such file" because the shell's argument parser and Python's `os.listdir` disagree on the exact bytes of the filename. Verify the copy succeeded with `ls -la /tmp/sshots/` before assuming the path is usable. The narrow no-break space is `\xe2\x80\xaf` in UTF-8 bytes — you can detect it with `python3 -c "import sys; print([hex(ord(c)) for c in sys.argv[1] if ord(c) > 0x7f])" "filename.png"`. This applies to any user-supplied macOS path — Photos exports, Screen Time reports, anything AppleScript-generated with timestamps.

## Vision-tool fallback ladder — tesseract when vision_analyze / browser_vision / computer_use all fail

On Apple Silicon Hermes environments, the higher-level vision stack can
go dark at the same time (`vision_analyze` returns `404 page not found`,
`browser_vision` returns `404`, `computer_use` capture returns 0×0 with
"cua-driver offline" or empty image data). When that happens, the
**tesseract CLI at `/opt/homebrew/bin/tesseract` still works** —
installed via `brew install tesseract`. It is the documented OCR
fallback, faster than the vision APIs, free, no API credits, and
serviceable for diagnosing layout bugs in dashboard screenshots.

The full recipe — copy via `shutil` (NOT shell `cp`), run tesseract
via `subprocess.run` with `--psm 11` for sparse text and `-l eng`,
read via the sandbox `TMPDIR` not `/tmp` because the sandbox tmpfs
does not share `/tmp` with the user shell, and parse output as
lines of layout blocks — is in
[`references/screenshot-ocr-via-tesseract.md`](references/screenshot-ocr-via-tesseract.md).

Three properties of the tesseract fallback that aren't obvious:
1. **Local ollama vision models (llava, llama3.2-vision) hallucinate
   on dark UIs.** They will confidently describe a dark dashboard as
   "video call app" or "alphabet exercise". Do not trust them as a
   second-tier fallback. Tesseract is more reliable for layout
   diagnosis, less reliable for semantic understanding — pick the
   tool for the task.
2. **Tesseract reads tabular and stacked content correctly with `--psm 11`**
   (sparse text). The default `--psm 3` (auto) sometimes drops
   sidebar/header text. If the OCR output misses a section, retry
   with `--psm 6` (single block) or `--psm 4` (single column).
3. **Don't ship tesseract output as a "view" to the user.** It's a
   diagnostic tool for the agent. The right move is OCR → identify
   the bug → patch → verify by reading served bytes → ship. Never
   `MEDIA:<ocr.txt>` to the user — it looks like noise.

## Live dashboard panels must hydrate from already-loaded data when the WS stream goes silent

This is the most subtle live-UI pattern: WebSocket-driven panels
(swarm graph, scanner activity log, live findings feed) look great
while the source scan is **running** because events stream in
continuously. The moment the scan **completes**, the WS stays open
but the server stops sending events — and every panel that updates
"on event" silently freezes at "0 / idle" / "scanner idle" /
"no findings yet". The user opens the completed scan and sees a
blank dashboard that obviously should be full of historical data.

**The fix is a hydration pass** that runs after the initial REST
load (`/scans/{id}/findings` + `/scans/{id}/subdomains` + optionally
`/scans/{id}/events`) and seeds each live panel from the data
already in `S`. Skip hydration while the scan is `running` or
`queued` so WS events still win. Trigger it from the same
`loadScanData(id)` function that triggered the REST loads.

```js
async function loadScanData(scanId) {
  const S = window._S;
  const [scan, findings, subs, events] = await Promise.all([
    api.get(`/scans/${scanId}`),
    api.get(`/scans/${scanId}/findings`).catch(() => ({ findings: [] })),
    api.get(`/scans/${scanId}/subdomains`).catch(() => ({ subdomains: [] })),
    api.get(`/scans/${scanId}/events?limit=500`).catch(() => ({ events: [] })),
  ]);
  S.currentScan = scan;
  S.findings = findings.findings || [];
  S.subs = subs.subdomains || [];
  S.events = events.events || [];
  renderOverview(); renderFindings(); renderSubs(); renderEvents();
  // Hydrate the live-only panels from already-loaded data
  if (scan.status !== 'running' && scan.status !== 'queued') {
    hydrateLiveFromScan(scanId);
  }
}

function hydrateLiveFromScan(scanId) {
  // Swarm graph: rebuild nodes from S.subs
  S.subs.slice(0, 80).forEach((s, i) => {
    swarm.addNode({ id: `sub-${i}`, type: 'sub', label: s.subdomain,
                    ip: s.real_ip || s.ip, x: orbit(i, S.subs.length) });
  });
  // Activity feed: synthesize one row if /events 404'd,
  // otherwise replay the events table
  const rows = S.events.length
    ? S.events.map(e => ({ ts: e.timestamp, kind: e.kind, msg: e.message }))
    : [{ ts: Date.now(), kind: 'lifecycle', msg: 'Scan completed' }];
  rows.slice(0, 100).forEach(renderActivityRow);
  // Live findings feed: pull from S.findings using the right timestamp key
  S.findings.slice(0, 100).forEach(f => {
    const ts = f.first_seen ? new Date(f.first_seen * 1000).toLocaleTimeString()
                            : (f.discovered_at || '');
    renderLiveFinding({ ts, severity: f.severity, target: f.target,
                        detail: f.detail, host: f.host });
  });
}
window.WHX_HYDRATE_LIVE = hydrateLiveFromScan;   // for console debugging
```

Three non-obvious bits that bit me mid-session:

1. **API key mismatches across endpoints.** `/subdomains` returned
   `real_ip` (not `ip`); `/findings` returned `first_seen` as Unix
   seconds (not ISO `discovered_at`). Always curl each endpoint and
   check the actual field names before writing the hydration code —
   guessing produces "undefined IP" / "Invalid Date" rows.
2. **The hydration call must run AFTER the REST loads complete.** If
   you put it inside `loadScanData()` but call the APIs sequentially
   with `await`, the hydration sees empty arrays. Use `Promise.all`
   to load them concurrently, then hydrate.
3. **Idempotency on re-render.** If `loadScanData` is called twice
   (e.g. user clicks the scan again), hydration should not duplicate
   rows. Clear the live-panel state first, then re-seed:
   `activityFeed.innerHTML = ''; liveFindingsFeed.innerHTML = '';`
   before the `forEach` loops. Or guard with a `S._hydratedFrom`
   set keyed by scan_id so you only hydrate once per session.

The corresponding server-side requirement: every endpoint the
hydration reads must return a real, paginated list (not a 404 with
an empty body). If `/scans/{id}/events` doesn't exist on the
server, return `200 {"events": []}` instead of letting the handler
raise — the hydration handles empty gracefully, but a 404 makes
`Promise.all` reject and the whole load fails.

### Auto-pick races the user's click — the `userPinned` guard

When `loadAll()` runs on a polling timer (every 5-15s) AND
auto-selects the most-relevant scan (e.g. "the running one"), the
auto-pick will silently overwrite the user's explicit row click
on the next tick. The user clicks a history row, sees the panel
switch momentarily, then watches it snap back. This is the
"click-stick race" — the most subtle bug in a polling dashboard.

**Fix**: pin a flag in localStorage on explicit click, respect
it in auto-pick:

```js
// openScan is called from a click handler
function openScan(scanId) {
  S.scanId = scanId;
  try { localStorage.setItem('app.userPinned', '1'); } catch {}
  S.userPinned = true;
  loadAll();
}

// in loadAll, the auto-pick branch
const anyRunning = S.scans.some(s => s.status === 'running');
const userPinned = S.userPinned || (localStorage.getItem('app.userPinned') === '1');
if (!S.scanId || (anyRunning && !userPinned)) {
  // auto-pick: the first running scan, or the most recent
  S.scanId = (S.scans.find(s => s.status === 'running') || {}).scan_id
          || S.scans[0]?.scan_id;
} // else: respect the user's choice
```

**Clear the pin on launchNewScan()** so the auto-pick resumes
after the user starts a new scan:

```js
function launchNewScan() {
  try { localStorage.removeItem('app.userPinned'); } catch {}
  S.userPinned = false;
  // ... actual launch ...
}
```

**Verify in console**: `localStorage.getItem('app.userPinned')`
should be `'1'` after a row click, `null` after launching. This
is the same verification as the loadAll step logging — read the
state, not the pixels.

The pair — `userPinned` guard + step-by-step loadAll logging —
is the diagnostic + fix combination for "the dashboard looks
fine but the wrong scan is selected" and "I clicked a row and
nothing happened." See
`wex/dashboard/static/app.js` `loadAll()` and `openScan()` for
the canonical implementation, and the `wehuntx` skill's
`references/session-2026-06-19-phase2-lifecycle-diff-verified.md`
§ "Click-stick race fix" for the bug history.

## State + settings sync

Persist to localStorage on every change:

```js
function saveModel(m) {
  S.model = m;
  try { localStorage.setItem('wehax-model', m); } catch {}
  // re-render every visible reference
  $('topbar-pill-model').textContent = m;
  $('orch-model').textContent = m;
  $('fb-model').textContent = m;
  // also push to API
  api.put('/settings', { model: m }).catch(e => toast('offline', e.message, 'warn'));
}
```

Read on init:

```js
const S = {
  API: localStorage.getItem('wehax-host') || 'http://127.0.0.1:8777',
  model: localStorage.getItem('wehax-model') || 'minimax-m3:cloud',
  // ...
};
```

**Six surface points to update on settings save**: (1) localStorage,
(2) in-memory `S`, (3) API PUT, (4) topbar pill, (5) inspector
kv-row, (6) re-open the dialog with fresh values. Missing even
one = "the model didn't change" bug from the user's perspective.

## WebSocket

```js
function connectWS(scanId) {
  // The WebSocket URL must match the server's route. FastAPI supports both:
  //   @app.websocket("/ws/{scan_id}")  → use /ws/{scan_id}  (path param, server reads scan_id from path)
  //   @app.websocket("/ws")            → use /ws?scan_id=... (query param)
  // Most server code uses the path-param form. If the client uses ?scan_id=
  // and the server has no such query-param handler, the WS never connects
  // and the bus-emit events flow into the void.
  const ws = new WebSocket(S.API.replace(/^http/, 'ws') + '/ws/' + encodeURIComponent(scanId));
  ws.onmessage = (msg) => { try { handleWSEvent(JSON.parse(msg.data)); } catch (e) { console.warn('bad ws', e); } };
  ws.onclose = () => scheduleWSRetry();
  ws.onerror = () => { try { ws.close(); } catch {} };
}

function scheduleWSRetry() {
  S.wsRetry = Math.min(S.wsRetry + 1, 6);
  const delay = Math.min(8000, 400 * 2 ** S.wsRetry);
  if (S.wsTimer) clearTimeout(S.wsTimer);
  S.wsTimer = setTimeout(() => connectWS(S.scanId), delay);
}
```

Exponential backoff: 400ms → 800 → 1600 → 3200 → 6400 → 8000
(capped), 6 retries. Then either give up (show a yellow banner)
or keep retrying once a minute.

If the API base URL changes via settings, **disconnect the WS
manually** so the next periodic refresh re-opens it against the
new host. Otherwise the WS stays connected to the dead host
forever and the user thinks the live updates are broken.

## Toasts

A small top-right notification system, no library:

```js
function toast(title, sub = '', kind = 'ok', ms = 3000) {
  const t = el('div', { class: 'toast ' + kind },
    el('div', { class: 'glyph' }, kind === 'ok' ? '✓' : kind === 'warn' ? '⚠' : '✗'),
    el('div', { class: 'body' },
      el('div', { class: 'title' }, title),
      sub ? el('div', { class: 'sub' }, sub) : null,
    ),
  );
  $('toast-host').appendChild(t);
  setTimeout(() => { t.style.transition = 'opacity 0.3s, transform 0.3s'; t.style.opacity = 0; t.style.transform = 'translateX(20px)'; }, ms);
  setTimeout(() => t.remove(), ms + 400);
}
```

Container: `<div id="toast-host"></div>` at end of body, CSS
`position: fixed; top: 16px; right: 16px; z-index: 999;`

For the polished version` (icon, progress bar, click-dismiss, hard cap
of 5, data-search mode `>query`, recents, inline shortcut chips, global
API spinner with try/finally counter) — see
[`references/palette-toast-spinner.md`](references/palette-toast-spinner.md).

For the **60 KB minimalist rebuild** of an 8 MB PlainAdmin dashboard
(the "super simple and stunning" / Linear-grade redesign pattern):
3-column layout, one accent, command bar (⌘K), filter-aware
command palette that doesn't auto-launch on Enter, the
`window.fn.toString()` stale-cache diagnostic, countUp first-render
suppression, the "Show all N" pagination pattern, the
`[hidden]`-attribute-overridden-by-display-flex pitfall, the
macOS-Vision-OCR-via-swift blank-page diagnostic, and the FastAPI
3-tier serve (`app.html` preferred, `dashboard.html` fallback) — see
[`references/minimalist-redesign-and-fastapi-fallback.md`](references/minimalist-redesign-and-fastapi-fallback.md).
Reusable OCR script at
[`scripts/ocr.swift`](scripts/ocr.swift).

## Sync chat replies via Future (when the HTTP endpoint needs to wait for an async chat)

The default pattern for a chat endpoint is "fire-and-forget on
WebSocket, client subscribes to receive the reply." This is
fine for streaming UIs but terrible for `fetch()`-based clients:
the HTTP response returns 200 immediately with no answer, the
client falls back to the WS to read it, and you have a 2-path
merge problem on the client side.

The cleaner pattern: **register a Future keyed by `cmd_id` on
the orchestrator, return the response, the WS handler fills the
Future on completion**.

```python
# Python side — on the orchestrator
self._chat_futures: dict[str, asyncio.Future] = {}

async def _handle_chat(self, message: str, cmd_id: str) -> None:
    if not message.strip():
        if cmd_id in self._chat_futures: self._chat_futures[cmd_id].set_result('')
        return
    self._emit(CH_CHAT, 'chat_user', message, {...})
    if cmd_id in self._chat_futures:
        # create the future BEFORE kicking off the LLM call
        self._chat_futures[cmd_id] = asyncio.get_event_loop().create_future()
    try:
        reply = await self._call_llm_text(messages, model, host)
        self._emit(CH_CHAT, 'chat_reply', reply, {...})
        if cmd_id in self._chat_futures and not self._chat_futures[cmd_id].done():
            self._chat_futures[cmd_id].set_result(reply)
    except Exception as e:
        if cmd_id in self._chat_futures and not self._chat_futures[cmd_id].done():
            self._chat_futures[cmd_id].set_exception(e)

async def await_chat(self, cmd_id: str, timeout: float = 180.0) -> str:
    if cmd_id not in self._chat_futures:
        self._chat_futures[cmd_id] = asyncio.get_event_loop().create_future()
    try:
        return await asyncio.wait_for(self._chat_futures[cmd_id], timeout=timeout)
    finally:
        self._chat_futures.pop(cmd_id, None)
```

```python
# HTTP endpoint
@app.post("/scans/{scan_id}/chat")
async def chat(scan_id, req: ChatRequest):
    orch = orchestrators.get(scan_id)
    if orch:
        cmd_id = uuid.uuid4().hex
        await orch.submit_command('chat', {'message': req.message, 'cmd_id': cmd_id})
        try:
            reply = await orch.await_chat(cmd_id, timeout=180.0)
            return {'answer': reply, 'reply': reply, 'text': reply, 'model_used': model}
        except asyncio.TimeoutError:
            return {'answer': '(timeout)', 'reply': '(timeout)', 'text': '(timeout)'}
    # historical: call LLM directly
    ...
```

```js
// Client side
async function orchSend() {
  const msg = $('orch-input').value.trim();
  const r = await api.post(`/scans/${S.scanId}/chat`, { message: msg });
  // r is now { answer, reply, text, model_used } — always populated
  appendOrchReply(r.answer || r.reply || r.text || '(empty)');
}
```

**Three reasons to do this over the WS-only approach**:
1. `fetch()`-based clients (REST tools, curl, the dashboard's `api.req()`)
   get a real answer in one round-trip, not a 200-with-no-payload.
2. The client doesn't need a second open channel (WS) to read chat
   replies — simpler client code.
3. Errors are returned in the HTTP response body, not just emitted
   on the WS where the client might not be listening.

Keep `cmd_id` generation on the server (UUID is fine), not the
client — the client just fires and reads.

## FastAPI route ordering — `/{param}` catches literal siblings

The most subtle FastAPI bug: routes are matched in **declaration order**,
first match wins. So if you define `GET /scans/{scan_id}` and then
`GET /scans/modes`, the first route catches `/scans/modes` with
`scan_id="modes"` and returns "scan not found" before `/scans/modes`
ever gets a chance.

**Fix**: define literal routes (`/scans/modes`, `/scans/grouped`,
`/scans/summary`) BEFORE any `/{param}` route in the file. A comment
helps future-you:

```python
# IMPORTANT: this MUST be defined BEFORE /scans/{scan_id}... routes
# so FastAPI matches the literal path first.
@app.get("/scans/modes")
async def list_scan_modes():
    ...
```

This applies to every FastAPI/Starlette app where you mix
`/resource/{id}` with `/resource/{action}` (e.g. `/users/me` vs
`/users/{user_id}`). The cure is declaration order, not regex
or path constraints.

## Defensive middleware — turn 500s into 200s with empty payloads

Legacy / empty / corrupt scan DBs will throw inside API handlers.
The naive 500 is fine for an API tool, but it breaks the dashboard
(orphan rows in the sidebar with red "scan not found" everywhere).

**Five-layer defense**, from the data layer out:

1. **The data method itself** (e.g. `state.recent_findings`) wraps
   the raw query in try/except for `sqlite3.OperationalError` /
   `no such table` and returns `[]`. The method never throws.
2. **The endpoint** wraps the state call in try/except and returns
   `{"findings": [], "warning": "..."}` instead of raising.
3. **A global FastAPI exception handler** converts any unhandled
   exception into a structured `{"ok": false, "error": ..., "path": ...}`
   response — the dashboard's defensive renderers can show a useful
   message instead of breaking the whole UI.
4. **The request-logging middleware** catches the same exceptions
   (it runs OUTSIDE the FastAPI exception chain) and returns 200
   with the empty payload + `findings: [], scans: [], subdomains: [], summary: {}`
   so the dashboard's `r.json()` and `r.findings || []` always works.
5. **The client call site** always uses `d.findings || []` /
   `Array.isArray(d.scans) ? d.scans : (d.scans || [])` — never
   trust the shape.

Without all five, you get the "I can see the scan in the sidebar
but clicking it 500s" experience that's hard to debug because each
layer partially hides the problem.

## macOS daemonization — survive parent shell exit

`subprocess.Popen(..., start_new_session=True)` is NOT enough on
macOS for a process launched from a script that exits. The child
gets reparented to launchd (PPID=1) and the API port stays open,
but the child **may be killed** when the controlling terminal
session ends, depending on how the session was set up.

**Bulletproof double-fork wrapper** that works on Linux AND macOS:

```python
import os, sys
def daemonize():
    if os.fork() > 0: sys.exit(0)  # first parent exits
    os.setsid()                     # become session leader
    if os.fork() > 0: sys.exit(0)  # second parent exits
    # now: PPID=1, no controlling TTY, fully detached
    si = open('/dev/null', 'r'); os.dup2(si.fileno(), sys.stdin.fileno())
    so = open('/path/to/log', 'a+'); os.dup2(so.fileno(), sys.stdout.fileno())
    se = open('/path/to/log', 'a+'); os.dup2(se.fileno(), sys.stderr.fileno())
    # optional: write pid file
    with open('/path/to/daemon.pid', 'w') as f: f.write(str(os.getpid()))
```

For self-healing (auto-restart on death), add a wrapper loop:

```python
import time
RESTART_DELAY_S = 30
MAX_RESTARTS = 50
def run_one(n):
    proc = subprocess.Popen([...], stdout=open(LOG, 'a'), stderr=subprocess.STDOUT,
                            stdin=subprocess.DEVNULL, start_new_session=True)
    rc = proc.wait()  # blocks until the child exits
    log(f"child exited rc={rc}, restarting in {RESTART_DELAY_S}s")
    time.sleep(RESTART_DELAY_S)
# main loop
n = 0
while n < MAX_RESTARTS:
    n += 1
    run_one(n)
```

`start_new_session=True` on the inner `Popen` is REQUIRED even after
the double-fork — it makes the grandchild fully detached from any
remaining TTY/pipe state.

Add `signal.signal(signal.SIGTERM, ...)` for graceful shutdown so
the wrapper exits cleanly when the user Ctrl+C's it.

## Multi-page vs modal architecture decision

When the user asks for "a Scans page, a New Scan page, a Tools page,
a Leaks page" — do you build a real router or stack modals?

| Approach | When |
|---|---|
| **Stack modals over a single page** | One primary content (current scan), all navigation is overlays. Modal opens, reads/writes, closes. The dashboard keeps the same 3-pane layout underneath. |
| **Real route-based pages** | The "pages" are heavyweight (e.g. Tools has 30 tool cards, a separate state, separate WS) and the user expects to lose dashboard context while on them. |

**Default to modals** for agentic dashboards. Three reasons:
1. The user almost always wants to return to the current scan
   (modal-closed restores it instantly vs. route-back-with-state).
2. WebSocket streams to one set of channels; modals overlay them
   without disconnecting.
3. The state, renders, and modals all live in one IIFE, one file,
   one boot path — way easier to debug than N route handlers.

When modals get too big (the "New Scan" modal needs 30 tool
checkboxes, mode picker, advanced settings), extract the modal
content into its own render function inside the IIFE:

```js
function renderNewScanModal() {
  $('ns-mode-grid').innerHTML = '';
  S.scanModes.forEach(m => {
    $('ns-mode-grid').appendChild(
      el('button', { class: 'ns-mode', 'data-mode': m.id, onclick: () => selectMode(m.id) },
        el('div', { class: 'ns-mode-name' }, m.name),
        el('div', { class: 'ns-mode-desc' }, m.description),
        el('div', { class: 'ns-mode-tools' }, m.tools.join(' · ')),
      )
    );
  });
}
```

The modal HTML is static in `dashboard.html`; the JS just populates
its content. This keeps the file sizes reasonable while still
being one IIFE.

## Modals

Every modal shares the same wrapper:

```html
<div class="modal-bg" id="modal-foo" onclick="if(event.target===this)closeFoo()">
  <div class="modal" style="max-width:520px">
    <div class="modal-head">
      <h2>title</h2>
      <button class="topbar-btn" onclick="closeFoo()">×</button>
    </div>
    <div class="modal-body">...content...</div>
    <div class="modal-foot">...buttons...</div>
  </div>
</div>
```

CSS:
```css
.modal-bg {
  position: fixed; inset: 0; z-index: 100;
  background: rgba(0,0,0,0.55);
  display: flex; align-items: center; justify-content: center;
  opacity: 0; pointer-events: none;
  transition: opacity 0.18s;
}
.modal-bg.show { opacity: 1; pointer-events: auto; }
```

Show: `$('modal-foo').classList.add('show')`. Hide: remove 'show'.
Click outside to close is the `onclick="if(event.target===this)closeFoo()"`
on the wrapper. The inner `.modal` element has `onclick` (the
`closeXxx` function) that does `event.stopPropagation()` if you
need clicks inside to NOT close.

`Esc` to close: install a single global keydown listener that
checks `$('modal-foo').classList.contains('show')` and closes
if true. Don't install a per-modal listener — they pile up.

### Outside-click-to-close + × button — the clean delegated pattern (supersedes the inline onclick)

The inline `onclick="if(event.target===this)closeFoo()"` above works
for a single modal but does not compose when you have ≥3 modals, some
of which contain clickable children with their own handlers, and
some of which use a custom shell (e.g. a command palette whose
content is a `.palette-shell` div rather than a `.modal` div).
**The cleaner pattern for multi-modal dashboards is ONE delegated
`mousedown` document listener** that handles both the × button and
backdrop clicks uniformly:

```js
document.addEventListener('mousedown', (e) => {
  // 1) explicit × close buttons — works on every modal
  const x = e.target.closest('[data-modal-close]');
  if (x) {
    const modal = x.closest('.modal-bg');
    if (modal) { modal.classList.remove('show'); e.stopPropagation(); return; }
  }
  // 2) backdrop click — only if click is OUTSIDE the modal's content
  const backdrop = e.target.closest('.modal-bg');
  if (!backdrop || !backdrop.classList.contains('show')) return;
  if (backdrop.dataset.noBackdropClose !== undefined) return;
  // find the visible content node; some modals use .modal, some use a custom shell
  const content = backdrop.querySelector(':scope > .modal, :scope > .palette-shell');
  if (content && content.contains(e.target)) return;  // inside content → keep open
  backdrop.classList.remove('show');
}, true);  // capture phase, runs before any inner handler
```

Modal header markup for the × button (wrap title in a span so flexbox
can right-align the close button):

```html
<div class="modal-head">
  <h2><span>title</span><button class="modal-close-x" data-modal-close>×</button></h2>
</div>
```

Five rules that make this work without surprises:
1. **`mousedown` not `click`** — fires before focus/select, no flash
   of text-selection inside an input before the modal closes.
2. **Capture phase (`true`)** — runs before any bubbling handler on
   a child. The `stopPropagation()` after × close stops a parent
   from also seeing the click as a backdrop hit.
3. **`:scope > .modal, :scope > .palette-shell`** — handles modals
   whose content lives in a non-`.modal` element (e.g. a command
   palette whose shell is a sibling-level custom div). Without
   `:scope >` the query would also find `.modal` descendants of
   the content.
4. **`dataset.noBackdropClose`** opt-out for the rare persistent
   modal (confirmation dialogs that should NOT close on outside
   click). Add `data-no-backdrop-close` to the `.modal-bg` to
   disable outside-click close for that one.
5. **Lock body scroll while any modal is open**, and restore only
   when the LAST modal closes (multi-modal guard):
   ```js
   function openModal(id) {
     document.getElementById(id).classList.add('show');
     document.body.style.overflow = 'hidden';
   }
   function closeModal(id) {
     document.getElementById(id).classList.remove('show');
     if (!document.querySelector('.modal-bg.show')) document.body.style.overflow = '';
   }
   ```

For the WeHax full theme-aware modal CSS (gradient accent bar via
`::before`, layered dark+light shadows, × button with rotate-on-hover
micro-animation) and a 32-case verification ladder, see
`references/round19-modal-theme-and-outside-click.md`.

## Theme + responsive — pointer to the full reference

The 3-way theme cycle (dark / light / system), the 4-breakpoint
responsive collapse (250 → 200 → 64px mobile sidebar with
click-outside-to-close), the CSS-var cascade gotcha, the canvas
`getComputedStyle` pattern, and the viewport-scaling orbit math
for canvas-rendered visualizations are all covered in:

[`references/theme-and-responsive.md`](references/theme-and-responsive.md)

**One must-read gotcha from that reference** (worth surfacing here
because it bit me mid-session): CSS custom properties cascade
**down the DOM tree, not sideways**. Overriding `--bg-0` on
`body.light` works for DOM rendering BUT
`getComputedStyle(documentElement).getPropertyValue('--bg-0')`
keeps returning the original `:root` value. If your
canvas-rendered visualization reads theme colors via
`getComputedStyle(documentElement)`, the canvas stays in the
wrong theme in light mode (invisible white text on white
background, invisible particles). **Fix**: scope the overrides
to `html.light`, not `body.light`. Then both `documentElement`
and `document.body` resolve to the new values.

**Second light-theme gotcha — hardcoded dark backgrounds.** After
the var-cascade fix, the remaining light-mode bugs are inline/CSS
backgrounds written as literal dark colors instead of `--bg` vars.
A panel styled `background: rgba(10,13,20,0.5)` (or `#0a0d14`,
`#15192...`) renders as a dark gray box in light mode with
low-contrast text on top — the classic "one panel is still dark"
bug. Audit for it before declaring light mode done:
`search_files pattern="rgba\(10,\s*13,\s*20|#0[0-9a-f]{5}|background:\s*#1[0-9a-f]"`
inside the HTML. For each hit, either switch to a `--bg-*` var
(which flips automatically) or add a scoped override:
`html.light .hero-timeline { background: rgba(124,92,255,0.05); }`.
The lesson: **never hardcode a dark background literal — use a
`--bg` var or gate it behind `html.light`.** This catches the
timeline/sparkline panel, any "inset well" inside a card, and any
`rgba(0,0,0,...)` overlay you reused from a dark-only mockup.

**Light-theme verification gotchas in the automation browser**:
(1) `browser_vision` screenshots come back **all-black** if you
toggle the theme class mid-frame via `browser_console`
(`documentElement.classList.add('light')`) — the capture races the
repaint. Either reload the page (theme persists via localStorage)
or call `window.__applyTheme('light')` and screenshot on the *next*
turn, never in the same evaluate call. (2) `localStorage` reads can
throw `SecurityError: access is denied` in the headless automation
context — the app already wraps every `localStorage` call in
try/catch so it degrades fine, but your console probes must too.
(3) `getComputedStyle(documentElement).getPropertyValue('--x')` can
return empty strings in that same context — trust the rendered
pixels (screenshot) over computed-style reads when they disagree.

## "Make the layout more creative" — asymmetric bento grid

When the user asks to make a dashboard *"more creative"*, *"stunning"*,
or says the current layout *"looks too conventional/static"*, the
default boring shape (hero full-width → row of N identical stat cards →
2-col content → list, all in a narrow centered column) is the problem.
Replace it with an **asymmetric CSS-Grid bento**: one `.home-bento`
wrapper using `grid-template-areas`, a tall "spotlight" tile spanning
2 rows next to single-row tiles, a big 2-row canvas tile, and full-bleed
sections. Use named grid areas (not `span N` math) so responsive
collapse is just re-declaring the areas at each breakpoint.

For this user, "creative" means gradients + glow + varied tile sizes +
edge-to-edge width — a tidy symmetric grid is below the bar. Push the
visual polish (a giant gradient hero number in a tall spotlight tile,
a corner glow blob, a progress meter), not just a reflow.

**Apply the bento per-tab, not just on home.** When the user says
"keep continue" / "make the layouts creative", every Bootstrap
`row > col-lg-8 / col-lg-4` pane converts to its own named bento.
Recurring shapes: dominant-left + stacked-right (`.live-bento`:
`"feed subs" / "feed brain"`), and two-up + full-width bottom strip
(`.orch-bento`: `"chat metrics" / "pipeline pipeline"`). **Promote any
inherently-wide component (horizontal phase stepper, timeline, wide
table) to a full-width bottom `grid-area` row** — it's the single
biggest readability win (the 6-node stepper was unreadable in a narrow
column, perfect across a full-width row). Use
`min-height: calc(100vh - 160px)` so near-empty tabs still fill the
viewport.

Full CSS (12-col home grid, spotlight tile, the `.live-bento` /
`.orch-bento` per-tab grids, responsive area rewrites), the meter
wiring, and the verify-grid-areas console probe are in
[`references/bento-grid-layout.md`](references/bento-grid-layout.md).

**The polish layers that come AFTER the bento conversion** — when the
user keeps saying "keep continue" / "make it more creative" / "keep
gooning" — are in
[`references/list-to-cards-and-polish-layers.md`](references/list-to-cards-and-polish-layers.md):
list-heavy pane → responsive card grid (Subdomains), severity stat-strip
as one-click quick-filter (Findings, incl. the "chip value must be a real
`<select>` option" pitfall), header overflow "⋯" menu to declutter ≥6
icon buttons, WebAudio severity-pitched chime, presentation auto-cycle
mode, canvas new-item pulse ring, ambient gradient-mesh background,
skeleton shimmer, and the **functional regression console probe** to run
after any large markup refactor (this user's bar: "run all features" =
end-to-end browser verification each feature visibly works, launch flows
checked against the real API).

## HUD frame — 3-rail dashboard layout (64px left / flex main / 300px right)

When a dashboard needs a permanent left navigation rail AND a
right activity/inspector rail (e.g. "Linear-grade but operational"
admin shells — multi-tool scanners, multi-agent runtimes, anything
where the user wants every panel visible at once), the layout is:

```css
.hud {
  display: grid;
  grid-template-columns: 64px minmax(0, 1fr) 320px;
  height: calc(100vh - 56px);          /* under topbar */
  gap: 0;
  background: var(--bg-0);
}
.hud-rail      { /* 64px left nav */ }
.hud-main      { /* scrollable center, overflow-y: auto */ }
.hud-aside     { /* 300px right inspector with its own scroll */
  border-left: 1px solid var(--line);
  background: linear-gradient(180deg, var(--bg-0), var(--bg-1));
  overflow-y: auto;
}
```

The 64px left rail is the **icon-only** primary nav (no labels),
the center is the workspace, the right rail is a
**secondary live feed** (activity stream, selected-item inspector,
webhook log, etc.) that's always visible without a modal. The key
is: the right rail is NOT a tab — the user doesn't have to click to
see it. It just updates in place as the app runs.

**Three rules for the right rail:**

1. **Sticky section headers** (`position: sticky; top: 0`) so a long
   list scrolled deep still shows which section you're in. The
   header must have its own background (not transparent) or it
   mixes with the row content above it.
2. **Density > whitespace.** 8-12px row padding, 12-13px font,
   monospace timestamps. The rail is for skimming, not reading.
3. **Empty state must be actionable.** "No activity yet" is
   useless; "No activity yet — start a scan" with an action is
   informative. When the stream is empty because the app just
   booted, show a 2-line explanation with a primary CTA.

**The full pattern in the WeHuntX #5 refresh** uses:
- left rail: 7 icon buttons (Home, Scans, Findings, Subs, Webhooks,
  Orchestrator, Settings) with an active-state pill (`background:
  var(--brand-soft); color: var(--brand)`)
- right rail: "Live activity" header + sticky timestamp sections
  ("Today", "Yesterday", "Older") + per-event row (glyph, kind,
  msg, ts)
- main: dashboard with `grid-template-rows: auto auto 1fr` for
  the stat strip / tool pipeline / findings list
- a per-card top-row with 3 actions (filter, export, ⋯ menu) on
  every card so the user doesn't have to dig for "what can I do
  with this card"

The HUD frame replaces the older "top nav + center pane" shell.
It's the right choice when the user has said "more creative" or
"operational console" — not when the user has said "marketing
page" or "blog post."

## Severity sparkline — 4-bar inline SVG per card

When stat cards have a sparkline (severity over time, daily
count, etc.), the canonical pattern is **4 bars, 60×18, no
axis labels**. Width is 60px, height is 18px, each bar is 12px
wide with 2px gap, 4 bars total. Rendered as inline SVG so the
user can copy the card and keep the visual.

```js
function severitySparkline(buckets) {
  // buckets = {critical: N, high: N, medium: N, low: N} for the 4 most recent
  const max = Math.max(1, ...Object.values(buckets));
  const colors = {
    critical: 'var(--sev-critical, #ff5d6c)',
    high:     'var(--sev-high, #fb923c)',
    medium:   'var(--sev-medium, #fbbf24)',
    low:      'var(--sev-low, #38e8ff)',
  };
  const order = ['critical', 'high', 'medium', 'low'];
  const bars = order.map((k, i) => {
    const v = buckets[k] || 0;
    const h = Math.max(2, (v / max) * 16);   // 16px max, 2px min
    const y = 18 - h;
    return `<rect x="${i * 14}" y="${y}" width="12" height="${h}"
              rx="1.5" fill="${colors[k]}" opacity="0.85"/>`;
  }).join('');
  return `<svg width="60" height="18" viewBox="0 0 60 18"
            style="display:block">${bars}</svg>`;
}
```

The 4-bar layout communicates "this stat has 4 dimensions"
(severity buckets) without needing a legend. Color maps to
severity so the user reads it instantly.

**Use this on** the Findings-overview card, the Subdomain-stats
card, and any other card where the headline number needs a
"this is from N severity buckets" hint. Don't use it on cards
where the number is already a single dimension (e.g. "scans
today" is just one bar trend — use a 7-bar daily trendline
there instead).

**Empty state**: when all buckets are 0, return 4 grey bars at
2px height with 0.3 opacity. The visual still reads as "sparkline
present" so the card height doesn't change.

## Per-card top-row with actions — the action contract

When a dashboard has 6+ cards, the user needs to know what
actions exist per card without opening a modal first. The pattern
is **3 actions visible on every card**, in a top-right action row
on the card itself:

```html
<div class="card" data-card-id="findings">
  <div class="card-head">
    <h3>Findings</h3>
    <div class="card-actions">
      <button data-card-action="filter" title="Filter findings">⚐</button>
      <button data-card-action="export" title="Export as JSON">↥</button>
      <button data-card-action="menu"   title="More">⋯</button>
    </div>
  </div>
  ...
</div>
```

```js
// Single delegated handler — one listener covers all cards
document.addEventListener('click', (e) => {
  const btn = e.target.closest('[data-card-action]');
  if (!btn) return;
  const card = btn.closest('[data-card-id]');
  if (!card) return;
  const id = card.dataset.cardId;
  const action = btn.dataset.cardAction;
  cardActions(id, action, card);
});

function cardActions(id, action, card) {
  if (id === 'findings' && action === 'filter') openFilterModal('findings');
  if (id === 'findings' && action === 'export') exportFindings(card);
  if (id === 'findings' && action === 'menu')   openCardMenu(card);
  // ... per card
}
```

**Three rules for per-card actions:**

1. **The action icons must be `data-card-action` strings, NOT
   inline onclick.** Inline onclick on a dynamic list of cards
   produces "X cards, X onclick strings, hard to refactor."
2. **Always 3 actions, in this order: filter / export / more.**
   When the user sees 3 icons in a row, the order should be
   predictable. Filter (flag), Export (up-arrow), More (dots).
3. **The "more" action opens a dropdown menu, NOT a modal.**
   Modals are heavyweight; the "more" menu is a 200x150
   absolute-positioned list with secondary actions (rename,
   duplicate, archive, delete). See the "header overflow ⋯
   menu" pattern in `references/list-to-cards-and-polish-layers.md`
   for the full CSS.

**The benefit**: the user can filter / export / "more" on any
card without reading the topbar, the keyboard shortcuts, or the
help modal. Every card has a clear "I can do things to this"
affordance at all times.

## Tool pipeline stepper — horizontal stepper for sequential ops

When a card represents a multi-step process (scan lifecycle:
"recon → enumerate → verify → report", or a CI pipeline:
"build → test → deploy → monitor"), the visual is a **horizontal
stepper** with N nodes connected by lines, not a vertical list:

```html
<div class="pipeline" data-pipeline-id="scan-lifecycle">
  <div class="pipe-step done" data-step="recon">
    <div class="pipe-dot"></div><div class="pipe-label">Recon</div>
  </div>
  <div class="pipe-line done"></div>
  <div class="pipe-step active" data-step="enumerate">
    <div class="pipe-dot"></div><div class="pipe-label">Enumerate</div>
  </div>
  <div class="pipe-line"></div>
  <div class="pipe-step" data-step="verify">
    <div class="pipe-dot"></div><div class="pipe-label">Verify</div>
  </div>
  <div class="pipe-line"></div>
  <div class="pipe-step" data-step="report">
    <div class="pipe-dot"></div><div class="pipe-label">Report</div>
  </div>
</div>
```

```css
.pipeline { display: flex; align-items: center; gap: 0; padding: 12px 0; }
.pipe-step { display: flex; flex-direction: column; align-items: center;
             flex: 0 0 auto; min-width: 96px; }
.pipe-dot { width: 14px; height: 14px; border-radius: 50%;
            background: var(--bg-2); border: 2px solid var(--line); }
.pipe-step.done   .pipe-dot { background: var(--green); border-color: var(--green); }
.pipe-step.active .pipe-dot { background: var(--brand); border-color: var(--brand);
                               box-shadow: 0 0 0 4px var(--brand-soft); }
.pipe-line { flex: 1; height: 2px; background: var(--line); margin-top: 6px; }
.pipe-line.done { background: var(--green); }
.pipe-label { margin-top: 6px; font-size: 11px; color: var(--text-2);
              text-transform: uppercase; letter-spacing: 0.05em; }
```

**Three rules:**

1. **3-6 steps.** Less than 3 doesn't need a stepper; more than
   6 wraps the labels. The "scan lifecycle" example uses 4.
2. **Width = `(N steps × 96px) + (N-1 lines × flex 1)`.** The
   stepper fills its container; labels stay above the dots, not
   to the side.
3. **Step states are 3: pending (grey), active (brand glow),
   done (green).** No "error" state on the dot — failures are
   surfaced via a separate per-step status pill BELOW the
   stepper, not by re-coloring the dot. Mixing states confuses
   the visual.

The stepper goes ABOVE the per-step detail panel. Click a dot
to drill in (if interactive) — or just leave the dots as
indicators and use a separate "view X" button on the detail
panel.

## What to put in the JS file vs. the HTML file

- **HTML** — DOM structure, modals, CSS, SVG icons, anything static
- **JS** — state, renders, event handlers, fetch calls, WebSocket
- **Inline JS in HTML** — only for `<script>` tag at the bottom
  loading the external JS, and for one-line `onclick` handlers
  that need to work before boot completes

Putting logic in `onclick` attributes (e.g. `onclick="openScan('${id}')"`)
is fine for dispatch but bad for anything that needs the IIFE
state. If you need state, attach via `addEventListener` after the
DOM is built.

## Async dual-write (localStorage + backend PUT) with graceful failure

When a user-editable setting needs to land in BOTH the browser
(localStorage, for instant re-load) AND the backend (PUT, for cross-
device / server-side reads), the right pattern is async dual-write
with explicit success/failure toasts:

```js
async function saveSettings() {
  // 1) Read the form
  const newHost  = $('sHost').value  || S.host;
  const newModel = $('sModel').value || S.model;
  // 2) Optimistically update in-memory state
  S.host  = newHost;  S.model = newModel;
  // 3) Write to localStorage (best-effort — headless browsers may deny)
  try {
    localStorage.setItem('app.host',  newHost);
    localStorage.setItem('app.model', newModel);
  } catch {}
  // 4) Push to backend
  try {
    const r = await api.request('/settings', {
      method: 'PUT',
      body: { host: newHost, model: newModel },
    });
    if (r && r.ok) {
      toast('✓ settings saved', 'persisted to server', 'ok');
    } else {
      toast('⚠ saved locally only', (r && r.error) || 'backend PUT failed', 'warn', 5000);
    }
  } catch (e) {
    // Network down, 5xx, CORS, timeout — local state is still good
    toast('⚠ saved locally only', 'server unreachable: ' + (e?.message || e), 'warn', 5000);
  }
}
```

Three properties that matter:
- **Async**: the function doesn't block the UI; the toast confirms when it's done
- **Always toast the result**: silent saves are the #1 "I clicked Save and nothing happened" complaint
- **Distinguish "no server" from "server rejected"**: the catch arm hits on network failure, the inner `if (r.ok)` arm hits on a 4xx/5xx with a real response

The corresponding `api.request()` is the generic primitive every
non-trivial app needs (sibling to `api.get`/`api.post`/`api.put`):

```js
async request(path, opts = {}) {
  _spinStart();
  try {
    const o = { method: opts.method || 'GET', headers: opts.headers || {}, ...opts };
    if (o.body && typeof o.body !== 'string') o.body = JSON.stringify(o.body);
    if (o.body && !o.headers['Content-Type']) o.headers['Content-Type'] = 'application/json';
    const r = await fetch(S.apiBase + path, o);
    let data = null;
    try { data = await r.json(); } catch { data = { ok: r.ok, status: r.status }; }
    if (!r.ok) {
      const err = new Error('HTTP ' + r.status + ' ' +
        ((data && (data.detail || data.error)) || ''));
      err.status = r.status; err.data = data;
      throw err;
    }
    return data;
  } finally { _spinEnd(); }
}
```

The `_spinStart() ... _spinEnd()` bookends are the global API
loading spinner counter (try/finally so a throw doesn't pin the
spinner forever). See the vanilla-js-spa palette/toast/spinner
reference for the full setup.

## FastAPI: nested-class BaseModel is a ForwardRef that breaks /openapi.json

A subtle FastAPI trap: if you define `class SettingsPatch(BaseModel)`
INSIDE a factory function and reference it in a route signature,
FastAPI's schema generator can't resolve the type and `/openapi.json`
returns a graceful-error payload instead of the schema:

```json
{
  "ok": false,
  "error": "TypeAdapter[ForwardRef('_SettingsPatch')] is not fully defined...",
  "paths": {},
  "findings": [], "scans": [], "subdomains": [], "summary": {}
}
```

The fix is to **hoist the model to module scope** alongside
`ScanRequest`, `ChatRequest`, etc. — anywhere FastAPI's schema
generator can find it. The factory-function pattern (great for
**handlers**, keeps them out of module-level state) does NOT work
for **models**. Two options:

```python
# Option 1 (clean): module-scope model
class SettingsPatch(BaseModel):
    patch: T.Optional[T.Dict[str, T.Any]] = None
    apiBase: T.Optional[str] = None
    ollamaHost: T.Optional[str] = None
    model: T.Optional[str] = None

# Option 2 (uglier): rebuild the inner class so the schema resolves
def _make_endpoint():
    class _SettingsPatch(BaseModel):
        patch: T.Dict[str, T.Any]
    _SettingsPatch.model_rebuild()  # forced
    @app.put('/settings')
    async def _h(req: _SettingsPatch = None): ...
    return _h
```

Pick option 1. The schema is cleaner, the type is discoverable, and
the route still has access to the closure-scoped state it needs.

**For dual-shape endpoints** (modern UI sends flat fields, legacy
callers send `{"patch": {...}}`), the module-scope class can have
BOTH shapes and the handler picks whichever is non-empty:

```python
@app.put('/settings')
async def update_settings(req: SettingsPatch = None, request: Request = None):
    if req is not None:
        if isinstance(req.patch, dict) and req.patch:
            patch = req.patch
        else:
            patch = {k: v for k, v in {
                'apiBase': req.apiBase, 'ollamaHost': req.ollamaHost,
                'model': req.model
            }.items() if v is not None}
    elif request is not None:
        # raw-body fallback for clients that bypass the pydantic binding
        try:
            body = await request.json()
            if isinstance(body, dict) and 'patch' in body and isinstance(body['patch'], dict):
                patch = body['patch']
            elif isinstance(body, dict):
                patch = body
            else:
                patch = {}
        except Exception:
            patch = {}
    else:
        patch = {}
```

**The verification**: `curl http://127.0.0.1:PORT/openapi.json | jq '.paths | length'`
should return a non-zero number (50+ in a real app). A 0 or
`{"error": "..."}` is the forward-ref symptom. Always curl this
endpoint and check it's a real schema after defining new request
models — the dashboard's `/openapi.json` link is the canary.

## When NOT to use this pattern

- Multi-page app with shared routing → use a real SPA framework.
- Heavy state management (Redux, normalized caches) → use React.
- Server-rendered pages for SEO → use a server template engine.
- 50+ components with rich interactions → the file gets too big.

For everything else — agentic dashboards, admin panels, internal
tools, one-screen scan UIs, debug consoles, status pages — this
pattern is faster to build, easier to debug, and deploys with a
single file copy.

## Stale-page diagnostic in browser tools

When `window.someFunction` returns "undefined" in a
`browser_console.evaluate()` call right after you just defined it, the
page is stale — the prior `browser_navigate` didn't actually reload,
or the script failed to parse. Three ways to confirm and recover:

1. `document.readyState` should be `'complete'` — if still `'loading'`,
   the page hasn't finished bootstrapping.
2. `typeof window.X` for a known-bundled function — if your other
   `window.foo` returns `'function'` but the new one returns `'undefined'`,
   the new addition didn't make it into the served bundle.
3. `fetch('/static/dashboard.js?_=cb')` and grep for the new function
   name — if absent, your edit didn't save or the server is serving a
   stale file from cache.

Recovery: `browser_navigate` to the same URL with a fresh cache-buster
(`?_=N` where N is a timestamp), then re-evaluate. If still missing,
`node --check` the file to catch syntax errors that broke the bundle.

## addEventListener at top-level: the silent-failure trap

A common pattern is to wire all buttons at the bottom of the IIFE:

```js
// ── Wire header buttons ──
$('newScanBtn')?.addEventListener('click', openNewScan);   // ← top-level call
$('allScansBtn')?.addEventListener('click', openAllScans);
$('nsLaunch')?.addEventListener('click', launchNewScan);
```

If the `<script>` tag is at the **bottom of `<body>`** (the common
case), the buttons exist and the listeners attach fine. But if the
script runs before `<body>` is fully parsed (e.g. `<script src>` in `<head>` with no `defer`), or the button is rendered
conditionally by a modal/toggle that fires later, the `?.` optional
chain silently **skips** the registration and the click "does
nothing." No error in console, no obvious next step.

**Fix**: move all `addEventListener` wiring into a single function
called from `boot()` after the DOM is guaranteed to be ready:

```js
function wireButtons() {
  const on = (id, fn) => { const e = $(id); if (e) e.addEventListener('click', fn); };
  on('newScanBtn', openNewScan);
  on('allScansBtn', openAllScans);
  on('nsLaunch', launchNewScan);
  // ... all other wiring
}

async function boot() {
  wireButtons();          // ← always works
  await loadAll();
  // ...
}
document.addEventListener('DOMContentLoaded', boot);
```

The `on(id, fn)` helper pattern also makes the code scannable — one
line per button, no `?.` chains, no missed cases.

### Functions defined inside `wireButtons()` are invisible to module-level callers

A trap that follows directly from moving wiring into `wireButtons()`:
if you ALSO define a helper inside `wireButtons()` (e.g. `_bumpBell`,
`openNotifDrawer`, `applyTheme`) and then call it from a function
declared at **module/IIFE top level** (e.g. `toast()` calling
`_bumpBell(level)`), the call throws `ReferenceError` — the helper is
closure-scoped to `wireButtons`, not visible outside it. The symptom is
nasty: a `try { _bumpBell(level); } catch {}` swallows the error
silently, so the bell counter just never increments and there's no
console error to chase.

2. **Define the helper at IIFE top level** (not inside `wireButtons`)
   and only *wire* (addEventListener) inside `wireButtons`.

Rule of thumb: `wireButtons()` should contain ONLY `addEventListener`
calls and one-liners. Any function a top-level renderer or `toast()`
might call belongs at module scope (and on `window` if cross-context).
This is the same ordering trap as exposing `applyTheme` on `window` so
`boot()` can call it after `wireButtons()` runs.

## Canvas: hover detection on a transformed 2D context

When you put an interactive visualization (constellation, graph, particle
system) on a `<canvas>`, the hover math is the thing that takes the longest
to get right. The transform is **not** `e.clientX` → node — it's:

```
// On draw:
ctx.translate(W/2 - 400*zoom, H/2 - 190*zoom)
ctx.scale(zoom, zoom)
// Draw node at canvas-space (x, y)

// On hover (findNode):
// Reverse the transform: mouse px -> canvas-space
const tx = mouseX - W/2 + 400*zoom
const ty = mouseY - H/2 + 190*zoom
const localX = tx / zoom
const localY = ty / zoom
// Then hypot(node.x - localX, node.y - localY) < radius
```

The "invert the drawAsm transform" comment is the most important line.
Forget the `+ 400*zoom` and the hover target jumps to the wrong side of
the canvas. Forget `/ zoom` and it stops working when you zoom in.

**Debug recipe** when hover is wrong: log `{mouseX, mouseY, W, H, zoom,
localX, localY, node.x, node.y}` once. The numbers will tell you which
side of the transform you got wrong.

**Click-to-inspect pattern**: attach full data to the node at build time
(`node.finding = f; node.fullName = name;`) and the click handler does
`openFindingModal(node.finding)`. Don't re-look-up the data from
S.findings in the click — by then the index may have changed.

**Canvas visualization scales with viewport**: orbit radii and particle
bounds should multiply by `W/800, H/380` (the reference dimensions)
each frame so the constellation always fits the canvas — see
`references/theme-and-responsive.md` § "Canvas-rendered visualization:
scale with viewport" for the full math.

## Stacked SVG donut from severity buckets

For "breakdown" charts (severity mix, status mix, anything with N
categories), use N SVG circles each with their own `stroke-dasharray`
+ `stroke-dashoffset`, NOT a single weighted arc. Single arcs look
broken when one bucket is 0 (`circ/circ` produces 0 visible stroke).

```js
const colors = { critical:'#ff5d6c', high:'#fb923c', medium:'#fbbf24',
                 low:'#38e8ff', info:'#6b7390' };
const R = 65, cx = 80, cy = 80, circ = 2 * Math.PI * R;
let segs = `<circle cx="${cx}" cy="${cy}" r="${R}" fill="none"
  stroke="var(--bg-0)" stroke-width="14"/>`;
let offset = 0;
['critical','high','medium','low','info'].forEach(k => {
  const v = counts[k]; if (v <= 0) return;
  const len = (v / total) * circ;
  const gap = total > 1 ? 2 : 0;       // small gap between segments
  segs += `<circle cx="${cx}" cy="${cy}" r="${R}" fill="none"
    stroke="${colors[k]}" stroke-width="14" stroke-linecap="round"
    stroke-dasharray="${Math.max(len - gap, 0.1)} ${circ - Math.max(len - gap, 0.1)}"
    stroke-dashoffset="${-offset}"
    style="transition: stroke-dasharray 0.8s, stroke-dashoffset 0.8s"/>`;
  offset += len;
});
svg.innerHTML = segs;
```

Two gotchas:
- `stroke-dashoffset` rotates the start. With the SVG pre-rotated
  by `transform: rotate(-90deg)` in CSS, segments start at 12 o'clock
  and proceed clockwise.
- The 2px gap makes segments visually distinct without adding a
  separate `stroke` color. Without it the segments blur together.

## Animated count-up for stat numbers

When a stat card's value changes (new finding verified, scan started,
counter incremented), animate the number from its current displayed
value to the new one with cubic ease-out. A 700ms tween feels
significantly more polished than a snap.

```js
const _counters = {};
function countUp(id, target, dur = 700) {
  const el = $(id); if (!el) return;
  const start = parseInt(el.textContent) || 0;
  if (start === target) { el.textContent = target; return; }
  const t0 = performance.now();
  cancelAnimationFrame(_counters[id]);
  const step = (now) => {
    const p = Math.min(1, (now - t0) / dur);
    const eased = 1 - Math.pow(1 - p, 3);
    el.textContent = Math.round(start + (target - start) * eased);
    if (p < 1) _counters[id] = requestAnimationFrame(step);
  };
  _counters[id] = requestAnimationFrame(step);
}
```

Use it for any counter that the user might watch change. Skip it for
values that change every frame (60fps counters just look jittery).

The `_counters` map keyed by element id is important — without it,
two rapid refreshes will fight over the same element and the
animation will jump.

## "Verified only" filter — strict separation by `verified` integer

When a finding can be in 3 states (verified=1 real, verified=0
unverified, verified=-1 false positive), the UI should NEVER show
unverified/false-positive findings anywhere — not in stats, not in
the recent list, not in the constellation, not in the heatmap. They
exist in the data; the operator just doesn't see them.

Single helper at the top of the IIFE:

```js
const verifiedOnly = (arr) => (arr || []).filter(f => f.verified === 1);
```

Then in every render:
```js
const vList = verifiedOnly(S.findings);
$('homeVerified').textContent = vList.length;
$('homeCritical').textContent = vList.filter(f => ['critical','high'].includes(f.severity)).length;
renderHeatmap(vList);     // pass through, don't refilter
renderASM(vList);
renderRecent(vList);
```

If the dashboard ever says "Total Findings: 4, Verified: 4" but
shows 0 critical, that's CORRECT — 4 are verified, all 4 are info
severity. Don't second-guess. The discipline is: the user sees
verified-only data, period.

For the FULL pattern (active verifier daemon, the WS plumbing, the
side-by-side rejected/unverified badge, the constellation's
verified-only view), see
[`references/verified-only-display-pattern.md`](references/verified-only-display-pattern.md).

## Global window.onerror / unhandledrejection catcher — install BEFORE app.js

When the page renders statically (no dynamic content, no error in
the visible console, no toast), the IIFE has already crashed at
parse time — before any inner error handler could fire. DOMContentLoaded
never runs because the boot path itself threw. To diagnose this:

**Inject a global catcher inline in the HTML, immediately BEFORE
the suspect `<script>` tag.** The catcher captures the boot-time
error and surfaces it into a banner the agent can read via
`browser_console`, or that the user sees:

```html
<!-- IMMEDIATELY BEFORE <script src="/static/app.js"> -->
<script>
(function () {
  var banner = null;
  function show(msg) {
    if (!banner) {
      banner = document.createElement('div');
      banner.style.cssText = 'position:fixed;top:0;left:0;right:0;' +
        'background:#dc2626;color:#fff;padding:8px 16px;font:13px/1.4 monospace;' +
        'z-index:99999;white-space:pre-wrap;max-height:50vh;overflow:auto';
      document.body && document.body.appendChild(banner);
      // If body not parsed yet, wait for it
      if (!document.body) document.addEventListener('DOMContentLoaded',
        function () { document.body.appendChild(banner); });
    }
    banner.textContent += msg + '\n';
  }
  window.__AGENT_ERRORS = [];
  window.addEventListener('error', function (e) {
    var rec = { type: 'error', msg: e.message,
                file: (e.filename || '').split('/').pop(),
                line: e.lineno, col: e.colno,
                stack: e.error ? String(e.error.stack).slice(0, 400) : '' };
    window.__AGENT_ERRORS.push(rec);
    show('💥 ' + rec.msg + ' @ ' + rec.file + ':' + rec.line);
  });
  window.addEventListener('unhandledrejection', function (e) {
    var rec = { type: 'promise', reason: String(e.reason).slice(0, 200),
                stack: e.reason && e.reason.stack ?
                       String(e.reason.stack).slice(0, 400) : '' };
    window.__AGENT_ERRORS.push(rec);
    show('⚠ ' + rec.reason);
  });
})();
</script>
<script src="/static/app.js"></script>
```

**Why placement matters**: a catcher installed AT the top of
`app.js` (inside the IIFE) won't see the error if the IIFE itself
crashes on its first line. The catcher must be in a SEPARATE
inline `<script>` block that runs as soon as HTML parsing hits it,
with no dependency on `app.js` having parsed successfully.

**Diagnostic workflow**:
1. Inject catcher (temp — remove once root cause is found).
2. Hard reload with cache-buster (`?v=N`).
3. The banner shows the actual error: file, line, message, stack.
4. Common hits: `Cannot read properties of null (reading 'addEventListener')`
   (DOM dependency not yet parsed) → fix with `defer` or move script.
5. Remove the temp catcher after the bug is fixed; the production
   page should rely on `defer` + `DOMContentLoaded` + the inner
   error handling each renderer wraps itself in.

**Don't** rely on this as your only error reporting — wrap critical
renderers in `try { ... } catch (e) { console.error('renderX', e); }`
so a single render failure doesn't break the whole boot. The
catcher is a diagnostic tool, not a permanent fixture.

## When you integrate a 3rd-party admin template (PlainAdmin / AdminLTE / Tabler / etc.)

If the user says "use this template" and you bring in PlainAdmin
(35-page Bootstrap-grid template, 8 MB of assets), the #1
integration failure is **class-name mismatch** — the framework
calls its main content wrapper `.main-wrapper` (not `.main`!),
its header needs Bootstrap `container-fluid > row > col-lg-X`
internally, and any CSS override you write on `.main` wipes out
its `margin-left: 250px` layout.

For the full recipe (5-step migration, what to copy, what NOT
to copy, icon font gotchas, class-name cheatsheet for 5 popular
templates, "design is messed up" debug ladder), see
[`references/admin-template-integration.md`](references/admin-template-integration.md).

## Sticky activity footer in a long-scrolling sidebar

When the sidebar has more items than the viewport height, the user
scrolls the nav and loses sight of the most important state: how
many scans are running. The fix is a **sticky-bottom activity
indicator** that lives in the same scrollable container and pins
to the bottom edge.

```html
<aside class="sidebar-nav-wrapper">   <!-- overflow-y: auto; height: 100vh -->
  <nav class="sidebar-nav">...</nav>
  <div class="sidebar-activity" id="sidebarActivity">  <!-- position: sticky; bottom: 0 -->
    <div class="act-pulse"></div>                       <!-- green when active, gray when idle -->
    <div class="act-text">
      <span class="act-label">scanning</span>
      <span class="act-count" id="sidebarActCount">0</span>
    </div>
    <button class="act-stop" id="stopAllBtn" style="display:none">
      <i class="lni lni-close"></i>
    </button>
  </div>
</aside>
```

```css
.sidebar-activity {
  position: sticky; bottom: 0;          /* pins to bottom of scrollable parent */
  margin: 12px; padding: 10px 14px;
  display: flex; align-items: center; gap: 10px;
  background: linear-gradient(135deg, rgba(74,222,128,0.12), rgba(56,232,255,0.06));
  border: 1px solid rgba(74,222,128,0.3); border-radius: 10px;
  transition: all 0.3s;
}
.sidebar-activity.idle { background: var(--bg-0); border-color: var(--line); }
.sidebar-activity .act-pulse {
  width: 10px; height: 10px; border-radius: 50%; background: var(--green);
  box-shadow: 0 0 0 0 rgba(74,222,128,0.7);
  animation: activityPulse 1.8s ease-in-out infinite;
}
.sidebar-activity.idle .act-pulse { background: var(--text-3); animation: none; }
@keyframes activityPulse {
  0%   { box-shadow: 0 0 0 0 rgba(74,222,128,0.7); }
  70%  { box-shadow: 0 0 0 8px rgba(74,222,128,0); }
  100% { box-shadow: 0 0 0 0 rgba(74,222,128,0); }
}
```

```js
// In loadAll() — single source of truth for "is anything running?"
const active = S.scans.filter(s => s.status === 'running').length;
const actEl = $('sidebarActivity');
const actCount = $('sidebarActCount');
const stopBtn = $('stopAllBtn');
if (actEl) actEl.classList.toggle('idle', active === 0);
if (actCount) {
  actCount.textContent = active;
  actCount.style.transform = 'scale(1.2)';            // tiny pulse on update
  setTimeout(() => { if (actCount) actCount.style.transform = 'scale(1)'; }, 200);
}
if (stopBtn) stopBtn.style.display = active > 0 ? 'flex' : 'none';
```

Three reasons to make this sticky (not `position: fixed` to the
viewport): (1) it scrolls with the sidebar's overflow, (2) it
respects the sidebar's width and padding, (3) when the sidebar
collapses to 64px on mobile, the indicator stays inside the
collapsed region and doesn't overflow.

Pair it with a `confirm()`-gated "Stop all" action — stopping N
running scans is irreversible and easy to trigger by accident on a
touchscreen.

## Keyboard shortcut system (vim-style `g` prefix + ⌘ chords)

When the user wants to fly through the dashboard without touching
the mouse, a single document-level keydown listener covers it. Skip
when typing in inputs/textareas/contenteditable, then dispatch on
plain keys for global actions, ⌘/Ctrl chords for power actions, and
`g` then-key pairs for vim-style tab jumping.

```js
document.addEventListener('keydown', (e) => {
  // never hijack while typing
  const tag = (e.target?.tagName || '').toLowerCase();
  if (tag === 'input' || tag === 'textarea' || e.target?.isContentEditable) return;
  const cmd = e.metaKey || e.ctrlKey;

  // ── globals ──
  if (e.key === '?' || (e.shiftKey && e.key === '/')) { e.preventDefault(); openHelp(); return; }
  if (e.key === 'Escape') { closeAllModals(); return; }
  if (cmd && e.key === 'k') { e.preventDefault(); $('searchBox')?.focus(); return; }
  if (cmd && e.key === 'n') { e.preventDefault(); openModal('modal-newscan'); return; }

  // ── vim-style prefix: g then letter within 1s ──
  if (e.key === 'g') { window.__gPrefix = true;
    setTimeout(() => { window.__gPrefix = false; }, 1000); return; }
  if (window.__gPrefix) {
    const map = { d:'home', l:'live', f:'findings', s:'subdomains',
                  o:'orchestrator', r:'system', e:'settings', m:'memory' };
    if (map[e.key]) { e.preventDefault(); setTab(map[e.key]); window.__gPrefix = false; return; }
  }
});
```

Three subtleties that bit me:
- **Esc should close modals, but if you have a help overlay open too,
  `closeAllModals()` is the right primitive** (iterate
  `.wehax-modal.show` and remove the class) — don't hardcode the
  one modal id.
- **`?` shows up as `?` on US layouts but as `Shift+/` on many others.**
  Check both: `if (e.key === '?' || (e.shiftKey && e.key === '/'))`.
- **The `g` prefix timer is 1 second.** Slow typists may miss it.
  Adjust per audience; 1s is the sweet spot for keyboard-comfortable
  users.

Always pair the system with a visible **Help overlay** that lists
the shortcuts in a 2-column `<kbd>` grid (see
[`references/keyboard-shortcuts.md`](references/keyboard-shortcuts.md) for
the full markup, the kbd CSS, and the segmented-control CSS for the
help modal).

## Explicit theme picker (segmented control) in Settings

The 3-way header button is good for power users. For everyone else,
add a segmented-control picker in the Settings tab so the choice is
discoverable and re-selectable.

```html
<div id="themePicker" class="theme-picker" role="group" aria-label="Theme">
  <button type="button" class="theme-opt" data-theme="dark">
    <i class="lni lni-night"></i><span>Dark</span></button>
  <button type="button" class="theme-opt" data-theme="light">
    <i class="lni lni-sun"></i><span>Light</span></button>
  <button type="button" class="theme-opt" data-theme="system">
    <i class="lni lni-cog"></i><span>System</span></button>
</div>
```

```css
.theme-picker { display: inline-flex; gap: 4px; padding: 4px;
  background: var(--bg-0); border: 1px solid var(--line); border-radius: 10px; }
.theme-picker .theme-opt {
  display: flex; align-items: center; gap: 8px;
  padding: 8px 14px; min-width: 92px; justify-content: center;
  background: transparent; border: 0; border-radius: 7px;
  color: var(--text-2); font-size: 12.5px; font-weight: 600;
  cursor: pointer; transition: all 0.15s;
}
.theme-picker .theme-opt:hover { background: rgba(124,92,255,0.08); color: var(--text); }
.theme-picker .theme-opt.active {
  background: linear-gradient(135deg, var(--brand) 0%, #5d3eff 100%);
  color: white; box-shadow: 0 4px 12px rgba(124,92,255,0.4);
}
```

```js
// Single apply function shared by the header button AND the picker
let _currentMode = 'dark';
const updatePicker = () => {
  document.querySelectorAll('.theme-opt').forEach(b => {
    b.classList.toggle('active', b.dataset.theme === _currentMode);
  });
};
const applyTheme = (mode) => {
  _currentMode = mode;
  document.documentElement.classList.remove('light', 'system-theme');
  if (mode === 'light') document.documentElement.classList.add('light');
  else if (mode === 'system') { /* ... as in theme-and-responsive.md ... */ }
  setThemeIcon();
  updatePicker();   // <-- key: picker mirrors whatever was applied
};
window.__applyTheme = applyTheme;   // expose for boot to call after wireButtons()

// picker clicks
document.querySelectorAll('.theme-opt').forEach(btn => {
  btn.addEventListener('click', () => {
    const m = btn.dataset.theme; if (!m) return;
    applyTheme(m);
    try { localStorage.setItem('wehax.theme', m); } catch {}
  });
});

// boot must call applyTheme AFTER wireButtons() so the picker is in the DOM
async function boot() {
  wireButtons();
  try {
    const t = localStorage.getItem('wehax.theme') || 'dark';
    if (window.__applyTheme) window.__applyTheme(t);
  } catch {}
  // ...
}
```

The two ordering traps: (1) if `applyTheme` is defined inside
`wireButtons()` it's not visible to `boot()` until that runs, so
expose it on `window`; (2) the picker markup lives in the Settings
pane which is `display:none` until first opened, but the click
handler attaches at wireButtons time — that's fine, the elements
still exist in the DOM tree.

## Interactive canvas: hover + click-to-inspect on orbiting nodes

Static canvas visualizations are fine for dashboards. The moment
the user wants to "click a node and see what it is", you need
hover detection, tooltip, and click-to-inspect. The transform math
is the same as for plain drawing — see the "Canvas: hover detection
on a transformed 2D context" section above. What this section
adds is **attaching the full data to each node at build time** so
the click handler doesn't have to re-look-up by id.

```js
function buildAsmGraph() {
  ASM.nodes = [];
  // root
  ASM.nodes.push({ id:'root', x:400, y:190, ..., type:'root',
                   label: S.currentScan?.domain || '—', glow: true });

  // subs — attach the full name so the click handler can copy it
  subNames.forEach((name, i) => {
    ASM.nodes.push({ id:'sub'+i, x:400+Math.cos(ang)*120*scaleX, y:..., type:'sub',
                     label: shortName(name), fullName: name });
  });

  // findings — attach the full finding object so click opens detail modal
  const findings = verifiedOnly(S.findings).filter(...).slice(0, 50);
  findings.forEach((f, i) => {
    ASM.nodes.push({ id:'fin'+i, x:..., y:..., type:'finding', sev, finding: f });
  });
}

// In draw(), when rendering each node, the hovered one gets a brighter ring
ASM.nodes.forEach(n => {
  const isHover = ASM.mouse.hover === n;
  ctx.strokeStyle = n.color + (isHover ? 'ff' : '88');  // brighter on hover
  ctx.lineWidth = isHover ? 2.5 : 1.5;
  // label appears for all hovered nodes + always-visible ones
  if (n.ring === 0 || n.r === 5 || isHover) { /* draw label */ }
});

// Tooltip overlay (HTML element positioned via JS, not canvas-drawn)
const tip = $('asmTooltip');
if (tip) {
  if (ASM.mouse.hover) {
    const n = ASM.mouse.hover;
    // convert canvas-space coords to screen px (reverse the drawAsm transform)
    const screenX = (W/2 - 400*ASM.zoom) + n.x * ASM.zoom;
    const screenY = (H/2 - 190*ASM.zoom) + n.y * ASM.zoom;
    tip.style.left = (screenX + 14) + 'px';
    tip.style.top  = (screenY - 10) + 'px';
    const kindLbl = n.type === 'root' ? 'TARGET' : n.type === 'sub' ? 'SUBDOMAIN' : 'FINDING';
    tip.innerHTML = `<div style="color:${n.color};font-weight:800">${kindLbl}</div>
                     <div>${esc(n.label)}</div>
                     ${n.sev ? `<span style="color:${n.color}">${n.sev.toUpperCase()}</span>` : ''}`;
  } else { tip.style.display = 'none'; }
}

// Hover + click handlers
const findNode = (mx, my) => {
  const tx = mx - W()/2 + 400*ASM.zoom;
  const ty = my - H()/2 + 190*ASM.zoom;
  const localX = tx / ASM.zoom;
  const localY = ty / ASM.zoom;
  let closest = null, closestD = 18;     // 18px hit radius
  ASM.nodes.forEach(n => {
    const d = Math.hypot(n.x - localX, n.y - localY);
    if (d < closestD) { closestD = d; closest = n; }
  });
  return closest;
};
canvas.addEventListener('mousemove', e => {
  const rect = canvas.getBoundingClientRect();
  ASM.mouse.hover = findNode(e.clientX - rect.left, e.clientY - rect.top);
  canvas.style.cursor = ASM.mouse.hover ? 'pointer' : 'default';
});
canvas.addEventListener('mouseleave', () => { ASM.mouse.hover = null; });
canvas.addEventListener('click', e => {
  const rect = canvas.getBoundingClientRect();
  const n = findNode(e.clientX - rect.left, e.clientY - rect.top);
  if (!n) return;
  if (n.type === 'finding' && n.finding) openFindingModal(n.finding);
  else if (n.type === 'sub' && n.fullName) { navigator.clipboard?.writeText(n.fullName); toast('copied', n.fullName, 'info', 1500); }
  else if (n.type === 'root') toast('target', n.label, 'brand', 1500);
});
```

Three rules that make the interactivity feel right:
1. **Store the full data on the node at build time.** Don't re-look-up
   in the click handler — by then the index may have changed.
2. **Tooltip is an HTML element, not canvas-drawn.** Cheaper to update,
   gets the OS text selection / right-click for free, and animates
   with CSS for free.
3. **Hit radius (18px) is larger than the rendered radius (4-22px).**
   The visual nodes are small but the click targets are generous —
   sub-4px node clicks feel buggy.

## MV3 extension that mirrors the SPA (popup + options + background)

When the dashboard SPA exists, the browser extension should look
and behave like a mini version of it: same design tokens, same
`el()`/`$()` helpers, same defensive renders, same API client.
The trick is the **shared-script + importScripts + service-worker
trifecta** that lets one `shared.js` work in all three contexts.

### File layout

```
extension/
├── manifest.json
├── shared.js          # window.WH = { api, getOrFetchToken, loadSettings, saveSettings }
├── popup.html         # 380px-wide action popup
├── popup.js           # one IIFE
├── options.html       # full-page options (open_in_tab: true)
├── options.js         # one IIFE
└── background.js      # service worker — uses importScripts('shared.js')
```

### The shared.js pattern

`shared.js` is a regular IIFE that exposes its helpers on `window.WH`.
The popup and options pages load it via `<script src="shared.js">`.
The service worker loads it via `importScripts("shared.js")`. The
service worker then accesses the helpers as `self.WH` (or just `WH`).

```js
// shared.js (works in all three contexts)
(() => {
  'use strict';
  function makeApi(state) {
    async function req(path, opts = {}) {
      const o = Object.assign({ headers: {} }, opts);
      if (o.body && typeof o.body !== 'string') {
        o.body = JSON.stringify(o.body);
        o.headers['content-type'] = 'application/json';
      }
      const tok = await WH.getOrFetchToken(state.apiBase);
      if (tok) o.headers['X-WeHax-Bridge'] = tok;
      const r = await fetch(state.apiBase + path, o);
      const text = await r.text();
      let d = text; try { d = text ? JSON.parse(text) : {}; } catch {}
      if (!r.ok) throw new Error((d && (d.detail || d.error)) || ('HTTP ' + r.status));
      return d;
    }
    return { get: (p) => req(p), post: (p, b) => req(p, { method: 'POST', body: b }),
             put: (p, b) => req(p, { method: 'PUT', body: b }), del: (p) => req(p, { method: 'DELETE' }) };
  }
  async function getOrFetchToken(apiBase) {
    if (!apiBase) return null;
    const stored = await chrome.storage.local.get(['bridgeToken', 'bridgeApiBase']);
    if (stored.bridgeToken && stored.bridgeApiBase === apiBase) return stored.bridgeToken;
    const r = await fetch(apiBase + '/bridge/token');
    const d = await r.json();
    if (d.token) await chrome.storage.local.set({ bridgeToken: d.token, bridgeApiBase: apiBase });
    return d.token || null;
  }
  const WH = (typeof window !== 'undefined' ? window : self);
  WH.WH = { api: makeApi, getOrFetchToken,
            loadSettings: async () => chrome.storage.sync.get(null, /*...*/),
            saveSettings: async (s) => { /* ... */ } };
})();
```

The `typeof window !== 'undefined' ? window : self` picks the right
global object. Service workers don't have `window`, pages do.

### Manifest gotcha

Do NOT use `"type": "module"` in the background config if you want
`importScripts` to work — they're mutually exclusive. The minimal
manifest block is:

```json
"background": {
  "service_worker": "background.js"
}
```

Then `background.js` starts with:
```js
importScripts("shared.js");
// ... uses WH.api, WH.getOrFetchToken, etc.
```

If you switch to ES module style (`import { api } from './shared.js'`),
the popup and options pages can't use the same shared.js without
adding `type="module"` to their `<script>` tags, which then breaks
the popup (chrome-extension:// URLs sometimes reject module scripts
for action popups).

### Extension-specific pitfalls

- **MV3 has no persistent background page** — the service worker
  sleeps. Use `chrome.alarms` for any periodic work (badge polling,
  scan tracking, notifications) and store state in `chrome.storage.local`
  so it survives the wake/sleep cycle.
- **Bridge token is required** — MV3 service workers can't use
  cookies or CSRF for cross-origin. WeHax solves this with a
  `GET /bridge/token` endpoint that returns a long-lived shared
  token. Cache it per `apiBase` (not globally) so switching APIs
  doesn't carry over a stale token.
- **Popup is destroyed on blur** — any `setInterval` or open
  WebSocket dies with it. Don't start background work from the
  popup; do it in the service worker.
- **`host_permissions: ["http://127.0.0.1:8777/*"]`** is required
  for `fetch()` to work to localhost. Firefox grants localhost by
  default; Chromium does not.
- **`chrome.tabs.captureVisibleTab` is rate-limited** — don't call
  it in a tight loop. One capture per second is fine.
- **Context menu IDs persist** across reloads. If you change the
  menu structure, call `chrome.contextMenus.removeAll()` first or
  you get a "duplicate ID" error.

### Manifest checklist for a localhost-only API extension

```json
{
  "manifest_version": 3,
  "name": "WeHax Recon",
  "version": "1.2.0",
  "permissions": ["tabs", "activeTab", "contextMenus", "notifications", "storage", "alarms"],
  "host_permissions": ["http://127.0.0.1:8777/*"],
  "background": { "service_worker": "background.js" },
  "action": {
    "default_popup": "popup.html",
    "default_icon": { "16": "icons/icon16.png", "32": "icons/icon32.png", "128": "icons/icon128.png" }
  },
  "options_ui": { "page": "options.html", "open_in_tab": true },
  "commands": { "scan-current-tab": { "suggested_key": { "mac": "Command+Shift+S" } } }
}
```
