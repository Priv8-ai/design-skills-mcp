#!/usr/bin/env swift
// /tmp/ocr.swift
//
// OCR a screenshot using macOS Vision framework. No API credits,
// no Python deps. Returns text + bounding-box coordinates.
//
// Usage:
//   cp "/path/to/Screenshot 1447-12-26 at 5.29.03\u202fPM.png" /tmp/shot.png
//   swift /tmp/ocr.swift /tmp/shot.png
//
// Output format: one line per detected text region, with bounding box:
//   [x%,y%,w%xh%] the detected text
//
// x,y are top-left in % of image (0-100). w,h are width/height in %.
//
// To crop to a region first (skip browser chrome, focus on the
// page content area), use ocr3.swift:
//   swift ocr3.swift /tmp/shot.png 0,7,100,88
//       (x=0%, y=7%, w=100%, h=88%)
//
// Install: this file lives at /tmp/ocr.swift, write-once-and-reuse.

import Foundation
import Vision
import AppKit

guard CommandLine.arguments.count > 1 else {
    print("usage: swift ocr.swift <image>")
    exit(1)
}

let path = CommandLine.arguments[1]
let url = URL(fileURLWithPath: path)
guard let image = NSImage(contentsOf: url),
      let cgImage = image.cgImage(forProposedRect: nil, context: nil, hints: nil) else {
    print("could not load image at \(path)")
    exit(1)
}

let request = VNRecognizeTextRequest { (request, error) in
    if let error = error { print("vision error: \(error)"); exit(1) }
    guard let observations = request.results as? [VNRecognizedTextObservation] else { exit(0) }
    // Sort top to bottom (Vision uses bottom-left origin so maxY is the topmost line)
    let sorted = observations.sorted { $0.boundingBox.maxY > $1.boundingBox.maxY }
    for o in sorted {
        if let t = o.topCandidates(1).first {
            let bb = o.boundingBox
            // Convert from bottom-left to top-left origin (%)
            let x = Int(bb.minX * 100)
            let y = Int((1 - bb.maxY) * 100)
            let w = Int(bb.width * 100)
            let h = Int(bb.height * 100)
            print("[\(x),\(y),\(w)x\(h)] \(t.string)")
        }
    }
}
request.recognitionLevel = .accurate
request.usesLanguageCorrection = true
request.minimumTextHeight = 0.001  // catch small text (tab titles, mono IDs, etc.)

let handler = VNImageRequestHandler(cgImage: cgImage, options: [:])
do {
    try handler.perform([request])
} catch {
    print("perform failed: \(error)")
    exit(1)
}
