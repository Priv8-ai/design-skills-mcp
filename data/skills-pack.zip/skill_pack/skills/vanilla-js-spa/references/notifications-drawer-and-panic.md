# Notifications drawer + bell counter + global panic button

The class of work: persist the toast stream to a re-openable history,
increment a header counter as feedback fires, and add a single-click
"kill everything" emergency action. For agentic dashboards with
lots of background activity, a long-running user walks away, comes back
wondering "what happened while I was out?" — this is the answer.

## 1. Persistent toast history (last 50)

Toasts auto-dismiss after 4.5s; that's fine for the moment but useless
for "what did that error say again?" The drawer solves it by writing
every toast to a small ring buffer in localStorage.

```js
const TOAST_HIST_KEY = 'wehax.toastHistory';
let _toastHistory = [];
try { _toastHistory = JSON.parse(localStorage.getItem(TOAST_HIST_KEY) || '[]'); } catch {}

function _recordToast(t) {
  _toastHistory.unshift(t);                  // newest first
  if (_toastHistory.length > 50) _toastHistory.length = 50;   // cap at 50
  try { localStorage.setItem(TOAST_HIST_KEY, JSON.stringify(_toastHistory)); } catch {}
}

function clearToastHistory() {
  _toastHistory = [];
  try { localStorage.removeItem(TOAST_HIST_KEY); } catch {}
  renderNotificationsDrawer();
}
window.clearToastHistory = clearToastHistory;
```

Call `_recordToast` from inside `toast()` right after appending the
node — but BEFORE the auto-dismiss timer, so the record exists even
if the node gets dismissed in 4.5s:

```js
function toast(title, body, level='', ms=4500) {
  // ... existing code, appendChild(el) ...
  _recordToast({ title, body, level, ts: Date.now() });
  // ... auto-dismiss timer ...
}
```

The shape stored is intentionally minimal (`{title, body, level, ts}`)
to keep localStorage small — 50 entries × ~150 bytes = ~7KB.

## 2. The drawer markup (slide-in from right)

A 420px-wide fixed panel that slides in from the right. The backdrop
dims the rest of the page; clicking the backdrop (or Esc) closes it.

```html
<!-- inside the body, after the toast container -->
<div id="notifDrawer" class="notif-drawer">
  <div class="notif-head">
    <h5><i class="lni lni-alarm"></i> Notifications</h5>
    <div class="notif-head-actions">
      <button class="notif-clear" onclick="clearToastHistory()" title="Clear all">
        <i class="lni lni-trash"></i> Clear</button>
      <button class="notif-close" onclick="closeNotifDrawer()" title="Close">
        <i class="lni lni-close"></i></button>
    </div>
  </div>
  <div id="notifList" class="notif-list"></div>
</div>
<div id="notifBackdrop" class="notif-backdrop" onclick="closeNotifDrawer()"></div>
```

```css
.notif-backdrop { position: fixed; inset: 0; background: rgba(0,0,0,0.6);
  z-index: 99990; opacity: 0; pointer-events: none; transition: opacity 0.25s;
  backdrop-filter: blur(2px); }
.notif-backdrop.open { opacity: 1; pointer-events: auto; }
.notif-drawer { position: fixed; top: 0; right: 0; bottom: 0;
  width: min(420px, 100vw); background: var(--bg-1);
  border-left: 1px solid var(--line); z-index: 99991;
  display: flex; flex-direction: column;
  transform: translateX(100%);
  transition: transform 0.28s cubic-bezier(0.4, 0, 0.2, 1);
  box-shadow: -20px 0 60px rgba(0,0,0,0.5); }
.notif-drawer.open { transform: translateX(0); }
.notif-head { display: flex; align-items: center; justify-content: space-between;
  padding: 18px 20px; border-bottom: 1px solid var(--line); background: var(--bg-2); }
.notif-head h5 { margin: 0; font-size: 14px; font-weight: 700; color: var(--text); }
.notif-head h5 i { color: var(--brand-2); margin-right: 6px; }
.notif-head-actions { display: flex; gap: 6px; }
.notif-head-actions button { background: transparent; border: 1px solid var(--line);
  color: var(--text-2); padding: 4px 10px; border-radius: 6px; font-size: 11px;
  cursor: pointer; display: flex; align-items: center; gap: 4px; transition: all 0.15s; }
.notif-head-actions button:hover { color: var(--text); border-color: var(--brand); }
.notif-head-actions .notif-clear:hover { color: var(--red); border-color: var(--red); }
.notif-list { flex: 1; overflow-y: auto; padding: 8px; }
.notif-item { display: flex; gap: 12px; padding: 10px 12px; border-radius: 8px;
  margin-bottom: 4px; background: var(--bg-2);
  border-left: 3px solid var(--cyan); transition: background 0.15s; }
.notif-item:hover { background: var(--bg-0); }
.notif-item.ok   { border-left-color: var(--green); }
.notif-item.warn { border-left-color: var(--amber); }
.notif-item.crit, .notif-item.err { border-left-color: var(--red); }
.notif-item > i { font-size: 16px; color: var(--cyan); flex-shrink: 0; margin-top: 2px; }
.notif-item.ok   > i { color: var(--green); }
.notif-item.warn > i { color: var(--amber); }
.notif-item.crit > i, .notif-item.err > i { color: var(--red); }
.notif-content { flex: 1; min-width: 0; }
.notif-title { font-size: 12.5px; font-weight: 600; color: var(--text); }
.notif-body  { font-size: 11.5px; color: var(--text-2); margin-top: 2px; word-wrap: break-word; }
.notif-time  { font-size: 10px; color: var(--text-3); margin-top: 4px; }
```

## 3. Render and time-ago

```js
function _toastAgo(ts) {
  if (!ts) return '';
  const diff = Date.now() - ts;
  if (diff < 60000)     return Math.floor(diff/1000)   + 's ago';
  if (diff < 3600000)   return Math.floor(diff/60000)  + 'm ago';
  if (diff < 86400000)  return Math.floor(diff/3600000)+ 'h ago';
  return Math.floor(diff/86400000) + 'd ago';
}

function renderNotificationsDrawer() {
  const list = $('notifList');
  if (!list) return;
  if (!_toastHistory.length) {
    list.innerHTML = '<div class="palette-empty"><i class="lni lni-inbox"></i>' +
      ' no notifications yet<br>' +
      '<small style="opacity:0.6;margin-top:6px;display:block">' +
      'toasts will appear here as you work</small></div>';
    return;
  }
  list.innerHTML = _toastHistory.map((t, i) => {
    const ago = _toastAgo(t.ts);
    return `<div class="notif-item ${esc(t.level||'')}" data-i="${i}">
      <i class="lni ${_toastIcon(t.level)}"></i>
      <div class="notif-content">
        <div class="notif-title">${esc(t.title)}</div>
        ${t.body ? `<div class="notif-body">${esc(t.body)}</div>` : ''}
        <div class="notif-time">${ago}</div>
      </div>
    </div>`;
  }).join('');
}
window.renderNotificationsDrawer = renderNotificationsDrawer;

function openNotifDrawer() {
  $('bellDot')?.classList.remove('on');        // mark "seen"
  renderNotificationsDrawer();
  $('notifDrawer')?.classList.add('open');
  $('notifBackdrop')?.classList.add('open');
}
function closeNotifDrawer() {
  $('notifDrawer')?.classList.remove('open');
  $('notifBackdrop')?.classList.remove('open');
}
window.openNotifDrawer = openNotifDrawer;
window.closeNotifDrawer = closeNotifDrawer;
```

`_toastIcon` is the same helper the toast system uses; if it lives in
module scope already, just reuse it. The drawer uses the same icon
color as the original toast so users can match drawer entries to
recent memories of the toast.

**Refresh the timestamps** when the drawer opens (so "0s ago" updates
to "30s ago" if it's been open 30s) — call `renderNotificationsDrawer()`
inside `openNotifDrawer()`.

## 4. Bell counter in the header

The bell icon in the header shows the count of toasts since the user
last opened the drawer. Red glow when there's an error/critical.

```html
<button class="icon-btn" id="bellBtn" title="Notifications"
        onclick="openNotifDrawer()">
  <i class="lni lni-alarm"></i>
  <span class="badge" id="bellDot">0</span>
</button>
```

```js
// Bump the bell counter on every toast.
// If you defined this inside wireButtons(), you MUST also expose it on window
// so module-scope toast() can reach it. The toast function in vanilla-js-spa
// is at module scope, so it can't see function declarations from inside
// wireButtons() — that's the temporal trap.
function _bumpBell(level) {
  const dot = $('bellDot');
  if (!dot) return;
  const n = parseInt(dot.textContent || '0') + 1;
  dot.textContent = n > 99 ? '99+' : n;
  if (level === 'crit' || level === 'err') dot.classList.add('on');
}
window._bumpBell = _bumpBell;     // expose for module-scope callers

// And inside toast():
function toast(title, body, level='', ms=4500) {
  // ... existing code ...
  try { (typeof _bumpBell === 'function' ? _bumpBell : window._bumpBell)(level); } catch {}
  // ... rest ...
}
```

**The "module-scope vs wireButtons" trap** — this is the single most
common reason "the bell counter doesn't update" bug. `toast()` is
called from many places (palette runs, API errors, scan events); it
lives at module scope. If `_bumpBell` is defined inside
`wireButtons()` and the user-facing bell counter is wired there too,
`toast()` can't see `_bumpBell` because it's a closure variable,
not a module-scope one. Two fixes, both used together:

1. **Expose the helper on `window`** so any caller can reach it:
   `window._bumpBell = _bumpBell;`
2. **The safe-call pattern** in the call site so it works whether
   the helper is in scope or not:
   `(typeof _bumpBell === 'function' ? _bumpBell : window._bumpBell)(level)`

Same fix applies to any module-scope function that needs to call a
helper defined later in `wireButtons()` (theme helpers, palette
helpers, etc.). When in doubt, put the helper at module scope OR
expose it on `window` immediately after defining it.

## 5. Global PANIC button

One-click "nuke everything" for emergencies. Red-tinted icon button,
confirm-gated, multi-step wipe (stop scans → clear backend → clear
localStorage → reload).

```html
<button class="icon-btn" id="panicBtn" title="PANIC: stop all + wipe"
        onclick="globalPanic()"
        style="background:rgba(255,93,108,0.1);border-color:rgba(255,93,108,0.3)">
  <i class="lni lni-warning" style="color:var(--red)"></i>
</button>
```

```css
#panicBtn { transition: all 0.2s; }
#panicBtn:hover { background: var(--red) !important; border-color: var(--red) !important; }
#panicBtn:hover i { color: white !important; }
```

```js
async function globalPanic() {
  if (!confirm('⚠ PANIC MODE\n\nThis will:\n  • Stop ALL running scans\n  • Clear ALL data (scans, findings, settings)\n  • Wipe local browser storage\n\nAre you absolutely sure?')) return;
  const btn = $('panicBtn');
  if (btn) { btn.disabled = true; btn.innerHTML = '<i class="lni lni-spinner"></i>'; }
  toast('⚠ PANIC initiated', 'stopping scans + wiping data', 'crit', 0);
  // 1. stop all running scans sequentially (safer than Promise.all if rate-limited)
  const running = S.scans.filter(s => s.status === 'running');
  for (const s of running) {
    try { await api.post(`/scans/${s.scan_id}/stop`); } catch {}
  }
  // 2. wipe backend (best-effort — may not exist)
  try { await fetch(S.apiBase + '/scans',    { method: 'DELETE' }); } catch {}
  try { await fetch(S.apiBase + '/settings', { method: 'DELETE' }); } catch {}
  // 3. wipe browser
  try { localStorage.clear(); } catch {}
  // 4. confirm + reload
  toast('✓ panic complete — reloading', '', 'ok', 1500);
  setTimeout(() => location.reload(), 1200);
}
window.globalPanic = globalPanic;
```

Five design points:

1. **Multi-line `confirm()`** so the user sees the blast radius before
   clicking. A single-line "Are you sure?" is too easy to click through.
2. **Sequential `for...of await`** for stop calls — Promise.all is
   faster but if the API is rate-limited it'll 429 you. Sequential
   is safer for an irreversible action.
3. **`toast(..., 'crit', 0)`** — 0ms auto-dismiss = persistent toast
   that the user has to manually dismiss. Matches the urgency.
4. **Button disabled + spinner icon** during the wipe so the user
   can't double-click.
5. **`localStorage.clear()` last** — actually, the `confirm` is
   non-modal relative to the page reload, so the user could interact
   with the page mid-wipe. localStorage.clear happens AFTER API calls
   so any rollback still has settings to look at. Then reload.

## 6. Esc closes the drawer (add to global keydown)

```js
if (e.key === 'Escape') { closeAllModals(); closeNotifDrawer(); return; }
```

`closeAllModals()` already handles `.wehax-modal` instances; the
drawer uses a different class (`.notif-drawer`) so it needs its own
close call. Both should run on Esc.

## Verification ladder

After wiring drawer + bell + panic:

1. Fire 3 toasts → bell counter shows "3", with the .on class active
   if any were `err`/`crit`.
2. Click bell → drawer slides in, 3 items shown (newest first), bell
   counter resets to 0 visually (but `_bumpBell` keeps incrementing).
3. Wait 30s, open drawer again → "30s ago" on the first item.
4. Reload page → drawer still has the 3 items (persisted).
5. Click "Clear" → drawer shows empty state, localStorage key gone.
6. Click the panic button → confirm dialog appears, decline → nothing
   happens.
7. Confirm → "PANIC initiated" toast stays, button shows spinner,
   all running scans are stopped, page reloads.
8. After reload, localStorage is empty (`localStorage.length === 0`).
9. Esc closes the drawer (verify with a synthetic keydown event).

If step 1 shows "0" after firing 3 toasts, the `_bumpBell` scoping
trap bit you. Check `window._bumpBell` is a function in the console.
