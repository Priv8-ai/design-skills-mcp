# Dashboard Layout Pitfalls — Tables, Grids, Fallback UX

Three lessons from the 2026-06-24 WeHuntX dashboard rebuild. Each
ones is a class-level pitfall any vanilla-JS dashboard will hit.

---

## 1. Tables — `table-layout: fixed` + explicit col widths

When showing rows of mixed-width cells (severity, type name, target
hostname, evidence description, tool name) in a fixed-width dashboard
pane:

- **`table-layout: auto` (default) sizes columns by content** — long
  evidence strings in one column eat all the space and squeeze
  others to ~38px wide. Cells with content like
  `Redirects to https://…` push other cells to nothing.
- **Set `table-layout: fixed` and give EVERY `<col>` an explicit
  width** in the colgroup:

  ```html
  <colgroup>
    <col style="width: 80px" />   <!-- sev -->
    <col style="width: 140px" />  <!-- type -->
    <col style="width: 200px" />  <!-- target -->
    <col />                       <!-- evidence: gets the rest -->
    <col style="width: 120px" />  <!-- tool -->
  </colgroup>
  ```

  Use bare `<col />` (no width) for exactly ONE column that should
  absorb remaining space. Two `<col />` in a row both collapse to
  min-content (~38px).
- **Add `min-width: 0` on `<td>`** so `text-overflow: ellipsis` can
  actually trigger inside fixed-width cells.
- **Probe cell widths after layout** with `browser_console`:

  ```js
  Array.from(document.querySelectorAll('#findingsTable tr')[1]
    .querySelectorAll('td'))
    .map(td => ({t: td.textContent.slice(0,30), w: td.offsetWidth}))
  ```

### Symptom checklist

- Cells show truncated content (`ssrf`, `open_re` instead of
  `ssrf`, `open_redirect`)
- A column that should be 200px wide shows 38px
- Adding `width: 200px` on `<th>` has no effect → table-layout is auto
- Two adjacent `<col />` in colgroup → both collapsed

---

## 2. CSS Grid — child vs sibling

`display: grid` with `grid-template-columns: 1fr 1fr` lays out
**direct children**. If you put a `<div class="band">` (live strip)
inside `.canvas` (the grid), the band occupies one grid track and the
two panes collide into the other.

**Rule:** every direct child of a grid container is a grid item. If
your "band" should span the full width above two side-by-side panels,
the band must be a **sibling** of the grid container, not a child.

### Pattern

```html
<section class="detail">
  <header>…</header>
  <div class="counters">…</div>
  <div class="live-strip">…</div>   <!-- sibling, NOT inside .canvas -->
  <div class="canvas">              <!-- grid: 1.5fr 1fr -->
    <div class="pane">…</div>
    <div class="pane">…</div>
  </div>
</section>
```

**Companion rule:** cap band heights so they don't dominate. Set
`.live-strip { max-height: 140px; flex-shrink: 0; }` so the grid
below gets `flex: 1` of remaining height.

### Verify grid track widths after layout

When panes look "wrong sizes" in a screenshot but the CSS says
`1.5fr 1fr`, probe before changing CSS:

```js
Array.from(document.querySelectorAll('.canvas > .pane')).map(p => ({
  role: p.className, w: p.offsetWidth, h: p.offsetHeight
}))
```

### Symptom checklist

- Both panes have wildly different heights, or one is `0×N` → a
  child crept into the grid container.
- The **first pane is the narrower one** despite `1.5fr 1fr` → the
  intrinsic min-content is reversing your fr ratio. Fix with
  `grid-template-columns: minmax(0, 1.5fr) minmax(0, 1fr)`, or use
  explicit `width: 60%` / `width: 40%` in a flex container.

---

## 3. Honest fallback messaging

When a chat/agent endpoint can return data either from a live LLM
OR from a cached/deterministic path, **always show which one fired**.
Pattern:

```
llm LLM empty → status fallback (2ms) · 2ms
```

vs.

```
llm floki-nmare returned 412 chars · 3.4s
```

The user trusts the dashboard more when the chips show the actual
code path. Same principle: if the LLM returns 0 chars, **say so**
("brain offline — answering from cached state") instead of silently
serving the cached version as if it were a fresh answer.

### Two-line chip pattern

- **Line 1:** intent parsed (`"show critical findings"` →
  `intent: per-scan chat`).
- **Line 2:** code path + latency (`llm floki-nmare · 3.4s` vs
  `cache hit · 2ms`).

### Why this matters

When the user sees "brain offline — answering from cached state",
they know the dashboard is being honest and the cached answer is
deliberate. When the dashboard silently swaps in a fallback, the
user loses trust — the response looked real but wasn't. Two-line
chips fix this with zero engineering cost.

---

## Cross-references

- SKILL.md verification ladder (line ~208: "See the verification
  ladder below.")
- WeHuntX incident: dashboard v2 wire() boot failure (incident #4 in
  `wehuntx/references/incidents.md`) — same dashboard, different
  failure mode (CSS class drift vs. CSS grid child count).
