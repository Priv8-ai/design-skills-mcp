# Keyboard shortcuts + help overlay

The class of work: add a discoverable keyboard shortcut system to a
vanilla-JS dashboard with a modal-driven help overlay that lists
every binding. Targets: agentic / scan / admin dashboards, not
marketing sites.

## The three shortcut classes

Most useful keymaps blend three styles:

1. **Plain keys** for the most-used actions, no modifier needed.
   `?` for help. `Esc` to close. `/` to focus search.
2. **⌘/Ctrl chords** for power actions. `⌘K` to focus search
   when `/` is too discoverable. `⌘N` for new. `⌘/` for toggle.
3. **Vim-style `g` prefix** for tab navigation. `g` then `d`
   (Dashboard), `f` (Findings), `s` (Subdomains), etc. within
   1 second of each other. Cheap to add, fast to use.

A single document-level `keydown` listener handles all three.
Skip the listener when the user is typing in an
`input`/`textarea`/`contenteditable` so existing keystrokes
(space, escape, enter, arrow keys) still work normally.

## Full implementation

```js
document.addEventListener('keydown', (e) => {
  const tag = (e.target?.tagName || '').toLowerCase();
  if (tag === 'input' || tag === 'textarea' || e.target?.isContentEditable) return;
  const cmd = e.metaKey || e.ctrlKey;

  // ── globals ──
  if (e.key === '?' || (e.shiftKey && e.key === '/')) {
    e.preventDefault(); openHelp(); return;
  }
  if (e.key === 'Escape') { closeAllModals(); return; }
  if (cmd && e.key === 'k') { e.preventDefault(); $('searchBox')?.focus(); return; }
  if (cmd && e.key === 'n') { e.preventDefault(); openModal('modal-newscan'); return; }
  if (cmd && e.key === '/') {
    e.preventDefault();
    document.getElementById('themeBtn')?.click();
    return;
  }

  // ── vim-style prefix: g then letter within 1s ──
  if (e.key === 'g') {
    window.__gPrefix = true;
    setTimeout(() => { window.__gPrefix = false; }, 1000);
    return;
  }
  if (window.__gPrefix) {
    const map = {
      d: 'home', l: 'live', f: 'findings', s: 'subdomains',
      o: 'orchestrator', r: 'system', e: 'settings', m: 'memory',
    };
    if (map[e.key]) {
      e.preventDefault();
      setTab(map[e.key]);
      window.__gPrefix = false;
      return;
    }
  }
});

function closeAllModals() {
  document.querySelectorAll('.wehax-modal.show').forEach(m => m.classList.remove('show'));
}

function openHelp() { openModal('modal-help'); }
window.openHelp = openHelp;        // expose for onclick attr fallback
```

## Help overlay modal markup

A 2-column grid of `<kbd>` elements. Mobile collapses to 1 column
via `@media (max-width: 576px)`.

```html
<div class="wehax-modal" id="modal-help"><div class="box" style="max-width:780px">
  <h5><i class="lni lni-keyboard"></i> Keyboard Shortcuts</h5>
  <p style="color:var(--text-2);font-size:12.5px;margin-bottom:18px">
    Master these to fly through WeHax without ever touching the mouse.
  </p>
  <div class="help-grid">
    <div class="help-row">
      <span class="help-label">Toggle theme</span>
      <span class="help-keys"><kbd>⌘</kbd><kbd>/</kbd></span>
    </div>
    <div class="help-row">
      <span class="help-label">Focus search</span>
      <span class="help-keys"><kbd>⌘</kbd><kbd>K</kbd></span>
    </div>
    <div class="help-row">
      <span class="help-label">New scan</span>
      <span class="help-keys"><kbd>⌘</kbd><kbd>N</kbd></span>
    </div>
    <div class="help-row">
      <span class="help-label">Close modal / panel</span>
      <span class="help-keys"><kbd>Esc</kbd></span>
    </div>
    <div class="help-row">
      <span class="help-label">Show this help</span>
      <span class="help-keys"><kbd>?</kbd></span>
    </div>

    <div class="help-divider">Navigation (press <kbd>G</kbd> then key)</div>
    <div class="help-row">
      <span class="help-label">Dashboard</span>
      <span class="help-keys"><kbd>G</kbd> <kbd>D</kbd></span>
    </div>
    <div class="help-row">
      <span class="help-label">Live Feed</span>
      <span class="help-keys"><kbd>G</kbd> <kbd>L</kbd></span>
    </div>
    <div class="help-row">
      <span class="help-label">Verified Findings</span>
      <span class="help-keys"><kbd>G</kbd> <kbd>F</kbd></span>
    </div>
    <div class="help-row">
      <span class="help-label">Subdomains</span>
      <span class="help-keys"><kbd>G</kbd> <kbd>S</kbd></span>
    </div>
    <div class="help-row">
      <span class="help-label">Orchestrator</span>
      <span class="help-keys"><kbd>G</kbd> <kbd>O</kbd></span>
    </div>
    <div class="help-row">
      <span class="help-label">Resources</span>
      <span class="help-keys"><kbd>G</kbd> <kbd>R</kbd></span>
    </div>
    <div class="help-row">
      <span class="help-label">Settings</span>
      <span class="help-keys"><kbd>G</kbd> <kbd>E</kbd></span>
    </div>
    <div class="help-row">
      <span class="help-label">Memory</span>
      <span class="help-keys"><kbd>G</kbd> <kbd>M</kbd></span>
    </div>

    <div class="help-divider">Constellation zoom</div>
    <div class="help-row">
      <span class="help-label">Zoom in / out / reset</span>
      <span class="help-keys"><kbd>+</kbd> <kbd>−</kbd> <kbd>0</kbd></span>
    </div>
  </div>
  <div class="d-flex justify-content-end mt-3">
    <button class="btn btn-outline btn-sm" onclick="closeModal('modal-help')">Close</button>
  </div>
</div></div>
```

## CSS — kbd + grid + responsive

```css
.help-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 10px 28px; }
.help-row {
  display: flex; align-items: center; justify-content: space-between;
  padding: 8px 12px;
  background: var(--bg-0); border: 1px solid var(--line); border-radius: 8px;
}
.help-row .help-label { color: var(--text); font-size: 12.5px; font-weight: 500; }
.help-row .help-keys { display: inline-flex; gap: 4px; align-items: center; }
.help-row kbd, .help-divider kbd {
  display: inline-block; min-width: 22px; padding: 3px 7px;
  font-size: 10.5px; font-weight: 700;
  color: var(--text); background: var(--bg-2);
  border: 1px solid var(--line); border-bottom-width: 2px;
  border-radius: 4px; font-family: 'SF Mono', monospace;
}
.help-divider {
  grid-column: 1 / -1;
  color: var(--text-3); font-size: 10px; text-transform: uppercase;
  letter-spacing: 1.2px; font-weight: 700;
  padding: 14px 0 4px; border-top: 1px solid var(--line); margin-top: 6px;
}
.help-divider:first-of-type { border-top: 0; padding-top: 4px; }
@media (max-width: 576px) {
  .help-grid { grid-template-columns: 1fr; gap: 6px; }
}
```

The kbd design — raised 2px bottom border, monospace font, tight
padding — reads as "physical key" on both light and dark themes
without any extra rules. No per-theme overrides needed.

## Discovery — a header button for the help overlay

Most users won't press `?` until they're shown. Add a `?` icon
button to the header next to the theme button:

```html
<button class="icon-btn" id="helpBtn" title="Keyboard shortcuts (?)">
  <i class="lni lni-question-circle"></i>
</button>
```

```js
on('helpBtn', openHelp);
```

The icon (`lni-question-circle` in LineIcons, `bi-question-circle` in
Bootstrap Icons) is the universal "help" affordance. Tooltip should
hint at the keyboard shortcut too.

## Pitfalls

1. **`?` and `/` differ across keyboard layouts.** US layouts produce
   `e.key === '?'` directly when Shift is held. Many others produce
   `e.key === '/'` with `e.shiftKey === true`. Match both:
   `if (e.key === '?' || (e.shiftKey && e.key === '/'))`.

2. **`Esc` should be the universal "close whatever is open."** If you
   have nested modals, `closeAllModals()` is the safe primitive —
   iterate `.wehax-modal.show` and remove the class. Don't try to
   track which modal opened which.

3. **Don't hijack `Tab`.** The browser uses it for focus traversal.
   Same for `Space` (scrolls), `ArrowUp/Down` (cursor / scroll),
   `Enter` (form submit). Restrict your listener to letters,
   numbers, `?`, and modifier chords.

4. **The `g` prefix timer state is on `window`** so the second keydown
   in the same pair can read it. Using a local `let` inside the
   listener doesn't work — each event creates a new binding.
   `window.__gPrefix` is the simple, debuggable option.

5. **Test with a real `keydown`, not `keypress` or `keyup`.** `keypress`
   is deprecated and doesn't fire for non-character keys. `keyup`
   fires after the user releases — feels laggy. `keydown` is the
   right choice for interactive shortcuts.

6. **Don't preventDefault on keys you're not handling.** If a future
   user adds a global `/` shortcut and you call `preventDefault()`
   in a catch-all, you'll break it. Only call `preventDefault()` on
   keys you actually consume.

7. **Help button discoverability vs. help modal discoverability.**
   The header `?` button teaches the keyboard shortcut. The keyboard
   shortcut (pressing `?`) shows the same overlay. Two paths to the
   same destination is correct.
