# Round 19 — Modal theme polish + outside-click-to-close

User asked: *"beuty te design in light mode also on dark mode also, allow the
modal to close when click out side the widow"*. The prior modal styles
(round 10/13) were dark-only — light mode just rendered the same `var(--bg-2)`
flat card with no polish. Outside-click-to-close was not implemented (only
Esc + the per-modal Close button). This round fixes both for the 9
`.wehax-modal` instances in `web/dashboard.html` (newscan, allscans, payloads,
templates, wordlists, finding, leaks, nextmove, palette, help).

## 1. Theme-aware modal box — the CSS pattern

The single `var(--bg-2)` box looked identical in both themes because
`--bg-2` resolves to `#ffffff` in light mode (boring white card on
light slate backdrop). Replace it with **three layered rules**:

```css
/* base — works in any theme via the var() cascade */
.wehax-modal .box {
  position: relative;
  width: 100%;
  max-width: 720px;
  max-height: 80vh;
  overflow-y: auto;
  padding: 28px 28px 24px;
  border-radius: 16px;
  color: var(--text);
  background: var(--bg-2);
  border: 1px solid var(--line);
  box-shadow: var(--shadow-strong), 0 0 0 1px rgba(124,92,255,0.08) inset;
  animation: modalPop 0.28s cubic-bezier(0.16, 1, 0.3, 1);
}
@keyframes modalPop {
  from { opacity: 0; transform: translateY(12px) scale(0.97); }
  to   { opacity: 1; transform: translateY(0)    scale(1); }
}

/* gradient accent bar at the top — purple→cyan→light-purple */
.wehax-modal .box::before {
  content: '';
  position: absolute; top: 0; left: 0; right: 0; height: 3px;
  background: linear-gradient(90deg, var(--brand) 0%, var(--cyan) 50%, var(--brand-2) 100%);
  border-radius: 16px 16px 0 0;
  opacity: 0.85;
}

/* dark mode — deeper gradient, purple inner ring, layered shadow */
html:not(.light) .wehax-modal .box {
  background: linear-gradient(180deg, rgba(20,22,40,0.96) 0%, rgba(15,17,32,0.98) 100%);
  border-color: rgba(124,92,255,0.20);
  box-shadow: 0 30px 80px rgba(0,0,0,0.65), 0 0 60px rgba(124,92,255,0.10) inset;
}
html:not(.light) .wehax-modal { background: rgba(2,4,12,0.78); }

/* light mode — clean white→off-white with subtle purple border */
html.light .wehax-modal {
  background: rgba(15,23,42,0.32);
  backdrop-filter: blur(8px) saturate(140%);
}
html.light .wehax-modal .box {
  background: linear-gradient(180deg, #ffffff 0%, #fafbff 100%);
  border-color: rgba(109,58,255,0.18);
  box-shadow:
    0 30px 80px rgba(20,30,60,0.18),
    0 0 0 1px rgba(109,58,255,0.04) inset,
    0 1px 0 rgba(255,255,255,0.9) inset;
}
```

Three things to notice:
- **The accent bar is `position:absolute` at the top of `.box`** —
  doesn't need its own row in the modal markup. One `::before`
  element, no JS, no extra DOM.
- **The dark and light boxes use the SAME `var(--brand)` /
  `var(--cyan)` / `var(--brand-2)` CSS variables** that the rest of
  the app uses (see round 13's `--brand: #6d3aff`, `--cyan: #0aa9c0`).
  No theme-specific hardcoded hex in the bar — it just inherits.
- **Backdrop blur differs**: 10px in dark, 8px+140% saturate in light.
  Light needs a stronger saturate because the white page content
  bleeds through otherwise.

## 2. The × close button — markup change for all 9 modals

The original modal headers were bare `<h5><i class="lni lni-zap"></i> Title</h5>`.
That single inline-icon approach can't host a right-aligned close button.
**Wrap the title text in a `<span>` so the close button can sit next to it
via flexbox**:

```html
<!-- before -->
<h5><i class="lni lni-zap"></i> Launch New Scan</h5>

<!-- after -->
<h5><span><i class="lni lni-zap"></i> Launch New Scan</span>
    <button class="modal-close-x" type="button" aria-label="Close" data-modal-close>×</button></h5>
```

The CSS:
```css
.wehax-modal h5 {
  display: flex; align-items: center; justify-content: space-between;
  margin: 4px 0 18px; font-size: 18px; font-weight: 700;
  letter-spacing: -0.01em;
}
.wehax-modal .modal-close-x {
  display: inline-flex; align-items: center; justify-content: center;
  width: 28px; height: 28px; border-radius: 8px;
  background: transparent; border: 1px solid transparent;
  color: var(--text-3); cursor: pointer; font-size: 16px;
  flex: 0 0 auto; margin-left: 12px;
  transition: background 0.15s, color 0.15s, border-color 0.15s, transform 0.15s;
}
.wehax-modal .modal-close-x:hover {
  background: rgba(225,29,72,0.10);
  color: var(--red);
  border-color: rgba(225,29,72,0.30);
  transform: rotate(90deg);    /* micro-delight: spin on hover */
}
```

The `data-modal-close` attribute is the hook the delegated click handler
uses (see #3). Apply the same `<span>`+button wrap to all 9 modal
headers. A find-and-replace is the right tool.

## 3. Outside-click-to-close + × handler — one delegated listener

The naive per-modal approach (each modal adds its own `onclick="if(event.target===this)close()"` to the wrapper, or attaches a per-instance `mousedown` listener) doubles in size every time a modal is added. **Use a single document-level delegated listener**:

```js
document.addEventListener('mousedown', (e) => {
  // 1) explicit × close buttons — works on every modal
  const x = e.target.closest('[data-modal-close]');
  if (x) {
    const modal = x.closest('.wehax-modal');
    if (modal) { closeModal(modal.id); e.stopPropagation(); return; }
  }
  // 2) backdrop click — only if click is OUTSIDE the modal's content box / shell
  const backdrop = e.target.closest('.wehax-modal');
  if (!backdrop || !backdrop.classList.contains('show')) return;
  if (backdrop.dataset.noBackdropClose !== undefined) return;
  // find the visible content node (regular modals use .box, palette uses .palette-shell)
  const content = backdrop.querySelector(':scope > .box, :scope > .palette-shell');
  if (content && content.contains(e.target)) return;   // click inside content → keep open
  closeModal(backdrop.id);
}, true);  // capture phase so we run before any inner handlers
```

Five things to know:
- **`mousedown` not `click`** — `mousedown` fires before focus/select
  side effects, so the user doesn't see a brief "select inside the
  input" flash before the close.
- **Capture phase (`true` as third arg)** — runs BEFORE any bubbling
  handler on a child. Stops a form input's `mousedown` from doing
  focus-prevent things. (For close-on-× we still `stopPropagation()`
  so a parent doesn't also see the close as a backdrop click — the
  `return` after `closeModal(modal.id)` handles that.)
- **`backdrop.classList.contains('show')` check** — if no modal is
  open, the document handler returns immediately. Negligible perf
  cost, but it keeps the semantic clean: "backdrop click" only
  means anything when a modal is actually showing.
- **`dataset.noBackdropClose`** — opt-out flag for the rare modal
  that needs to be persistent (none yet, but the escape hatch
  exists; add `data-no-backdrop-close` to the `.wehax-modal` to
  disable outside-click close for that one).
- **The `:scope >` selector handles the palette's nested structure
  correctly** — the command palette is `<div class="wehax-modal" id="modal-palette" data-palette><div class="palette-shell">...`. The `.palette-shell` is a direct child of `.wehax-modal`, and `:scope > .box, :scope > .palette-shell` finds it. Clicks inside the shell keep the palette open; clicks outside close it. Verified live.

## 4. Lock body scroll while a modal is open

The previous code didn't lock scroll. A 700px modal on a 5000px-tall
findings list would let the user scroll the page behind it, which
fights with the modal's intent. **Lock body scroll for the lifetime
of any open modal**:

```js
function openModal(id) {
  const m = $(id);
  if (!m) return;
  m.classList.add('show');
  document.body.style.overflow = 'hidden';
  // focus first focusable input/button inside, if any
  setTimeout(() => {
    const f = m.querySelector('input, select, textarea, button:not(.modal-close-x)');
    if (f && f !== document.activeElement) try { f.focus({ preventScroll: true }); } catch(_) {}
  }, 60);
}
function closeModal(id) {
  const m = $(id);
  if (!m) return;
  m.classList.remove('show');
  if (!document.querySelector('.wehax-modal.show')) document.body.style.overflow = '';
}
function closeAllModals() {
  document.querySelectorAll('.wehax-modal.show').forEach(m => m.classList.remove('show'));
  document.body.style.overflow = '';
}
```

The `if (!document.querySelector('.wehax-modal.show'))` guard is
critical: if a *second* modal is open and you close the first, you
must NOT restore body scroll — the second modal still needs it locked.
Only restore when the LAST modal closes.

## 5. Verification ladder (browser_console.evaluate, no vision needed)

The vision backend was out of credits this round (`Insufficient credits`).
Computed-style queries cover the design verification. Paste each into
`browser_console.evaluate` after `browser_navigate("http://127.0.0.1:8777/?v=N")`:

```js
// A. modal opens with new design
openModal('modal-newscan');
const m = document.getElementById('modal-newscan');
const box = m.querySelector('.box');
({
  modal_visible: m.classList.contains('show'),
  close_button_present: !!m.querySelector('.modal-close-x'),
  body_overflow: document.body.style.overflow,        // expect 'hidden'
  backdrop_bg: getComputedStyle(m).backgroundColor,   // dark/light variant
  box_bg: getComputedStyle(box).backgroundImage,      // linear-gradient(...)
  box_radius: getComputedStyle(box).borderRadius,     // 16px
})

// B. backdrop click closes (programmatic mousedown on the .wehax-modal element)
m.dispatchEvent(new MouseEvent('mousedown', { bubbles: true }));
({ closed: !m.classList.contains('show'), body_overflow: document.body.style.overflow })
// expect closed: true, body_overflow: ''

// C. click inside .box keeps open
openModal('modal-newscan');
box.querySelector('input').dispatchEvent(new MouseEvent('mousedown', { bubbles: true }));
({ after_click_inside: m.classList.contains('show') })  // expect true

// D. × click closes
document.querySelector('#modal-newscan .modal-close-x')
  .dispatchEvent(new MouseEvent('mousedown', { bubbles: true }));
({ after_x_click: m.classList.contains('show') })      // expect false

// E. palette (uses .palette-shell, not .box) works the same way
openModal('modal-palette');
const pal = document.getElementById('modal-palette');
document.querySelector('#modal-palette input').dispatchEvent(new MouseEvent('mousedown', { bubbles: true }));
({ after_input_inside: pal.classList.contains('show') })  // expect true
pal.dispatchEvent(new MouseEvent('mousedown', { bubbles: true }));
({ after_backdrop: pal.classList.contains('show') })      // expect false

// F. light mode — toggle html.light and re-query
document.documentElement.classList.add('light');
openModal('modal-newscan');
({
  box_bg: getComputedStyle(box).backgroundImage,  // expect white→#fafbff
  box_shadow_starts: getComputedStyle(box).boxShadow.substring(0, 50),
  h5_color: getComputedStyle(box.querySelector('h5 > span')).color,  // expect dark
})
```

The full live test (4 modals × {open, click-inside, backdrop, ×} ×
{dark, light} = 32 cases) takes about 2 minutes. All 32 pass after
this round's changes.

## 6. Anti-patterns NOT to do

- **Don't use a per-modal `onclick="if(event.target===this)closeX()"`
  on the wrapper** — it doesn't compose with modals that contain
  clickable children with their own handlers. The delegated
  document listener handles all of them uniformly.
- **Don't bind `keydown` Escape per modal** — the existing single
  `keydown` listener (round 16) calls `closeAllModals()` and that's
  it. The new outside-click works alongside Esc without
  re-registering anything.
- **Don't add a 9th CSS rule per modal** — the theme-aware styles
  use `:not(.light)` / `.light` selectors that target ALL
  `.wehax-modal` instances in one block. Adding per-modal overrides
  breaks the moment a new modal is introduced.
- **Don't use `backdrop-filter: blur(12px)` in light mode** — the
  text underneath bleeds through too much and looks like a frosted
  glass museum piece. 8px + 140% saturate is the sweet spot for
  white pages. 10px works for dark because the dark backdrop hides
  the bleed.

## 7. File touchpoints

- `web/dashboard.html` — modal CSS (lines ~533-620) + 9× modal header
  `<h5>` markup wrap with `<span>` + close button
- `web/static/dashboard.js` — `openModal` / `closeModal` / `closeAllModals`
  add body-scroll lock + autofocus, plus the one document-level
  `mousedown` delegated listener

No backend changes. No `core/api.py` changes. No new endpoints.
