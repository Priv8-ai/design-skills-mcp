# Verified-only findings display pattern

When the underlying data model has a 3-state lifecycle for findings
(`verified=1` real, `verified=0` unverified, `verified=-1` false
positive), the dashboard should NEVER show unverified/false-positive
findings. The user only sees the verified slice. This is a
**hard constraint** — the operator doesn't want to see noise that
"might be" a finding; they want to act on confirmed facts.

This file captures the pattern across all renders. The full
backend (active verifier daemon, WS plumbing, side-by-side
rejected/unverified counts) is its own layer; this is the
**front-end display contract**.

## The single helper

At the top of the IIFE, ONE function:

```js
// ONLY show verified findings (verified === 1) anywhere the user sees them
// Anything else (verified === 0 unverified, verified === -1 false positive) is hidden.
const verifiedOnly = (arr) => (arr || []).filter(f => f.verified === 1);
```

Pass the verified list down through every render instead of refiltering:

```js
function loadFindings() { /* fetch + populate S.findings (all severities) */ }
function loadHomeStats() {
  const vList = verifiedOnly(S.findings);
  $('homeVerified').textContent = vList.length;
  // pass vList through to sub-renders — never refilter
  renderHeatmap(vList);
  renderASM(vList);
  renderRecentFindings(vList);
}
```

## The "Total vs Verified" stat discipline

Always show both numbers when the user is being told about findings:

```html
<div class="stat-card">
  <div class="value" id="homeTotalFindings">0</div>
  <div class="label">TOTAL FINDINGS</div>
  <div class="sub" id="homeTotalFindingsSub">all severities</div>
</div>
<div class="stat-card brand">
  <div class="value" id="homeVerified">0</div>
  <div class="label">VERIFIED REAL</div>
  <div class="sub" id="homeVerifiedSub">0 rejected · 0 unverified</div>
</div>
<div class="stat-card red">
  <div class="value" id="homeCritical">0</div>
  <div class="label">CRITICAL / HIGH</div>
  <div class="sub" id="homeCriticalSub">verified only</div>
</div>
```

The cards read:
- **Total** = `S.findings.length` (all severities, all states)
- **Verified** = `verifiedOnly(S.findings).length`
- **Critical/High** = `verifiedOnly(S.findings).filter(f => ['critical','high'].includes(f.severity)).length`

The sub-text under "Verified" explicitly shows the rejected and
unverified counts, so the user knows those findings exist but were
filtered. This is important — otherwise the user thinks findings
"disappeared" when they were actually reclassified.

## The constellation pull-through

The constellation canvas (or graph, or list) should pull from the
verified list and the live `S.subs` table, NOT the raw findings list:

```js
function buildAsmGraph() {
  const vList = verifiedOnly(S.findings);
  // subs from the live subdomains list (NOT from findings)
  let subNames = (S.subs || []).map(s => s.subdomain).filter(Boolean);
  // dedup + cap
  subNames = [...new Set(subNames)].slice(0, 24);
  // root → subs → findings
  ASM.nodes.push({ id:'root', ..., type:'root' });
  subNames.forEach((n, i) => ASM.nodes.push({ id:'sub'+i, ..., type:'sub' }));
  vList.forEach((f, i) => ASM.nodes.push({ id:'fin'+i, ..., type:'finding', finding: f }));
}
```

The findings nodes store the full finding object so click-to-inspect
can pop the finding detail modal without a second lookup.

## The dedicated "Verified Findings" tab

A second tab (in addition to "All Findings") that is the
default-view tab. Sidebar badge shows the verified count, not the
total:

```html
<a data-tab="findings">
  <i class="lni lni-checkmark-circle"></i> Verified Findings
  <span class="badge" id="fVerifiedBadge">0</span>
</a>
```

Users who want to see "everything" can be given an unfiltered tab
later, but the verified tab is the default and the only one
promoted in the sidebar.

## The "Critical/High" sub-text

`Critical/High` is computed from the verified list. When the user
sees "Critical/High: 0" but the verifier log shows it just
confirmed 4 critical findings, that's a "the verifier confirmed
them but they haven't propagated to the dashboard yet" delay.
Don't change the helper to also count unverified — the discipline
is firm: the dashboard only shows verified data.

## When the user says "show me the rejected ones"

If they really need to see the rejected/unverified findings, add a
debug modal in settings or behind a query param, NOT a main-tab
switch. The main dashboard is the operator's action surface; the
rejected findings are an audit/debug surface.

## Worked example (WeHax v0.4+)

Dashboard on `bab.sa` deep scan:
- 20 raw findings (5 critical, 8 high, 5 medium, 2 info)
- 6 verified = 1 (OSINT DNS-resolves), 11 verified = -1 (false positives),
  3 verified = 0 (unverified by verifier)
- All 6 verified are `info` severity (OSINT tech fingerprints)

Dashboard shows:
- **TOTAL FINDINGS**: 20
- **VERIFIED REAL**: 6
- **CRITICAL / HIGH**: 0 (the 5 critical + 8 high were all rejected
  or unverified)
- **VERIFIED BREAKDOWN**: 6 info
- **SUB-TEXT under VERIFIED**: 11 rejected · 3 unverified

The recent findings list shows 6 rows. The constellation shows 6
finding nodes. The donut shows 6 segments (all info color). The
"4 verified nodes · 0 subs · 4 findings" header reflects the latest
state.

User's question: "But there are 5 critical findings in the scan, why
are they not showing?" Answer: "They were verified by the active
prober as false positives (the tool's regex matched but the response
wasn't actually a 403 — it was a generic 404 page). The verifier
log shows the 11 rejects. Open Settings → Verifier Log to see
details."

This is the right user experience. The dashboard shows what the
system actually believes to be real. The rejected findings are
preserved in the DB for audit, not for the operator's eyes.

## Pitfalls

- **Don't show unverified findings with a "PENDING" badge as a
  compromise.** The user's instruction is "don't show vuln unless
  verified" — that's binary, not a status flag. Show it or don't.
- **Don't compute critical/high from `S.findings` (raw).** Always
  filter first. The whole point of the verified-only contract is
  that the user trusts the dashboard's numbers to mean "this is
  real."
- **Don't lose the rejected/unverified counts.** If the sub-text
  drops them, the user thinks findings disappeared. Always show
  "X rejected · Y unverified" so they know those findings exist
  but are filtered.
- **Don't break the discipline for "demo" findings.** Test data
  that was manually injected as critical should still be filtered
  if `verified !== 1`. The contract doesn't care about provenance.
