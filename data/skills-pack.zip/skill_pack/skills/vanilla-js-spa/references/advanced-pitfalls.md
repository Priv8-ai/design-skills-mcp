# Advanced pitfalls for vanilla-JS SPA dashboards

Concrete debugging recipes and design patterns accumulated from real production
sessions. Companion to SKILL.md; load when a vanilla-JS dashboard is misbehaving
in ways the main skill doesn't directly cover, or when designing a serious
production UI (not a throwaway mockup).

---

## 1. Module-script caching trap (`browser_navigate` keeps serving stale code)

**Symptom.** You edit `dashboard.js`, restart the server, reload the page via
`browser_navigate`, and the new code is NOT executing. Console errors reference
line numbers that no longer exist in the file. `curl` of the JS URL shows the
fresh content; the browser keeps running the old content.

**Cause.** `<script type="module">` is cached aggressively. Even though the
parent page is reloaded, the module fetch may hit a 304 and reuse the cached
module graph. With Hermes `browser_navigate` on the same URL, browsers often
treat the navigation as same-document and skip the module re-fetch entirely.

**Fix.**
- Add a cache buster to the script tag: `<script type="module" src="/v2/dashboard.js?v=2">`
- Bump the `?v=N` value on every JS/CSS edit you want to verify
- Alternative: append a query to the page URL itself (`/v2?v=3`) — but this
  alone is often not enough for module scripts

**Detection.** Compare line numbers in stack traces against the actual file.
If they don't match, the browser is running a cached old copy.

---

## 2. Indent-due-to-misplaced-brace: functions defined but unreachable

**Symptom.** After appending a new section to a long JS file, the new functions
exist (search finds them) but are not callable from module scope. `window.__foo`
exposes them but `typeof foo` returns `undefined`. The file parses cleanly
(`node -c` exits 0).

**Cause.** The new section was appended inside another block whose closing `}`
was missing from the previous section. Indent looks consistent so the mis-nesting
is invisible. Node still parses it (function declarations inside blocks become
block-scoped but only at runtime; `node -c` doesn't catch this).

**Detection.**
```bash
# Find every top-level function declaration
grep -nE "^(async )?function (foo|bar|baz)" dashboard.js

# If any result starts with whitespace, it's nested (probably wrongly)
# Use a regex that excludes leading whitespace
grep -nE "^[^ ]+(async )?function" dashboard.js
```

**Fix.** Read the file in `sed -n 'N,N+5p'` around the section header. The
block that should have ended before the new section needs its `}` added.

**Prevention.** When appending a new module-top-level section to a long file:
1. Find the LAST `}` of the previous section (`grep -n "^}" dashboard.js | tail -1`)
2. Insert the new section AFTER that line
3. Never paste code that was indented relative to its original context — strip
   the indentation so the visual column matches what it should be at module top level

---

## 3. `loadScans`-without-render: state populated but UI doesn't update

**Symptom.** API returns data. `state.scans.length > 0` after `loadScans()`.
The rail/list/table stays empty or shows the "no data" placeholder. No console
error.

**Cause.** `loadScans()` populates `state.scans` but does NOT call `render()`.
Only `boot()` does, and `boot()` runs once on DOMContentLoaded. If loadScans
fails silently on first call (e.g. setConnState throws before state is
populated), boot's `loadScans()` also fails, but the partial state from a
later manual call gets used and never re-renders.

**Fix.**
```js
async function loadScans() {
  setConnState('connecting');
  try {
    const d = await apiGet('/scans');
    state.scans = Array.isArray(d?.scans) ? d.scans : [];
    render();   // <-- ALWAYS call render after mutating state
  } catch (e) {
    setConnState('error');
  }
}
```

**Detection.** From browser console:
```js
window.__app.state.scans.length   // 0?
await window.__app.loadScans()
window.__app.state.scans.length   // > 0 now?
document.getElementById('rail').children.length   // still 0? → render() not called
```

---

## 4. Single-scroll-chain layout recipe

The #1 layout bug in production dashboards: every section independently sizes
itself, so the body scrolls AND the chat scrolls AND the table scrolls AND the
sidebar scrolls. Result: nested scroll traps, hidden content, lost scroll
position on resize.

**Recipe** (apply in this exact order):
```css
/* 1. Lock the body. Only inner panels may scroll. */
body {
  overflow: hidden;
  height: 100dvh;          /* dynamic viewport = handles mobile chrome */
}

/* 2. Topbar is sticky but NOT in the scroll flow. */
header.topbar {
  position: sticky;
  top: 0;
  height: 44px;
  flex-shrink: 0;
}

/* 3. Main is the fixed-height container that holds the grid. */
main.surface {
  height: calc(100dvh - 44px);
  display: grid;
  overflow: hidden;        /* important: do NOT let main itself scroll */
}

/* 4. Grid columns. Each column is a flex column with min-height: 0. */
.layout {
  display: grid;
  grid-template-columns: 280px 1fr 280px;
  height: 100%;
  min-height: 0;           /* grid items need this for flex children to shrink */
}
.column {
  display: flex;
  flex-direction: column;
  min-height: 0;
  min-width: 0;
}

/* 5. Scrollable region inside each column. flex: 1 + overflow: auto. */
.column-body {
  flex: 1;
  min-height: 0;
  overflow-y: auto;
}

/* 6. Tables wrap in .table-wrap with overflow: auto + sticky header. */
.table-wrap {
  overflow: auto;
  max-height: 100%;        /* constrained by parent flex */
}
.table-wrap thead th {
  position: sticky;
  top: 0;
  background: var(--bg-1);  /* opaque so content doesn't bleed through */
  z-index: 1;
}
```

**The min-height: 0 mantra.** Every flex/grid child that contains a scrollable
region MUST have `min-height: 0` (or `min-width: 0` for horizontal). Without
it, the default `min-height: auto` lets the child grow to its content size and
the scroll never engages.

**Responsive collapses:**
```css
@media (max-width: 1100px) {
  .layout { grid-template-columns: 240px 1fr; }
  .system-aside { display: none; }
}
@media (max-width: 820px) {
  .layout { grid-template-columns: 1fr; }
  .rail { display: none; }
}
```

---

## 5. The Terminal Brutalism archetype

When you want a dashboard that feels like a serious engineering tool (think
NASA mission control, Bloomberg terminal, hacker ops console) — not a SaaS
landing page — apply these constraints together. Borrowing them individually
produces a Frankenstein; only the full set produces the archetype.

**Substrate.** Off-black, never `#000`. OKLCH for predictable contrast:
```css
--bg:      oklch(0.13 0.01 250);   /* deep slate, slightly cool */
--bg-1:    oklch(0.16 0.012 250);  /* surfaces */
--bg-2:    oklch(0.20 0.013 250);  /* raised cards */
--bg-hover: oklch(0.24 0.014 250);
```

**Type.** Monospace everywhere. JetBrains Mono / IBM Plex Mono / Geist Mono.
Display sizes capped at 30px — never larger.

**Lines.** 1px hairlines, low opacity. NO `border-radius` on cards (strict 90°).
Reserve `border-radius` for status dots only (use `--r-pill: 9999px`).

**Color.** One accent, used sparingly (≤10% of surface). Mint OKLCH
`0.78 0.16 145` works. Severity palette is OKLCH throughout (crit/high/med/low/info).

**ASCII framing.** Use brackets, arrows, dots, bars instead of icons:
- `[ WeHuntX ]` for branding
- `▸` `▶` `●` `○` `▍` for state indicators
- `+ NEW` `×` for buttons
- `MISSION CONTROL · V2` as eyebrow text (uppercase, tracked, monospaced)

**Motion.** Sub-300ms. Cubic-bezier `(0.23, 1, 0.32, 1)` for ease-out.
GPU-only (`transform`, `opacity`). Always respect `prefers-reduced-motion`.

**Status colors (OKLCH):**
- accent mint: `oklch(0.78 0.16 145)`
- danger:      `oklch(0.65 0.22 27)`
- warn:        `oklch(0.78 0.15 75)`
- info:        `oklch(0.70 0.13 230)`

**What NOT to do** (these break the archetype):
- No gradients
- No glassmorphism (backdrop-blur on cards)
- No soft shadows (use 1px hairlines instead)
- No rounded corners on rectangles (cards, buttons, inputs)
- No emoji (use monospace glyphs)
- No Lucide/Feather icons (use thin-line SVG primitives if needed, or ASCII)

---

## 6. Synthesizing multiple design skills

When you load 5+ design skills (brutalist + impeccable + minimalist + emil-kowalski
+ composition-patterns), the temptation is to apply every rule. Don't.

**The synthesis rule:** pick ONE primary archetype, borrow the highest-leverage
1-2 ideas from each secondary skill, drop everything else.

Example synthesis for a security ops dashboard:
| Skill | Kept | Dropped |
|---|---|---|
| brutalist | ASCII framing, 90° corners, monospace | over-the-top kinetic typography |
| impeccable | OKLCH, semantic z-index, type scale | their glassmorphism examples |
| minimalist | generous spacing, no icons, off-black | their whitespace-heavy marketing layouts |
| emil-kowalski | sub-300ms cubic-beziers, GPU-only, interruptible | bouncy spring physics |
| composition-patterns | lift state pattern | React-specific hooks |

The result is one coherent system, not 5 contradictory rulebooks.

---

## 7. Detection: after rewriting HTML, what does the JS still expect?

**Symptom.** A `setX()` or `renderY()` throws `Cannot read properties of null`
because `$('#oldId')` returns null. The page renders partially and then
silently dies (because the function has no error boundary).

**Detection ritual after any HTML rewrite:**
```bash
# List every selector the JS queries
grep -oE "\\\$\\('#[a-zA-Z0-9_-]+'\\)" dashboard.js | sort -u

# List every ID the HTML defines
grep -oE 'id="[a-zA-Z0-9_-]+"' index.html | sort -u

# Diff them — every JS selector must have a matching HTML ID
diff <(grep -oE "\\\$\\('#[a-zA-Z0-9_-]+'\\)" dashboard.js | sort -u) \
     <(grep -oE 'id="[a-zA-Z0-9_-]+"' index.html | sort -u)
```

**Fix pattern.** Replace `pill.querySelector('.status-pill__lbl').textContent`
chains with direct ID references where possible. Add `if (!el) return;` guards
to every renderer so one missing element doesn't kill the whole render chain.

---

## 8. CSS file-size discipline

For a serious production dashboard (auth + 3-column layout + 4 tabs + chat +
tables + modals + motion), CSS should be 30-60 KB / 1000-1800 lines.

| Size | Meaning |
|---|---|
| <10 KB | Probably a mockup, not a production system |
| 10-30 KB | Minimum viable, missing token system or motion layer |
| 30-60 KB | Sweet spot for a serious single-page dashboard |
| 60-100 KB | Probably duplicate token definitions or un-tree-shaken utility imports |
| >100 KB | Something is wrong (likely two competing design systems) |

If you're under 10 KB, you don't have a design system. If you're over 100 KB,
audit for token duplication before adding more.

---

## 9. Inline global error catcher (production addition)

The vanilla-js-spa SKILL already covers this for dev. For production, the
catcher should also POST to a `/api/errors` endpoint so you can see what broke
in the wild:

```js
window.addEventListener('error', (e) => {
  navigator.sendBeacon('/api/errors', JSON.stringify({
    msg: e.message,
    src: e.filename,
    line: e.lineno,
    col: e.colno,
    stack: e.error?.stack,
    ua: navigator.userAgent,
    ts: Date.now(),
  }));
});
```

The backend can store these to SQLite and surface them in the dashboard's
System tab as a "Recent JS errors" card. Single highest-value debug surface
for a vanilla-JS dashboard in production.