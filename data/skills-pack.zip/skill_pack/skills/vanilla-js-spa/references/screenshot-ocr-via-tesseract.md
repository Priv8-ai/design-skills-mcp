---
name: screenshot-ocr-via-tesseract
description: Reusable recipe for OCR'ing user-supplied macOS screenshots when the higher-level vision tools (vision_analyze, browser_vision, computer_use capture) are offline. Uses tesseract CLI via subprocess from a Python helper, copies the screenshot through shutil (NOT shell cp) to handle the U+202F narrow-no-break space macOS inserts in filenames, and runs tesseract out of the sandbox TMPDIR (not /tmp) because the sandbox tmpfs is isolated from the user shell.
when_to_load: When you need to read the contents of a desktop screenshot the user attached, and vision_analyze / browser_vision / computer_use have all failed (404, empty image, "cua-driver offline", etc.). Always load this BEFORE spending tool calls on those broken paths.
---

# Screenshot OCR via tesseract (vision-tools-failed fallback)

## When to reach for this

Before trying this recipe, ALWAYS attempt the high-level vision
tools first — `vision_analyze(path)`, `browser_vision(...)`, and
`computer_use(action='capture')`. They are higher quality and faster
when they work. Only fall back to tesseract when:

- `vision_analyze` returns `404 page not found` or "Connection error"
- `browser_vision` returns `404` or returns a black/blank image
- `computer_use` capture returns a 0×0 image or "cua-driver offline"

If even ONE of the three works, prefer it. Tesseract is reliable for
layout / text-positioning bugs but cannot describe icons, charts, or
visual polish — it can only read the letters.

## The full recipe

```python
import os, glob, shutil, subprocess

# 1. Find the user's screenshot(s). The macOS filename embeds U+202F
#    narrow-no-break space between timestamp and AM/PM, so do NOT
#    use shell globs or `cp`. Use Python's glob + shutil.
srcs = sorted(glob.glob('/Users/0x/Desktop/Screenshot*.png'))
if not srcs:
    raise SystemExit('no screenshots found')

# 2. Copy to a path without weird Unicode. The Hermes sandbox tmpfs
#    is rooted at os.environ['TMPDIR'] which is usually
#    /var/folders/.../T/ — NOT /tmp. Files copied to /tmp from the
#    sandbox are not visible to subprocesses that read /tmp, because
#    /tmp in the sandbox is a different mount.
out_dir = os.path.join(os.environ['TMPDIR'], 'sshots')
os.makedirs(out_dir, exist_ok=True)
copies = []
for i, src in enumerate(srcs):
    dst = os.path.join(out_dir, f'{i+1}.png')
    shutil.copy(src, dst)
    copies.append(dst)
print(f'copied {len(copies)} screenshots to {out_dir}')

# 3. OCR each via tesseract. Use --psm 11 for sparse / scattered
#    text (good for dark UIs where layout matters). Use --psm 4 for
#    a single column of text. -l eng is fine for English UIs.
for path in copies:
    print(f'\n========== {os.path.basename(path)} ==========')
    r = subprocess.run(
        ['tesseract', path, 'stdout', '--psm', '11', '-l', 'eng'],
        capture_output=True, text=True, timeout=60,
    )
    print(r.stdout)
    if r.returncode != 0:
        print('STDERR:', r.stderr[:300])
```

The output is plain text. Read it like a transcript of the page —
the spatial layout is lost, but the text content is reliable enough
to spot "the panel says 'idle' even though there's a scan" bugs.

## Variations

- **For dense paragraphs (chat replies, log output)** use
  `--psm 6` (assume single uniform block of text).
- **For tables** use `--psm 6` + `-c preserve_interword_spaces=1`
  if available.
- **For UI chrome only** (debugging "the modal isn't rendering"),
  `--psm 11` with a high `-c tessedit_create_tsv=1` is overkill —
  just read the `--psm 11` text and look for missing elements.
- **If the OCR output is gibberish or empty** the image is probably
  blank (modal overlay covering everything, or all-black screenshot
  from a mid-frame theme toggle). Cross-check with
  `file {path}` and `sips -g pixelHeight -g pixelWidth {path}`
  to confirm the image dimensions are non-zero.

## Why this exists

The session that produced this recipe spent 6+ tool calls trying
`vision_analyze`, `browser_vision`, `computer_use`, and local ollama
vision models (`llava:7b`, `llama3.2-vision`) before landing on
tesseract. The vision tools all returned 404 or empty; the local
ollama models hallucinated ("video call app", "alphabet exercise",
"100%, 10, 20, 30, 4567890"). Tesseract returned the actual text in
the screenshots within seconds and immediately revealed the bug.

The lesson is NOT "tesseract is always better" — it is **"build a
fallback ladder and don't burn cycles on broken tools."** The
recommended order:

1. `vision_analyze(image_url=path, question=...)` — usually wins
2. `browser_navigate` to a `file://` URL + `browser_vision` — works
   when vision_analyze is offline
3. `computer_use capture` + `vision_analyze(screenshot_path)` —
   works when both vision APIs are down but computer_use is up
4. **tesseract via subprocess** — last resort, when all three above
   are down. Always available if `brew install tesseract` was run.

## Sandbox tmpfs pitfall (the gotcha that wasted a turn)

In the Hermes sandbox:

- `os.environ['TMPDIR']` → `/var/folders/.../T/` (per-user tempdir)
- `/tmp` → sandbox-private tmpfs that is NOT shared with the host

If you `cp /Users/0x/Desktop/foo.png /tmp/foo.png` from `terminal()`,
the file lands on the host's `/tmp`, not the sandbox's `/tmp`. A
subsequent `subprocess.run(['tesseract', '/tmp/foo.png', ...])` from
`execute_code()` looks at the sandbox's `/tmp` and gets
`No such file or directory`.

The fix is to ALWAYS write to `os.environ['TMPDIR']` (Python resolves
this correctly inside the sandbox) and pass that path to subprocess.
Conversely, files written to `os.environ['TMPDIR']` from `execute_code()`
are visible to the user via `ls /var/folders/.../T/` — useful for
copying artifacts out of the sandbox.

## Don't ship OCR output to the user as a "view"

Tesseract output is diagnostic for the agent — not a deliverable.
A stream of OCR'd words ("Load Scan" "0" "idle" "TARGET" "SUBDOMAIN"
"0" "—" "0" "—" "41") is confusing to read in chat. Instead:

1. OCR the screenshot
2. Read the OCR like a transcript
3. Identify the bug (e.g. "panel says 'idle' but scan has 347 findings")
4. Patch the code
5. Verify by reading served bytes or running curl on the relevant endpoint
6. Tell the user "patched, here's what to refresh" — they verify themselves

The user can see the original screenshot; they don't need to read
the OCR. Save it as evidence in your session log if you need to
reference it later.