# Findings timeline sparkline (canvas, stacked bars by severity)

The class of work: show a compact, time-bucketed "how busy has the
scanner been" indicator that fits under the hero on the dashboard
home. Zero deps, ~50 lines of canvas, theme-aware.

## Why a sparkline, not a counter

The home already has 4 stat cards. Adding a 5th counter ("verified
findings this hour: 3") would just be another number. A sparkline
shows the **shape** of recent activity — bursts, lulls, ramp-up,
shutdown — at a glance. The user sees "we're in a busy burst" or
"nothing's happened in 40 minutes" without reading the number.

## HTML

Drop a canvas under the hero. Wrap it in a container with a header
+ count + legend so the user knows what the colors mean.

```html
<div class="hero-timeline" id="heroTimeline">
  <div class="tl-header">
    <span class="tl-title">FINDINGS TIMELINE</span>
    <span class="tl-count" id="tlCount">0 total · last hour</span>
  </div>
  <canvas id="tlCanvas" width="800" height="60"></canvas>
  <div class="tl-legend">
    <span class="tl-leg"><i style="background:var(--red)"></i>critical</span>
    <span class="tl-leg"><i style="background:var(--orange)"></i>high</span>
    <span class="tl-leg"><i style="background:var(--amber)"></i>medium</span>
    <span class="tl-leg"><i style="background:var(--cyan)"></i>low</span>
    <span class="tl-leg"><i style="background:var(--green)"></i>info</span>
  </div>
</div>
```

## CSS

```css
.hero-timeline { margin-top: 22px; padding: 12px 14px;
  background: rgba(10,13,20,0.5); border: 1px solid var(--line);
  border-radius: 10px; }
.tl-header { display: flex; align-items: center; justify-content: space-between;
  margin-bottom: 6px; }
.tl-title { color: var(--text-3); font-size: 9.5px; text-transform: uppercase;
  letter-spacing: 1.5px; font-weight: 800; }
.tl-count  { color: var(--brand-2); font-size: 11px; font-weight: 700;
  font-family: 'SF Mono', monospace; }
#tlCanvas  { width: 100%; height: 60px; display: block; border-radius: 6px; }
.tl-legend { display: flex; gap: 14px; margin-top: 6px; flex-wrap: wrap; }
.tl-leg { display: inline-flex; align-items: center; gap: 4px;
  color: var(--text-3); font-size: 10px; font-weight: 600; }
.tl-leg i { width: 8px; height: 8px; border-radius: 50%; display: inline-block; }
```

The container background uses `rgba(10,13,20,0.5)` (semi-transparent
dark) so it works against both the dark and light hero gradients.
On light theme, this looks like a slightly darker inset panel — fine,
it stands out from the white hero card behind it.

## JS — the renderer

Twelve time buckets, each 5 minutes wide, totaling 1 hour. Verified
findings are bucketed by `found_at` (or `timestamp` fallback, or
"now" if neither exists, which dumps unknown-timestamps into the
rightmost bucket).

```js
function renderTimeline() {
  const cv = $('tlCanvas');
  if (!cv) return;
  const dpr = window.devicePixelRatio || 1;
  const W = cv.offsetWidth || 800;
  const H = 60;
  cv.width = W * dpr; cv.height = H * dpr;            // crisp on retina
  const ctx = cv.getContext('2d');
  ctx.scale(dpr, dpr);
  const vList = verifiedOnly(S.findings);              // SAME discipline as everywhere

  // 12 time buckets, 5 min each, 1 hour total
  const buckets = Array(12).fill(0).map(() =>
    ({ critical:0, high:0, medium:0, low:0, info:0 }));
  const now = Date.now();
  const WINDOW = 60 * 60 * 1000;
  vList.forEach(f => {
    const ts = f.found_at ? new Date(f.found_at).getTime()
              : f.timestamp ? new Date(f.timestamp).getTime()
              : now;
    if (isNaN(ts)) return;
    const ago = now - ts;
    if (ago > WINDOW) return;
    const idx = Math.max(0, 11 - Math.floor(ago / (WINDOW/12)));
    const sev = (f.severity || 'info').toLowerCase();
    if (['critical','high','medium','low','info'].includes(sev)) buckets[idx][sev]++;
  });

  const total = vList.length;
  const cnt = $('tlCount');
  if (cnt) cnt.textContent = total + ' total · last hour';

  // Scale bars to the max bucket (so empty buckets are 0-height,
  // the busiest bucket fills the canvas height)
  let max = 0;
  buckets.forEach(b => { Object.values(b).forEach(v => { if (v > max) max = v; }); });
  if (!max) max = 1;

  // Hardcoded colors are fine here — the legend dots are also hardcoded,
  // and the dashboard's --red/--orange/--amber/--cyan/--green don't need
  // to be referenced in canvas (canvas doesn't read CSS vars by name).
  const colors = { critical:'#ff5d6c', high:'#ff8c5a', medium:'#fbbf24',
                   low:'#38e8ff', info:'#4ade80' };

  // grid lines (very subtle)
  ctx.strokeStyle = 'rgba(255,255,255,0.05)';
  ctx.lineWidth = 1;
  for (let i = 0; i < 4; i++) {
    const y = (H / 4) * i + 0.5;
    ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(W, y); ctx.stroke();
  }

  // Stacked bars per bucket: info on bottom, critical on top
  const colW = W / 12;
  buckets.forEach((b, i) => {
    const x = i * colW + 2;
    const w = colW - 4;
    let stackY = H - 2;
    ['info','low','medium','high','critical'].forEach(sev => {
      const v = b[sev];
      if (!v) return;
      const h = (v / max) * (H - 4);
      stackY -= h;
      ctx.fillStyle = colors[sev];
      ctx.fillRect(x, stackY, w, h);
    });
  });

  // Subtle purple gradient overlay (composited as 'screen' so it
  // tints the bars without obscuring them)
  const grd = ctx.createLinearGradient(0, 0, 0, H);
  grd.addColorStop(0, 'rgba(124,92,255,0.15)');
  grd.addColorStop(1, 'rgba(124,92,255,0)');
  ctx.fillStyle = grd;
  ctx.globalCompositeOperation = 'screen';
  ctx.fillRect(0, 0, W, H);
  ctx.globalCompositeOperation = 'source-over';
}
window.renderTimeline = renderTimeline;
```

Call it from `loadHero()` after the scan data is fetched:

```js
async function loadHero() {
  if (!S.scanId) return;
  try {
    const s = await api.get('/scans/' + S.scanId);
    S.currentScan = s;
    S.findings = s.findings || [];
    // ... existing hero updates ...
    renderTimeline();         // <-- add
  } catch(e) {}
}
```

## Five things that matter

1. **`devicePixelRatio` scaling** — without `cv.width = W * dpr`, the
   canvas looks blurry on retina. The `ctx.scale(dpr, dpr)` at the
   start of the renderer means the rest of the code can keep using
   logical pixels.

2. **`verifiedOnly(S.findings)`** — the same discipline applied to
   every other surface. The timeline MUST NOT show unverified
   findings; the user explicitly said "don't show vuln unless it's
   verified." This applies to the sparkline, the donut, the
   constellation, AND the timeline.

3. **Buckets are right-to-left in time** — bucket[0] is 60 min ago,
   bucket[11] is "just now". `ago > WINDOW` skips old findings,
   `Math.max(0, 11 - Math.floor(ago / (WINDOW/12)))` computes the
   right index. `now` fallback (for missing timestamps) puts the
   finding in bucket[11] = "now."

4. **Stacked bars with fixed ordering** (info → low → medium → high →
   critical, bottom to top) means the user always reads the worst
   color on top — even if the eye picks up just the topmost pixel,
   the severity is correct.

5. **`globalCompositeOperation = 'screen'`** on the gradient overlay
   tints the bars without darkening the gaps. Switch back to
   `'source-over'` after or the next `fillRect` will also use screen
   mode and surprise you.

## Why no `getComputedStyle` for the colors

The toast, palette items, sidebar activity pulse — all theme-aware
via CSS vars. The timeline colors are hardcoded hex. Why?

- The severity colors are **semantic**, not theme-derived. A
  `critical` finding is red whether the dashboard is dark or light.
- The legend dots are also hardcoded — if the canvas were theme-aware
  but the legend were not, they'd disagree.
- Canvas can't read CSS vars by name anyway; you'd be using
  `getComputedStyle(documentElement).getPropertyValue('--red')` per
  frame (cheap, but pointlessly). The `--red` var is itself derived
  from a hardcoded hex.

Trade-off: if you change the brand palette via the theme picker,
the timeline doesn't follow. Accept that, or wire the canvas to
read the vars like the constellation does (see `theme-and-responsive.md`
§ "Canvas code that respects the theme").

## Verification ladder

After wiring the timeline:

1. **Shape shows busy/quiet** — find a scan with 5+ findings in
   the last hour; verify the bar at the right edge is taller than
   the left. Find one with no recent activity; verify the right
   edge is empty.
2. **Severity stacking** — inject test findings of all 5 severities
   in bucket 11; verify you see green at the bottom, cyan, amber,
   orange, red stacked upward.
3. **Re-render on every loadHero** — set S.findings to `[]` in the
   console, then call `renderTimeline()`; verify the bars disappear
   and the count reads "0 total · last hour".
4. **DPR scaling** — on a retina display (devicePixelRatio 2 or 3),
   the bars should be sharp, not blurry. Check by zooming the
   screenshot.
5. **Verified-only filter** — inject an unverified finding
   (`f.verified = 0`); it MUST NOT appear in any bucket.
6. **Resizes with viewport** — resize the window from 1280px to
   768px; the canvas re-flows and the bars redistribute without
   overflow or gaps.

## When to skip this pattern

- The app has no concept of "events over time" (CRUD, settings, reports)
- Findings are extremely rare (the user never has more than 1-2 per
  session — the timeline would be empty 99% of the time)
- The home already has a different "activity" widget that does this
  job (e.g. the sidebar progress rows from `sidebar-progress-rows.md`)

The timeline complements the sidebar progress rows — one shows
"how's the work going" (current), the other shows "how busy has
the system been" (recent). Different signals, different surfaces.
