# AI-Slop Design Discipline (for vanilla-JS dashboards)

Distilled from a 2026-06-23 WeHuntX v2 dashboard build. The principle
generalizes to any vanilla-JS dashboard project, not just WeHuntX. The
full session context is in `wehuntx-pipeline/references/session-2026-06-23-v2-sidestep.md`.

## Why this exists

LLM-generated dashboards in 2025-2026 converge on the same 10-12 lazy
patterns. The user sees them as "AI-generated" instantly and rejects
the work. The user in this skill's history explicitly named the
category ("missed up") when a v1 dashboard shipped with these patterns.
This reference is a one-page checklist to run before any new
vanilla-JS dashboard is shipped.

## The banned-patterns test

Before shipping any dashboard, run this test. ANY "yes" is a reject —
rework until all 10 are "no":

- [ ] **No glassmorphism as a default.** `backdrop-filter: blur()` is a
      tool, not a theme. Use it once (modal backdrop) or not at all.
- [ ] **No gradient text on headings.** Solid color, always.
- [ ] **No side-stripe severity borders.** `border-left: 4px solid var(--sev)`
      is a Material 2018 anti-pattern. Use row tint, top accent, or chip.
- [ ] **No hero-metric template.** Big number + label in 3-4 stat cards.
      Bento grid, not stat row.
- [ ] **No identical card grids.** 3×3 or 4×3 of identical cards.
      Asymmetric bento.
- [ ] **No repeated eyebrows.** Uppercase label above every section
      ("OVERVIEW", "FINDINGS", "ACTIVITY"). ONE per page maximum
      (in the hero only).
- [ ] **No numbered section markers.** "1. Overview / 2. Findings" in
      big bold numbers. Plain headings or no headings.
- [ ] **No serif fonts in tech dashboards.** Inter, Geist, system-ui,
      monospace. No Playfair, no Source Serif, no Cormorant.
- [ ] **No fake screenshots.** No mock browser window with a generic
      webpage in a marketing section.
- [ ] **No "Used by" logo walls.** 8 generic tech-company logos in a
      row. SaaS pattern, not dashboard.

## The dials (use these instead)

- **One accent color at ≤10% of surface.** Whole dashboard is
  neutrals; accent is reserved for the one live pulse, one CTA, one
  chip. More accents = noise. (Example: v2 picked mint
  `oklch(0.78 0.16 145)`.)
- **One radius system.** 2 values max (e.g. 6px inputs/buttons,
  12px cards/panels). No 4px/8px/16px/24px mixed. Consistency is
  the design.
- **One font stack.** One family, two weights, one mono. No
  "Iowan for headings, Inter for body, JetBrains for code".
- **OKLCH for new colors** — not hex, not hsl. OKLCH makes it
  trivial to keep the same hue family with deliberate lightness
  offsets, and `oklch(L C H)` reads as "what you intended"
  without RGB math.
- **Hairline borders over fills.** 1px borders for separators and
  card edges. Depth from contrast, not from a different fill.
- **Motion = motivated only.** If removing the animation wouldn't
  lose information, the animation shouldn't be there.
  `prefers-reduced-motion: reduce` kills everything. (v2 ships
  exactly 2 animations: connecting-pill pulse and rail-skeleton
  shimmer.)
- **WCAG AA contrast minimum.** 4.5:1 text, 3:1 large/UI. Run
  colors through a contrast checker BEFORE shipping.

## Workflow hint for the variant-first path

For WeHuntX specifically, the existing `wehuntx-pipeline` rule says:
build 2-3 variants A/B/C, screenshot them head-to-head, let the user
pick, then promote. **Distribute these three stances across the
variants as a starting point** (the user can still override):

- **A: Vercel/Linear command-center** — bento grid, hairline
  borders, one accent, eyebrow in hero only, motion = motivated.
  The WeHuntX v2 build already implemented this; reuse it as
  Variant A.
- **B: Warp HUD / terminal-native** — monospace throughout, ASCII
  separators, status bar at the bottom, no rounded corners,
  phosphor-on-black palette. Stripped-down; everything is a `> _`
  prompt or a row in a table.
- **C: Editorial / longform** — large type, generous whitespace,
  content scrolls vertically, findings are a readable list not a
  table, severity is a parenthetical not a chip. Reads like a
  report, not a dashboard.

## Pitfalls when shipping vanilla-JS + FastAPI StaticFiles

From the same v2 build:

- **Relative `<link>` paths break when mounted under a subpath.** HTML
  served at `/v2` with `<link rel="stylesheet" href="./dashboard.css">`
  resolves to `/dashboard.css` (parent), not `/v2/dashboard.css`.
  **Always use absolute paths (`href="/v2/dashboard.css"`) when the
  asset lives at a sub-URL.** Symptom: page renders with default
  Times font, white background; no error in console because the file
  404s are silent in `<link>`.
- **API field shape ≠ developer intuition.** Always `curl` the
  endpoint first and read the actual JSON shape before writing the
  renderer. Common developer assumptions (`tool`, `url`, `ollama_model`)
  silently break with no error.
- **`d.ok && d.findings || []` precedence is a footgun.** `&&` binds
  tighter than `||`, so `d.ok && d.findings || []` returns `[]` when
  `d.ok` is falsy even if `d.findings` has rows. Use
  `Array.isArray(d.findings) ? d.findings : []`.
- **Conditional CSS class emission silently hides colors for zero
  rows.** When `${count ? 'critical' : ''}` is used to emit a
  modifier class, the modifier is only added when the count is
  truthy, so zero-count rows stay unstyled. Pattern: always emit
  the modifier class (`class="ov-num low"`); let CSS decide how
  to render zero vs non-zero.

## What this reference is NOT

Not a design system. Not a component library. Not a Tailwind
alternative. It's a discipline — a short checklist for the moment
before you ship. The implementation details (which OKLCH value,
which font weight, which radius size) are the easy part; the
discipline is the hard part.
