# FastAPI + Vanilla-JS Defensive Stack — Session Notes

Built this pattern over multiple WeHax sessions. Captures the
specific code shapes that ship, not the design discussion.

## Layer 1: `state.py` data method wraps the raw query

The single most common crash: a fresh or rehydrated scan's
`agentic_state.db` is missing the `findings` table (no migrations
ever ran, or the scan was killed before phase 4). The
`recent_findings()` method queries `SELECT * FROM findings ...`
and throws `sqlite3.OperationalError: no such table: findings`.

**Fix** — catch the specific error, return `[]`:

```python
async def recent_findings(self, limit: int = 50) -> T.List[dict]:
    def _q(conn):
        try:
            return conn.execute(
                "SELECT * FROM findings WHERE scan_session=? ORDER BY id DESC LIMIT ?",
                (self.scan_session, limit)).fetchall()
        except sqlite3.OperationalError as e:
            if "no such table" in str(e).lower():
                return []
            raise
    rows = await self._read(_q)
    ...
```

Don't catch `Exception` — only catch the specific operational
errors. The non-"no such table" errors are real bugs that need
to surface, not be silently swallowed.

## Layer 2: Endpoint try/except

```python
@app.get("/scans/{scan_id}/findings")
async def get_findings(scan_id: str, limit: int = 200, ...) -> dict:
    handle = _get_handle(scan_id)
    if not handle:
        raise HTTPException(status_code=404, detail="scan not found")
    try:
        state = AgenticState(handle.db_path, handle.domain)
        _align_scan_session(state)
        rows = await state.recent_findings(limit=limit * 4 if (...) else limit)
    except Exception as e:
        return {"findings": [], "filtered": False,
                "warning": f"scan DB not initialized: {e}"}
    # ... rest
```

The warning field is what the dashboard renders in a yellow
banner so the user knows the scan is empty-corrupt, not empty.

## Layer 3: Global FastAPI exception handler

```python
@app.exception_handler(Exception)
async def _global_exc_handler(request, exc):
    import traceback
    try:
        print(f"[api] unhandled error on {request.method} {request.url.path}: {exc}\n{traceback.format_exc()}")
    except Exception: pass
    return {"ok": False, "error": str(exc) or exc.__class__.__name__,
            "detail": f"{request.method} {request.url.path} failed",
            "warning": "fallback: empty result returned to keep the dashboard alive"}
```

This catches the uncaught exceptions that escape the endpoint's
own try/except — important because some exceptions (e.g.
Pydantic validation in nested models) are raised by FastAPI
BEFORE your handler runs.

## Layer 4: Request-logging middleware (the killer layer)

The `_log_requests` middleware runs OUTSIDE the FastAPI exception
chain. By default it returns 500 with a JSON body. The fix: return
200 with the same empty payload keys the dashboard expects:

```python
def _log_requests(request, call_next):
    try:
        response = await call_next(request)
    except Exception as exc:
        _log.exception("%s %s 500 %.1fms %s", method, path, ms, exc)
        from fastapi.responses import JSONResponse
        return JSONResponse(
            status_code=200,  # NOT 500 — keep the dashboard alive
            content={
                "ok": False, "error": str(exc), "type": type(exc).__name__,
                "path": path, "method": method,
                "warning": "fallback: empty result returned to keep the dashboard alive",
                "findings": [], "scans": [], "subdomains": [], "summary": {},
            },
        )
    ...
```

**Critical**: the `findings: [], scans: [], subdomains: [], summary: {}`
keys MUST be present even on error, because the client does
`const scans = await r.json(); renderScanList(scans)` — if `scans`
is missing, the renderer crashes too.

## Layer 5: Client call site

```js
const d = await api.get('/scans');
const scans = Array.isArray(d) ? d : (d.scans || d.results || []);
renderScanList(scans);
```

Never trust the response shape. Check for the array OR an envelope
object. Default to `[]`.

```js
// Defensive property reads
const model = d.model || d.model_used || S.model;
const text = d.text || d.answer || d.reply || d.detail || '(empty)';
```

If 5 different keys all mean the same thing in different endpoints,
read all of them. The cost is one extra `||` chain; the benefit
is "the same field works whether the endpoint is /orchestrate,
/scans/{id}/chat, or the legacy /scans/{id}/orchestrate."

## The empty-DB rehydrate problem

`scan_meta.json` rehydrates scan handles on API restart. But
the matching `agentic_state.db` may be 0 bytes (scan was killed
during init). The handle exists, the `findings` table doesn't.

The `_align_scan_session` function tries to recover by picking
whichever session has the most findings, but if there are NONE
it returns empty and the recent_findings call still has to
handle the missing table.

The 5-layer stack above is the cure. There's no single fix.

## When to keep the 500 vs return 200

The five layers turn most 500s into 200s with empty payloads.
There are cases where you SHOULD return 500:

- Auth failures (401, 403) — the dashboard needs to know
- Validation errors (422) — the user needs to fix the input
- Truly catastrophic failures (DB connection lost) — better
  to fail loud than to silently swallow

For everything that's "the scan exists but its data is corrupt
or partial," return 200 with the empty payload + warning. The
user can still see the scan, click into it, get a useful
"this scan has no findings" message, and (if they care) delete
or restart it.
