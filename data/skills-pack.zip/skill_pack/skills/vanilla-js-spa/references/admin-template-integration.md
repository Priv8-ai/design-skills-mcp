# Integrating a 3rd-party admin template (PlainAdmin / AdminLTE / Tabler / StarAdmin / NiceAdmin)

When you bring in a pre-built admin template (PlainAdmin, AdminLTE, Tabler, etc.) and try to compose it with your own content, the framework's class names, structure, and CSS specificity will fight you. This file is the recipe for not losing that fight.

Verified against PlainAdmin v2.x (Mar 2026) but the same patterns apply to every other Bootstrap-grid admin template.

## The 1-minute audit before you write any code

Before you copy any HTML, read the template's `index.html` end to end and write down these facts. The first integration fails 100% of the time when you skip this.

1. **What is the WRAPPER class for the main content area?** In PlainAdmin it's `main-wrapper` (NOT `main`!). In AdminLTE it's `content-wrapper`. In Tabler it's `page`. In StarAdmin it's `main-content`. Many templates also have a separate `main` for `<main>` itself, which is a different element.

2. **What is the HEADER class?** PlainAdmin uses `header`, others use `navbar`, `topbar`, `app-header`, etc. The header usually has its own grid layout inside.

3. **What is the SIDEBAR class?** PlainAdmin `sidebar-nav-wrapper`, AdminLTE `main-sidebar`, Tabler `navbar-vertical`. Note: some templates put the sidebar INSIDE the main wrapper (and shift the wrapper), some put it OUTSIDE (and the wrapper sits to the right). PlainAdmin = outside.

4. **What DOM STRUCTURE does the header expect?** PlainAdmin needs `container-fluid > row > col-lg-X`. If you put a single `<div>` in there, the spacing/layout breaks because the CSS targets `.header .row` selectors with flexbox `flex-direction: row-reverse`.

5. **Where do CSS variable overrides go?** Many templates define `:root { --primary: ...; }`. If you override on `body` instead of `:root`, you break. If you override `--primary` and the template uses `--primary-color`, you changed nothing.

## The 5-step migration

### Step 1: Copy the assets
```bash
cp -r ~/Downloads/template-pro/assets web/static/assets
```
Don't copy the HTML — you'll write your own composition, not paste theirs.

### Step 2: Wire CSS in the right order in `<head>`
```html
<link rel="stylesheet" href="/static/assets/css/bootstrap.min.css" />  <!-- 1. framework -->
<link rel="stylesheet" href="/static/assets/css/lineicons.css" />       <!-- 2. icon font -->
<link rel="stylesheet" href="/static/assets/css/main.css" />           <!-- 3. template core -->
<style>/* 4. your overrides LAST so they win specificity */</style>
```
Reversing the order means your overrides get stomped.

### Step 3: Build your HTML with the template's wrapper classes
```html
<body>
  <aside class="sidebar-nav-wrapper">  <!-- their sidebar class, not yours -->
    <div class="navbar-logo">...</div>
    <nav class="sidebar-nav">...</nav>
  </aside>

  <main class="main-wrapper">  <!-- THEIR class for main, not "main" -->
    <header class="header">     <!-- their header class -->
      <div class="container-fluid">
        <div class="row">
          <div class="col-lg-7 col-md-6 col-12 header-left d-flex align-items-center">
            <!-- left stuff -->
          </div>
          <div class="col-lg-5 col-md-6 col-12 header-right d-flex justify-content-end align-items-center">
            <!-- right stuff -->
          </div>
        </div>
      </div>
    </header>

    <div class="main-content">
      <!-- your content panes here -->
    </div>
  </main>
</body>
```

### Step 4: Don't override framework layout classes
The #1 bug: you have a section like:
```css
.main { background: var(--bg); }       /* ← overrode their margin-left: 250px */
.sidebar { background: var(--bg); }     /* ← overrode their position: fixed; left: 0; top: 0; width: 250px */
```
…and the layout collapses because you wiped out the layout. Solution: scope your overrides with element OR use a NEW class for your themed areas:
```css
/* BAD: wipes their layout */
.main { background: #0d1117; }

/* GOOD: append your own class to the same element */
<main class="main-wrapper wehax-main">
.wehax-main { background: #0d1117; color: #e6edf3; }
```

### Step 5: Custom components get NEW classes
Don't reuse the template's `card-style-1` for your own stat card if their `card-style-1` is a content card. Build your own:
```css
.wehax-stat-card { /* your custom stat card */ }
.wehax-stat-card .icon { /* your colored circle */ }
.wehax-stat-card .icon.brand { background: rgba(124,58,237,0.18); color: #a78bfa; }
.wehax-stat-card .icon.green  { background: rgba(63,185,80,0.18); color: #3fb950; }
```

## Icon fonts (LineIcons / FontAwesome / MaterialDesignIcons) — the gotcha

The icon font files (`.woff2`, `.ttf`) are referenced from CSS via `url("../fonts/LineIcons.woff2")`. **The relative path is from the CSS file, not from the HTML.** So:
- `assets/css/lineicons.css` references `../fonts/LineIcons.woff2` → looks in `assets/fonts/LineIcons.woff2` ✓
- The HTML references `/static/assets/css/lineicons.css` and `/static/assets/images/logo/logo.svg` — both served from `/static/assets/...` ✓

If you move the CSS but forget to copy the `fonts/` directory, the icon font silently fails to load and `<i class="lni lni-dashboard"></i>` renders as a blank box. **The fix is always: verify the `fonts/` directory is intact and the `src:` URL in the CSS file matches the actual path.**

Browser dev tools shows 404s for `.woff2` files in the network tab — that's the smoking gun.

## Class-name lookup cheatsheet for common templates

| Template | Sidebar | Main wrapper | Header | Container |
|---|---|---|---|---|
| PlainAdmin | `sidebar-nav-wrapper` | `main-wrapper` | `header` (uses `container-fluid > row > col-*`) | `container-fluid` |
| AdminLTE | `main-sidebar` | `content-wrapper` | `main-header` | `container-fluid` |
| Tabler | `navbar-vertical` | `page` | `navbar navbar-expand-md` | `container-xl` |
| StarAdmin | `sidebar` | `main-content` (directly on `<main>`) | `navbar` | `container-fluid` |
| NiceAdmin | `sidebar` | `main` | `header.nav-header` | `container-fluid` |

## Layout-side bug audit checklist (1-minute)

When the design looks wrong but you can't see what's wrong, run these in the browser console:

```js
// 1. Are key layout elements present?
const sb = document.querySelector('.sidebar-nav-wrapper');
const main = document.querySelector('.main-wrapper');
const header = document.querySelector('.header');
[!!sb, !!main, !!header, main?.offsetWidth, main?.getBoundingClientRect().left]

// 2. Did CSS load?
document.styleSheets.length
Array.from(document.styleSheets).map(s => s.href || 'inline')

// 3. Are icon fonts actually rendering?
const ico = document.querySelector('.lni-dashboard');
const before = getComputedStyle(ico, '::before');
[before.content, before.fontFamily, before.fontSize, before.display]

// 4. Is main content hidden under the fixed sidebar?
main.getBoundingClientRect().left    // should equal sidebar width (e.g. 250)
// If it's 0, the main wrapper has no margin-left — wrong class name.

// 5. Are cards sized correctly?
const card = document.querySelector('.card');
[card.offsetWidth, getComputedStyle(card).padding, getComputedStyle(card).border, getComputedStyle(card).borderRadius]
```

## Pitfalls

- **Don't trust the template's `index.html` examples for card patterns.** PlainAdmin's `card-style-1` is a content card with `.card-meta` / `.card-image` / `.card-content`, NOT a stat card. They have no stat card pattern — their numbers are inline in chart legends. If you want a stat card, build your own.
- **`el.classList.contains('active')` doesn't trigger a CSS re-paint if your CSS targets `.foo` but your element has `class="foo active"` and the rule is `.foo.active`.** Always test the actual selector.
- **Font file paths are relative to the CSS file, not the HTML.** If you see blank icons, check `src: url("../fonts/...")` in the CSS and confirm `fonts/` is in the right place relative to the CSS.
- **PlainAdmin's `main-wrapper` is `margin-left: 250px` by default, not the `<main>` element.** Renaming it to `main` (which is also a real class in some templates) silently breaks the layout.
- **The template's own `main.js` is optional.** PlainAdmin ships a `main.js` that does some chart initializations, sidebar toggles, etc. If your custom JS conflicts, audit the template's `main.js` BEFORE including it. Many templates work fine with just the CSS. **Common silent failure**: PlainAdmin's `main.js` does `document.querySelector('#menu-toggle').addEventListener(...)` (no `?.`) and throws `TypeError: Cannot read properties of null` on the first line if your dashboard doesn't have that exact element. The page loads, boot completes, and the user sees a half-working dashboard with 2 errors in the console. **Fix**: open the template's `main.js`, grep for selectors, and confirm every one exists in YOUR DOM. If you don't need its functionality, just don't include the tag.
- **CSS `@import` chains in the template's `main.css` will pull in more CSS than you expect.** Open the file and grep for `@import` — you may be loading 5 extra files you didn't know about (themes, calendar, quill editor, etc.). Most are unused and can be cut.
- **`position: fixed` sidebar + long body = visible "void" below the fold in full-page screenshots.** The sidebar covers only the viewport height. When the body is taller than the viewport (most dashboards are), the area to the left of the scrolled content shows `body` background. The screenshot looks like the sidebar is cut. **This is a screenshot artifact, not a bug** — in the real browser the sidebar stays fixed. Verify by checking the screenshot height vs the viewport height before declaring it broken.
- **`/system` endpoints that read config files unconditionally 500 when the config is missing.** Wrap in `if (path.exists())` before `read_text()`:
  ```python
  try:
      spath = Path("~/.app/settings.json").expanduser()
      host = json.loads(spath.read_text()).get("host", default) if spath.exists() else default
  except Exception: host = default
  ```
- **`/metrics` and `/system` field names drift independently of the UI's expectations.** Defensive JS pattern: `d.active_scans ?? d.by_status?.running ?? 0` accepts either shape. Faster than chasing the API to rename fields.

## The fastest visual-check workflow when the user says "design is messed up"

The user's "design is messed up" is almost never a CSS problem. It's
**one of these four, in order of likelihood**:

1. **Your class names don't match the framework's.** You used `class="main"`,
   the framework expects `class="main-wrapper"` (PlainAdmin) or
   `class="content-wrapper"` (AdminLTE). The result: no `margin-left: 250px`,
   so the main content sits under the fixed sidebar. Single biggest cause
   of "design is messed up" reports.
2. **The framework's `main.js` is throwing on a missing element.** You
   brought in `<script src="main.js">` and the template's first line is
   `document.querySelector('#menu-toggle').addEventListener(...)`. Your
   custom DOM has no `#menu-toggle`. Page loads, boot completes, console
   shows 2 uncaught errors, the half-loaded page is broken in subtle
   ways. **Don't include the template's main.js if you don't need it.**
3. **An icon font failed to load.** `<i class="lni lni-dashboard">`
   renders as a blank square. Cause: the `fonts/` directory wasn't
   copied, OR the CSS's `src: url("../fonts/...")` doesn't match the
   actual path. Open the network tab and look for `.woff2` 404s.
4. **Your CSS override clobbered the framework's layout.** You wrote
   `.main { background: var(--bg); }` to theme the main area. The
   framework's `.main` had `margin-left: 250px; position: relative`.
   Your override wiped the layout. **Use a new class** (`.wehax-main`)
   instead of overriding the framework's.

**The 30-second console audit** (run this BEFORE changing any CSS):

```js
// 1. Did the framework's CSS actually load?
document.body.style.backgroundColor     // if "rgba(0,0,0,0)" the CSS didn't load
document.styleSheets.length              // should be 4-6, not 0

// 2. Are key layout elements present?
document.querySelector('.sidebar-nav-wrapper')   // PlainAdmin: should be truthy
document.querySelector('.main-wrapper')           // PlainAdmin: should be truthy
const main = document.querySelector('.main-wrapper')
main.getBoundingClientRect().left                 // PlainAdmin: should be 250
main.getBoundingClientRect().width                // PlainAdmin: should be ~1030

// 3. Did the framework's JS throw?
window.__WEHAX_ERRORS || []                       // any pop in this list?
// empty + only automation-layer exceptions = your page is clean
// pop with file/line/stack = real bug, fix it

// 4. Are icon fonts actually rendering?
const ico = document.querySelector('.lni-dashboard')
getComputedStyle(ico, '::before').content          // should be "\ea8e" or similar
// if "none", the .lni-dashboard::before rule didn't match — font failed to load
```

**The fix ladder** (in order — don't skip steps):

1. Verify the wrapper class is correct (Step 1 in the "fastest workflow"
   list above). Renaming `class="main"` to `class="main-wrapper"` fixes
   ~50% of "design is messed up" reports instantly.
2. Remove `<script src="main.js">` if included. Reload. Does it look right?
   You didn't need it.
3. Open the network tab. Are `.woff2` font files 404'ing? Copy the
   `fonts/` directory if so.
4. Search your CSS for any rule that targets `.main` or `.sidebar`. If
   found, rename to `.wehax-main` / `.wehax-sidebar`.
5. Take a screenshot, verify against the 30-second audit again. The
   issue is almost always one of steps 1-4.

If the audit above passes but the design still looks wrong, then it's
a real CSS problem — and at that point a screenshot via
`browser_vision` is the right next step.

## Reference: PlainAdmin folder structure (what you'll have on disk)

```
web/static/assets/
├── css/
│   ├── bootstrap.min.css                  ← required
│   ├── lineicons.css                      ← required for lni-* icons
│   ├── materialdesignicons.min.css        ← optional (MDI icons)
│   ├── main.css                           ← required, the framework CSS
│   ├── fullcalendar.css                   ← optional
│   ├── morris.css                         ← optional
│   └── quill/{bubble,snow}.css            ← optional
├── js/
│   ├── bootstrap.bundle.min.js            ← required
│   ├── jvectormap.min.js                  ← optional
│   ├── world-merc.js                      ← optional (for jvectormap world map)
│   ├── apexcharts.min.js                  ← optional
│   ├── fullcalendar.js                    ← optional
│   ├── Chart.min.js                       ← optional
│   ├── moment.min.js                      ← optional (for fullcalendar)
│   ├── quill.min.js                       ← optional
│   ├── main.js                            ← optional (template's own JS)
│   └── polyfill.js                        ← optional
├── fonts/                                 ← required if you use lineicons/mdi
│   ├── LineIcons.{eot,svg,ttf,woff,woff2}
│   └── materialdesignicons-*.{eot,ttf,woff,woff2}
├── images/                                ← for logos, avatars, etc.
│   ├── logo/logo-2.svg
│   ├── favicon.svg
│   └── ...
└── scss/                                  ← SCSS source if you want to customize
```

For a "just give me a dark themed dashboard" target, you need:
- `css/bootstrap.min.css`
- `css/lineicons.css`
- `css/main.css`
- `js/bootstrap.bundle.min.js`
- `fonts/LineIcons.{woff2,ttf,woff}`
- `images/favicon.svg` (optional)

Everything else can be deleted to keep the asset bundle small.
