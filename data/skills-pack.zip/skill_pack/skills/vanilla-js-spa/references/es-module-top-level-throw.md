# ES module top-level throw hides hoisted bindings (2026-06-24)

The parent SKILL.md covers the IIFE boot-crash failure mode (dashboard
renders statically with empty stats + "no error in console"). This
reference covers the **ES module analogue**: `<script type="module">`
loading where an unhandled rejection inside an early render call leaves
the module's hoisted top-level `function`/`var` bindings effectively
unreachable from page-level inspection.

## Symptom signature

- HTML is fine, CSS is fine, browser renders the page correctly.
- `typeof boot` returns `undefined` in the console even though
  `grep -nE "^function|^async function" dashboard.js` shows `function
  boot()` at column 0.
- `window.__wex.loadScans` IS defined (the export bundle ran), but the
  bare name `loadScans` is not accessible.
- `console.log` shows no errors. `console.error` may show a single
  "Uncaught (in promise) TypeError: Cannot set properties of null
  (setting 'textContent')".
- Topbar/status pill stays on default ("connecting · ollama: —").
- Data tables show 0 rows despite the API returning real data.

## Why it happens

When an ES module body throws during initial evaluation, the
engine's hoisting semantics are subtler than the IIFE case. Function
declarations DO hoist, but the surrounding evaluation context can
end up in a state where:

1. Some top-level statements ran and attached side-effects (e.g.
   `window.__wex = { ... }` populated with render functions).
2. The Promise returned by an `async function` invocation at module
   top level (e.g. via `DOMContentLoaded → boot()` → `Promise.allSettled([...])`)
   rejected with a TypeError from a null-deref.
3. The rejection becomes an "unhandled promise rejection" — appears
   as a single `console.error` line, NOT as a `console.log` error.
4. The module's outer execution context finishes, but the next time
   the page tries to read `boot` from the global namespace, the
   binding is in a state the engine treats as `undefined` for the
   purposes of `typeof`.

The diagnostic that reveals this: `typeof X === 'undefined'` for
top-level `function`/`async function` declarations that DO appear
in the source. The check `grep -nE "^function [a-z]" file.js` should
be the FIRST step, not the last.

## The catcher that diagnoses it

Place this `<script>` block BEFORE the module `<script type="module">`
tag. Listeners installed after the module loads miss past rejections.

```html
<script>
window.__errs=[];
addEventListener('error',e=>window.__errs.push(
  'ERR: '+e.message+' @ '+(e.filename||'?')+':'+(e.lineno||'?')));
addEventListener('unhandledrejection',e=>window.__errs.push(
  'REJ: '+(e.reason?.message||e.reason)+'\n'+
  (e.reason?.stack?.slice(0,400)||'')));
</script>
<script type="module" src="/dashboard.js?v=1"></script>
```

Then in the console:

```js
window.__errs.join('\n\n')
```

You'll see something like:

```
REJ: Cannot set properties of null (setting 'textContent')
TypeError: Cannot set properties of null (setting 'textContent')
    at renderHero (http://127.0.0.1:8777/v2/dashboard.js?v=5:237:23)
    at render (http://127.0.0.1:8777/v2/dashboard.js?v=5:636:3)
```

The line number points straight at the selector mismatch.

## Common null-deref patterns in render code

```js
// BAD: assumes element exists
const pill = $('#oldPillId');
pill.dataset.state = 'ok';
pill.querySelector('.lbl').textContent = '...';  // boom if null

// GOOD: defensively guarded
const pill = $('#oldPillId');
if (pill) {
  pill.dataset.state = 'ok';
  const lbl = pill.querySelector('.lbl');
  if (lbl) lbl.textContent = '...';
} else {
  // fallback path or skip
}
```

When rewriting CSS+HTML+JS as a set, the BEST practice is to make
every `render*` function defensive from the start. The render path
should NEVER throw on missing elements — it should skip them and log.

## Source-fix sequence

1. Map selectors BEFORE writing the new HTML:
   ```bash
   rg -oE "[\$#]\([\"'][a-zA-Z][a-zA-Z0-9_-]+[\"']\)|querySelector\([\"'][^)]+[\"']\)" \
      dashboard.js | sort -u
   ```
2. Make every render function defensive (null-guards on every `$(...)`).
3. Run the inline error catcher from `index.html` BEFORE the module tag.
4. After smoke-test, bump `?v=N+1` on the script src.
5. `window.__errs` should be empty `[]`.

## Related patterns from this skill

- `references/script-tag-defer-pitfall.md` — IIFE analogue of this same
  failure mode
- `references/inline-window-onerror-catcher.md` — the IIFE-side
  catcher pattern
- `references/el-null-guard-gotcha.md` — the defensive-render helper

## Cross-reference

- WeHuntX v3 redesign session: `wehuntx/references/v3-terminal-brutalism-redesign.md`
  — full rewrite-cascade narrative with the 4-step mandatory sequence.