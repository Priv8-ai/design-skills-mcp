# Global-namespace assignment ordering

A class of silent boot failures unique to multi-section vanilla-JS files
where the "test surface" (`window.__app = { ... }`) is split across
multiple blocks in the same file. The whole file errors with
`Cannot set properties of undefined (setting 'X')` but the static
content still renders, so it looks like the JS is "partly working".

## The pattern that breaks

```js
// Top of file, "expose chat helpers" comment
window.__app.chat = {           // <-- BREAKS
  send, show, hide,
};

// 500 lines later, end of file
window.__app = {                // <-- THIS is the actual parent assignment
  state, boot, switchTab, ...
};
```

`window.__app` is `undefined` at line 1, so the property assignment
throws `TypeError: Cannot set properties of undefined (setting 'chat')`.
In a `<script type="module">`, the throw aborts the **entire module** —
every function declared after the throw point becomes inaccessible to
later code, but content rendered with the static HTML still shows.

## Diagnostic ladder

When "static HTML renders, counters show '—', all `__app.X` returns
undefined, no error in DevTools":

1. **Open the file in a real DOM.** Console:
   ```js
   addEventListener('error', e => console.log('caught:', e.message, e.filename, e.lineno));
   await import('/dashboard.js');   // re-import to see the error
   ```
   This often shows the line that threw during initial load.

2. **Look for the `Cannot set properties of undefined (setting 'X')`**
   family. It always means: parent object isn't assigned yet at the
   line that sets the child property.

3. **Look for `Identifier 'foo' has already been declared`.** You
   added a new function and forgot to delete the old one. Re-read the
   file from the top — the duplicate is usually at the original
   location, not where you added the new one.

## Two fixes — pick one

**Fix A (preferred): declare the parent first, add to it after**

```js
// Top of file
if (!window.__app) window.__app = {};

// Mid-file
window.__app.chat = { send, show, hide };

// End of file (this now adds to the existing object instead of
// replacing it; same effect for symbol resolution at call time)
window.__app = { ...window.__app, state, boot, switchTab };
// or just:
Object.assign(window.__app, { state, boot, switchTab });
```

**Fix B: defer the property assignment to after the parent**

Move the `window.__app.chat = { ... }` block to AFTER the
`window.__app = { ... }` parent assignment. Works but spreads the
test-surface across the file in a non-obvious way.

## Why this bites vanilla-JS but not React/Vue

React/Vue `useEffect` / `onMounted` runs after the module body, so
property assignment at module-top-level is fine. Vanilla-JS often
puts the test-surface at module-top-level for the browser console
("I want to call `__app.boot()` from DevTools"). The cost of that
ergonomics is that the file's logical execution order is now
"top-to-bottom," and any property-of-undefined throw is fatal.

## The related duplicate-declaration trap

When you `patch` a file to add a new wrapper around an existing
function, the `patch` only adds — it doesn't remove. The original
function is still there. Module-level `function foo()` declarations
with the same name in the same scope are a `SyntaxError` (caught at
parse time) OR a runtime `Identifier 'foo' has already been declared`
in some loader chains.

**Rule:** when adding a new version of a function via `patch`, the
`old_string` should be the **whole original function body**, not a
single line. Verify with `grep -n 'function foo' file.js` — there
should be exactly one match.

## Verification after any top-of-file change

```js
// From browser console after each file rewrite
typeof boot, typeof __app.boot, typeof __app.switchTab
// All three should be 'function', not 'undefined'
```

If the first is `'function'` but the other two are `'undefined'`,
you have the ordering bug. If the first is `'undefined'`, the boot
function never ran — usually a parse error caught earlier.
