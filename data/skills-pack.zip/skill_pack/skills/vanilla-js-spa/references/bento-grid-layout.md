# Bento-grid layout — "make it more creative" for a dashboard home

When the user says *"change the layouts to be more creative"*,
*"this looks too conventional/static"*, or *"design is messed up, make
it stunning"*, the highest-leverage move on a dashboard home is to
break the boring **vertical stack** (hero → row of N identical stat
cards → 2-col content → list) into an **asymmetric CSS-Grid bento**
where tiles vary in size and the layout fills the full width.

This came out of the WeHax home redesign. Before: hero (full width) →
4 equal stat cards in a row → constellation(8)+donut(4) → findings.
Everything in a narrow centered column with big empty margins. After:
a 12-column bento with a tall green "spotlight" stat, two wide stats,
a big 2-row constellation tile, a stacked donut+stat column, and a
full-bleed findings strip.

## The grid

Use `grid-template-areas` (named regions) — far more legible and
rearrangeable than `grid-column: span N` math. Put the WHOLE home
inside one `.home-bento` wrapper and give each child a `grid-area`.

```css
.home-bento {
  display: grid;
  gap: 16px;
  grid-template-columns: repeat(12, 1fr);
  grid-auto-rows: min-content;
  grid-template-areas:
    "hero hero hero hero hero hero hero hero spot spot spot spot"
    "sa   sa   sa   sa   sb   sb   sb   sb   spot spot spot spot"
    "asm  asm  asm  asm  asm  asm  asm  asm  donut donut donut donut"
    "asm  asm  asm  asm  asm  asm  asm  asm  sc    sc    sc    sc"
    "find find find find find find find find find find find find";
}
.bento-hero  { grid-area: hero; margin: 0 !important; }   /* kill the old mb-4 */
.bento-sa    { grid-area: sa; }
.bento-sb    { grid-area: sb; }
.bento-asm   { grid-area: asm; margin: 0 !important; }
.bento-donut { grid-area: donut; }
.bento-sc    { grid-area: sc; }
.bento-find  { grid-area: find; margin: 0 !important; }
/* make the cards inside fill their grid cell height */
.bento-asm > .card, .bento-find > .card, .bento-donut > .card { height: 100%; }
.bento-asm .asm-stage { height: 100%; min-height: 460px; }   /* taller hero canvas */
```

The asymmetry comes from a tile that spans **2 rows** (here `spot`
spans the hero row + the stats row) right next to single-row tiles.
That vertical anchor is what makes it read as "designed" instead of
"stacked."

## The spotlight tile (dramatic single-metric tile)

One stat gets blown up huge with a gradient number, a meter, and a
glow — far more striking than a 4th identical card. `justify-content:
space-between` pushes the big number to the top and the meter to the
bottom, so the deliberate empty space in the middle looks intentional.

```css
.bento-spotlight {
  grid-area: spot;
  display: flex; flex-direction: column; justify-content: space-between;
  background:
    radial-gradient(ellipse 300px 300px at 70% 10%, rgba(74,222,128,0.16), transparent 60%),
    linear-gradient(160deg, var(--bg-2) 0%, var(--bg-3) 100%);
  border: 1px solid rgba(74,222,128,0.25);
  border-radius: 16px; padding: 24px;
  position: relative; overflow: hidden;
  box-shadow: 0 8px 32px rgba(0,0,0,0.3);
}
.bento-spotlight::after {        /* corner glow blob */
  content: ''; position: absolute; right: -40px; bottom: -40px;
  width: 180px; height: 180px; border-radius: 50%;
  background: radial-gradient(circle, rgba(74,222,128,0.12), transparent 70%);
  pointer-events: none;
}
.bento-spotlight .sp-value {     /* the hero number */
  font-size: 84px; font-weight: 800; line-height: 0.9; letter-spacing: -3px;
  background: linear-gradient(135deg, #4ade80, var(--cyan));
  -webkit-background-clip: text; background-clip: text;
  -webkit-text-fill-color: transparent;
  margin: 12px 0;
}
.bento-spotlight .sp-meter { height: 6px; background: var(--bg-0); border-radius: 3px; overflow: hidden; margin-top: 16px; }
.bento-spotlight .sp-meter-fill { height: 100%; background: linear-gradient(90deg, var(--green), var(--cyan)); border-radius: 3px; transition: width 1s cubic-bezier(0.4,0,0.2,1); }
```

Wire the meter to a real ratio in the data-load:

```js
const totalF = S.findings.length || 1;
const pct = Math.round((verifiedOnly(S.findings).length / totalF) * 100);
if ($('spMeterFill')) $('spMeterFill').style.width = pct + '%';
if ($('spMeterLabel')) $('spMeterLabel').textContent =
  `${verifiedOnly(S.findings).length} of ${S.findings.length} findings verified`;
```

## Responsive collapse — rewrite the areas, not the columns

Don't fight the 12-col grid at small widths. Re-declare
`grid-template-areas` (and switch to 2 or 1 columns) at each
breakpoint. The named regions make this trivial:

```css
@media (max-width: 1100px) {
  .home-bento {
    grid-template-columns: repeat(2, 1fr);
    grid-template-areas:
      "hero hero" "spot spot" "sa sb" "asm asm" "donut sc" "find find";
  }
  .bento-asm .asm-stage { min-height: 380px; }
}
@media (max-width: 640px) {
  .home-bento {
    grid-template-columns: 1fr;
    grid-template-areas: "hero" "spot" "sa" "sb" "asm" "donut" "sc" "find";
  }
}
```

## Beyond home — bento per tab (the "keep continue" extension)

Once the home is a bento, the user will want the *other* tabs to match
("keep continue", "make the layouts more creative" applies to every
pane). Each tab pane that's currently a Bootstrap `row > col-lg-8 /
col-lg-4` split converts cleanly to its own named bento. Two shapes
recur:

**Dominant-left + stacked-right** (Live Feed: big event stream left,
subs + brain stacked right). One wide column (`1.7fr`) spanning both
rows, two right tiles each one row:

```css
.live-bento {
  display: grid; gap: 16px;
  grid-template-columns: 1.7fr 1fr;
  grid-template-areas: "feed subs" "feed brain";
  align-items: stretch;
  min-height: calc(100vh - 160px);   /* fill the viewport, not just content */
}
.bento-feed { grid-area: feed; }   /* > .card { height:100%; display:flex; flex-direction:column } */
.bento-subs { grid-area: subs; }
.bento-brain{ grid-area: brain; }
@media (max-width: 900px) {
  .live-bento { grid-template-columns: 1fr;
    grid-template-areas: "feed" "subs" "brain"; min-height: 0; }
}
```

**Two-up + full-width bottom strip** (Orchestrator: chat left, metrics
right, phase pipeline full-width across the bottom):

```css
.orch-bento {
  display: grid; gap: 16px;
  grid-template-columns: 1.7fr 1fr;
  grid-template-areas: "chat metrics" "pipeline pipeline";
  min-height: calc(100vh - 160px);
}
```

**The key insight: promote inherently-wide content to a full-width
bottom area.** The 6-node horizontal phase stepper was cramped and
barely readable when boxed in a narrow `col-lg-4` right column. Given
its own full-width `pipeline pipeline` row, the gradient progress line
and all 6 evenly-spaced node labels finally have room. Any horizontal
component (steppers, timelines, wide tables, mesh diagrams) belongs in
a full-bleed row, never a sidebar column.

Two alignment wins to verify with the console probe (`offsetHeight`):
- `align-items: stretch` + `> .card { height:100% }` makes the
  left dominant tile and the right tiles end at the same bottom edge
  (e.g. chat 469px == metrics 469px). Eyeball it, then confirm.
- `min-height: calc(100vh - 160px)` makes the bento fill the viewport
  so a near-empty tab doesn't collapse to a thin strip. Drop it (set
  `min-height:0`) at the mobile breakpoint or the single column gets a
  giant blank tail.

**Three-tier bento (Resources): gauge row + L-shape + full-width
strip.** A metrics/resources tab often has 4 small gauges, two
medium panels, and one wide panel. The clean shape is a 4-col grid
where the gauges fill the top row, telemetry + GPU form an L (the
GPU panel spans 2 rows next to the 2-row telemetry chart, so both
end at the same bottom edge — verify with `offsetHeight`, e.g.
both 366px), and the service mesh is a full-width bottom strip:

```css
.res-bento {
  display: grid; gap: 16px;
  grid-template-columns: repeat(4, 1fr);
  grid-template-areas:
    "g1   g2   g3   g4"
    "tele tele tele gpu"
    "tele tele tele gpu"
    "mesh mesh mesh mesh";
}
.bento-g1{grid-area:g1} /* ...g2..g4 */
.bento-telemetry{grid-area:tele} .bento-gpu{grid-area:gpu} .bento-mesh{grid-area:mesh}
@media (max-width:900px){ .res-bento{ grid-template-columns:repeat(2,1fr);
  grid-template-areas:"g1 g2" "g3 g4" "tele tele" "gpu gpu" "mesh mesh"; } }
@media (max-width:560px){ .res-bento{ grid-template-columns:1fr;
  grid-template-areas:"g1" "g2" "g3" "g4" "tele" "gpu" "mesh"; } }
```

## List-heavy tabs: card grids + stat strips, not bento

Bento is for tabs with a few heterogeneous panels. **Tabs that are
one long list** (Subdomains, Findings, Memory) don't bento — instead
make the *list itself* creative:

**Card grid** (Subdomains, Memory) — replace the flat monospace list
with an auto-fill card grid + a filter input + a grid/list view toggle:

```css
.sub-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(240px, 1fr)); gap: 10px; }
.sub-card { display: flex; align-items: center; gap: 11px; padding: 12px 14px;
  background: var(--bg-2); border: 1px solid var(--line); border-radius: 10px;
  position: relative; overflow: hidden; cursor: pointer; transition: all 0.16s; }
.sub-card::before { content:''; position:absolute; left:0; top:0; bottom:0; width:3px; background:var(--cyan); opacity:0.6; }
.sub-card:hover { transform: translateY(-2px); border-color: var(--cyan); box-shadow: 0 6px 18px rgba(0,0,0,0.3); }
```
`minmax(240px, 1fr)` auto-fills 3+ columns on desktop, collapses to 1
on mobile with zero media queries. Make each card click-to-copy
(`navigator.clipboard?.writeText` + toast) and render a hidden copy
icon that fades in on `:hover`. Keep a `_subView` flag + `setSubView()`
for grid↔list, persisted nowhere (transient is fine). The same
`.mem-card` shape works for memory entries (type tag + time-ago +
content + meta pills).

**Stat strip** (Findings) — a row of 6 colored severity chips above
the table that double as one-click quick-filters:

```css
.sev-strip { display: grid; grid-template-columns: repeat(6, 1fr); gap: 10px; margin-bottom: 18px; }
.sev-chip { position: relative; padding: 14px 12px; border-radius: 12px; cursor: pointer;
  border: 1px solid var(--line); background: var(--bg-2); overflow: hidden; transition: all 0.18s; }
.sev-chip::before { content:''; position:absolute; left:0; top:0; bottom:0; width:3px; background:var(--c,var(--text-3)); }
.sev-chip.active { border-color: var(--c); background: color-mix(in srgb, var(--c) 12%, var(--bg-2)); }
.sev-chip .sc-n { font-size:26px; font-weight:800; color:var(--c); letter-spacing:-1px; }
.sev-chip.critical{--c:var(--red)} .sev-chip.high{--c:var(--orange)} /* medium amber, low cyan, info green, all brand */
```
`quickSev(sev)` sets the `<select>` filter value and re-renders.
**Gotcha**: the filter dropdown must contain an `<option>` for every
chip you offer — clicking the "info" chip set `select.value='info'`
silently to `''` because there was no `info` option, so it filtered
to nothing. Add the missing options when you add the chips.

## Polish layers (mesh bg, entrance stagger, skeleton shimmer)

Three cheap CSS-only layers that lift a finished dashboard from "clean"
to "stunning" — all gated behind `@media (prefers-reduced-motion)`:

- **Animated gradient mesh background**: a `body::before` fixed full-
  viewport layer with 3-4 drifting radial blobs + a 32s `meshDrift`
  keyframe (translate+scale+rotate, `infinite alternate`). Sits at
  `z-index:0`; bump `.main-wrapper`/`.sidebar` to `z-index:1` and keep
  fixed overlays (toasts/modals/minimap) far above. Dim to 60% in
  light mode.
- **Tile entrance stagger**: a `tileIn` keyframe (opacity+translateY+
  scale) applied to `.anim-in [class$="-bento"] > *` with incremental
  `animation-delay` per `:nth-child`. Retrigger on tab switch in
  `setTab()`: `pane.classList.remove('anim-in'); void pane.offsetWidth; pane.classList.add('anim-in')`
  (the forced reflow is what re-fires the animation).
- **Skeleton shimmer**: paint `<div class="skeleton"><div class="sk-row">`
  rows (diagonal gradient sweep, 1.4s loop) into list containers at the
  very start of `boot()`, before any data arrives. Real renders replace
  them automatically.

## Decluttering a busy header — overflow "⋯" menu

After adding many header toggles (theme, palette, help, bell, sound,
presentation, panic = 9 buttons), group the utility/danger toggles into
one "⋯" dropdown. Keep the high-frequency ones (theme, palette, help,
bell) as direct icons; move sound/presentation/panic into a
`.overflow-menu` opened by `toggleOverflow()` with a delegated
document click-outside-to-close. Menu items keep their text labels +
icons; toggle state shows via an `.on` class (purple) and the danger
item (panic) is red below an `.ovf-sep`. The toggle functions that
swap an icon must target the inner `<i>`, not `innerHTML`, so the text
label span survives.

## Pitfalls

- **Old margin classes fight the grid gap.** The original tiles had
  Bootstrap `mb-4` / lived inside `.row.g-3` columns. When you lift
  them into the bento, strip the row/col wrappers and add
  `margin: 0 !important` to the grid children, or you get
  double-spacing.
- **A canvas tile won't auto-grow.** Give the `.card` `height: 100%`
  and the canvas-stage a `min-height`, AND make sure the canvas
  renderer reads `offsetWidth`/`offsetHeight` each draw (it already
  does if you followed the "scale with viewport" pattern). After the
  layout change the constellation went from 380px → 487px tall and
  the canvas auto-resized to 606×484 with no JS change.
- **Verify grid areas resolve** after wiring. One quick console probe
  catches a typo'd area name (which silently drops the tile to
  `auto`/overlapping):
  ```js
  ['.bento-hero','.bento-spotlight','.bento-sa','.bento-sb','.bento-asm',
   '.bento-donut','.bento-sc','.bento-find'].forEach(s => {
    const el = document.querySelector(s);
    console.log(s, el ? getComputedStyle(el).gridArea.split('/')[0].trim() : 'MISSING');
  });
  ```
  Every selector should print its own region name, none `MISSING`.
- **"Creative" ≠ "functional-but-plain."** For this user the bar is
  gradients + glow + varied tile sizes + edge-to-edge width. A tidy
  symmetric grid is below the bar — push the visual polish (a tall
  spotlight, a corner glow blob, a gradient hero number), not just a
  reflow.
