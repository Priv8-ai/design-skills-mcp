# Sidebar progress rows — animated per-scan cards under the activity footer

When the dashboard sidebar has a sticky activity footer showing "scanning
N", users want to know WHICH scans are running, not just the count.
Solution: a list of compact progress rows below the footer, one per
running scan, with the target name + current phase + a percentage bar
that animates smoothly.

## HTML — sticky footer + progress container

```html
<aside class="sidebar-nav-wrapper">          <!-- overflow-y: auto; height: 100vh -->
  <nav class="sidebar-nav">...</nav>
  <div class="sidebar-activity" id="sidebarActivity">  <!-- sticky bottom -->
    <div class="act-pulse"></div>
    <div class="act-text">
      <span class="act-label">scanning</span>
      <span class="act-count" id="sidebarActCount">0</span>
    </div>
    <button class="act-stop" id="stopAllBtn" style="display:none">
      <i class="lni lni-close"></i>
    </button>
  </div>
  <!-- progress rows: hidden when no scans are running -->
  <div class="sidebar-progress" id="sidebarProgress"></div>
</aside>
```

The progress div is a sibling of the activity footer, not nested inside.
When `:empty` it auto-hides via CSS.

## CSS — 12 lines

```css
.sidebar-progress { margin: 0 12px 12px; display: flex; flex-direction: column; gap: 6px; }
.sidebar-progress:empty { display: none; }
.scan-row { padding: 8px 10px; background: var(--bg-0); border: 1px solid var(--line);
  border-radius: 8px; transition: all 0.2s; }
.scan-row:hover { border-color: var(--brand); transform: translateX(2px); }
.scan-row .scan-row-top { display: flex; align-items: center; gap: 8px; margin-bottom: 6px; }
.scan-row .scan-row-target { flex: 1; font-size: 12px; font-weight: 600;
  color: var(--text); white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.scan-row .scan-row-phase { font-size: 9px; color: var(--text-3);
  text-transform: uppercase; letter-spacing: 1px; font-weight: 600; }
.scan-row .scan-row-pct { font-size: 11px; font-weight: 800;
  color: var(--brand-2); font-family: 'SF Mono', monospace; min-width: 36px; text-align: right; }
.scan-row .scan-row-bar { height: 4px; background: var(--line); border-radius: 2px; overflow: hidden; }
.scan-row .scan-row-bar-fill { height: 100%;
  background: linear-gradient(90deg, var(--brand) 0%, var(--cyan) 100%);
  border-radius: 2px; transition: width 0.6s ease; }
```

The hover micro-interaction (translateX 2px + brand border) is the polish
that makes these feel alive without being annoying.

## JS — phase-to-percentage estimation, render in loadAll

```js
// In loadAll() — populates the progress list every refresh
const progressEl = $('sidebarProgress');
if (progressEl) {
  const running = S.scans.filter(s => s.status === 'running');
  if (!running.length) {
    progressEl.innerHTML = '';                  // CSS hides the container
  } else {
    progressEl.innerHTML = running.slice(0, 5).map(s => {
      const phase = s.current_phase || 'init';
      const pct = phasePct[phase] ?? 50;        // unknown phase → 50%
      const target = (s.domain || s.scan_id || '').slice(0, 24);
      return `<div class="scan-row" onclick="setTab('home')" title="Click to view">
        <div class="scan-row-top">
          <span class="scan-row-target">${esc(target)}</span>
          <span class="scan-row-phase">${esc(phase)}</span>
          <span class="scan-row-pct">${pct}%</span>
        </div>
        <div class="scan-row-bar"><div class="scan-row-bar-fill" style="width:${pct}%"></div></div>
      </div>`;
    }).join('') + (running.length > 5 ? `<div style="text-align:center;font-size:10px;color:var(--text-3);padding:4px">+${running.length - 5} more</div>` : '');
  }
}
```

## Phase → percentage map

When the orchestrator doesn't expose a real progress field, derive a
rough percentage from the current phase. The map below covers WeHax's
pipeline; adjust for your domain:

```js
const phasePct = {
  init: 8,
  OSINT: 20,
  subdomains: 38,
  'cdn-waf': 48,
  toolswarm: 65,
  exploit: 82,
  verify: 92,
  report: 98,
  completed: 100,
  failed: 0,
  cancelled: 0,
  paused: 30,
};
```

Two things to know:
- **Unknown phases default to 50%** so the bar doesn't jump to 0 and
  look broken if a new phase gets added upstream.
- **Failed/cancelled → 0%** so the operator immediately sees the scan
  is in a terminal bad state, not in progress.

## The 0.6s ease transition matters

`transition: width 0.6s ease` on the bar fill makes percentage changes
look like the scan is moving, even when the actual orchestrator
updates are coarse (phase changes every few seconds). When the phase
jumps from "subdomains" (38%) to "toolswarm" (65%), the bar smoothly
glides rather than snapping. This is the single visual difference
between "looks alive" and "looks broken."

## Cap at 5 rows, +N more overflow

A 250px-wide sidebar gets cramped above 5 rows. Slice to 5, then show
"+N more" if there are more. Users who want the full list can click
"All Scans" in the header.

## When to use this pattern

- The dashboard has long-running async work (scans, builds, deploys,
  data imports) that the operator watches
- The sidebar already has a sticky activity footer — the progress
  rows are a natural extension
- Users have asked "what's running right now" or "how far along is X"

Skip when:
- The app is synchronous (CRUD forms, settings, simple reports)
- The "activity" is just a heartbeat ping, not a long-running task
