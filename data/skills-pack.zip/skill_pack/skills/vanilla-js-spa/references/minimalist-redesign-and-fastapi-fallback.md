# Minimalist redesign: 8 MB PlainAdmin → 60 KB hand-crafted

When the user says "super simple and stunning", "make it minimalist",
"Linear-grade", or otherwise pushes back on a heavy admin-template
dashboard, the right move is a **complete rebuild** of the front-end
files, not iterative slimming of the heavy version. The bento
grid, the 138 asset files, the glassmorphism, the gradient mesh
— all of it goes. What replaces it is a single 3-column layout
with one accent color, a command bar (⌘K), and 3 well-typed
tabs. This doc captures the rebuild pattern + the six pitfalls
that show up during it.

## The lean target

```
app.html   ~8 KB   ── one HTML file, semantic markup, no script tags inline
app.css   ~23 KB   ── one stylesheet, CSS custom properties, ~12 rules
app.js    ~28 KB   ── one IIFE, vanilla, no framework
─────────────────────────────────────────────────────
TOTAL      ~60 KB  (down from 8.6 MB PlainAdmin)
```

That's a **144× reduction** and a real speedup. Page renders
under 50ms. No build step. No npm. The whole UI fits in your
head and survives a fresh `cp -r` to a new project.

## Design language to copy

Linear × Vercel × Stripe. Three rules:

1. **Monochrome base + one accent.** `--bg: #0A0A0B`, `--text:
   #EDEDEF`, `--line: #26262E`, `--brand: #8B5CF6` (electric
   purple). Status colors only when meaningful: green for
   verified, red for rejected, orange for critical, blue for info.
2. **Generous whitespace, sharp typography.** 14px base, 13px in
   dense lists, 11px mono for IDs/timestamps. `letter-spacing:
   -.01em` on titles. `font-feature-settings: "tnum"` on
   numeric stat cards (so digits line up).
3. **Subtle motion, no flash.** 0.15s hover transitions,
   1.6s pulse on the WebSocket live dot. No full-screen flashes,
   no parallax, no particle effects.

The bento is OUT. The 3-column responsive grid is IN:

```
┌─ Top bar (56px): brand · ⌘K · live status · theme ──────────┐
├──────────┬────────────────────────────────────┬──────────┤
│ TARGET   │  Tabs · 4 chips with count badges  │ BRAIN    │
│ (320px)  │  ──────────────────────────────    │ (360px)  │
│  form    │  (single scrollable timeline per   │ status   │
│  stats   │   active tab — no bento sub-grids) │ chat     │
└──────────┴────────────────────────────────────┴──────────┘
```

`grid-template-columns: 320px 1fr 360px` on desktop, single
column on `max-width: 1024px` (right + left panels `display:
none`, the center tabs become a single-column mobile UI).

## Implementation steps

1. Write `app.html` (8 KB): semantic markup, no script tags
   inline (load `app.js` at end of body), no `onclick=` attributes
   (wire via `addEventListener` from JS).
2. Write `app.css` (23 KB): CSS custom properties on `:root` for
   tokens, one `data-theme` selector for light mode override
   (NOT `body.light` — see the `theme-and-responsive.md` reference
   for the cascade gotcha), media queries at 1024/768/576.
3. Write `app.js` (28 KB): single IIFE, one `S` state object,
   `el()`/`$()` helpers, `api()` wrapper, `render*()` functions,
   `wireButtons()`, `boot()`.
4. Update the FastAPI server: prefer `app.html`, fall back to
   `dashboard.html` (see "FastAPI 3-tier serve" below).
5. Delete the old PlainAdmin assets. Don't keep them as
   "fallback" — the moment they're on disk, `script src` and
   `link href` paths keep accidentally resolving to them.

## FastAPI 3-tier serve — prefer the new, fall back to the old

```python
# In wex/dashboard/api.py, near the static mount block

dash_dir = ROOT / "wex" / "dashboard"
app_html = None
for candidate in ("app.html", "dashboard.html"):
    p = dash_dir / candidate
    if p.exists():
        app_html = p
        break
if app_html:
    @app.get("/", response_class=HTMLResponse)
    async def index():
        return app_html.read_text()
if (dash_dir / "static").exists():
    app.mount("/static", StaticFiles(directory=str(dash_dir / "static")), name="static")
```

This lets you keep the old `dashboard.html` for one release as
a safety net while the new `app.html` is being verified, then
delete the old one once you're confident.

**Pitfall**: if you ALSO serve the new file at
`wex/dashboard/static/dashboard.html` (under `/static/`), it
will be returned at `/static/dashboard.html` AND the
`/` route will pick up `wex/dashboard/dashboard.html` (the
old one). The two paths can silently disagree. **Don't
duplicate filenames across `wex/dashboard/` and
`wex/dashboard/static/`** — pick one location per file.

## Pitfall 1 — server still serves the old file after you replaced it

Symptom: you replaced `dashboard.html` with the new 8 KB design.
The file on disk is 8 KB. But `curl http://127.0.0.1:8777/`
returns 143 KB (the old version).

Three causes, in order of likelihood:

1. **Old background process still owns the port.** The new server
   you launched as `pid 93688` got EADDRINUSE, and the old one
   keeps serving the old file. Fix: kill the old one explicitly
   via the port, not the pid:
   ```bash
   lsof -ti tcp:8777 | xargs kill -9
   sleep 1
   python wex.py serve --port 8777
   ```
2. **`uvicorn` worker inherited the old process state.** Even if
   you `kill <pid>` the parent, the worker child keeps running.
   `lsof -ti tcp:8777` finds the actual worker process.
3. **The HTML-route was on `dash_dir / "dashboard.html"`** and
   the API caches the file at boot. Restart the server after
   renaming files (the route is fine, but the in-memory `app_html`
   reference might be stale if you used a one-shot global).

The verification: `curl -s http://127.0.0.1:8777/ | wc -c` should
equal `wc -c < path/to/served/file`. If they differ, the server
isn't serving the file you think.

## Pitfall 2 — `window.fn` is defined but is the OLD version

The "stale-page diagnostic" in SKILL.md covers "function not on
window". The more common case: the function IS on window, but is
the OLD version because the browser cached the old `.js` file.

Symptom: you just added a new code path to `app.js` (`fndRow` now
has a `freject` line), `findingRow.toString()` shows the OLD
source, the rendered output matches the old version.

```js
// In the browser console
findingRow.toString().substring(0, 400)
// if it does NOT contain 'freject', the browser is using a cached
// version of the file. The server is serving the new one — the
// browser just hasn't fetched it.
```

Recovery ladder:

1. `location.reload(true)` — sometimes works, sometimes doesn't.
2. `browser_navigate` to the same URL with a fresh cache-buster:
   `?_=99` (any new query string).
3. **The reliable one**: kill the old browser session and open
   fresh. F5 in a headless context is unreliable because the
   cache headers might be `Cache-Control: max-age=0` but
   `Last-Modified` can still cause revalidation.
4. Nuclear: `localStorage.clear(); sessionStorage.clear();` then
   reload.

`node --check /path/to/app.js` first to confirm the on-disk
file actually has your new code — if it does, then it's a browser
cache problem and a hard reload is the answer.

## Pitfall 3 — countUp animates the wrong way during snapshots

When you do `countUp('homeFindings', 24)` after the user opened
the page, the visible number animates from whatever was there
(0, or a stale 19) up to 24 over 700ms. A browser snapshot
captured mid-animation shows the in-between value (e.g. 7), and
the operator thinks "the dashboard says only 7 findings, the
scan produced 24."

The fix is two-sided:

**Renderer side** — don't `countUp` on first render. Detect the
first render and just set the value directly:

```js
const _firstRender = new Set();
function countUp(id, target, dur = 700) {
  const el = $(id); if (!el) return;
  const isFirst = !_firstRender.has(id);
  _firstRender.add(id);
  if (isFirst) { el.textContent = target; return; }
  // ... existing animation logic
}
```

**Verification side** — when probing the dashboard after a
state change, wait at least 1 second before reading the count:

```js
await new Promise(r => setTimeout(r, 1200));
const n = document.getElementById('homeFindings')?.textContent;
```

The 700ms animation + 200ms paint buffer is the safe window. If
the number still doesn't match expectations after that, the
data path is wrong (not the animation).

## Pitfall 4 — command bar with generic items triggers accidental launches

A common pattern is: clicking the top-bar ⌘K button opens a
modal, the user types a search term, presses Enter, and the
focused item launches a scan they didn't want.

The bug: the modal renders 12 items even when the user typed
"auth", and the first item is "Launch scan". Pressing Enter
runs "Launch scan" — not the matching "Run auth_hunter" two
rows down.

The fix: **split the command bar into two modes**:

- **Empty input** → show the FULL menu (5 tabs + 6 generic
  commands, 11 total). User can press Enter on any.
- **Non-empty input** → show ONLY items that actually match
  the filter. The first item is always a real result.
  Generic commands (Launch, Reset, Theme) are HIDDEN when
  the user is actively searching.

```js
function buildCmdList(filter) {
  const items = [];
  const f = (filter || '').toLowerCase().trim();
  const matches = (s) => !f || s.toLowerCase().includes(f);
  const hasFilter = f.length > 0;

  // ── Tab nav is always shown (filter-aware) ─────────────────
  for (const t of ['feed', 'findings', 'subs', 'tools', 'history']) {
    if (matches(t) || matches('tab') || matches('go') || !hasFilter) {
      items.push({ icon: '▸', text: 'Go to ' + t, sub: 'tab', action: () => { setTab(t); closeCmd(); } });
    }
  }

  // ── Generic actions (only when no filter) ─────────────────
  if (!hasFilter) {
    items.push({ icon: '▶', text: 'Launch scan', sub: 'enter domain in left form', action: () => { $('domain').focus(); closeCmd(); } });
    // ... 5 more
  }

  // ── Filtered matches (only when user typed something) ─────
  if (hasFilter) {
    for (const t of _tools) {
      if (matches(t.name) || matches(t.category)) {
        items.push({ icon: '⚙', text: 'Run ' + t.name, sub: t.category, action: () => { runTool(t.name); closeCmd(); } });
      }
    }
    for (const s of S.scans) {
      if (matches(s.domain) || matches(s.scan_id) || matches(s.status || '')) {
        items.push({ icon: '◎', text: 'Open ' + s.domain, sub: `${s.status} · ${s.current_phase} · ${s.finding_count}F`, action: () => { openScan(s.scan_id); closeCmd(); } });
      }
    }
    for (const fnd of S.findings) {
      if (matches((fnd.type || '') + ' ' + (fnd.target || '') + ' ' + (fnd.detail || ''))) {
        items.push({ icon: 'F', text: `${fnd.severity} · ${fnd.type} · ${fnd.target}`, sub: (fnd.detail || '').slice(0, 80), action: () => { setTab('findings'); closeCmd(); } });
      }
    }
  }
  return items;
}
```

The two-mode split is the whole game. With it, "auth" → 1 match
(`Run auth_hunter`). Without it, "auth" → 11 items, first one
is `Go to feed`, and Enter jumps to the feed tab instead of
running the tool the user was searching for.

## Pitfall 5 — `[hidden]` attribute is silently overridden by `display: flex/grid/block`

The HTML `hidden` attribute sets `display: none` via the UA
stylesheet, but any class rule that sets a different
`display` value on the same element wins by CSS specificity.
This is the most common cause of "my modal/popup/panel shows
up on page load and covers the whole page, blanking the
content".

Symptom: the user takes a screenshot and reports "the
dashboard shows nothing". You open the page in a real
browser and it works. The screenshot is taken in a context
where the JS didn't run (or ran late) so the modal is
showing in its initial state with a 60% black backdrop +
blur, completely blanking the still-empty page.

Example that bit me — the command-bar modal:

```html
<div class="modal-mask" id="cmdMask" hidden>
  <div class="cmd-modal">...</div>
</div>
```

```css
/* WRONG — `hidden` is silently overridden */
.modal-mask {
  display: flex; align-items: flex-start; justify-content: center;
  /* ... */
}
/* The HTML `hidden` attribute sets `display: none`, but this
   class rule wins. The modal renders from the very first
   frame, before any JS runs. */
```

**Two fixes, both correct:**

```css
/* Option A — use [hidden] in the rule (preferred) */
.modal-mask { display: flex; /* normal state */ }
.modal-mask[hidden] { display: none !important; }

/* Option B — never rely on the `hidden` attribute; toggle a class */
.modal-mask { display: none; }
.modal-mask.open { display: flex; }
```

Option A keeps the markup semantic (no extra class), the
`!important` is OK because it's scoped to the attribute
selector. Option B is more explicit but adds a class to the
JS open/close path.

**The diagnostic**: when the user says "the page is blank"
and a browser snapshot is empty, do a `getComputedStyle`
check on the suspected covering element:

```js
const m = $('cmdMask');
console.log({
  hidden: m.hidden,                          // true
  display: getComputedStyle(m).display,      // 'flex' — the bug
  hasAttribute: m.hasAttribute('hidden'),    // true
});
```

`hidden: true` + `display: 'flex'` = the bug. The fix is the
CSS rule above.

This applies to every element type: modals, side panels,
"loading" overlays, "X is empty" empty states, etc. If the
element uses the `hidden` attribute and also has a class
that sets `display: <something>`, the class wins. **Either
remove the `display: <something>` from the default class, or
add the `[hidden] { display: none !important; }` safety
rule.**

The matching JS that toggles the attribute stays the same
either way:

```js
$('cmdBtn').addEventListener('click', () => {
  $('cmdMask').hidden = false;   // remove the [hidden] attribute
  $('cmdInput').focus();
});
function closeCmd() {
  $('cmdMask').hidden = true;    // re-add the [hidden] attribute
}
```

## Pitfall 6 — diagnosing a "blank page" screenshot without vision credits

Sometimes the user uploads a screenshot of a blank-looking
page and you have no vision budget to look at it. Three
recovery paths, in order of how often they catch the real
cause:

**1. OCR the screenshot with macOS Vision + Swift.** This
gets you the visible text + bounding-box coordinates in
~2 seconds, no API credits required. Save this snippet to
`/tmp/ocr.swift`:

```swift
// /tmp/ocr.swift
import Foundation
import Vision
import AppKit

let path = CommandLine.arguments[1]
let url = URL(fileURLWithPath: path)
guard let image = NSImage(contentsOf: url),
      let cgImage = image.cgImage(forProposedRect: nil, context: nil, hints: nil) else {
    print("could not load image"); exit(1)
}

let request = VNRecognizeTextRequest { (request, error) in
    guard let obs = request.results as? [VNRecognizedTextObservation] else { exit(0) }
    let sorted = obs.sorted { $0.boundingBox.maxY > $1.boundingBox.maxY }
    for o in sorted {
        if let t = o.topCandidates(1).first {
            let bb = o.boundingBox
            // Vision uses bottom-left origin; convert to top-left
            let x = Int(bb.minX * 100), y = Int((1 - bb.maxY) * 100),
                w = Int(bb.width * 100), h = Int(bb.height * 100)
            print("[\(x),\(y),\(w)x\(h)] \(t.string)")
        }
    }
}
request.recognitionLevel = .accurate
request.minimumTextHeight = 0.001   // catch small text

try VNImageRequestHandler(cgImage: cgImage, options: [:]).perform([request])
```

```bash
# Copy the screenshot to a path without weird Unicode first
# (screenshot filenames often have \u202f non-breaking space
#  before AM/PM, which breaks cp / open in scripts)
cp "/path/to/Screenshot 1447-12-26 at 5.29.03\u202fPM.png" /tmp/shot.png
swift /tmp/ocr.swift /tmp/shot.png
```

If the OCR returns mostly browser chrome + a modal title
("Type a command, search tool, or jump to scan…") and
**zero text from the page itself**, the page content is
invisible to the user — usually the Pitfall 5 case (modal
covering everything) or a CSS issue that's hiding the
layout panels.

**2. Crop the screenshot to a specific region and OCR that.**
When the full-image OCR returns too much noise (browser
tabs, URL bar), write a small variant that takes crop
coordinates and OCRs only that region:

```swift
// /tmp/ocr3.swift — takes (x%, y%, w%, h%) as 2nd arg
// Crops cgImage to that region in pixel space, then OCRs it.
// Page content is usually 0-100% X, 7-95% Y (skip browser chrome)
swift /tmp/ocr3.swift /tmp/shot.png 0,7,100,88
```

**3. Read the file metadata to bound the problem.**

```bash
# What the user saw
file /tmp/shot.png            # dimensions, color space
sips -g all /tmp/shot.png     # pixel width/height
stat -f "modified: %Sm" /tmp/shot.png  # when was the screenshot taken
```

If the screenshot is 9x larger than a known-good empty-state
screenshot (e.g. 538 KB vs 57 KB), the page is showing rich
content (likely the OLD dashboard, not the new one). The
user is probably looking at a stale `dashboard.html` route
or a port collision with an old server (Pitfall 1).

**Combine with the `findingRow.toString()` check** to confirm
the browser actually fetched the new JS — if the toString
matches the on-disk source, the issue is CSS, not JS.

## The "Show all N" pattern for large lists

When the API has 2000+ findings or 5000+ subdomains, you can't
render them all in a virtual-scroll-free vanilla page. Render
200 by default, show a "Show all N" button at the bottom that
sets a `S._showAll = true` flag and re-renders.

```js
function renderFindings() {
  const list = S.findings.filter(/* ... */);
  const renderLimit = S._showAll ? list.length : Math.min(list.length, 200);
  // ... render list.slice(0, renderLimit) ...
  host.innerHTML = list.slice(0, renderLimit).map(/* ... */).join('')
    + (list.length > renderLimit
        ? `<div class="show-all"><button id="showAllFindings">Show all ${list.length} findings</button></div>`
        : '');
  const sfa = document.getElementById('showAllFindings');
  if (sfa) sfa.addEventListener('click', () => { S._showAll = true; renderFindings(); });
}
```

```css
.show-all { padding: 12px 16px; text-align: center;
  border-top: 1px solid var(--line); background: var(--bg-1); }
.show-all button { font-size: 12px; color: var(--text-2);
  padding: 6px 14px; border: 1px solid var(--line);
  border-radius: 6px; transition: all .15s; }
.show-all button:hover { color: var(--brand-2); border-color: var(--brand); }
```

On the server side, **bump the default limit** so the UI has
all the data available when the user clicks "Show all":

```python
# API default caps (default-limit means "if no ?limit= provided, return this many")
@app.get("/scans/{scan_id}/findings")
async def get_findings(scan_id: str, limit: int = 2000) -> dict:    # was 200
    ...

@app.get("/scans/{scan_id}/subdomains")
async def get_subs(scan_id: str, limit: int = 5000) -> dict:        # was 500
    ...
```

The user sees 200 rows + a "Show all 4,827" button. Click → all
4,827 render. The 4,827 are already in `S.findings` from the
load step; no extra API call.

## When the user is happy with 60 KB, don't add 600 KB

The minimalist redesign temptation is to "polish" the lean
version with the same bento / glassmorphism / mesh that the
old version had. Don't. The lean version's value IS the
absence of those layers. If the user wants bento, they
wouldn't have asked for minimalist in the first place.

The four polish moves that DO survive on a minimalist design:

1. **Animated count-up on stat numbers** — 700ms cubic ease
   on the verified/subs counter, feels polished without weight.
2. **Live dot pulse on WebSocket** — 1.6s expanding-ring
   animation, 4 lines of CSS, signals "real-time" without
   being loud.
3. **Hover lifts on tool cards** — `transform: translateY(-1px)`
   + `border-color: var(--brand)` on hover. 2 CSS lines.
4. **Severity-pitched chimes on new findings** — WebAudio 2
   oscillators (sine + triangle), 0.6s envelope, gated on a
   user toggle. Optional, not on by default (autoplay norms).

Everything else (gradient mesh, count-up, skeleton shimmer,
constellation pulse) is a polish layer that fights the
minimalist aesthetic. If the user is in "Linear-grade" mode,
those layers are wrong even if they look good in isolation.
