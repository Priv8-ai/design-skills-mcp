# Command Palette (⌘+K / Ctrl+K) — full pattern

VSCode-style command palette: an input-driven overlay that fuzzy-searches
across tabs, modals, and actions, with keyboard nav (↑↓↵) and click-to-run.
The killer feature for any non-trivial dashboard. Once users discover it,
they use it for everything — it's faster than clicking nav, works on mobile
where nav is collapsed, and surfaces actions the user didn't know existed.

## Trigger

Add a ⌘+K command palette when:
- The dashboard has ≥8 navigation targets (tabs, modals, actions) — below
  that, the modal-cycles-helpful is overkill
- The user has power-user traits (you can guess from their other asks:
  "add keyboard shortcuts", "make it more efficient", "add a search bar
  for actions")
- The mobile sidebar collapses to icon-only and users lose text labels —
  the palette brings them back

Skip when:
- The app has <5 navigation targets
- The user is non-technical and unlikely to learn shortcuts

## The COMMANDS array

Single source of truth, plain JS array of objects, each with icon + label
+ sub-description + action + search keywords:

```js
const COMMANDS = [
  // tabs
  { id:'tab-home',   icon:'lni-dashboard',     label:'Dashboard',     sub:'home view',           action: () => setTab('home'),         kw:'home dashboard overview' },
  { id:'tab-live',   icon:'lni-rss-alt',       label:'Live Feed',     sub:'realtime events',     action: () => setTab('live'),         kw:'live events feed realtime stream' },
  { id:'tab-find',   icon:'lni-warning',       label:'Verified Findings', sub:'explore & inspect', action: () => setTab('findings'),     kw:'findings vulnerabilities results' },
  { id:'m-new',      icon:'lni-plus',          label:'New Scan',      sub:'launch a scan',       action: () => openModal('modal-newscan'), kw:'new scan start create launch' },
  { id:'a-stop',     icon:'lni-close',         label:'Stop All Running Scans', sub:'kill all',       action: () => $('stopAllBtn')?.click(), kw:'stop cancel kill terminate' },
  { id:'a-wipe',     icon:'lni-trash',         label:'Wipe All Data', sub:'delete every scan',   action: () => wipeAllData(),          kw:'wipe delete reset clean data scans' },
  // ... 20+ more
];
```

Three things to get right:
- **`kw` (keywords)** — natural-language synonyms the user might type.
  "find" should match "Verified Findings" via `kw:'findings vulnerabilities
  results'`, AND "realtime" should match Live Feed via `kw:'live events
  feed realtime stream'`. Make the `kw` 5-10 words covering the obvious
  ways a user would search for this.
- **`sub`** — short context, shown under the label. "tab · home view"
  or "action · confirm first" or "toolbox · attack payloads". Helps
  users distinguish two commands with similar labels.
- **`action`** — closure capturing whatever's needed. If the action needs
  to navigate AND open a modal, do both in sequence:
  `action: () => { setTab('home'); setTimeout(() => openModal('modal-new'), 100); }`

## Fuzzy scorer (no library, 8 lines)

```js
function fuzzyScore(cmd, q) {
  q = q.toLowerCase().trim();
  if (!q) return 1;                                  // empty query → show all
  const hay = (cmd.label + ' ' + cmd.sub + ' ' + (cmd.kw||'')).toLowerCase();
  if (hay.includes(q)) return 10 + (hay.startsWith(q) ? 5 : 0);  // exact / starts-with wins
  // fuzzy: every char of q must appear in hay in order
  let i = 0;
  for (const ch of hay) { if (ch === q[i]) i++; if (i === q.length) return 5; }
  return 0;
}
```

Ranking: exact substring match (10) > starts-with (15) > fuzzy-in-order (5).
Empty query returns 1 for all (sorted, capped at 12 shown).

Don't bother with a real fuzzy library (fuse.js) for ≤30 commands — the
above is fast, deterministic, and zero-dependency.

## Modal HTML — custom layout, hide the standard .box

The standard `.wehax-modal .box` is centered with rounded corners and a
backdrop. The palette wants a top-anchored, narrower, no-radius panel.
Hide the standard box and use a custom shell:

```html
<div class="wehax-modal" id="modal-palette" data-palette>
  <div class="palette-shell">
    <div class="palette-input-wrap">
      <i class="lni lni-search-alt"></i>
      <input id="paletteInput" type="text" placeholder="Type a command, tab, or action…"
             autocomplete="off" spellcheck="false" />
      <span class="palette-shortcut"><kbd>⌘</kbd><kbd>K</kbd></span>
    </div>
    <div id="paletteList" class="palette-list"></div>
    <div class="palette-foot">
      <span><kbd>↑</kbd><kbd>↓</kbd> navigate</span>
      <span><kbd>↵</kbd> run</span>
      <span><kbd>esc</kbd> close</span>
      <span style="margin-left:auto;color:var(--text-3)" id="paletteCount">0 commands</span>
    </div>
  </div>
</div>
```

```css
.wehax-modal[data-palette] { padding: 0; align-items: flex-start; padding-top: 14vh; }
.wehax-modal[data-palette] .box { display: none; }              /* hide standard box */
.wehax-modal[data-palette] .palette-shell { display: block; ... }
```

The `data-palette` attribute lets the CSS target only the palette modal
without polluting the others.

## CSS — three layers, 30 lines total

```css
.palette-input-wrap { display: flex; align-items: center; gap: 12px;
  padding: 14px 16px; border-bottom: 1px solid var(--line); }
.palette-input-wrap input { flex: 1; background: transparent; border: 0;
  color: var(--text); font-size: 16px; outline: none; }
.palette-item { display: flex; align-items: center; gap: 12px;
  padding: 10px 12px; border-radius: 8px; cursor: pointer; transition: background 0.1s; }
.palette-item.active { background: linear-gradient(135deg, rgba(124,92,255,0.20) 0%, rgba(56,232,255,0.10) 100%); }
.palette-item.active i { color: var(--brand-2); }
.palette-foot { display: flex; align-items: center; gap: 14px;
  padding: 8px 16px; border-top: 1px solid var(--line);
  background: var(--bg-0); color: var(--text-3); font-size: 10.5px; }
.palette-empty { padding: 40px 20px; text-align: center; color: var(--text-3); }
```

Light theme inherits via the same `var(--bg-2)`, `var(--line)`, etc.
No special-case rules needed.

## Open / render / run / move

```js
let _palIdx = 0;
let _palResults = [];

function openPalette() {
  renderPalette('');                       // start with all
  openModal('modal-palette');
  setTimeout(() => $('paletteInput')?.focus(), 50);   // wait for show transition
}

function renderPalette(q) {
  _palResults = COMMANDS
    .map(c => ({ c, s: fuzzyScore(c, q) }))
    .filter(r => r.s > 0)
    .sort((a,b) => b.s - a.s)
    .slice(0, 12)                           // cap at 12 visible
    .map(r => r.c);
  _palIdx = 0;
  const list = $('paletteList');
  if (!list) return;
  if (!_palResults.length) {
    list.innerHTML = '<div class="palette-empty"><i class="lni lni-search"></i> no matches for "'+esc(q)+'"</div>';
    return;
  }
  list.innerHTML = _palResults.map((c, i) => `
    <div class="palette-item ${i===0?'active':''}" data-i="${i}" onclick="paletteRun(${i})">
      <i class="${c.icon}"></i>
      <div class="palette-text">
        <div class="palette-label">${esc(c.label)}</div>
        <div class="palette-sub">${esc(c.sub||'')}</div>
      </div>
      <span class="palette-enter"><kbd>↵</kbd></span>
    </div>`).join('');
}

function paletteRun(i) {
  const c = _palResults[i];
  if (!c) return;
  closeModal('modal-palette');
  try { c.action(); } catch (e) { console.error('palette', e); }
}

function paletteMove(delta) {
  if (!_palResults.length) return;
  _palIdx = (_palIdx + delta + _palResults.length) % _palResults.length;
  document.querySelectorAll('.palette-item').forEach((el, i) =>
    el.classList.toggle('active', i === _palIdx));
  document.querySelector('.palette-item.active')?.scrollIntoView({ block: 'nearest' });
}

window.openPalette = openPalette;
window.renderPalette = renderPalette;
window.paletteRun = paletteRun;
window.paletteMove = paletteMove;

// Live filter on each keystroke
$('paletteInput')?.addEventListener('input', e => renderPalette(e.target.value));
```

## Keyboard handling — three key rules

**Rule 1: When the palette is open, the global keydown handler must yield.**

This is the most important detail. The default global handler skips
all keys when the user is typing in an input — but the palette IS an
input, so the user's ↑↓↵ keys would do nothing. Add an early-out at
the top of the global handler:

```js
document.addEventListener('keydown', (e) => {
  const tag = (e.target?.tagName || '').toLowerCase();
  const inField = tag === 'input' || tag === 'textarea' || e.target?.isContentEditable;

  // ── palette is open → handle its own keys even when typing ──
  if (document.getElementById('modal-palette')?.classList.contains('show')) {
    if (e.key === 'Escape')   { e.preventDefault(); closeModal('modal-palette'); return; }
    if (e.key === 'ArrowDown') { e.preventDefault(); paletteMove(1); return; }
    if (e.key === 'ArrowUp')   { e.preventDefault(); paletteMove(-1); return; }
    if (e.key === 'Enter')     { e.preventDefault(); paletteRun(_palIdx); return; }
  }
  if (inField) return;

  // ... rest of the global handler (?, ⌘+K, ⌘+N, g+key, etc.) ...
});
```

**Rule 2: Re-route ⌘+K from "focus search" to "open palette".**

If the global handler previously did `⌘+K → focus searchBox`, change
it to `⌘+K → openPalette()`. Update the help modal's "Focus search"
label to "Command palette" at the same time.

**Rule 3: Expose all the palette functions on `window`.**

`openPalette`, `renderPalette`, `paletteRun`, `paletteMove`, `_palIdx`
— all need to be on `window` so the browser console can test them
and so other modals can call them.

## Discoverability

The single biggest mistake is shipping ⌘+K without surfacing it. Users
won't guess. Three ways to make it discoverable:

1. **A search icon button in the header** (lni-search-alt) that opens
   the palette via `onclick="openPalette()"`. Title attribute:
   "Command palette (⌘+K)".
2. **A `⌘K` placeholder hint** in the search input across the app
   (if you have one).
3. **The help modal lists it** under "Global" with `<kbd>⌘</kbd><kbd>K</kbd>`.

## Pairing with sidebars that collapse to icons on mobile

When the sidebar collapses to 64px on mobile (icon-only), the user
loses the text labels — "Dashboard", "Findings", "Settings" all
become mystery icons. The palette becomes the primary navigation on
mobile because it brings the labels back. Worth advertising this
in the help modal: "On mobile, the command palette is the fastest
way to navigate."

## Stale-page gotcha when iterating in browser tools

When iterating on the palette via `browser_console.evaluate()`, if a
prior evaluate set `window.__palIdx = 99` and the page hasn't
reloaded, that stale state can leak into later tests. Two ways to
cope:
- Always `browser_navigate(url)` with a cache-buster `?_=N` between
  test groups, then re-evaluate
- Reset the palette state explicitly at the start of each test:
  `window._palIdx = 0; openPalette();`

If `window.openPalette` returns "undefined" in a console test after
you just defined it, the page is stale (or the script failed to
parse). Reload with a cache-buster URL.

## Verification ladder

After wiring the palette, verify in this order:
1. Press `⌘+K` → modal opens, input is focused
2. Type nothing → 12 items shown, first is active
3. Type "find" → filters to 4 items, "Verified Findings" is first
4. Press ↓ → active moves from "Dashboard" to second item
5. Press ↵ → modal closes, action runs (e.g. tab changes)
6. Press `⌘+K`, type "x" → empty state shows "no matches for x"
7. Press Esc → modal closes
8. Toggle theme → palette still readable (no color hardcoded)
9. Help modal still says "Command palette" not "Focus search"

If any step fails, the bug is almost always in:
- The early-out in the global keydown handler (step 1 or 5)
- The `data-palette` CSS hiding `.box` (step 1 — modal opens but is invisible)
- The `kw` field not containing a synonym the user tried (step 3)
