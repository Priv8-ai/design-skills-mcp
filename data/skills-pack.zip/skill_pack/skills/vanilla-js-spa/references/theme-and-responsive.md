# Theme system + responsive layout (4-breakpoint mobile-first)

The class of work: build a single-page dashboard that flips between
dark / light / system themes and adapts gracefully from 1920px desktop
to 360px phone, with no build step and no framework.

Two non-obvious traps account for 90% of the failures:
1. **CSS custom property cascade gotcha** — overriding on `body` doesn't
   propagate to `getComputedStyle(documentElement)`, which is what
   canvas-rendered visualizations need.
2. **Hardcoded canvas colors** — if you style your theme via CSS vars
   but the canvas uses hardcoded `'#e6edf3'`, the canvas stays light
   text on a dark background when the theme flips to light. Invisible
   labels, invisible particles.

## Theme: 3-way cycle on a single button

The minimal viable theme system: one button, three states, persisted to
localStorage, flows through CSS custom properties so all surfaces swap
together.

```html
<button id="themeBtn"><i class="lni lni-night"></i></button>
```

```js
const setThemeIcon = () => {
  const ico = $('themeBtn')?.querySelector('i');
  if (!ico) return;
  // system-theme is checked FIRST so the gear icon wins over the
  // .light class that's also present in system mode
  if (document.documentElement.classList.contains('system-theme')) {
    ico.className = 'lni lni-cog';
  } else if (document.documentElement.classList.contains('light')) {
    ico.className = 'lni lni-sun';
  } else {
    ico.className = 'lni lni-night';
  }
};

const applyTheme = (mode) => {
  document.documentElement.classList.remove('light', 'system-theme');
  if (mode === 'light') {
    document.documentElement.classList.add('light');
  } else if (mode === 'system') {
    document.documentElement.classList.add('system-theme');
    const prefersDark = window.matchMedia?.('(prefers-color-scheme: dark)').matches;
    if (prefersDark) document.documentElement.classList.remove('light');
    else document.documentElement.classList.add('light');
    // re-apply when the OS preference changes (only while in system mode)
    window.matchMedia?.('(prefers-color-scheme: dark)')
      .addEventListener?.('change', () => {
        if (document.documentElement.classList.contains('system-theme')) applyTheme('system');
      });
  }
  setThemeIcon();
};

on('themeBtn', () => {
  let next = 'dark';
  if (document.documentElement.classList.contains('light')) next = 'system';
  else if (document.documentElement.classList.contains('system-theme')) next = 'dark';
  else next = 'light';
  applyTheme(next);
  try { localStorage.setItem('wehax.theme', next); } catch {}
});

// boot: restore from localStorage
async function boot() {
  try {
    const t = localStorage.getItem('wehax.theme') || 'dark';
    if (t === 'light') document.documentElement.classList.add('light');
    else if (t === 'system') {
      document.documentElement.classList.add('system-theme');
      const prefersDark = window.matchMedia?.('(prefers-color-scheme: dark)').matches;
      if (!prefersDark) document.documentElement.classList.add('light');
    }
    const ico = $('themeBtn')?.querySelector('i');
    if (ico) {
      if (t === 'light') ico.className = 'lni lni-sun';
      else if (t === 'system') ico.className = 'lni lni-cog';
    }
  } catch {}
  // ...
}
```

### The CSS — one :root, one override block

```css
:root {
  --bg-0:        #0a0d14;
  --bg-1:        #0f1219;
  --bg-2:        #151927;
  --bg-3:        #1a1f30;
  --line:        #232940;
  --text:        #e6ebf5;
  --text-2:      #8a96b3;
  --text-3:      #5a6480;
  --brand:       #7c5cff;
  --brand-2:     #a78bfa;
  --cyan:        #38e8ff;
  --green:       #4ade80;
  --red:         #ff5d6c;
  --amber:       #fbbf24;
  --orange:      #fb923c;
  --grad-1:      linear-gradient(135deg, rgba(124,92,255,0.18) 0%, rgba(56,232,255,0.10) 100%);
  --grad-2:      linear-gradient(135deg, rgba(255,93,108,0.18) 0%, rgba(124,92,255,0.10) 100%);
  --grad-3:      linear-gradient(135deg, rgba(74,222,128,0.18) 0%, rgba(56,232,255,0.08) 100%);
  --asm-edge:    rgba(56,232,255,0.18);
  --asm-edge-2:  rgba(167,139,250,0.10);
  --asm-particle:rgba(124,92,255,0.18);
  --asm-label:   #e6edf3;
  --shadow-strong: 0 24px 60px rgba(0,0,0,0.5);
}

/* ⚠️ CRITICAL: override on `html.light`, NOT `body.light` */
html.light {
  --bg-0:        #f5f7fc;
  --bg-1:        #fbfcff;
  --bg-2:        #ffffff;
  --bg-3:        #ffffff;
  --line:        #e3e8f4;
  --text:        #0f1219;
  --text-2:      #4a5573;
  --text-3:      #8a96b3;
  --brand:       #6d3aff;
  --brand-2:     #6d3aff;
  --cyan:        #0aa9c0;
  --green:       #16a34a;
  --red:         #e11d48;
  --amber:       #d97706;
  --orange:      #ea580c;
  --asm-edge:    rgba(109,58,255,0.20);
  --asm-edge-2:  rgba(109,58,255,0.10);
  --asm-particle:rgba(109,58,255,0.12);
  --asm-label:   #0f1219;
  --shadow-strong: 0 24px 60px rgba(20,30,60,0.18);
}

html.light body {
  background:
    radial-gradient(ellipse 800px 500px at 15% 0%, rgba(109,58,255,0.06), transparent 50%),
    radial-gradient(ellipse 600px 400px at 100% 100%, rgba(10,169,192,0.04), transparent 50%),
    var(--bg-1);
  color-scheme: light;
}

/* Override specific themed surfaces (PlainAdmin-style framework overrides) */
html.light .sidebar-nav-wrapper { background: linear-gradient(180deg, var(--bg-2) 0%, var(--bg-1) 100%); }
html.light .stat-card, html.light .card, html.light .box, html.light .hero-card { background: var(--bg-2); }
html.light .footer { background: var(--bg-2); border-top: 1px solid var(--line); }
html.light .form-control, html.light .form-select { background: var(--bg-2); border-color: var(--line); color: var(--text); }
```

### The CSS-var cascade gotcha (the bug I lost 20 minutes on)

CSS custom properties cascade DOWN the DOM tree, not sideways. So:
- `:root` is `<html>` — sets the dark vars
- `body.light { --bg-0: ... }` sets `--bg-0` for `<body>` and all its descendants

But `getComputedStyle(documentElement).getPropertyValue('--bg-0')` reads
the value from `<html>`, which still has the original `:root` value.
`getComputedStyle(document.body).getPropertyValue('--bg-0')` returns
the overridden value (because the var cascades down from body).

If your canvas-rendered visualization reads from
`getComputedStyle(document.documentElement)`, it gets the WRONG theme
in light mode — the body shows light gray, the canvas keeps drawing
white text on transparent (invisible).

**Fix**: scope the override to `html.light` instead of `body.light`.
Then `getComputedStyle(documentElement)` returns the light values.

### Canvas code that respects the theme

The canvas can't read CSS via `style.color`. You have to query the
computed variables each frame (cheap) and use them:

```js
function draw() {
  const ctx = canvas.getContext('2d');
  const cs = getComputedStyle(document.documentElement);
  const edgeColor = cs.getPropertyValue('--asm-edge').trim() || 'rgba(56,232,255,0.18)';
  const labelColor = cs.getPropertyValue('--asm-label').trim() || '#e6edf3';
  const particleColor = cs.getPropertyValue('--asm-particle').trim() || 'rgba(124,92,255,0.18)';
  // ... use edgeColor, labelColor, particleColor
}
```

Reading CSS vars in a 60fps render loop is fine — `getComputedStyle`
is cached for the frame. Don't try to be clever and read once on
theme change; the recompute is negligible.

## Responsive: 4 breakpoints, mobile sidebar collapse

The setup:
- Desktop: fixed 250px sidebar, main wrapper has `margin-left: 250px`
- ≤ 1200px: tighter stat cards, smaller hero/donut
- ≤ 992px: sidebar 200px, hides section labels
- ≤ 768px: **sidebar collapses to 64px icon-only**, expands to 250px on tap
- ≤ 576px: 1-column, header buttons hide, search wraps

```css
/* 1200px — compact */
@media (max-width: 1200px) {
  .stat-card .value { font-size: 24px; }
  .severity-donut { width: 150px; height: 150px; }
}

/* 992px — narrower sidebar */
@media (max-width: 992px) {
  .sidebar-nav-wrapper { width: 200px; }
  .main-wrapper { margin-left: 200px; }
  .nav-section { display: none; }   /* section labels like "TOOLS" */
}

/* 768px — collapsed icon-only sidebar */
@media (max-width: 768px) {
  .sidebar-nav-wrapper {
    width: 64px;
    transition: width 0.25s ease;
    overflow-x: hidden;
  }
  .sidebar-nav-wrapper.expanded {
    width: 250px;
    box-shadow: 4px 0 24px rgba(0,0,0,0.4);
  }
  .sidebar-nav-wrapper .logo-text,
  .sidebar-nav-wrapper .logo-sub { display: none; }
  .sidebar-nav-wrapper.expanded .logo-text,
  .sidebar-nav-wrapper.expanded .logo-sub { display: block; }
  .sidebar-nav .nav-item > a { justify-content: center; }
  .sidebar-nav-wrapper.expanded .nav-item > a { justify-content: flex-start; }
  .sidebar-nav .nav-item > a .text,
  .sidebar-nav .nav-item > a .badge { display: none; }
  .sidebar-nav-wrapper.expanded .nav-item > a .text,
  .sidebar-nav-wrapper.expanded .nav-item > a .badge { display: inline-flex; }
  .main-wrapper { margin-left: 64px; }
  .stat-card { padding: 12px 14px; }
  .asm-stage { height: 280px; }
}

/* 576px — 1-column */
@media (max-width: 576px) {
  .header { flex-wrap: wrap; gap: 8px; }
  .header input.search { order: 10; flex: 1 0 100%; max-width: none; }
  .row.g-3 .col-md-3 { flex: 0 0 100%; max-width: 100%; }
  .asm-stage { height: 220px; }
  .header .icon-btn.mobile-hide { display: none; }
}
```

The mobile sidebar expand/collapse is one class on the wrapper:
`.expanded`. The header has a `sidebarToggle` button that toggles it.
A document-level click handler closes it when the user taps outside
(only on ≤768px, so desktop clicks aren't affected).

```js
on('sidebarToggle', () => {
  document.querySelector('.sidebar-nav-wrapper')?.classList.toggle('expanded');
});
document.addEventListener('click', (e) => {
  const sb = document.querySelector('.sidebar-nav-wrapper');
  if (!sb || !sb.classList.contains('expanded')) return;
  if (window.innerWidth > 768) return;          // only on mobile
  if (sb.contains(e.target)) return;            // click inside sidebar — ignore
  if (e.target.closest('#sidebarToggle')) return; // the toggle button itself
  sb.classList.remove('expanded');
});
```

## Canvas-rendered visualization: scale with viewport

A common bug: a constellation/graph uses fixed canvas-space coordinates
(800×380), but the canvas resizes with the container. On mobile the
inner ring (radius 120) and outer ring (radius 230) overflow the
shrunk canvas.

Fix: scale the orbit radii by the current canvas/box size:

```js
const scaleX = W / 800, scaleY = H / 380;  // W, H = current canvas px
const cx0 = 400, cy0 = 190;
ASM.nodes.forEach((n, i) => {
  if (n.ring > 0) {
    const ang = ASM.t * 0.3 + i * 0.7;
    const radius = n.ring === 1 ? 120 : 230 + (i % 3) * 8;
    n.x = cx0 + Math.cos(ang) * radius * scaleX;
    n.y = cy0 + Math.sin(ang) * (radius * 0.55) * scaleY;
  } else {
    n.x = cx0 + Math.cos(ASM.t * 0.5) * 2;
    n.y = cy0 + Math.sin(ASM.t * 0.5) * 2;
  }
});
// Wrap particles in the scaled bounds too
ASM.particles.forEach(p => {
  p.x += p.vx; p.y += p.vy;
  if (p.x < 0) p.x = 800; if (p.x > 800) p.x = 0;
  if (p.y < 0) p.y = 380; if (p.y > 380) p.y = 0;
  ctx.beginPath(); ctx.arc(p.x * scaleX, p.y * scaleY, p.r, 0, Math.PI * 2); ctx.fill();
});
```

This way the visualization always fits its container, whether 1280px
desktop or 360px phone, and the click-to-inspect hover math still
works (see `vanilla-js-spa` SKILL.md "Canvas: hover detection on a
transformed 2D context" for the transform-inversion recipe).

## What I had to fix mid-session (lessons)

1. **First I put overrides on `body.light` — wasted 20 minutes.** The
   variable got applied to body descendants but `getComputedStyle(html)`
   still returned the dark value. The body was light gray; the canvas
   kept drawing in dark colors. Fix: move to `html.light`.

2. **Icon class swap order matters.** I had `if (light) sun; else if
   (system) cog; else night`. In system mode both `system-theme` and
   `light` classes are present, so the first branch always won, and
   the user never saw the gear icon. **System check must come first.**

3. **`scaleX/scaleY` declared after first use.** I added the scaled
   drawing for the nodes but the particle loop above still used raw
   `p.x, p.y`. Hoist `scaleX = W/800, scaleY = H/380` to the top of
   the render function so both loops can use them.

4. **The `.collapsed` class is desktop-only.** If your desktop
   sidebar uses `.collapsed` for the hamburger and your mobile CSS
   uses `.expanded` for the same thing, your JS handler will only
   work in one mode. Pick one class name (`expanded` works for both)
   and make the mobile CSS target the same class.

5. **Body background gradient must be re-declared in light mode.**
   `body { background: radial-gradient(...rgba(124,92,255,0.10)...) }`
   uses the dark color. Override with `html.light body { background:
   radial-gradient(...rgba(109,58,255,0.06)...) }`. Otherwise the
   background "leaks" through the light cards and looks weird.

## Verification ladder

After wiring theme + responsive, the 30-second audit:

```js
// 1. Theme class is on <html>, not <body>
document.documentElement.className   // expect "light" or "system-theme" or ""

// 2. CSS vars on <html> reflect the active theme
const cs = getComputedStyle(document.documentElement);
cs.getPropertyValue('--bg-0')       // dark: "#0a0d14", light: "#f5f7fc"
cs.getPropertyValue('--text')       // dark: "#e6edf5", light: "#0f1219"

// 3. Canvas reads the same vars (draw a frame, check pixel color)
const cv = document.querySelector('canvas');
const ctx = cv.getContext('2d');
ctx.getImageData(cx, cy, 1, 1).data // [r,g,b,a] — should match theme

// 4. Sidebar widths at each breakpoint (simulate by setting class on body)
[1280, 1200, 992, 768, 576, 360].forEach(w => {
  console.log(w, getComputedStyle(document.querySelector('.sidebar-nav-wrapper')).width);
});
// 1280: 250px, 1200: 250px, 992: 200px, 768: 64px, 576: 64px

// 5. Click theme button 3x, confirm class cycle
const log = [];
$('themeBtn').click(); log.push(document.documentElement.className); // 'light'
$('themeBtn').click(); log.push(document.documentElement.className); // 'system-theme light'
$('themeBtn').click(); log.push(document.documentElement.className); // ''
```

If any step in 1-4 returns a dark value while in light mode, the
class scope is wrong. Step 5 verifies the cycle order. Steps 1+2
without 4 mean the canvas won't follow.
