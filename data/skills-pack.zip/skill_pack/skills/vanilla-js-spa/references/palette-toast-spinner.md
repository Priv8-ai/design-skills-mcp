# Command palette data search + recents + inline chips + upgraded toast + global spinner

Five polish features that turn a working vanilla-JS dashboard from "functional"
to "feels like a real product." All are zero-dependency, single-file additions
to a `<50 KB` JS file, and they share infrastructure (the palette modal, the
`api` wrapper, the toast container) you already have.

## 1. Palette data search mode (`>query`)

Once the user is hooked on the command palette, the next ask is usually
"can I search my actual data with it?" — findings, subdomains, scan IDs.

The pattern: when the query starts with `>`, switch to data-search mode
and ignore the COMMANDS array. Return sectioned results instead.

```js
function renderPalette(q) {
  // ── data search mode (queries starting with ">") ──
  if (q.startsWith('>')) return renderDataSearch(q.slice(1).trim());
  // ... rest of command palette ...
}

function renderDataSearch(q) {
  _palResults = [];
  const list = $('paletteList');
  if (!list) return;
  if (!q) {
    list.innerHTML =
      '<div class="palette-empty"><i class="lni lni-search-alt"></i> ' +
      'type to search findings, subdomains & scans' +
      '<br><small style="opacity:0.6;margin-top:6px;display:block">' +
      'prefix with <code>&gt;</code> to search data · e.g. <code>&gt;xss</code>' +
      '</small></div>';
    const cnt = $('paletteCount'); if (cnt) cnt.textContent = 'data search';
    return;
  }
  const ql = q.toLowerCase();
  // 1) findings (verified-only, same discipline as everywhere else)
  const findings = verifiedOnly(S.findings).filter(f => {
    const hay = `${f.type||''} ${f.target||''} ${f.detail||''} ${f.severity||''} ${f.tool||''}`.toLowerCase();
    return hay.includes(ql);
  }).slice(0, 5);
  // 2) subdomains
  const subs = (S.subs || []).filter(s => (s.host || s).toLowerCase?.().includes(ql)).slice(0, 5);
  // 3) scans
  const scans = (S.scans || []).filter(s => (s.scan_id || s.domain || '').toLowerCase().includes(ql)).slice(0, 3);
  const total = findings.length + subs.length + scans.length;

  if (!total) {
    list.innerHTML = `<div class="palette-empty"><i class="lni lni-search-alt"></i> ` +
      `no data matches "<strong>${esc(q)}</strong>"` +
      `<br><small style="opacity:0.6;margin-top:6px;display:block">` +
      `try a different term, or remove <code>&gt;</code> to search commands</small></div>`;
    const cnt = $('paletteCount'); if (cnt) cnt.textContent = '0 results';
    return;
  }

  let html = '';
  if (findings.length) {
    html += `<div class="palette-section">FINDINGS <span class="palette-section-count">${findings.length}</span></div>`;
    findings.forEach(f => {
      const sev = (f.severity || 'info').toLowerCase();
      const color = sev==='critical'?'red':sev==='high'?'orange':sev==='medium'?'amber':sev==='low'?'cyan':'green';
      html += `<div class="palette-item" onclick="paletteOpenFinding('${esc(f.id||f.fid)}')">
        <i class="lni lni-warning" style="color:var(--${color})"></i>
        <div class="palette-text">
          <div class="palette-label">${esc(f.type||'finding')} <span class="palette-badge sev-${sev}">${sev}</span></div>
          <div class="palette-sub">${esc((f.target||'').slice(0,60))}</div>
        </div>
        <span class="palette-enter"><kbd>↵</kbd></span>
      </div>`;
    });
  }
  if (subs.length) {
    html += `<div class="palette-section">SUBDOMAINS <span class="palette-section-count">${subs.length}</span></div>`;
    subs.forEach(s => {
      const host = s.host || s;
      html += `<div class="palette-item" onclick="paletteCopyText('${esc(host)}')">
        <i class="lni lni-globe"></i>
        <div class="palette-text">
          <div class="palette-label">${esc(host)}</div>
          <div class="palette-sub">discovered subdomain</div>
        </div>
        <span class="palette-enter"><kbd>copy</kbd></span>
      </div>`;
    });
  }
  if (scans.length) {
    html += `<div class="palette-section">SCANS <span class="palette-section-count">${scans.length}</span></div>`;
    scans.forEach(s => {
      const target = s.domain || s.scan_id || '';
      html += `<div class="palette-item" onclick="paletteOpenScan('${esc(s.scan_id)}')">
        <i class="lni lni-${s.status==='running'?'spinner':'check-mark'}"></i>
        <div class="palette-text">
          <div class="palette-label">${esc(target)} <span class="palette-badge" style="background:rgba(56,232,255,0.12);color:var(--cyan);border-color:rgba(56,232,255,0.3)">${esc(s.status)}</span></div>
          <div class="palette-sub">${esc(s.scan_id || '')} · ${esc(s.current_phase || '')}</div>
        </div>
        <span class="palette-enter"><kbd>open</kbd></span>
      </div>`;
    });
  }
  list.innerHTML = html;
  const cnt = $('paletteCount');
  if (cnt) cnt.textContent = `${total} result${total===1?'':'s'} across findings/subs/scans`;

  // Make Enter work — synthesize a one-item results array that clicks the first
  // visible item (Enter semantics differ between data sections and command rows)
  _palResults = [{ id:'_data', action: () => list.querySelector('.palette-item')?.click() }];
  _palIdx = 0;
}

function paletteOpenFinding(fid) {
  const f = S.findings.find(x => (x.id||x.fid) == fid);
  if (!f) return;
  closeModal('modal-palette');
  setTab('findings');
  setTimeout(() => openFindingModal(f), 200);
}
function paletteOpenScan(scanId) {
  const s = S.scans.find(x => x.scan_id === scanId);
  if (!s) return;
  closeModal('modal-palette');
  S.scanId = scanId; S.currentScan = s; renderScanPill();
  setTab('home');
  toast(`✓ switched to ${s.domain || scanId}`, '', 'ok');
}
function paletteCopyText(text) {
  if (navigator.clipboard) {
    navigator.clipboard.writeText(text).then(() => toast(`✓ copied "${text}"`, '', 'ok', 2500));
  } else {
    toast('✗ clipboard unavailable', '', 'err');
  }
  closeModal('modal-palette');
}
window.renderDataSearch = renderDataSearch;
window.paletteOpenFinding = paletteOpenFinding;
window.paletteOpenScan = paletteOpenScan;
window.paletteCopyText = paletteCopyText;
```

Three things to get right:

1. **Apply the verified-only filter to data search.** Findings with
   `verified !== 1` are unverified/false-positive noise; the user
   explicitly said *don't show vuln unless its verified* — this
   discipline applies to the palette too, not just the homepage.
2. **Sections render order matters.** Findings (highest-signal),
   then subs (medium), then scans (lowest). Same order as the user
   reads importance.
3. **Enter should "do the obvious thing" per row.** Findings open
   detail modal, subs copy to clipboard, scans switch active scan.
   Each row's `onclick` encodes that — `paletteRun` just clicks
   the first visible item.

The placeholder text should mention `>` so the mode is discoverable:

```html
<input id="paletteInput" placeholder="Type a command, or >query to search findings/subs…" ... />
```

## 2. Recents ring buffer in localStorage

After a few days of palette use, the user has 2-3 commands they hit
constantly (New Scan, Test Connection, Wipe Data). Show those at
the top of the empty-query result so they're one keystroke away.

```js
// In renderPalette (the command-search path, NOT data search):
let recents = [];
try { recents = JSON.parse(localStorage.getItem('wehax.palRecents') || '[]'); } catch {}
const isEmpty = !q;
let results;
if (isEmpty && recents.length) {
  const recentCmds = recents.map(rid => COMMANDS.find(c => c.id === rid)).filter(Boolean);
  const others = COMMANDS.filter(c => !recents.includes(c.id));
  results = [...recentCmds, ...others].slice(0, 12);
} else {
  results = COMMANDS.map(c => ({ c, s: fuzzyScore(c, q) })).filter(r => r.s > 0)
    .sort((a,b) => b.s - a.s).slice(0, 12).map(r => r.c);
}
// In the row HTML:
const recent = recents.includes(c.id) && isEmpty
  ? '<span class="palette-recent-tag">recent</span>' : '';

// Update recents in paletteRun (after running a command):
function paletteRun(i) {
  const c = _palResults[i];
  if (!c) return;
  try {
    let recents = JSON.parse(localStorage.getItem('wehax.palRecents') || '[]');
    recents = [c.id, ...recents.filter(r => r !== c.id)].slice(0, 5);   // LRU, max 5
    localStorage.setItem('wehax.palRecents', JSON.stringify(recents));
  } catch {}
  closeModal('modal-palette');
  try { c.action(); } catch (e) { console.error('palette', e); }
}

// Footer count reads:
const cnt = $('paletteCount');
if (cnt) cnt.textContent = isEmpty && recents.length
  ? `${recents.length} recent · ${COMMANDS.length} total`
  : `${COMMANDS.length} commands`;
```

```css
.palette-recent-tag {
  display: inline-block; margin-left: 6px; padding: 1px 6px;
  background: rgba(124,92,255,0.15); color: var(--brand-2);
  border: 1px solid rgba(124,92,255,0.3); border-radius: 8px;
  font-size: 8.5px; font-weight: 700; text-transform: uppercase;
  letter-spacing: 0.5px; vertical-align: middle;
}
```

Two gotchas:
- **Only show "RECENT" tag in empty-query mode**, never when the
  user is searching. Search results are ranked by fuzzy match, not
  recency, and a tag next to the wrong item is just clutter.
- **Max 5 entries** in the LRU. More than that and the tag is no
  longer "this is the thing you use most" — it's a list.

## 3. Inline shortcut chips in palette rows

Users with 20+ commands can't remember all the shortcuts. Show
the ones that exist directly in the row, on the right side, as
`<kbd>` chips. Tabs get `⌘1..8`, special actions get `⌘N`, `⌘/`,
`?`, etc.

```js
// COMMANDS array entries gain an `sc` field:
{ id:'tab-home', ..., sc:['⌘','1'], action:() => setTab('home') }
{ id:'m-new',    ..., sc:['⌘','N'], action:() => openModal('modal-newscan') }
{ id:'a-theme',  ..., sc:['⌘','/'], action:() => $('themeBtn')?.click() }
{ id:'a-help',   ..., sc:['?'],     action:() => openHelp() }

// In the row render:
const sc = c.sc
  ? `<span class="palette-sc">${c.sc.map(k => `<kbd>${esc(k)}</kbd>`).join('')}</span>`
  : `<span class="palette-enter"><kbd>↵</kbd></span>`;
```

```css
.palette-item .palette-sc { display: inline-flex; gap: 2px; align-items: center; }
.palette-item .palette-sc kbd {
  padding: 2px 6px; font-size: 10px;
  background: var(--bg-0); border: 1px solid var(--line); border-bottom-width: 2px;
  border-radius: 4px; color: var(--text-2);
  font-family: 'SF Mono', monospace; font-weight: 700;
}
.palette-item.active .palette-sc kbd {
  background: var(--bg-2); border-color: var(--brand); color: var(--brand-2);
}
```

The active-row treatment (purple border, brand color) makes the
chips feel like part of the same focus state as the row. Without
it, the chips look "stuck on" when the row is highlighted.

## 4. Section dividers + severity badges in palette

Section dividers between data-search result groups:
```css
.palette-section {
  padding: 8px 12px 4px; color: var(--text-3); font-size: 9.5px;
  text-transform: uppercase; letter-spacing: 1.5px; font-weight: 800;
  display: flex; align-items: center; gap: 8px;
}
.palette-section .palette-section-count {
  background: var(--bg-0); padding: 1px 7px; border-radius: 8px;
  color: var(--brand-2); border: 1px solid rgba(124,92,255,0.3); font-size: 9px;
}
```

Severity badges for findings in data search results:
```css
.palette-item .palette-badge {
  display: inline-block; margin-left: 6px; padding: 1px 6px; border-radius: 8px;
  font-size: 8.5px; font-weight: 700; text-transform: uppercase;
  letter-spacing: 0.5px; vertical-align: middle;
}
.palette-item .palette-badge.sev-critical { background: rgba(255,93,108,0.15); color: var(--red);    border: 1px solid rgba(255,93,108,0.3); }
.palette-item .palette-badge.sev-high     { background: rgba(255,140,90,0.15); color: var(--orange); border: 1px solid rgba(255,140,90,0.3); }
.palette-item .palette-badge.sev-medium   { background: rgba(251,191,36,0.15); color: var(--amber);  border: 1px solid rgba(251,191,36,0.3); }
.palette-item .palette-badge.sev-low      { background: rgba(56,232,255,0.15); color: var(--cyan);   border: 1px solid rgba(56,232,255,0.3); }
.palette-item .palette-badge.sev-info     { background: rgba(74,222,128,0.15); color: var(--green);  border: 1px solid rgba(74,222,128,0.3); }
```

The badge colors should match the rest of the dashboard's
severity palette (--red, --orange, --amber, --cyan, --green) so
the user recognizes the severity instantly.

## 5. Upgraded toast system (the full one)

The basic toast in the main SKILL.md is 4 lines of code and
"good enough for v1." The upgraded version is what you want for
a polished product: icon, progress bar, click-dismiss, hard cap
of 5, and a guaranteed-clean stack even under bursts.

```js
// Toast queue with icon + progress bar + click-to-dismiss + max-stacked
const TOAST_MAX = 5;
let _toastSeq = 0;
const _toastIcon = (level) => ({ ok:'lni-checkmark-circle', err:'lni-close',
                                 warn:'lni-warning', info:'lni-information' }[level||'info']) || 'lni-information';

function toast(title, body, level='', ms=4500) {
  const c = $('toastContainer'); if (!c) return;
  // ── hard cap: oldest is removed synchronously when over the limit ──
  const existing = c.querySelectorAll('.wehax-toast');
  if (existing.length >= TOAST_MAX) existing[0].remove();

  const el = document.createElement('div');
  el.className = 'wehax-toast ' + (level||'');
  el.setAttribute('data-toast-id', ++_toastSeq);
  el.innerHTML = `
    <i class="lni ${_toastIcon(level)} toast-ico"></i>
    <div class="toast-content">
      <div class="title">${esc(title)}</div>
      ${body ? `<div class="body">${esc(body)}</div>` : ''}
    </div>
    <button class="toast-x" aria-label="dismiss"><i class="lni lni-close"></i></button>
    ${ms > 0 ? `<div class="toast-progress" style="animation-duration:${ms}ms"></div>` : ''}
  `;
  el.querySelector('.toast-x')?.addEventListener('click', (e) => { e.stopPropagation(); dismiss(el); });
  el.addEventListener('click', () => dismiss(el));
  c.appendChild(el);
  if (ms > 0) setTimeout(() => dismiss(el), ms);

  function dismiss(node) {
    if (!node.isConnected) return;
    node.classList.add('leaving');
    setTimeout(() => node.remove(), 280);
  }
}
window.toast = toast;
```

```css
.wehax-toast { display: flex; align-items: flex-start; gap: 12px;
  background: var(--bg-2); border: 1px solid var(--line);
  border-left: 4px solid var(--cyan); border-radius: 10px;
  padding: 12px 14px; margin-bottom: 10px; color: var(--text);
  box-shadow: 0 12px 32px rgba(0,0,0,0.5);
  animation: slideIn 0.4s cubic-bezier(0.34, 1.56, 0.64, 1);
  position: relative; cursor: pointer; overflow: hidden; }
.wehax-toast.ok   { border-left-color: var(--green); }
.wehax-toast.warn { border-left-color: var(--amber); }
.wehax-toast.crit { border-left-color: var(--red); }
.wehax-toast .toast-ico { font-size: 20px; color: var(--cyan); margin-top: 1px; flex-shrink: 0; }
.wehax-toast.ok   .toast-ico { color: var(--green); }
.wehax-toast.warn .toast-ico { color: var(--amber); }
.wehax-toast.crit .toast-ico { color: var(--red); }
.wehax-toast .toast-content { flex: 1; min-width: 0; }
.wehax-toast .title { font-weight: 700; font-size: 13px; margin-bottom: 4px; }
.wehax-toast .body  { font-size: 12px; color: var(--text-2); }
.wehax-toast .toast-x { background: transparent; border: 0; color: var(--text-3);
  cursor: pointer; padding: 4px; line-height: 1; font-size: 12px; border-radius: 4px; flex-shrink: 0; }
.wehax-toast .toast-x:hover { color: var(--text); background: var(--bg-0); }
.wehax-toast .toast-progress {
  position: absolute; bottom: 0; left: 0; height: 2px;
  background: linear-gradient(90deg, var(--brand), var(--cyan));
  width: 100%; transform-origin: left center;
  animation: toastProgress linear forwards;
}
.wehax-toast.ok   .toast-progress { background: linear-gradient(90deg, var(--green),  var(--cyan)); }
.wehax-toast.warn .toast-progress { background: linear-gradient(90deg, var(--amber),  var(--orange)); }
.wehax-toast.crit .toast-progress { background: linear-gradient(90deg, var(--red),    var(--orange)); }
@keyframes toastProgress { from { transform: scaleX(1); } to { transform: scaleX(0); } }
.wehax-toast.leaving { animation: slideOut 0.28s ease-out forwards; }
@keyframes slideIn  { from { transform: translateX(120%); opacity: 0; } to { transform: translateX(0); opacity: 1; } }
@keyframes slideOut { from { transform: translateX(0); opacity: 1; max-height: 200px; margin-bottom: 10px; }
                      to   { transform: translateX(120%); opacity: 0; max-height: 0; margin-bottom: 0; padding: 0; } }
```

**Hard cap pitfall**: don't do `setTimeout(() => oldest.remove(), 280)` for
the cap trim — that's "soft" because the toast stays visible during
the slide-out animation and the count can grow during bursts. Use
`oldest.remove()` synchronously instead. The 5th toast appears, the
6th comes in, oldest is hard-removed in the same microtask, count
stays at 5.

**Why the `dismiss(el)` inner function** instead of inlining: the
X click, the body click, and the timer all need to call the same
`dismiss` with the same `isConnected` guard (prevents the timer
from removing a node that was already removed by a click). Inner
function captures `el` in closure so the guard is per-instance.

**Three dismissable surfaces**: the X button, clicking the body
anywhere, and the auto-timer. The first two get the user's
`stopPropagation()` on X so clicking X doesn't also trigger
the body click.

## 6. Global API loading spinner with try/finally counter

The single most visible "feels professional" upgrade after toasts.
The user can see when the dashboard is talking to the API.

```js
// api wrapper with global loading spinner
let _apiCount = 0;
function _spinStart() {
  _apiCount++;
  const b = $('apiSpinner'); if (b) b.classList.add('on');
  const c = $('apiSpinnerCount'); if (c) c.textContent = _apiCount > 1 ? '×' + _apiCount : '';
}
function _spinEnd() {
  _apiCount = Math.max(0, _apiCount - 1);
  const b = $('apiSpinner'); if (b && !_apiCount) b.classList.remove('on');
  const c = $('apiSpinnerCount'); if (c) c.textContent = _apiCount > 1 ? '×' + _apiCount : '';
}

const api = {
  async get(path) {
    _spinStart();
    try { const r = await fetch(S.apiBase + path); if (!r.ok) throw new Error('GET ' + path + ' ' + r.status); return r.json(); }
    finally { _spinEnd(); }
  },
  async post(path, body) {
    _spinStart();
    try { const r = await fetch(S.apiBase + path, { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(body||{}) });
          if (!r.ok) throw new Error('POST ' + path + ' ' + r.status); return r.json(); }
    finally { _spinEnd(); }
  },
};
window.api = api;
```

```html
<div id="apiSpinner" class="api-spinner" title="API call in flight">
  <div class="spinner-ring"></div>
  <span class="spinner-count" id="apiSpinnerCount"></span>
</div>
```

```css
.api-spinner {
  position: fixed; bottom: 20px; right: 20px; z-index: 99998;
  display: flex; align-items: center; gap: 8px;
  padding: 8px 14px 8px 10px;
  background: var(--bg-2); border: 1px solid var(--line);
  border-radius: 24px; font-size: 11px; color: var(--text-2);
  box-shadow: 0 6px 20px rgba(0,0,0,0.4);
  opacity: 0; transform: translateY(8px);
  transition: opacity 0.2s, transform 0.2s;
  pointer-events: none;
}
.api-spinner.on { opacity: 1; transform: translateY(0); }
.api-spinner .spinner-ring {
  width: 16px; height: 16px; border: 2px solid var(--line);
  border-top-color: var(--brand-2); border-radius: 50%;
  animation: spin 0.8s linear infinite;
}
.api-spinner .spinner-count { font-family: 'SF Mono', monospace; font-weight: 700; color: var(--brand-2); }
@keyframes spin { to { transform: rotate(360deg); } }
```

**Two critical details**:

1. **`try/finally` for the counter, not `try/catch` + manual decrement.**
   If `fetch` throws, you MUST still decrement. The `finally` block
   runs whether the request succeeded or threw — without it, a single
   failing API call permanently pins the spinner on.

2. **Show the `×N` count ONLY when N > 1.** A single in-flight call
   shows just the spinner ring. Two or more shows "×2", "×3", etc.
   This avoids the "spin spin spin, just one call, why are you
   flashing" feeling for the common single-request case.

**Bottom-right placement** is the standard — out of the way of the
content but always in the visual periphery. The toast container is
top-right, so they don't fight for space.

## Sharing infrastructure between palette and toast

Notice that `paletteCopyText`, `paletteOpenScan`, etc. all call
`toast()`. The toast is the **single feedback channel** for
"something happened" — palette runs use it to confirm copy,
tests use it to confirm save, API calls surface errors through it
(via `api.req()`'s throw). Don't have parallel feedback systems
(alert(), confirm(), browser notifications, status bar text).
One toast, one place to look, one animation grammar.

Same for the spinner — the **single progress channel** for "the
app is doing work." If you find yourself adding a second
progress indicator (button spinner, in-modal spinner, route
loader), you're violating the principle. Use the global spinner
or the toast with `ms: 0` for persistent feedback, not new
visuals.

## Verification ladder

After wiring all five, verify in this order:
1. Trigger an API call (e.g. click a refresh button) → spinner
   appears bottom-right for the call duration, hides when done.
2. Trigger 2 parallel API calls → spinner shows "×2", then "×1",
   then hides.
3. Fire 7 toasts in a synchronous burst → exactly 5 remain
   immediately (cap working), all 5 have icon + X + progress bar.
4. Click X on a toast → it animates out, 4 remain.
5. Wait 4.5s → a toast animates out, 3 remain (timer working).
6. `⌘+K`, type `>bab` → palette shows FINDINGS + SCANS sections.
7. Click a finding → modal opens, palette closes.
8. `⌘+K`, type nothing → 5 recent commands shown with `RECENT` tag.
9. `⌘+K`, type `theme` → only the Toggle Theme action shown.
10. ⌘+5 → switches to Orchestrator tab (palette shortcut chip
    `[⌘][5]` is also visible on that row in the palette).

If any step fails, the bug is almost always in:
- Step 1-2: `try/finally` missing in the api wrapper
- Step 3: `setTimeout`-based cap trim (use sync `oldest.remove()`)
- Step 6: `if (q.startsWith('>')) return renderDataSearch(...)`
  branch missing or `>` not being captured
- Step 8: recents localStorage not being read at the start of
  `renderPalette`, or the tag only showing in search-results mode
