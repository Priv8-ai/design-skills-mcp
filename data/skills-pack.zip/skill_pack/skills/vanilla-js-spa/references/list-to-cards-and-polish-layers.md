# List-heavy panes → cards, header overflow menu, and polish layers

Captured from the WeHax round where the user kept saying "keep continue",
"make the layouts more creative", and "keep gooning" — i.e. push polish
further on a dashboard that already worked. These are the patterns that
came after the core bento conversion (see `references/bento-grid-layout.md`).

## 1. List-heavy pane → responsive card grid (Subdomains pattern)

A flat monospace `<div>` list of hosts is the boring default. Convert to
a `repeat(auto-fill, minmax(240px, 1fr))` card grid with a filter input
and a grid/list view toggle. Each card: a colored left accent bar (`::before`),
a glowing status dot, the value (monospace, ellipsis-truncated), an optional
source tag, a copy-on-click icon revealed on hover.

```css
.sub-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(240px, 1fr)); gap: 10px; }
.sub-card { display:flex; align-items:center; gap:11px; padding:12px 14px;
  background:var(--bg-2); border:1px solid var(--line); border-radius:10px;
  position:relative; overflow:hidden; cursor:pointer; transition:all .16s ease; }
.sub-card::before { content:''; position:absolute; left:0; top:0; bottom:0; width:3px; background:var(--cyan); opacity:.6; }
.sub-card:hover { transform:translateY(-2px); border-color:var(--cyan); box-shadow:0 6px 18px rgba(0,0,0,.3); }
.sub-card .sub-host { flex:1; min-width:0; font-family:'SF Mono',monospace; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
```

The JS keeps a `_subView = 'grid'|'list'` module-level var, a `setSubView(v)`
that toggles the active class + re-renders, and a `subHostOf(s)` coercion
helper. **Pitfall:** the host value can be a string OR an object with
`.subdomain`/`.target`/`.host` — coerce with
`String(s.subdomain || s.target || s.host || (typeof s==='string'?s:'') || '')`
or `.slice`/`.toLowerCase` on a stray object throws
`n.label.slice is not a function`. Click-to-copy uses
`navigator.clipboard?.writeText(h)` with a toast (and a warn toast on the
insecure-origin failure path).

## 2. Severity stat-strip as clickable quick-filter (Findings pattern)

Above a findings table, a row of 6 colored chips (critical/high/medium/low/
info/all) doubles as a one-click severity filter. Each chip: big number +
uppercase label, color-coded via a `--c` custom prop, left accent bar,
corner radial glow, `.active` highlight.

```css
.sev-strip { display:grid; grid-template-columns:repeat(6,1fr); gap:10px; margin-bottom:18px; }
.sev-chip { position:relative; padding:14px 12px; border-radius:12px; cursor:pointer;
  border:1px solid var(--line); background:var(--bg-2); transition:all .18s ease; overflow:hidden; }
.sev-chip::before { content:''; position:absolute; left:0; top:0; bottom:0; width:3px; background:var(--c,var(--text-3)); }
.sev-chip.active { border-color:var(--c); background:color-mix(in srgb, var(--c) 12%, var(--bg-2)); }
.sev-chip.critical{--c:var(--red)} .sev-chip.high{--c:var(--orange)} .sev-chip.medium{--c:var(--amber)}
.sev-chip.low{--c:var(--cyan)} .sev-chip.info{--c:var(--green)} .sev-chip.all{--c:var(--brand-2)}
```

```js
function quickSev(sev) { const sel=$('fSev'); if(sel) sel.value=sev; renderFindings(); }
function updateSevStrip() { /* count verifiedOnly(S.findings) per severity, set chip numbers, toggle .active to match fSev */ }
```

**Pitfall that bit me:** `quickSev('info')` silently did nothing because the
`<select id="fSev">` had options for critical/high/medium/low but **not
`info`**. Setting `.value='info'` on a select with no matching `<option>`
fails silently (value stays `''`). Lesson: the quick-filter chips and the
underlying `<select>` must share the SAME option set — if a chip exists,
its value must be a real `<option>`.

## 3. Header overflow menu — declutter when icon buttons pile up

Past ~6 header icon buttons the bar gets busy. Move secondary/utility
toggles (sound, presentation mode, panic) into a single "⋯" dropdown.
Primary actions (theme, palette, help, bell) stay inline.

```html
<div class="overflow-wrap">
  <button class="icon-btn" id="overflowBtn" onclick="toggleOverflow()"><i class="lni lni-more-alt"></i></button>
  <div class="overflow-menu" id="overflowMenu">
    <button class="ovf-item" id="soundBtn" onclick="toggleSound()"><i class="lni lni-volume-mute"></i><span>New-finding sound</span></button>
    <button class="ovf-item" id="presentBtn" onclick="togglePresent()"><i class="lni lni-display"></i><span>Presentation mode</span></button>
    <div class="ovf-sep"></div>
    <button class="ovf-item danger" id="panicBtn" onclick="globalPanic()"><i class="lni lni-warning"></i><span>PANIC — stop all + wipe</span></button>
  </div>
</div>
```

`.overflow-menu { position:absolute; top:calc(100%+8px); right:0; display:none; }`
`.overflow-menu.open { display:block; }`. `toggleOverflow()` toggles `.open`;
a document `click` listener closes it when `!e.target.closest('.overflow-wrap')`.
**Keep toggle state on the menu item, not a separate header button** — the
`.on` class (purple highlight) shows active state, and the icon-swap in
`toggleSound()` targets the inner `<i>` so the `<span>` text label survives.

## 4. WebAudio chime on events (no audio files)

Severity-pitched two-oscillator chime, off by default (autoplay norms),
persisted to localStorage. Lower pitch = more severe.

```js
let _soundOn = false, _audioCtx = null;
function _chime(sev) {
  if (!_soundOn) return;
  _audioCtx = _audioCtx || new (window.AudioContext||window.webkitAudioContext)();
  const ctx = _audioCtx;
  const base = sev==='critical'?220 : sev==='high'?294 : sev==='medium'?392 : sev==='low'?523 : 659;
  [0,1].forEach(k => {
    const o=ctx.createOscillator(), g=ctx.createGain();
    o.type='sine'; o.frequency.value = base*(k?1.5:1); o.connect(g); g.connect(ctx.destination);
    const t0 = ctx.currentTime + k*0.08;
    g.gain.setValueAtTime(0,t0); g.gain.linearRampToValueAtTime(0.18, t0+0.02);
    g.gain.exponentialRampToValueAtTime(0.001, t0+0.45);
    o.start(t0); o.stop(t0+0.46);
  });
}
```

Lazy-construct the `AudioContext` only after the user enables sound (a user
gesture) — constructing it on page load gives a console warning and a
suspended context.

## 5. Presentation mode — auto-cycle tabs

Toggle that `setInterval`s through the tab list every ~8s, adds a glowing
viewport border (`body.presenting::after` with `box-shadow: inset 0 0 0 2px`)
and a "▶ PRESENTING" badge. Stores no state; clear the interval + remove
the class on toggle-off. Good for demos / wall displays.

## 6. New-event pulse ring on a canvas node

To draw attention when a brand-new item appears in a canvas viz: diff
against a `Set` of seen ids (seeded on first build so there's no pulse
storm on initial load), stamp `node.pulseT = ASM.t` on new nodes, and in
the draw loop render an expanding fading ring while `ASM.t - n.pulseT < 2.4`:

```js
if (n.pulseT != null) {
  const age = ASM.t - n.pulseT;
  if (age < 2.4) {
    const p = age/2.4;
    ctx.strokeStyle = n.color + Math.round((1-p)*180).toString(16).padStart(2,'0');
    ctx.lineWidth = 2*(1-p)+0.5;
    ctx.beginPath(); ctx.arc(n.x, n.y, n.r+2 + p*26, 0, Math.PI*2); ctx.stroke();
  } else n.pulseT = null;
}
```

## 7. Ambient animated gradient mesh background

A fixed `body::before` with 4 drifting radial-gradient blobs and a slow
32s `meshDrift` keyframe (translate + scale + rotate, `alternate`). Sits at
`z-index:0`; bump `.main-wrapper`/`.sidebar` to `z-index:1` so content stays
above. Dim to ~0.6 opacity in light mode. Always gate with
`@media (prefers-reduced-motion: reduce) { body::before { animation:none; } }`.

## 8. Skeleton shimmer while first data loads

Paint shimmer rows into list containers at the very TOP of `boot()` (before
any data lands), replaced automatically when the first render runs:

```js
const sk = (n,tall) => `<div class="skeleton">${Array.from({length:n}).map(()=>`<div class="sk-row${tall?' tall':''}"></div>`).join('')}</div>`;
['recentFindingsList','findingsList'].forEach(id => { const e=$(id); if(e&&!e.children.length) e.innerHTML=sk(4); });
```

`.sk-row { background:linear-gradient(100deg,var(--bg-2) 30%,var(--bg-3) 50%,var(--bg-2) 70%); background-size:220% 100%; animation:skShimmer 1.4s ease-in-out infinite; }`

## 9. Functional regression sweep after big layout refactors (DO THIS)

After converting many panes to bento/card grids, the markup moved a lot —
verify nothing broke functionally before calling it done. One console probe
checks every interactive surface at once:

```js
(function(){
  const fns = ['openModal','closeModal','openPalette','openGlobalSearch','openNotifDrawer',
    'openRelGraph','renderFindings','quickSev','setSubView','copySub','renderMemory',
    'toggleSound','togglePresent','toggleOverflow','openFindingModal','openNewScan','launchNewScan'];
  const missingFns = fns.filter(f => typeof window[f] !== 'function');
  const ids = ['asmCanvas','findingsList','subsList','memoryList','modal-newscan','overflowMenu','sevStrip'];
  const missingIds = ids.filter(id => !document.getElementById(id));
  return JSON.stringify({ missingFns, missingIds, errors: window.__WEHAX_ERRORS||[] });
})()
```

Then drive the real paths (open each modal, click a finding → detail modal,
switch all tabs, constellation zoom in/out). The user's standard for this
project: **"run all features" = end-to-end browser verification that each
feature visibly works**, not code that "should" work. Launch flows
(New Scan) get verified by checking the API actually created the resource
(`curl /scans` count went up, status=running) — not just that the modal
closed.
