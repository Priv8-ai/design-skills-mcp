# wire() + stale selectors after function renames (2026-06-24)

The parent `references/es-module-top-level-throw.md` covers the
generic render-side null-deref. This covers a narrower, easier-to-miss
variant: **you renamed or deleted a function, but missed updating
either the `window.__wex` export object or the `$('#X').addEventListener`
calls inside `wire()` that point to deleted DOM elements.**

The inline onerror catcher in `index.html` will catch these — the error
will appear in `window.__errs` — but `boot()` will reject and the
dashboard will render empty with no useful state.

## Symptom signature

- Module loads successfully (`window.__wex` populated, all expected
  function names present in the export object).
- 0 console errors during the initial fetch.
- `window.__errs` contains ONE entry that looks like:
  ```
  REJ: TypeError: Cannot read properties of null (reading 'addEventListener')
      at wire (http://127.0.0.1:8777/v2/dashboard.js?v=12:993:18)
      at boot (http://127.0.0.1:8777/v2/dashboard.js?v=12:1041:5)
  ```
- Status pill stays on default ("connecting" or empty), rail has
  mission rows but selecting one doesn't show detail.
- Topbar nav links don't switch tabs.
- Side-effect: the `if (!window.__wex) window.__wex = {};` guard from
  earlier rounds is the only thing keeping `window.__wex` from being
  `undefined` entirely — without it, the module errors out before
  exporting anything and you see a different failure mode.

## Why it happens

When you delete a feature (e.g. the command palette) and its associated
DOM elements (e.g. `#findingSearch`, `#findingSeverity`, `.navlink`),
two things need to happen in lockstep:

1. The `$('#oldSelector').addEventListener(...)` calls in `wire()`
   must be removed.
2. The `window.__wex = { oldFn, ... }` export object must drop the
   deleted function name.

If you do (1) but forget (2): the module body raises `ReferenceError`
when it executes `window.__wex = { foo: chatShow }` after `chatShow`
was renamed to `chatOpen`. The onerror catcher catches it. The
page renders empty.

If you do (2) but forget (1): the module loads fine, but `wire()`
calls `$('#findingSearch').addEventListener(...)` and `findingSearch`
returns null. The catcher reports
`Cannot read properties of null (reading 'addEventListener')`.
`boot()` rejects on the `await wire()` chain. Render never happens.

Both cases produce a dashboard that looks completely dead with no
visible JS error in the standard console — only the onerror catcher
sees it.

## The discipline: rename in 4 places at once

When renaming or deleting any feature that has DOM bindings:

1. **Function definition:** `function chatOpen() { ... }`
2. **Export object:** `window.__wex = { chat: chatOpen, ... }`
3. **wire() selectors:** remove `$('#oldButtonId').addEventListener(...)`
4. **All callsites:** `chatShow()` → `chatOpen()`, `chatHide()` → `chatClose()`

Grep audit after the edit:

```bash
# Find any remaining references to the old name
rg -n '\bchatShow\b' dashboard.js
rg -n '\bchatHide\b' dashboard.js

# Find all addEventListener calls — sanity-check each selector exists in the new HTML
rg -n "addEventListener" dashboard.js

# Verify all $() selectors resolve to elements in the new HTML
rg -oE "\\\$\\(['\"][a-zA-Z][a-zA-Z0-9_-]+['\"]\\)" dashboard.js | sort -u
# Then cross-reference against index.html ids
```

## The defensive wiring pattern

Instead of trusting that every selector resolves:

```js
// BAD — throws on null
$('#findingSearch').addEventListener('input', onSearchInput);

// GOOD — silently skips if missing
const searchEl = $('#findingSearch');
if (searchEl) searchEl.addEventListener('input', onSearchInput);

// EVEN BETTER — log skipped bindings so the next round catches them
const skipIfMissing = (sel, fn, evt='click') => {
  const el = $(sel);
  if (!el) { console.warn('[wire] missing:', sel); return; }
  el.addEventListener(evt, fn);
};
skipIfMissing('#findingSearch', onSearchInput, 'input');
skipIfMissing('#newScanBtn', onNewScan);
```

The `skipIfMissing` wrapper surfaces missing selectors as warnings
in the console instead of hard-throwing. The dashboard renders in
a degraded state instead of failing entirely.

## The boot() shape that survives this

```js
async function boot() {
  try {
    await Promise.allSettled([
      loadScans(),
      loadStatus(),
    ]);
  } catch (e) {
    console.error('[boot] preload failed:', e);
    // continue — render empty state instead of nothing
  }
  try {
    wire();      // never throws — skipIfMissing handles gaps
  } catch (e) {
    console.error('[boot] wire failed:', e);
  }
  try {
    render();    // defensive — null-guards on every $()
  } catch (e) {
    console.error('[boot] render failed:', e);
  }
  // even if everything above failed, status pill still works
  setConnState('ready');
}
```

Three `try/catch` boundaries means a failure in any one stage
doesn't take down the others. The user sees a degraded dashboard
with warnings in console, not a frozen page.

## Cache-buster discipline

Every JS or CSS edit to the v2 dashboard files MUST bump the
`?v=N` query string on the script/link tags:

```html
<link rel="stylesheet" href="/v2/dashboard.css?v=6">
<script type="module" src="/v2/dashboard.js?v=12"></script>
```

Without this, the browser caches the broken version and every fix
appears to do nothing. Use a single integer that bumps on every
edit. Don't use content hashes — the integer is faster to scan-diff
in commit history.

## Verification ladder after a wire() change

1. `node -c dashboard.js` — syntax check
2. Bump `?v=N` cache-buster on CSS and JS in `index.html`
3. `browser_navigate /v2?v=N+1` (the URL cache-buster too — bypasses HTML cache)
4. `browser_console expression="window.__errs.join('\\n\\n')"` — should be empty
5. `browser_console expression="Object.keys(window.__wex).length"` — should be the expected count
6. Click each topbar nav link, each dialog trigger, the chat tab — verify each opens the right panel
7. Only then report done.

If step 4 shows even one entry, the fix is incomplete. Don't ship.